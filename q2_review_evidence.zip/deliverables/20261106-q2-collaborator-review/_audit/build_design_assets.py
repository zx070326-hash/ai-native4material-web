"""Deterministic Q2 vector drawings from audited saved geometry; no simulation."""
from pathlib import Path
import hashlib, html, json, math
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parents[1];AS=OUT/'assets';AS.mkdir(parents=True,exist_ok=True)
INK='#173b3d';MUT='#52696a';TEAL='#24796f';BLUE='#356f98';GOLD='#986b26';RED='#a84b44'
COL={'Al₂O₃':('#eee0bd','#9b793d'),'ZnO':('#d8cee9','#75608c'),'SiNₓ':('#d0e3f0','#467a9c'),'E7':('#cee7df','#398575'),'碳筛':('#536166','#344348')}
def esc(x):return html.escape(str(x),quote=True)
def text(x,y,s,size=20,fill=INK,weight=400,anchor='start'):
 return f'<text x="{x}" y="{y}" font-size="{size}" fill="{fill}" font-weight="{weight}" text-anchor="{anchor}">{esc(s)}</text>'
def lines(x,y,ss,size=19,step=29,fill=MUT):return ''.join(text(x,y+i*step,s,size,fill)for i,s in enumerate(ss))
def rect(x,y,w,h,fill='white',stroke='#ccdbd7',r=0,extra=''):return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" stroke="{stroke}" {extra}/>'
def line(x1,y1,x2,y2,color='#8ba6a1',width=1.5,extra=''):return f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{color}" stroke-width="{width}" {extra}/>'
def arrow(x1,y1,x2,y2,color=TEAL):return line(x1,y1,x2,y2,color,2.2,'marker-end="url(#arrow)"')
def path(d,color=TEAL,width=2,fill='none',extra=''):return f'<path d="{d}" stroke="{color}" stroke-width="{width}" fill="{fill}" {extra}/>'
def panel(x,y,w,h,title,sub=None):return rect(x,y,w,h,'#fff','#d2e0db',15)+text(x+24,y+38,title,25,weight=700)+(text(x+24,y+68,sub,17,MUT)if sub else '')
def svg(name,w,h,title,desc,body):
 s=f'''<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}" role="img" aria-labelledby="title desc"><title id="title">{esc(title)}</title><desc id="desc">{esc(desc)}</desc><defs><marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0L10 5L0 10Z" fill="{TEAL}"/></marker><pattern id="hatch" width="8" height="8" patternUnits="userSpaceOnUse"><path d="M0 8L8 0" stroke="#abbdb7" stroke-width="1"/></pattern></defs><g font-family="Arial,Microsoft YaHei,Noto Sans CJK SC,sans-serif">{rect(0,0,w,h,'#f5f9f7','#d1dfda',20)}{body}</g></svg>'''
 (AS/name).write_text(s,encoding='utf-8');return s
def heading(title,sub):return text(38,49,title,33,weight=700)+text(40,84,sub,20,MUT)
AR=.08302889342260214
LAYERS=[('入口氧化层 / AR','Al₂O₃',AR),('驱动入口电极','ZnO',.0998),('驱动入口板','Al₂O₃',8),('内配向 / 绝缘','SiNₓ',.02),('电控液晶 · P = 12 µm','E7',2.5),('内配向 / 绝缘','SiNₓ',.02),('驱动出口板','Al₂O₃',8),('驱动出口电极','ZnO',.0998),('出口氧化接合层','Al₂O₃',AR),('被动补偿入口板','Al₂O₃',9.8),('内配向 / 绝缘','SiNₓ',.02),('正交被动补偿 · P = 12 µm','E7',2.5),('内配向 / 绝缘','SiNₓ',.02),('补偿 / 热胞共享板','Al₂O₃',8),('内配向 / 绝缘','SiNₓ',.02),('热液晶 · P = 24 µm','E7',8.55),('内配向 / 绝缘','SiNₓ',.02),('最终出口板','Al₂O₃',8)]
def stack():
 b=heading('题二 · 全固体连接的三液晶胞','固定同器件四态：25 / 50 °C × 外加 0 / 9.235 Vᵣₘₛ；厚度标签为真实法向尺寸，绘图不按比例')
 b+=panel(30,118,990,790,'材料截面与连接身份','光沿 +z 自上向下；外电极指驱动盒的外置端面，接合后上端电极位于复合壁内部')
 x,y,w=105,223,338;heights=[22,24,42,22,47,22,42,24,26,56,22,47,22,42,22,60,22,42];ends=[]
 for i,((role,mat,t),hh)in enumerate(zip(LAYERS,heights)):
  f,st=COL[mat];b+=rect(x,y,w,hh,f,st)+text(x+14,y+hh/2+7,mat,19,weight=700)
  b+=line(x+w+8,y+hh/2,480,y+hh/2,'#a6bab4',1,'stroke-dasharray="3 3"')
  thick=f'{t*1000:.2f}'.rstrip('0').rstrip('.')+' nm'if t<1 else f'{t:g} µm'
  b+=text(492,y+hh/2+7,role,18)+text(974,y+hh/2+7,thick,18,fill=st,weight=700,anchor='end');ends.append((y,y+hh));y+=hh
 b+=arrow(69,225,69,815)+text(57,207,'+z',18,TEAL,700)
 # Adjacent same-material oxide and plate, physical seam visible but no retained gap.
 y0,y1=ends[8][0],ends[9][1]
 b+=rect(99,y0-3,350,y1-y0+6,'none',TEAL,0,'stroke-width="3"')
 b+=line(105,ends[8][1],443,ends[8][1],TEAL,2,'stroke-dasharray="6 4"')
 b+=text(106,872,'接合面虚线：实体边界仍保留；两侧同 n，无内部 air / 胶 / 新种子膜。',18,MUT)
 b+=panel(1040,118,530,365,'层数必须分三种口径')
 b+=text(1065,210,'19 个保留实体',30,TEAL,700)+lines(1065,246,['屏前 18 个 + 外置碳筛 1 个。','五片支持板、三 LC、六 SiNₓ、','两 ZnO、两氧化层、碳筛。'],20)
 b+=text(1065,362,'18 个合并光学材料层',27,BLUE,700)+lines(1065,398,['83.03 nm 氧化层 + 单 9.8 µm 板','连续等效 Al₂O₃ = 9.88303 µm。'],19)
 b+=panel(1040,505,530,265,'光学厚度 ≠ 机械包深')
 b+=lines(1065,578,['驱动 Al 8 / ZnO .0998 / 氧化层','Al .083028893 / 被动 Al 9.8 µm','组成无滑移机械复合壁：'],20)
 b+=text(1065,684,'总深 17.98283 µm',27,GOLD,700)+text(1065,724,'ZnO 隔开两段 Al，不是单个超厚 Al 层。',18,MUT)
 b+=panel(1040,793,530,215,'计算切分与总厚')
 b+=lines(1065,862,['未合并：屏前 20 段，含碳筛 21 段。','Al 4 + 4 是同一 8 µm 共享板；','新增 Al 1.8 是 9.8 µm 板的计算切分。'],19)
 b+=text(1065,969,'屏前总轴向厚 55.83566 µm',20,TEAL,700)
 b+=panel(30,930,990,165,'最终出口与环境屏平面')
 b+=arrow(75,1012,370,1012)+rect(400,981,12,70,'#536166','#344348')+text(455,1007,'5 µm 碳筛：外置环境平面，非第六片支持板',23,weight=700)+text(455,1042,'中心距最终热 Al₂O₃ 出口 10 mm；倾角 25°。',20,MUT)
 b+=text(38,1131,'所有法向材料层 0.020–9.88303 µm；厚度与整体挠度分列。示意不证明释放、无空隙接合、残余应力或完整制程。',18,MUT)
 return svg('q2_stack_cross_section.svg',1600,1160,'全固态三胞光学与物理层序','18个屏前实体和外置碳屏构成19实体；连续氧化层与9.8微米板合为9.883微米光学层。截面不按比例，实际厚度逐层标注。',b)
def plan():
 b=heading('题二 · 光区、流体支路与外置选择屏','器件平面 x / y 与输出屏投影 x / y 分图；各图比例独立。实线为已定义几何，虚线为尚待工艺细化的提案。')
 b+=panel(30,118,730,777,'三胞重叠光区：局部俯视','所有长度 µm；环与分支是保留外围路径，不能从主光路层数中推掉。')
 cx,cy,s=335,410,.82
 def xy(x,y):return cx+x*s,cy+y*s
 for r,fill,st in [(170,'#e6e4db',GOLD),(150,'#fff','#9b793d')]:b+=f'<circle cx="{cx}" cy="{cy}" r="{r*s}" fill="{fill}" stroke="{st}" stroke-width="2"/>'
 b+=rect(cx-105*s,cy-105*s,210*s,210*s,'#eff5f2',TEAL,0,'stroke-dasharray="6 4"')
 b+=rect(cx-75*s,cy-75*s,150*s,150*s,'#cfe6dd',TEAL)+text(cx,cy+7,'150 × 150',20,TEAL,700,'middle')
 # Eight equal easy-axis bands depict actual lateral feature size, orientation schematic.
 for i in range(8):
  xx=cx-70+i*20
  b+=line(xx,cy-78,xx+10*math.cos(i*math.pi/8),cy-78+10*math.sin(i*math.pi/8),BLUE,3)
 b+=arrow(cx-170,cy+183,cx-50,cy+183)+text(73,620,'电 / 补偿沿 x：P12 µm，最小带 1.5 µm',18,BLUE)
 b+=arrow(cx-190,cy+70,cx-190,cy-50)+text(73,650,'热胞沿 y：P24 µm，最小带 3 µm',18,BLUE)
 b+=path(f'M{cx+123} {cy-57}L574 {cy-111}L704 {cy-111}',GOLD)+text(559,cy-128,'液腔环 r = 150–170',18,GOLD)
 b+=path(f'M{cx+86} {cy-86}L560 231',TEAL)+text(416,215,'配向区 x,y = ±105',18,TEAL)
 b+=text(73,703,'环裸高度：2.54 / 2.54 / 8.59 µm',20,GOLD,700)
 b+=text(73,738,'a = 150 µm：夹固薄板情景。',18,MUT)+text(73,765,'基片外缘与接合重叠面尚未定尺寸。',18,MUT)
 # Three branches at distinct z, routes explicitly schematic.
 for i,(port,color)in enumerate(zip([(250,300),(250,400),(250,500)],[TEAL,BLUE,GOLD])):
  px,py=xy(*port);start=xy(155,20+i*25)
  b+=path(f'M{start[0]} {start[1]}H{px-40}V{py}H{px}',color,20*s,extra='stroke-linejoin="round" opacity=".55"')+f'<circle cx="{px}" cy="{py}" r="{10*s}" fill="white" stroke="{color}" stroke-width="2"/>'
  b+=text(px+16,py+5,f'({port[0]}, {port[1]})',16,color)
 b+=text(452,620,'三条独立 z 层支路',18,MUT)+text(452,647,'宽 20；路线为提案',17,MUT)
 b+=rect(80,307,73,54,'#eee7f5','#75608c',5,'stroke-dasharray="5 4"')+text(116,340,'ZnO',17,'#75608c',700,'middle')+path('M153 335L205 360','#75608c')
 b+=text(71,281,'接触 tab 在接合区外 / 显式缺口',18,'#75608c')
 b+=text(65,840,'移除旧模块 r180–200 环形支座；本图不将其计作保留垫片。',18,RED)
 b+=panel(790,118,780,497,'原 600 选择屏：前向投影坐标','筛材料为碳 5 µm；旧核文件的 Ni 名称不代表当前筛材料。孔为三条固定槽。')
 ox,oy,sc=1180,350,.12
 b+=rect(ox-3000*sc,oy-900*sc,6000*sc,1800*sc,'#5b696d','#344348')
 for lo,hi in [(-2500,-600),(-200,200),(600,2500)]:b+=rect(ox+lo*sc,oy-600*sc,(hi-lo)*sc,1200*sc,'#f5f9f7','#d8e5df')
 b+=line(ox,oy-126,ox,oy+126,'#b2c8c0',1,'stroke-dasharray="5 4"')+line(ox-325,oy,ox+325,oy,'#b2c8c0',1,'stroke-dasharray="5 4"')
 b+=text(ox,oy+7,'400',16,TEAL,700,'middle')
 b+=text(830,230,'x: [−2500,−600] ∪ [−200,200] ∪ [600,2500]',19,weight=700)
 b+=text(830,516,'名义 y = ±600；每条边保守内收 11 µm。',20,TEAL,700)
 b+=lines(830,550,['积分域：x [−2489,−611] / [−189,189] / [611,2489]；y ±589。','整屏投影外缘 20 × 15 mm，未在局部孔图中按同一比例绘出。'],18,26)
 b+=panel(790,639,780,256,'最终出口到屏：y–z 侧视','10 mm 沿 z 定义，倾斜参考为 z = 10000 + y tan 25°（µm）。')
 b+=line(850,813,1490,813,'#abc0b7',1,'stroke-dasharray="5 4"')+rect(890,730,13,120,'#eee0bd','#9b793d')+arrow(916,813,1367,813)+line(1372,725,1447,882,'#536166',8)
 b+=text(921,776,'z₀ = 10 mm',22,TEAL,700)+text(842,875,'最终热胞 Al8 出口',18,MUT)+text(1439,745,'25°',22,INK,700)+text(1451,872,'碳屏',18,MUT)
 b+=panel(30,921,1540,169,'套准与边界的正确读法')
 b+=lines(58,990,['电控 / 被动补偿共享 P12 易轴纹理；补偿横向套准 6 µm，对应 π/2 轴相位，不是另加旋转后的第二次位移。','热胞相对驱动纹理在空间与轴向同时转 90°。硬截断 Gaussian 的 waist = 75 µm，完整 Gaussian 入射功率作分母。','接触 tab 形状、支路曲折路线、基片外形 / 重叠边界仍是工艺提案；当前投影是周期求场后施加有限出口包络，非全器件有限边界 Maxwell。'],19,29)
 return svg('q2_aperture_layout.svg',1600,1120,'全固态器件光区流体接点与环境选择屏','局部器件俯视标明150微米光区、210微米配向区、液腔环、三20微米支路及接触提案；分图标明原600孔和10毫米25度屏参考。',b)
def assembly():
 b=heading('题二 · 提议的干态装配顺序','这是一条可衔接的工艺提案，尚未制样；箭头表示顺序与接口，不表示已完成或已获得制造良率。')
 cards=[(30,142,'先制外部功能面','驱动出口板在载体上：Al8 → ZnO99.8 nm → 最终氧化层83.03 nm。'),(560,142,'干态直接氧化物接合','单 9.8 µm 被动入口板，与现有83 nm 氧化层直接接合；先于 LC 注液。'),(1090,142,'加工两侧内液晶面','复合壁两侧内面保持可达；六20 nm SiNₓ与8步易轴图案分面完成。'),(30,555,'完成三腔外围组装','保留三液腔环及通大气支路；补偿 / 热胞共享Al8，接上其余Al8外壁。'),(560,555,'独立填充与电接触','三腔分路注入E7并保留通大气液面；ZnO接点在重叠区外或显式缺口。'),(1090,555,'装外筛并核对参考','碳5 µm筛置于最终出口后10 mm、25°；原600三槽与11 µm影预算。')]
 for x,y,title,sub in cards:
  b+=panel(x,y,480,355,title)
  # Controlled line wrapping by stage.
  ss={'先制外部功能面':['驱动 Al8 先留在载体上。','外表面 ZnO 99.8 nm +','最终 Al₂O₃ 83.03 nm。'], '干态直接氧化物接合':['单9.8 µm被动入口板接合原氧化层。','连续Al = 9.88303 µm。','无新胶 / 种子层 / 保留内部air。'], '加工两侧内液晶面':['两侧各自制20 nm SiNₓ。','8步易轴最小带：1.5 / 3 µm。','避免后续工序破坏已完成表面。'], '完成三腔外围组装':['三裸腔高度2.54 / 2.54 / 8.59 µm。','余下壁与共享Al8构成三个液腔。','释放、夹持和边界刚度仍待核验。'], '独立填充与电接触':['三条20 µm支路分别连通环境。','不将液面气封热压强加给此版本。','接点不得被无定义的接合面覆盖。'], '装外筛并核对参考':['最终出口为距离零点。','整器件共同25 / 50 °C，','同一0 / 9.235 Vᵣₘₛ四态。']}[title]
  b+=lines(x+23,y+250,ss,18,27)
  # Miniature, layer-faithful pictograms; thicknesses deliberately exaggerated.
  yy=y+90
  if x==30 and y==142:
   b+=rect(x+60,yy+82,350,16,'url(#hatch)','#9aaea7')+rect(x+60,yy+36,350,46,*COL['Al₂O₃'])+rect(x+60,yy+23,350,13,*COL['ZnO'])+rect(x+60,yy+9,350,14,*COL['Al₂O₃'])+text(x+68,yy-4,'外部面 ↑  /  暂留载体 ↓',17,MUT)
  elif x==560 and y==142:
   b+=rect(x+60,yy+12,350,38,*COL['Al₂O₃'])+rect(x+60,yy+50,350,12,*COL['Al₂O₃'])+rect(x+60,yy+62,350,12,*COL['ZnO'])+rect(x+60,yy+74,350,38,*COL['Al₂O₃'])+line(x+60,yy+50,x+410,yy+50,TEAL,3,'stroke-dasharray="6 4"')+text(x+70,yy-4,'9.8 µm 板 / 氧化层 / ZnO / Al8',17,MUT)
  elif x==1090 and y==142:
   b+=rect(x+60,yy+24,350,72,*COL['Al₂O₃'])+rect(x+60,yy+12,350,12,*COL['SiNₓ'])+rect(x+60,yy+96,350,12,*COL['SiNₓ'])
   for j in range(8):b+=line(x+75+j*42,yy+4,x+95+j*42,yy+4,BLUE,3)+line(x+75+j*42,yy+117,x+95+j*42,yy+123,BLUE,3)
  elif x==30:
   for j in range(4):b+=rect(x+60,yy+j*30,350,15,*COL['Al₂O₃'])
   for j in range(3):b+=rect(x+60,yy+15+j*30,26,15,'#e6e4db',GOLD)+rect(x+384,yy+15+j*30,26,15,'#e6e4db',GOLD)+text(x+235,yy+28+j*30,['2.54','2.54','8.59'][j],15,MUT,400,'middle')
  elif x==560:
   for j,c in enumerate([TEAL,BLUE,GOLD]):b+=path(f'M{x+65} {yy+15+j*35}H{x+330}V{yy+30+j*35}H{x+400}',c,12)+f'<circle cx="{x+400}" cy="{yy+30+j*35}" r="9" fill="white" stroke="{c}" stroke-width="2"/>'
  else:b+=rect(x+60,yy+15,10,105,*COL['Al₂O₃'])+arrow(x+82,yy+68,x+354,yy+68)+line(x+367,yy+7,x+411,yy+121,'#536166',7)+text(x+143,yy+47,'10 mm / 25°',22,TEAL,700)
 b+=arrow(514,305,551,305)+arrow(1044,305,1081,305)+arrow(514,719,551,719)+arrow(1044,719,1081,719)
 b+=path('M1530 500V526H270V548',TEAL,2,extra='marker-end="url(#arrow)"')
 b+=rect(30,940,1540,164,'#fbf0e8','#dcc1ad',13)+text(55,980,'必须移除旧模块间支座；接合面应覆盖实际整个重叠面。',23,RED,700)
 b+=lines(55,1018,['旧 r180–200 µm 模块支座若保留，会重新撑开间隙。仅在光区做83 nm小凸台会在外围留下空隙，不能称全固体连接。','表面平整度、活化后最终厚度 / 光谱、薄板释放、无空洞接合、后续热史 / 图案转移与LC湿润，均不是这张流程图已证明的能力。','壁总深17.982829 µm属于机械复合结构；单一连续Al光学块9.88303 µm。最终层账本和真实样品截面须逐项对应。'],18,28)
 return svg('q2_proposed_dry_assembly.svg',1600,1130,'提议的全固态三胞干态装配流程','六个连续工艺环节，先干态制外电极和氧化层，再无新增膜直接接合9.8微米板，完成内SiNx图案及外围液腔后填充，最后装10毫米25度碳屏。流程尚未制造验证。',b)
def main():
 stack();plan();assembly()
 z=0.;ll=[]
 for role,mat,t in LAYERS:ll.append({'role':role,'material':mat,'normal_thickness_um':t,'axial_start_um':z,'axial_end_um':z+t});z+=t
 sources=['scripts/build_q1_collaborator_review.py','deliverables/20261104-q1-collaborator-review/q1_academic_design.svg','STATE.md','runs/20261105-q2-finish-decouple-solid-interface-optics64-127-0-01/launch.json','runs/20261105-q2-finish-assembly-d8p55-ledger-01/results.json','runs/20261105-q2-finish-assembly-solid-plate-01/results.json','experiments/q2_package_device_20261105.py','notes/q2_finish_assembly_20261105.md']
 spec={'status':'Conditional all-solid candidate; design communication, not fabrication drawing or manufactured device','layers_before_screen':ll,'screen':{'material':'Hagemann carbon source transferred to free foil','normal_thickness_um':5,'center_distance_from_final_thermal_Al_exit_um':10000,'tilt_deg':25,'plane_equation_um':'z=10000+y*tan(25deg)','projected_external_extent_um':[20000,15000],'nominal_holes_x_um':[[-2500,-600],[-200,200],[600,2500]],'nominal_holes_y_um':[-600,600],'conservative_edge_inset_um':11,'effective_x_um':[[-2489,-611],[-189,189],[611,2489]],'effective_y_um':[-589,589],'legacy_kernel_note':'Geometry/source contains historical Ni names; current screen optical response is carbon.'},'counts':{'physical_retained_including_screen':19,'merged_optical_layers_including_screen':18,'unmerged_computational_before_screen':20,'unmerged_computational_including_screen':21,'physical_support_pieces':5,'mechanically_connected_wall_assemblies':4},'thickness_identity':{'contiguous_oxide_plus_passive_Al_um':AR+9.8,'mechanical_bonded_wall_depth_um':8+.0998+AR+9.8,'prescreen_axial_envelope_um':z,'normal_layer_thickness_vs_bow':'Solid normal material thickness, whole-wall displacement, and LC normal gap are separate quantities. ZnO separates Al8 from contiguous Al9.883; mechanical17.9828 is not a single Al optical layer.'},'local_layout':{'units':'um','illumination_hard_square_xy':[-75,75],'Gaussian_waist':75,'normalization':'Full untruncated Gaussian incident power; exit hard-envelope approximation','alignment_square_xy':[-105,105],'LC_ring_inner_outer_radius':[150,170],'mechanical_clamp_radius_scenario':150,'bare_cavity_heights':[2.54,2.54,8.59],'LC_flat_normal_gaps':[2.5,2.5,8.55],'pattern_period_drive_passive_thermal':[12,12,24],'eight_step_min_band_drive_thermal':[1.5,3],'passive_registration_x':6,'thermal_spatial_and_axis_rotation_deg':90,'branch_width':20,'recorded_proposed_ports_xy':[[250,300],[250,400],[250,500]],'branch_route':'Drawing route schematic; channels at separate LC z levels','removed_old_intermodule_standoff_radius':[180,200],'contact_geometry':'Proposed only, outside actual overlap or explicit notch; exact mask dimensions undefined','substrate_outline_and_overlap_extent':'Not fully dimensioned; not inferred from mechanical circle or pattern square'},'dry_assembly':{'stage_titles':['Prepare external faces on carrier','Direct dry oxide bond to single9.8um passive plate','Prepare exposed inner SiNx/easy-axis faces','Assemble retained cavity rings and remaining walls','Fill E7 through separate vented branches/contact electrodes','Mount carbon screen from final exit reference'],'removed':'Old intermodule Al standoff; no retained glue, seed layer or internal air','bond_footprint':'Final83nm oxide must cover actual entire overlap/bond surface, not just optical square','unproven':['Surface roughness and activation process','Final oxide thickness/spectrum after activation','Released thin Al support flatness and residual stress','Void-free no-slip direct bond and thermal compatibility','SiNx anchoring/1.5um easy-axis transfer','Real contact/branch/edge masks','Bow-coupled director/optical response']},'figure_conventions':{'all_cross_section_heights':'Not to scale; physical layer dimensions printed','independent_plan_scales':True,'solid_lines':'Defined geometry/material boundaries','dashed_lines':'Physical same-material bond seam or proposed process boundary, labelled in each drawing','font':'Arial / Microsoft YaHei / Noto Sans CJK SC; SVG text retained','minimum_main_text_px':17,'no_badges':True},'evidence_sha256':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest()for p in sources},'assets':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted(AS.glob('q2_*.svg'))}}
 (OUT/'_audit/design_specification.json').write_text(json.dumps(spec,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps({'assets':spec['assets'],'prescreen_um':z,'counts':spec['counts']},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
