"""Extract the frozen Q2 partner materials audit; no optical or mechanical solve."""
from pathlib import Path
import csv,hashlib,json,math
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest()
load=lambda p:json.loads((ROOT/p).read_text(encoding='utf8'))
READ='runs/20261105-q2-finish-decouple-solid-interface-readout64-837-600-01'
rs=load(READ+'/results.json'); audit=load('runs/20261106-q2-finish-material-solid-constraints-01/results.json')
dense=load('runs/20261105-q2-finish-decouple-solid-interface-summary837-01/results.json')
row=next(x for x in dense['rows']if x['grid']=='837'and x['hole_inner_um']==600)
seven=load('runs/20261106-q2-finish-assembly-solid-order-peak-comparison-01/seven_point_summary.json')
assert math.isclose(rs['main']['VIS_conditional_lower_pp'],39.169174734014476,abs_tol=1e-12)
assert math.isclose(rs['main']['NIR_model_pp'],23.45309218420856,abs_tol=1e-12)
assert row['spectra_sha256']==sha(READ+'/spectra.npz')
assert not audit['A_evidence_closed'] and audit['A_model_range_pass'] and audit['B_reference_550nm_25C_model_pass']
g=rs['identity']['geometry_override'];assert g['effective_source_sha256']==audit['actual_effective']['execution_text_sha256']
def evidence(paths):
 return [{'repository_path':p,'sha256':sha(p)}for p in paths]

materials=[
 {'id':'E7_real_n','role':'Three nematic LC cells: driver2.5um, crossed passive2.5um, thermal8.55um',
  'source':{'title':'Infrared refractive indices of liquid crystals','doi':'10.1063/1.1877815','url':'https://doi.org/10.1063/1.1877815','source_phase':'E7 nematic at the tabulated15-50C temperatures','temperature_C':[15,20,25,30,35,40,45,50],'sample_thickness':'Different visible refractometry and infrared wedged-cell measurements; no matching2.5/8.55um patterned-device sample claimed','source_wavelength_um':[.450,.486,.546,.589,.633,.656,1.55,10.6]},
  'actual_use':'Separate25/50C rows of n=A+B/lambda^2+C/lambda^4 for ne/no; voltage changes director only.',
  'transformation':'Transcribed TableI coefficients; six visible lines fit.380-450nm and continuous NIR are extrapolation;1.55/10.6um are discrete checks, not continuous measured nk.',
  'unresolved_transfer':'Cross-batch combination with dielectric, anchoring and absorption sources. No continuous same-cell anisotropic complex25/50C spectrum; no below400nm Maxwell result.',
  'evidence':evidence(['data/q2_current/Li2005_E7_Cauchy.csv','.worktrees/q2-dual-response/data/literature/q2_lc_thermal_20261101/Li2005_E7_source.json'])},
 {'id':'E7_absorption','role':'Common isotropic loss assigned to both axes in all three LC cells',
  'source':{'title':'Molecular Design Strategies for High Birefringence Liquid Crystals','doi':'10.1557/PROC-709-CC7.2.1','url':'https://lcd.creol.ucf.edu/publications/2002/MRS.pdf','source_phase':'Merck E7 isotropic','temperature_C_approx':70,'sample_path_cm':2,'reference_path_cm':.1,'differential_path_cm':1.9,'source_figures':'Fig7 400-1700nm; Fig8 1600-3200nm'},
  'actual_use':'alpha is linearly interpolated then k=alpha_cm^-1*lambda_um*1e-4/(4pi); same k applied to ne/no at25/50C. Final candidate uses nominal curve, not max(k,.001) pressure.',
  'transformation':'Vector marker digitization and stated natural-log intensity-alpha conversion.380-400nm model holds first alpha; weakly overlapping source graphs joined with traceable data.',
  'unresolved_transfer':'Isotropic70C→nematic25/50C and axis dichroism unknown. Source Fig8 still labels1.9cm differential path while target-bandalpha~33.7cm^-1 would imply optical depth~64; detector dynamic range/shorter-cell calibration is not documented. This is an unresolved traceability question, not proven invalidation. No KK-consistent joint n,k uncertainty bound.',
  'evidence':evidence(['data/q2_parallel_loss_20261105/source_audit.json','data/q2_parallel_loss_20261105/Wu2002_MRS.pdf','data/q2_parallel_loss_20261105/Wu2002_E7_graph_alpha_k.csv'])},
 {'id':'E7_dielectric','role':'1kHz Frank-Gauss driver field at one common external0/9.235Vrms',
  'source':{'title':'Basu and Kehr2025 pure-E7 control, Micromachines16,457','doi':'10.3390/mi16040457','url':'https://doi.org/10.3390/mi16040457','source_phase':'Pure EMD E7 nematic control; not CNT mixture','temperature_C_domain':[25,60],'cell_thickness_um':20,'sample':'Commercial rubbed planar cell; ethanol preparation and4h vacuum degassing; clearing60C'},
  'actual_use':{'delta_epsilon25_50':[12.34304932735426,9.80080245456691],'epsilon_perp25_50':[4.886949076291233,4.886949076291233]},
  'transformation':'Native Fig4b red pure-control symbols digitized; Fig4a low-field plateau estimates epsilon_perp25 only.',
  'unresolved_transfer':'epsilon_perp50 is held, not measured. Different batch, alignment, cell thickness and processing than the optical/K sources and proposedSiNx device.',
  'evidence':evidence(['runs/20261105-q2-finish-decouple-E7-constitutive-source-01/E7hCNT2025.pdf','runs/20261105-q2-finish-decouple-E7-constitutive-digitized-01/Basu2025_Fig4b_pureE7_1kHz.csv','runs/20261105-q2-finish-source25-config-01/config.json'])},
 {'id':'E7_elasticity','role':'Frank splay/twist/bend energies in the frozen director fields',
  'source':{'title':'Huang and Tu, Current Applied Physics10(2010)561-564; independent constitutive comparator','doi':'10.1016/j.cap.2009.07.022','url':'http://www.yxhuang.cn/paper/paper/dependence.pdf','source_phase':'Slichem E7 nematic, clearing58C','temperature_C':[25,30,35,40],'cell_thickness_um':25,'alignment':'Rubbed planar polymer; PVA in methods/PI in discussion; varied pretilt'},
  'actual_use':{'K25_pN':[11.1,6.5,17.1],'K50_pN':[5.646076171459213,3.3062608211247646,8.698009237112842],'temperature_rule':'All3K scale by [Li2005dn589(T)/dn589(25)]^2. Baseline K25 values are assigned model inputs, not extracted fromHuang Fig4.'},
  'transformation':'Huang actual K11/K22 curve independently digitized only to test common-temperature-scaling assumptions; noK33 or50C points fabricated.',
  'unresolved_transfer':'Huang mode-specific K11/K22 temperature ratios differ and do not validate common dn^2 law, assignedK33 or0deg patternedSiNx anchoring. beta<1deg DLS absence is notK=0. Candidate is conditional on the stated elastic model.',
  'evidence':evidence(['runs/20261105-q2-finish-constitutive-material-source-01/source.pdf','runs/20261105-q2-finish-constitutive-material-digitized-01/Huang2010_Fig4_independent_curves.csv','runs/20261105-q2-finish-constitutive-material-digitized-01/results.json','runs/20261105-q2-finish-assembly-phase25-d8p55-source64-01/results.json'])},
 {'id':'SiNx_optical','role':'Six retained20nm insulating alignment films; actual legacy adapter filename containsDLC but material isSiNx',
  'source':{'title':'Development of ion-beam sputtered silicon nitride thin films for low-noise mirror coatings of gravitational-wave detectors','doi':None,'url':'https://arxiv.org/abs/2409.07147v2','verified_local_version':'v2,10February2025, from retainedPDFpage1','source_phase':'IBS SiNx sample23028, not generically any stoichiometricSi3N4','source_film_family_thickness_nm':[50,500],'sample23028_precise_thickness_nm':None,'measurement_temperature':'No matching25/50C pair in the selected Fig4 curve','deposition':'700V,195mA,N2/Ar flowratio2; unannealed Fig4 model, not900C-annealed spectrum'},
  'actual_use':'Native-vector Fig4 complex model380-2500nm; same spectrum at25/50C; n550=2.1068334072.',
  'transformation':'2126-node vector digitization; linear complex interpolation; positive fitted k retained. Above560nm author says k below instrument sensitivity: fitted tinyk is not measured zero/upper bound.',
  'unresolved_transfer':'IBS optical film→20nm ion-treated alignment surface and bothT. No matching-wafer epsilon7.5/Wa/Wp;1.5um8direction pattern not validated by this optical source.',
  'evidence':evidence(['data/q2_finish_material_20261105/SiNx_Amato2025.pdf','runs/20261105-q2-finish-material-SiNx-extract-01/SiNx23028_vector.csv','data/q2_finish_material_20261105/SiNx_spectrum/DLC_4keV_vector_digitized.csv'])},
 {'id':'SiNx_alignment_and_anchoring','role':'Planar easy-axis process precedent and assigned finite anchoring',
  'source':{'title':'Liquid Crystal Alignment Effects on SiNx Thin Film Layers Treated by Ion-Beam Irradiation','doi':'10.1143/JJAP.46.7711','url':'https://doi.org/10.1143/JJAP.46.7711','available_evidence':'Publisher/indexed abstract and metadata; savedIOPresponse is captcha, not fullpaper','source_phase':'PECVD SiNx ion-beam alignment precedent','temperature_and_thickness':'Not verified from fullpaper; no invented values','supporting_primary_fulltext':'https://www-ssrl.slac.stanford.edu/stohrgroup/publications/2001/Nature-411-56-01.pdf'},
  'actual_use':{'pretilt_deg':0,'azimuthal_Wa_J_m2':.000114,'polar_Wp_J_m2':.0002,'SiNx_lowfrequency_epsilon':7.5,'Al2O3_lowfrequency_epsilon':9},
  'transformation':'Wa1.14e-4 transferred from Chang2007a-C:H60deg treatment, doi10.1016/j.tsf.2007.04.039 (~20nmcarbon,pretilt~1.4deg). Wp2e-4, pretilt0 and dielectric7.5/9 remain scenario assignments, not thatSiNxmeasurement.',
  'unresolved_transfer':'OpticalIBSfilm, PECVDalignmentprecedent and a-C:Hanchoring are different samples/processes. Need not call them measured joint material parameters. Full eightdirection treatment/dose/contamination/temporary-mask removal remains proposed.',
  'evidence':evidence(['data/q2_finish_material_20261105/Lee2007_crossref.json','data/q2_finish_material_20261105/source_manifest_final.json','data/q2_package_A_20261105/DLC_Nature2001.pdf','data/q2_package_A_20261105/Chang2007_E7_aCH.pdf','runs/20261105-q2-finish-material-mask-01/results.json'])},
 {'id':'ZnO','role':'Two99.8nm outer driver electrodes',
  'source':{'title':'Spectroscopic Ellipsometry Study on Tuning the Electrical and Optical Properties of Zr-Doped ZnO Thin Films Grown by Atomic Layer Deposition','doi':'10.1021/acsaelm.1c01026','url':'https://pmc.ncbi.nlm.nih.gov/articles/PMC9121516/','selected_sample':'Undoped reference Fig5d,notZr-dopedcurve','source_phase':'PolycrystallineZnOreference; scalarfit used','growth_temperature_C':200,'measurement_temperature':'roomtemperature','film_thickness_nm':99.8,'thickness_fit_uncertainty_nm':.3,'substrate':'SiO2/Si(100),555ALDcycles','source_domain_um':[.35,2.5]},
  'actual_use':'New1254x747Figure5d axes,335jointnodes; n550=2.0077902491,k2500=.041801115572scenario. Both25/50Cuse same graph.',
  'transformation':'Colorcolumnmedians and actualtickcalibration; linearinterpolation; rawslightlynegativek floored0. Greenvisiblecurveends2444.805nm; final55.195nm explicitly continued with anchored linearfit. Author measured to2500nm: dashedblank doesnotmeanunmeasured.',
  'unresolved_transfer':'PrintedAD/units-normalization ambiguity remains; AD*Gamma improvesgraphreproduction but isnotauthorerratum. Graphfittedrho isnotindependentDCtransport; contacts, operatingTtransport and opticalmigrationunclosed.',
  'evidence':evidence(['data/q2_finish_lead_ZnO_source_20261105/PMC9121516.1.pdf','data/q2_finish_lead_ZnO_source_20261105/Figure5_original.png','runs/20261105-q2-finish-material-ZnO-hires-calibration-01/results.json','runs/20261105-q2-finish-material-ZnO-hires-input-01/ZnO2022_Fig5d_hires_exactnodes_tail_linear_scenario.csv','runs/20261105-q2-finish-material-ZnO-hires-drude-01/results.json'])},
 {'id':'Al2O3','role':'Five structural plates, two83.028893nm exterior films; direct bonded continuous9.883028893um internal block',
  'source':{'title':'Dispersion model for optical thin films applicable in wide spectral range','doi':'10.1117/12.2190104','url':'https://doi.org/10.1117/12.2190104','source_phase':'Amorphous/veryfinepolycrystallineAl2O3 electron-beamevaporatedfilm','measurement_temperature':'roomtemperature','film_thickness_nm':121.5,'substrate':'c-Si','numerical_data':'Author-provideddataset preserved in pinnedrefractiveindex.info database','source_domain_um':[.114114,125.124]},
  'actual_use':'FullcomplexFrantaspectrum; four8umplates,one9.8umplate,two83.028893nmfilms; same25/50C.',
  'transformation':'Boundcheckedlinearcomplexinterpolation. Identicalepsilon contiguousexitoxide83.028893nm+physicalplate9.8um merges to9.883028893um. Algebraic shared4+4um cuts merge toone8umplate.',
  'unresolved_transfer':'121.5nm/e-beam/c-Sisource→releasedmicronplates,ARandidealno-voidoxidebond. Static dielectric9/mechanicalE170GPa/nu.22 are separate scenarios. Process,stress,CTE,bondslip andactualflatness not certified.',
  'evidence':evidence(['data/raw/Al2O3_Franta.yml','data/nk/Al2O3_Franta.csv','data/sources.json','runs/20261105-q2-finish-decouple-solid-interface-merge127-01/results.json','runs/20261105-q2-finish-assembly-solid-plate-01/results.json'])},
 {'id':'carbon_screen','role':'5um tilted finite screen with three xslots, fixedinner600/yhalf600 and11umshadow',
  'source':{'title':'Optical constants from the far infrared to the x-ray region','doi':'10.1364/JOSA.65.000742','url':'https://doi.org/10.1364/JOSA.65.000742','additional_url':'https://refractiveindex.info/download/data/1974/Hagemann%201974%20-%20DESY%20report%20SR-74-7.pdf','source_phase':'Hagemann carbon tabulated scalar dataset; exact equivalence to proposedfreefoil not established','source_temperature':'Not specified in retainedYAML; no25/50Cpair','source_film_thickness':'Not specified in retainedYAML','source_domain_um':[.00004133,124]},
  'actual_use':'Complexn,k interpolation forfinite-thicknessscreenR/T; nominal5um,screenblockingboundalso checks3.75/5/6.25um andangle/polarization.',
  'transformation':'No target-domainwavelengthendhold; finite-holephysical-opticsprojectionwithoutsideilluminationandscreenleakageincluded.',
  'unresolved_transfer':'Dataset→free5umcarbonscreen,25/50Cinvariance,screenflatness,supportandmachining. It isnot theoldDLC20nmalignmentfilm.',
  'evidence':evidence(['data/constraints_upgrade_sources/C_Hagemann.yml','data/constraints_upgrade_sources/C_Hagemann.csv','runs/20261105-q2-package-device-kernels-01/inner600/gram.npz'])}
]
states=[]
for vi,V in enumerate((0,9.235)):
 for ti,T in enumerate((25,50)):
  states.append({'voltage_index':vi,'temperature_index':ti,'external_voltage_V_RMS':V,'temperature_C':T,'VIS400_780_mean_T':rs['main']['metrics']['visible']['T_by_voltage_temperature'][vi][ti],'NIR780_2500_mean_T':rs['main']['metrics']['nir']['T_by_voltage_temperature'][vi][ti]})
with (OUT/'final_four_states.csv').open('w',newline='',encoding='utf8')as f:
 writer=csv.DictWriter(f,fieldnames=list(states[0]));writer.writeheader();writer.writerows(states)
result={'scope':'Q2 collaborator materials/literature audit and final frozen-data extraction; no new physics or external search',
 'candidate':{'temperatures_C':[25,50],'external_voltages_V_RMS':[0,9.235],'LC_thickness_um':[2.5,2.5,8.55],'LC_periods_um':[12,12,24],'source_fields_SHA256':audit['source_field_sha256'],'ZnO_SHA256':audit['ZnO_table_sha256'],'actual_adapter':audit['actual_adapter'],'actual_effective':audit['actual_effective'],'interface':audit['interface'],'layer_account':audit['layer_account'],'thickness':audit['thickness']},
 'final_837_inner600':{'actual_wavelengths':837,'periodic_states':3348,'main_VIS_lower_NIR_pp':[rs['main']['VIS_conditional_lower_pp'],rs['main']['NIR_model_pp']],'VIS_thermal_meanabs_peak_pp':[max(row['independent']['VIS_thermal_meanabs_pp']),max(row['independent']['VIS_thermal_peaks_pp'])],'NIR_voltage_meanabs_peak_pp':[max(row['independent']['NIR_electric_meanabs_pp']),max(row['independent']['NIR_electric_peaks_pp'])],'four_states':states,'periodic_numerics':row['periodic_numerics'],'union837_minus713_main_pp':dense['union837_minus_standard713']['600']['main_pp'],'selected7_point_control':seven['summary'],'metric_scope':'Equal-wavelengthexploration:VIS380-780withuncomputed380-400arbitrarypassivitysubtraction;NIR780-2500minacrossvoltages.PPmeansabsolutetransmittancepercentagepoints,notrelativepercent.','spectra_path':READ+'/spectra.npz','spectra_sha256':sha(READ+'/spectra.npz')},
 'constraints':{'A_model_range_pass':audit['A_model_range_pass'],'A_evidence_closed':False,'B_reference_550nm_25C_model_pass':True,'B_reference_is_not_A':True,'verified_model_n_rows':audit['rows_unchanged_from_existing_verified_bounds'],'evidence_limit':'n-range/extremaareactualmodelchecks,notcontinuousmeasuredsame-filmallstateconfidencebound.E7no25at2500nm=1.50053024hasonly0.00053024modelmargin.'},
 'materials':materials,
 'evidence_classification':{
  'dry_experiments':'Computational controls and reproducibility checks: exact-spectrum reintegration; source-graph/Drude conventioncomparison;analyticGaussgradientchecks; homogeneousAlsegmentationequivalence; nested713/837quadrature; sevenactualwavelengthjointorder/slicecontrol. Thesearebench-freecomputationalexperiments,notsamplemeasurements.',
  'simulations':'Frozen64x33Frank/Gaussdirectorfields at specifiedK/epsilon/W; periodicvectorcomplexcascades; tiltedfinite-screenenvelopeprojection; separateanalyticcapillary/composite-plate scenarios. LowRTAresidualisnumericalconsistency,notmaterialvalidation.',
  'proposed_fabrication':'Directdryoxidebondwithnoadhesive/void,210umsquare1.5umeasy-axispattern,temporary-maskremoval,release,contact/notch/filltabsandventedchannels. No actual fabricatedprototype,experimentalfourstates,retentionorcyclelifeclaimed.'},
 'reuse_instructions':'RepositoryrelativeevidencepathsandSHAidentifyreusableinputs; include selectedsourcePDFs/tables/readouts/codewhenpackaging. ThisauditJSONisnotitselfacompleteMaxwellreplaypackage. Preserveoriginalsourcebytesandfailed/negativecontrolsneededtounderstandboundaries.',
 'report_blockers':[{'severity':'provenance_label_correction','issue':'SomeoldSiNxnotes/extractreceiptcallretainedPDFv1;actualPDFpage1is2409.07147v2,10Feb2025.Thephysics/tablebytesareunchanged. Partnertextmustuseactualv2orSHA-specificcitation.'}],
 'full_problem_solved':False,'source_records_and_readouts':evidence([READ+'/results.json',READ+'/spectra.npz','runs/20261105-q2-finish-decouple-solid-interface-summary837-01/results.json','runs/20261106-q2-finish-material-solid-constraints-01/results.json','runs/20261106-q2-finish-assembly-solid-order-peak-comparison-01/seven_point_summary.json',str(Path(__file__).relative_to(ROOT))])}
(OUT/'materials_literature_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
md='''# 题二合作审阅：材料与证据边界

当前交付是同一全固体连接器件的条件仿真构造：25/50°C、外0/9.235 Vrms，驱动/补偿/热E7厚2.5/2.5/8.55µm；原内部空气被同源Al₂O₃替换。19个保留实体对应18个合并光学层；20个筛前/21个含筛计算分段包括共享Al4+4等代数切分，并非独立保留物体。9.8µm被动入口板与83.028893nm出口氧化层连续，总厚9.883028893µm；合并层厚20–9883.028893nm，上限模型余量116.971107nm。易轴带宽1.5µm。

837个实际波长的600孔主幅为VIS保守下界39.169174734pp、NIR温调23.453092184pp；VIS热串绝对谱均/采样峰8.649102/31.367574pp，NIR电串3.018847/17.729122pp。PP是透射率百分点。小带差含正负抵消，不等于逐谱无串扰；没有用户给定的串扰合格线。713→837主幅变化+.011341/+.026863pp，七点阶数/切片控制只覆盖实际选点与共同81模端口，不作全带误差证书。

`final_four_states.csv`保留四态带均透射；`materials_literature_audit.json`给出原始精度、完整源谱/源码SHA、每材料可复用路径、处理步骤及限制。A的实际模型点值范围通过，B550nm/25°C参考值通过；**A_evidence_closed=False**。E7 no(25°C,2500nm)=1.50053024的模型余量很小，不可当实物置信下界。

| 输入 | 原始证据及实际使用 | 需要保持的边界 |
|---|---|---|
| E7实部 | Li2005，doi10.1063/1.1877815；25/50°C Cauchy双主轴 | 六可见线450–656nm拟合；380–450nm与连续NIR外推，1.55/10.6µm离散核验不补成全谱测量 |
| E7损耗 | Wu2002，doi10.1557/PROC-709-CC7.2.1；约70°C各向同性α转k | 迁移至25/50两轴；380–400nm保持首α。Fig8长波α与1.9cm光程的动态范围解释缺失，未据此判论文无效，也不认证损耗上界 |
| E7低频ε | Basu–Kehr2025，doi10.3390/mi16040457；纯E7红符号，1kHz，Δε25/50=12.343049/9.800802 | ε⊥25≈4.886949，50°C仍保持模型；不同批次、配向与厚度 |
| E7 Frank常数 | K25=[11.1,6.5,17.1]pN、共同Δn589²缩放为指定模型；Huang2010 doi10.1016/j.cap.2009.07.022仅作独立反证比较 | Huang只有25–40°C K11/K22、不同预倾，无K33/50°C；不能说当前三K温依已经测量验证 |
| SiNx光学 | Amato arXiv2409.07147**v2**，实际PDF2025-02-10；IBS23028原Fig4复拟合曲线 | 原膜族50–500nm→20nm；>560nm拟合k低于仪器灵敏度，未置零；IBS谱不等同PECVD/离子处理配向膜 |
| SiNx配向/锚定 | Lee2007 doi10.1143/JJAP.46.7711摘要及Nature411,56(2001)全文提供过程先例 | Lee全文未取得，不能发明膜厚/温度/Wa。Wa1.14e-4来自不同a-C:H；Wp2e-4、零预倾、ε7.5等仍为指定情景 |
| ZnO | Bohórquez2022 doi10.1021/acsaelm.1c01026；200°C ALD、室温99.8nm未掺杂参考，原图高分辨重标定 | 末55.195nm绿色虚线空白用明示线性图尾；ADΓ假说非作者勘误；没有独立DC/25–50°C输运闭合 |
| Al₂O₃ | Franta2015 doi10.1117/12.2190104；室温121.5nm电子束/Si复谱 | 向8/9.8µm支持、83nm表面膜和无空隙直接键合迁移；均匀ε合并是模型恒等式，不是键合质量证据 |
| 碳筛 | Hagemann1975 doi10.1364/JOSA.65.000742；宽谱复常数用于5µm筛 | 数据到自由箔/两温/平整度有迁移；不是旧DLC配向碳。保留3.75/5/6.25µm筛透射控制 |

## “干实验”与已完成内容

干实验在本交付中特指不操作样品的计算控制：图谱独立提取与印刷公式比对、Gauss解析/差分核验、同材层分段等价、保存四态谱重积分、嵌套波长网格以及七点阶数/切片对照。器件结果来自Frank/Gauss、周期矢量复散射和有限筛面传播仿真；毛细板形是分开的解析情景，未耦合入平整光学。

直接无胶氧化物连接、释放、1.5µm八方向表面处理、临时掩膜去除、接触/注液支路与装配次序属于**拟议加工方案**。目前没有新制样、四态实测、寿命循环或完整制程证书。复算可检验指定物性模型的结论，不能替代这些材料迁移条件。

来源版本须纠正：早期SiNx笔记/提取收据写v1，但保留PDF字节的第一页是v2；交付引用以实际v2与SHA为准。无需改动冻结数据即可澄清。
'''
(OUT/'materials_literature_audit.md').write_text(md,encoding='utf8')
check=load(str((OUT/'materials_literature_audit.json').relative_to(ROOT)))
assert check['candidate']['source_fields_SHA256']=='d281beb19c1504927f336eaac1dd74231ccd7d711903fb167ee0195d4e587e7e'
assert not check['constraints']['A_evidence_closed']
for x in check['source_records_and_readouts']:assert sha(x['repository_path'])==x['sha256']
for m in check['materials']:
 for x in m['evidence']:assert sha(x['repository_path'])==x['sha256']
print(json.dumps({'output_files':['materials_literature_audit.json','materials_literature_audit.md','final_four_states.csv','build_materials_audit.py'],'materials':len(materials),'readback_SHA_verified':True,'final_main_pp':result['final_837_inner600']['main_VIS_lower_NIR_pp'],'A_evidence_closed':False,'version_label_correction':'SiNxretainedPDFisv2'},ensure_ascii=False))
