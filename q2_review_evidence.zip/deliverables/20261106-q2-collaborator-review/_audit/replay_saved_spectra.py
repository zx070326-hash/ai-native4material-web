"""Cheap, NumPy-only Q2 result replay. Never runs Frank/Gauss/Maxwell.

Paths in manifests are relative to the research root, not this directory.
Only final/essential diagnostic spectra and their retained receipts are read.
"""
from pathlib import Path
import argparse,json,time,hashlib
import numpy as np
ROOT=Path(__file__).resolve().parents[3]
def stats(w,T):
 def avg(y,lo,hi):
  mask=(w>=lo)&(w<=hi);return np.trapezoid(y[...,mask],w[mask],axis=-1)/(hi-lo)
 vis=avg(T,.4,.78);nir=avg(T,.78,2.5);vt=T[:,1]-T[:,0];ne=T[1]-T[0]
 return {'main_pp':[float(100*(.95*np.min(abs(vis[1]-vis[0]))-.05)),float(100*np.min(abs(nir[:,1]-nir[:,0])))], 'VIS_thermal_meanabs_pp':(100*avg(abs(vt),.4,.78)).tolist(),'VIS_thermal_peak_pp':(100*np.max(abs(vt[:,w<=.78]),axis=-1)).tolist(),'NIR_electric_meanabs_pp':(100*avg(abs(ne),.78,2.5)).tolist(),'NIR_electric_peak_pp':(100*np.max(abs(ne[:,w>=.78]),axis=-1)).tolist()}
def main():
 p=argparse.ArgumentParser();p.add_argument('--manifest',type=Path,default=Path(__file__).with_name('q2_dependency_evidence_manifest.json'));p.add_argument('--out',type=Path);a=p.parse_args();tic=time.perf_counter();man=json.loads(a.manifest.read_text());rows=[]
 for item in man['saved_spectrum_replay_cases']:
  path=ROOT/item['spectra'];z=np.load(path);w=z['wavelength_um'];T=z['total_T'];s=stats(w,T);receipt=json.loads((ROOT/item['receipt']).read_text());expected=[receipt['main']['VIS_conditional_lower_pp'],receipt['main']['NIR_model_pp']];error=float(np.max(abs(np.array(s['main_pp'])-expected)));assert error<1e-10,(item['id'],error)
  rows.append({'id':item['id'],'wavelengths':len(w),'stats':s,'receipt_main_error_pp':error,'spectra_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'same_temperature_physical_candidate':item.get('same_temperature_physical_candidate',True)})
 result={'scope':'Exact saved-spectrum trapezoidal arithmetic replay only; no new optics or physical-input validation.','cases':rows,'runtime_seconds':time.perf_counter()-tic,'limits':['The 380-400nm unknown VIS interval is treated by the same passivity-blue lower-bound formula.','Signed-band cancellation is not decoupling; report absolute spectral mean/peak.','Mixed-temperature and single-pass cases are diagnostics, never same-uniform-temperature device candidates.']}
 if a.out:a.out.write_text(json.dumps(result,indent=2))
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()
