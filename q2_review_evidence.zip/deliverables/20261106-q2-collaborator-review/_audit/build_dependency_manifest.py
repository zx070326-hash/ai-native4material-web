"""Read-only source/data closure audit; writes new audit artifacts only.

Imports are traced, but no simulation function is invoked. Exact final shard
data are compared with retained merged fields before proposing removability.
"""
from pathlib import Path
import os,sys,json,hashlib,time,importlib,ast
for name in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[name]='1'
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT))
def rel(p):return str(p.resolve().relative_to(ROOT)).replace('\\','/')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
reads=[];stage='optical_import'
def audit(event,args):
 if event!='open' or not isinstance(args[0],(str,bytes,os.PathLike)):return
 try:
  p=Path(os.fsdecode(args[0])).resolve()
  if p.is_relative_to(ROOT)and p.suffix.lower()in ['.json','.csv','.npz','.yml','.yaml']and p.exists():reads.append((stage,p))
 except (OSError,ValueError):pass
sys.addaudithook(audit)
tic=time.perf_counter();solid=importlib.import_module('experiments.q2_finish_decouple_20261105_solid_interface');optmods={p.resolve()for m in sys.modules.values()if isinstance((p:=getattr(m,'__file__',None)),str)and (p:=Path(p)).suffix=='.py'and p.resolve().is_relative_to(ROOT)and not p.resolve().is_relative_to(ROOT/'.venv')}
stage='saved_mode_projection_import'
for name in ['experiments.q2_finish_decouple_20261105_readout','experiments.q2_gap_vector_review','experiments.q2_output_screen','experiments.q2_upgrade_output','experiments.lead_balance_compact_port']:importlib.import_module(name)
allmods={p.resolve()for m in sys.modules.values()if isinstance((p:=getattr(m,'__file__',None)),str)and (p:=Path(p)).suffix=='.py'and p.resolve().is_relative_to(ROOT)and not p.resolve().is_relative_to(ROOT/'.venv')};importsec=time.perf_counter()-tic
importreads=list(dict.fromkeys(reads));stage='manifest'
entries={}
def add(p,role,level,profile,notes=None):
 p=ROOT/p if isinstance(p,str)else p
 if not p.exists()or not p.is_file():raise FileNotFoundError(p)
 k=rel(p);e=entries.setdefault(k,{'path':k,'sha256':sha(p),'bytes':p.stat().st_size,'roles':[],'requirement_levels':[],'profiles':[]})
 for key,value in [('roles',role),('requirement_levels',level),('profiles',profile)]:
  if value not in e[key]:e[key].append(value)
 if notes:e.setdefault('notes',[]).append(notes)
 return k
for p in optmods:add(p,'Transitive original optical-entry import dependency','required','original_optical_recompute')
for p in allmods:add(p,'Transitive mode-field projection import dependency','required','saved_mode_projection')
for st,p in importreads:add(p,'Read during import; possibly legacy compatibility only, not final physical input','required', 'original_optical_recompute'if st=='optical_import'else'saved_mode_projection', 'Retain for unchanged original entry; do not misidentify compatibility data as final candidate material.')
launch=ROOT/'runs/20261105-q2-finish-decouple-solid-interface-optics64-missing713-0-01/launch.json';cfg=json.loads(launch.read_text())
for k in cfg['source_sha256']:add(k.replace('\\','/'),'Executed entry or declared source dependency','required','original_optical_recompute')
for k in cfg['input_sha256']:add(k.replace('\\','/'),'Actual final optical physical input or exact spectral grid','required','original_optical_recompute')
add('requirements.txt','Pinned Python environment','required','original_optical_recompute')
for f in ['experiments/q2_finish_decouple_20261105_readout.py','experiments/q2_finish_decouple_20261105_phase855_dense.py','experiments/q2_finish_decouple_20261105_solid_report.py','experiments/q2_finish_decouple_20261105_solid_dense.py']:add(f,'Final adapter/statistics source','required','delivery_replay')
for name in ['standard713','union837']:
 for f in ['scattered_fields.npz','results.json']:add(f'runs/20261105-q2-finish-decouple-solid-interface-selectedgrids-01/{name}/{f}','Final four-state complex E/G modal fields and actual R/T/A record','required'if name=='union837'else'recomputable','saved_mode_projection', 'standard713 is exact subset of retainedunion837; retain receipt even if compacting NPZ.')
for f in ['data/q2_current/solid_gram.npz','data/constraints_upgrade_sources/C_Hagemann.csv','runs/20261105-q2-package-device-kernels-01/inner600/gram.npz','runs/20261105-q2-package-device-kernels-01/inner700/gram.npz']:add(f,'Fixed finite-screen readout input','required','saved_mode_projection')
for f in ['runs/20261105-q2-finish-decouple-solid-interface-merge127-01/results.json','runs/20261105-q2-finish-decouple-solid-interface-merge127-01/launch.json','runs/20261105-q2-finish-decouple-solid-interface-merge127-01/effective_optics_source.py','runs/20261105-q2-finish-decouple-solid-interface-dense-launch-01/standard713.npz','runs/20261105-q2-finish-decouple-solid-interface-dense-launch-01/missing710.npz','runs/20261105-q2-finish-decouple-solid-interface-dense-launch-01/results.json']:add(f,'Identity/merge proof or fixed sampling support','required','original_optical_recompute')
cases=[]
def case(cid,folder,physical=True):
 spectra=folder+'/spectra.npz';receipt=folder+'/results.json'
 add(spectra,'Essential saved-spectrum positive/negative control','required','cheap_saved_spectrum_replay');add(receipt,'Exact result receipt, source identity and boundary conditions','required','cheap_saved_spectrum_replay')
 for f in ['source.py','inherited_numeric_results.json']:
  if (ROOT/folder/f).exists():add(folder+'/'+f,'Executed readout snapshot or original numeric receipt','required','evidence')
 cases.append({'id':cid,'spectra':spectra,'receipt':receipt,'same_temperature_physical_candidate':physical})
for grid in ['713','837']:
 for hole in [600,700]:case(f'solid{grid}_hole{hole}',f'runs/20261105-q2-finish-decouple-solid-interface-readout64-{grid}-{hole}-01')
for hole in [600,700]:
 case(f'air837_hole{hole}',f'runs/20261105-q2-finish-decouple-source25-phase855-readout64-837-{hole}-01')
 case(f'air127_hole{hole}',f'runs/20261105-q2-finish-decouple-source25-phase855-readout64-127-{hole}-01')
 case(f'd9p8_correctedZnO_hole{hole}',f'runs/20261105-q2-finish-material-ZnO-hires-new25-readout127-{hole}-01')
case('d9p8_y750_correctedZnO','runs/20261105-q2-finish-assembly-y750-hiresZnO-source25-readout127-01')
case('d9p8_oldZnO_reference','runs/20261105-q2-finish-decouple-source25-AR19-readout64-127-600-01')
for control in ['freezeThermal','freezeDC','singlePass']:case('diagnostic_'+control,f'runs/20261105-q2-finish-decouple-source25-control-{control}-readout600-01',False)
for f in ['fields.npz','results.json','source.py','summary_handoff.json']:add(f'runs/20261105-q2-finish-source25-combined64-01/{f}','Genuine d9.8 negative-control six-state 2D source','required','negative_control_recompute')
for f in ['fields.npz','results.json','source.py']:add(f'runs/20261105-q2-finish-assembly-phase25-d8p55-source64-01/{f}','Final genuine d8.55 six-state2D source; no thermal rescaling','required','final_field_evidence')
for folder in ['runs/20261105-q2-finish-material-ZnO-hires-new25-optics127-0-01','runs/20261105-q2-finish-material-ZnO-hires-new25-optics127-1-01','runs/20261105-q2-finish-decouple-source25-control-optics127-0','runs/20261105-q2-finish-decouple-source25-control-optics127-1','runs/20261105-q2-finish-assembly-y750-kernel-01']:
 for p in (ROOT/folder).glob('*'):
  if p.is_file()and p.suffix in ['.py','.json']:add(p,'Executed negative-control source or provenance snapshot','required','negative_control_recompute')
for control in ['reference','freezeThermal','freezeDC','singlePass']:
 for i in [0,1]:
  folder=f'runs/20261105-q2-finish-decouple-source25-control-optics127-{i}/{control}'
  add(folder+'/results.json','Actual mixed-temperature/singlepass diagnostic receipt','required','evidence')
  add(folder+'/scattered_fields.npz','Optional causal-control forward modal field, regenerable from retained source','optional_recomputable','negative_control_recompute')
for i in [0,1]:
 add(f'runs/20261105-q2-finish-material-ZnO-hires-new25-optics127-{i}-01/scattered_fields.npz','d9.8 correctedZnO modal field, supports exact y750 readout replay','required','negative_control_mode_replay')
 add(f'runs/20261105-q2-finish-decouple-source25-AR19-optics64-127-{i}/scattered_fields.npz','Legacy ZnO d9.8 modal fields required by unchanged factorized-analysis modal-power routine','required','negative_control_mode_replay')
for f in ['experiments/q2_finish_decouple_20261105_source25_controls.py','experiments/q2_finish_decouple_20261105_source25_analysis.py','experiments/q2_finish_decouple_20261105_digitize_constitutive.py','experiments/q2_finish_decouple_20261105_source25.py','notes/q2_finish_decouple_20261105.md']:add(f,'Mechanism/constitutive/negative-control code and evidence','required','evidence')
for folder in ['runs/20261105-q2-finish-decouple-source25-factorized-diagnosis-02','runs/20261105-q2-finish-decouple-source25-controls-identity-01','runs/20261105-q2-finish-decouple-solid-interface-summary127-01','runs/20261105-q2-finish-decouple-solid-interface-summary837-01','runs/20261105-q2-finish-decouple-source25-phase855-dense-summary-01','runs/20261106-q2-finish-assembly-solid-order-peak-comparison-01']:
 for p in (ROOT/folder).glob('*'):
  if p.is_file():add(p,'Retained scientific conclusion, exact source snapshot, graph or audit','required','evidence')
for f in ['E7hCNT2025.pdf','E7hCNT2025.xml','Huang2010_K_dependence.pdf','Huang_source_manifest.json','source_manifest.json','E7_2025_Figure4_native.jpeg','Huang2010_native_2.png']:add('runs/20261105-q2-finish-decouple-E7-constitutive-source-01/'+f,'Primary constitutive-source evidence; conditions and noncoverage retained','required','literature_evidence')
for p in (ROOT/'runs/20261105-q2-finish-decouple-E7-constitutive-digitized-01').glob('*'):
 if p.is_file():add(p,'Constitutive curve extraction, calibration and correction','required','literature_evidence')
for p in [OUT/'replay_saved_spectra.py',Path(__file__)]:add(p,'Standalone arithmetic replay/audit builder','required','delivery_replay')
# Exact bitwise inverse of source shard selection. Do not infer redundancy from
# filenames or size; compare every stored complex array to retained mode fields.
import numpy as np
def shard_check(prefix,final):
 z=np.load(ROOT/final);ww=z['wavelength_um'];rows=[]
 dirs=[ROOT/'runs'/f'{prefix}optics64-127-{i}'+''for i in []] # no file operations
 folders=[f'runs/{prefix}optics64-127-{i}'+('-01'if 'solid-interface' in prefix else '')for i in [0,1]]+[f'runs/{prefix}optics64-missing713-{i}'+('-01'if 'solid-interface' in prefix else '')for i in range(4)]
 for folder in folders:
  p=ROOT/folder/'scattered_fields.npz';s=np.load(p);ix=np.searchsorted(ww,s['wavelength_um']);ok=np.array_equal(ww[ix],s['wavelength_um'])and all(np.array_equal(s[k],z[k]if k=='harmonics'else z[k][ix])for k in s.files if k!='wavelength_um');assert ok,p
  add(p,'Raw modal shard bitwise included in retainedunion837','recomputable_duplicate','cleanup_candidate');rows.append({'path':rel(p),'sha256':sha(p),'bytes':p.stat().st_size,'retained_replacement':final,'all_keys_bitwise_equal':ok,'condition':'Only remove after retaining final union837 mode fields, original launch/source/dependency snapshots and all result/postflight receipts. Does not delete an independent negative control.'})
 return rows
solidfinal='runs/20261105-q2-finish-decouple-solid-interface-selectedgrids-01/union837/scattered_fields.npz';airfinal='runs/20261105-q2-finish-decouple-source25-phase855-selectedgrids-01/union837/scattered_fields.npz'
add(airfinal,'Essential same-source air counterpart union837 complex modes','required','negative_control_mode_replay');add(str(Path(airfinal).parent/'results.json').replace('\\','/'),'Air counterpart actual R/T/A and identity','required','evidence')
cleanup=shard_check('20261105-q2-finish-decouple-solid-interface-',solidfinal)+shard_check('20261105-q2-finish-decouple-source25-phase855-',airfinal)
snapshot=[]
for folder in [f'runs/20261105-q2-finish-decouple-solid-interface-optics64-127-{i}-01'for i in [0,1]]+[f'runs/20261105-q2-finish-decouple-solid-interface-optics64-missing713-{i}-01'for i in range(4)]:
 for p in (ROOT/folder).glob('*'):
  if p.suffix in ['.json','.py']:
   add(p,'Executed final optical source snapshot/provenance; keep even when raw shard removed','required','executed_snapshots')
   if p.name.startswith('dependency_'):
    name=p.name[len('dependency_'):];current=ROOT/'experiments'/name
    if current.exists():snapshot.append({'snapshot':rel(p),'snapshot_sha256':sha(p),'current':rel(current),'current_sha256':sha(current),'same_bytes':sha(p)==sha(current)})
commands=[
 {'id':'cheap_spectrum_arithmetic','command':'.venv/Scripts/python.exe deliverables/20261106-q2-collaborator-review/_audit/replay_saved_spectra.py --out deliverables/20261106-q2-collaborator-review/_audit/replay_verification.json','runtime':'Measured in replay_verification.json; NumPy-only, seconds, no Maxwell.'},
 {'id':'mode_to_screen_837_600','command':'.venv/Scripts/python.exe experiments/q2_finish_decouple_20261105_readout.py --runs runs/20261105-q2-finish-decouple-solid-interface-selectedgrids-01/union837 --hole runs/20261105-q2-package-device-kernels-01/inner600/gram.npz --out runs/REPLAY-NEW-solid837600','runtime':'Observed original four concurrent713/837 screen readouts about10-20s total; one current837 mode projection typically seconds to tens of seconds; no fresh Maxwell.'},
 {'id':'solid127_recompute','command':'.venv/Scripts/python.exe experiments/q2_finish_decouple_20261105_solid_interface.py optics --audit runs/20261105-q2-finish-decouple-solid-interface-merge127-01 --shards 2 --shard <0_or_1> --out runs/RECOMPUTE-NEW-solid127-<shard>','runtime':'Actual original249.04/252.64s per single-thread shard run concurrently; identical127 fourstates, order4/slices32.'},
 {'id':'solid710_missing_recompute','command':'.venv/Scripts/python.exe experiments/q2_finish_decouple_20261105_solid_dense.py optics --shards 4 --shard <0_to_3> --out runs/RECOMPUTE-NEW-solidmissing-<shard>','runtime':'Actual690.26–696.41s per single-thread shard,4 concurrently;710 new wavelengths. Combined127+710=837 actual wavelengths. All OMP/BLAS/MKL threads1.'},
 {'id':'exact_original_source_selection','command':'Original solid_dense.py select expects the original six run paths. For clean recomputes, copy the standalone adapter to a NEW path and change ONLY its input/output directory variables; retain all exact grids/source/geometry, or invoke identical source function with a newly constructed Namespace. Never overwrite existing run directories.','runtime':'Original actual837 selection6.3s; exact713 is direct index selection, not interpolation.'},
 {'id':'negative_factorial_arithmetic','command':'.venv/Scripts/python.exe experiments/q2_finish_decouple_20261105_source25_analysis.py --out runs/REPLAY-NEW-factorization','runtime':'Saved-spectrum/modal arithmetic + discrete LP/plot only, typically a few seconds. Uses original old-ZnO d9.8 diagnostics; not final all-solid model.'}]
manifest={'schema':'q2_dependency_evidence_manifest_v1','created_local_date':'2026-11-06','scope':'READ-ONLY dependency/evidence extraction; no deletion, new Maxwell, Git, or shared-core edits. Paths relative to F:/metamaterial.','final_identity':{'temperatures_C':[25,50],'fixed_bias_V_RMS':[0,9.235],'LC_drive_passive_thermal_um':[2.5,2.5,8.55],'director_shape':[64,33],'periods_um':[12,24],'order':4,'slices':32,'source_fields_sha256':cfg['input_sha256']['runs\\20261105-q2-finish-assembly-phase25-d8p55-source64-01\\fields.npz'],'executed_effective_optics_sha256':cfg['effective_source_sha256'],'all_solid_internal_interface_um':9.883028893422603,'physical_passive_entrance_plate_um':9.8,'retained_entities_including_screen':19,'merged_optical_layers_including_screen':18,'computational_segments_pre_screen_including_screen':[20,21],'screen_reference':'10mm after FINAL thermalAl exit, beta25deg; original600/700 fixed kernels','limitations':'Conditional K(T),epsilon_perp50,anchoring,source/thickness/state/process transfer; no uniform error/strict-decoupling/fullmanufacturing/pointwiseA certificate.'},'dependency_trace':{'method':'Actual Python import audit only, no function simulation invoked; open-event trace captures compatibility data loaded by unchanged entries.','runtime_seconds':importsec,'optical_modules':len(optmods),'all_projection_modules':len(allmods),'opened_data':[{'stage':s,'path':rel(p)}for s,p in importreads]},'profiles':{'original_optical_recompute':'Preserve all required members of this profile plus final_field_evidence and executed_snapshots. Unmodified adapter provenance checks require exact legacy paths.','saved_mode_projection':'Use retainedunion837 complexfields + fixed kernels/carbon + transitive import closure.','cheap_saved_spectrum_replay':'Only replay_saved_spectra.py, NumPy, selected spectra and receipts + this manifest; no giant Gram caches required.','negative_controls':'d9.8, y750, air-vs-solid, virtual mixed moduleT and singlePass have separate identities; never merge oldZnO diagnostics into correctedZnO final candidate.'},'entry_commands':commands,'saved_spectrum_replay_cases':cases,'files':sorted(entries.values(),key=lambda x:x['path']),'cleanup_candidates':cleanup,'cleanup_summary':{'raw_shard_bytes_bitwise_redundant':sum(r['bytes']for r in cleanup),'deletion_performed':False,'do_not_delete':['final genuine2D LCsource fields/results','solid and air finalunion837 modes/results','all final713/837 spectra/receipts and essential negatives','actual effective source/dependency snapshots if current entry differs','primary material literature/extraction/correction records','original600/700 screenGram and source/geometry records']},'source_snapshot_comparisons':snapshot,'cautions':['An imported legacy oldCB/SD1 data file is a compatibility dependency, not an accepted final material input.','Exact713 modeNPZ is a bitwise subset ofunion837 and reproducible by index extraction, but its receipt/metrics preserve a separate quadrature.','Duplicate snapshot hashes permit one canonical retained copy only if all original path/receipt references remain resolvable; do not delete on naming heuristics.','The manifest is a proposed keep/clean boundary for lead; no files were removed.']}
(OUT/'q2_dependency_evidence_manifest.json').write_text(json.dumps(manifest,indent=2));print(json.dumps({'files':len(entries),'modules':len(allmods),'import_seconds':importsec,'raw_duplicate_bytes':manifest['cleanup_summary']['raw_shard_bytes_bitwise_redundant'],'cleanup_shards':len(cleanup)}))
