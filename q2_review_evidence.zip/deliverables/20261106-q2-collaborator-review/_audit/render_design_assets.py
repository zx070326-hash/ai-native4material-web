"""Headless local SVG render and text clipping QA; no interactive browser."""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright
OUT=Path(__file__).resolve().parents[1]
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True)
 results=[]
 for name in ['q2_stack_cross_section','q2_aperture_layout','q2_proposed_dry_assembly']:
  page=browser.new_page(viewport={'width':1600,'height':1200},device_scale_factor=1)
  page.goto((OUT/'assets'/f'{name}.svg').as_uri());page.evaluate('document.fonts.ready')
  qa=page.evaluate('''() => {const root=document.documentElement, vb=root.viewBox.baseVal;return [...document.querySelectorAll('text')].map(t=>{const b=t.getBBox();return {text:t.textContent,x:b.x,y:b.y,w:b.width,h:b.height}}).filter(b=>b.x<0||b.y<0||b.x+b.w>vb.width||b.y+b.h>vb.height)}''')
  page.locator('svg').screenshot(path=str(OUT/'_audit'/f'{name}.png'))
  results.append({'asset':name+'.svg','outside_viewbox_text':qa})
  page.close()
 browser.close()
 (OUT/'_audit/design_render_qa.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps(results,ensure_ascii=False,indent=2))
