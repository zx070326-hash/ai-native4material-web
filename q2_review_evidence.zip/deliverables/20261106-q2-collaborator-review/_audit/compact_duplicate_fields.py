"""Remove only byte-hashed shards proven array-identical to retained unions.

--restore reconstructs semantic NPZ contents at original paths; original byte
hashes are provenance, not promised for regenerated ZIP containers.
"""
from pathlib import Path
import argparse, hashlib, json
import numpy as np
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--restore',action='store_true');a=p.parse_args()
 manifest=json.loads((OUT/'q2_dependency_evidence_manifest.json').read_text())
 receipt=OUT/'cleanup_receipt.json'
 if a.restore:
  old=json.loads(receipt.read_text())
  for row in old['removed']:
   path=ROOT/row['path']; union=ROOT/row['retained_replacement']
   assert sha(union)==row['retained_sha256']
   if path.exists():continue
   with np.load(union) as z:
    idx=np.array(row['retained_indices']); values={k:(z[k][idx] if k!='harmonics' else z[k]) for k in row['keys']}
    np.savez_compressed(path,**values)
  print('Original shard arrays restored; NPZ byte encoding may differ.');return
 if receipt.exists():raise RuntimeError('Cleanup already recorded; inspect receipt before another mutation.')
 for row in manifest['files']:
  path=ROOT/row['path'];assert path.is_file(),str(path)
  assert sha(path)==row['sha256'],f"Dependency drift: {path}"
 verified=[]
 for row in manifest['cleanup_candidates']:
  path=(ROOT/row['path']).resolve(); union=(ROOT/row['retained_replacement']).resolve()
  assert path.is_relative_to((ROOT/'runs').resolve()) and path.name=='scattered_fields.npz'
  assert sha(path)==row['sha256'] and union!=path
  with np.load(path) as z,np.load(union) as u:
   idx=np.searchsorted(u['wavelength_um'],z['wavelength_um'])
   assert np.array_equal(u['wavelength_um'][idx],z['wavelength_um'])
   for key in z.files:assert np.array_equal(z[key],u[key] if key=='harmonics' else u[key][idx]),(str(path),key)
   verified.append({**row,'retained_sha256':sha(union),'retained_indices':idx.tolist(),'keys':z.files})
 # All candidates and every retained dependency checked BEFORE deletion.
 pending={'scope':'Only 12 redundant raw field shards; historical independent results and provenance retained.','removed':verified,'bytes_released':sum(x['bytes']for x in verified),'all_required_dependencies_preflight_match':True,'restore_command':'.venv/Scripts/python.exe -X utf8 deliverables/20261106-q2-collaborator-review/_audit/compact_duplicate_fields.py --restore','restore_limit':'Array-identical reconstruction; original NPZ ZIP byte hashes remain historical. Existing select scripts need restored shards; final union projections do not.','completed':False}
 receipt.write_text(json.dumps(pending,indent=2),encoding='utf8')
 for row in verified:(ROOT/row['path']).unlink()
 pending['completed']=True
 pending['all_required_dependencies_postflight_match']=all((ROOT/r['path']).is_file() and sha(ROOT/r['path'])==r['sha256']for r in manifest['files'] if r['requirement_levels']!=['recomputable_duplicate'])
 assert pending['all_required_dependencies_postflight_match']
 receipt.write_text(json.dumps(pending,indent=2),encoding='utf8')
 print(json.dumps({'removed':len(verified),'bytes_released':pending['bytes_released'],'required_dependencies_intact':True}))
if __name__=='__main__':main()
