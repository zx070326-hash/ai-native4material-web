Q2 partner evidence package
Use Python 3.11+ and NumPy 2.x. From extracted root:
python -X utf8 deliverables/20261106-q2-collaborator-review/_audit/replay_saved_spectra.py --out replay.json

This independently reintegrates 15 saved cases; it does NOT rerun director fields or Maxwell.
The package also includes small original optical-entry source/input dependencies and actual executed snapshots.
Full mode-to-screen replay needs the retained union837 fields and inner600/700 Gram kernels (large local files; exact paths and SHA in dependency manifest). Those caches are not in this light review package.
Original select scripts need duplicate shards restored first; cleanup receipt records exact index reconstruction.
Primary literature PDFs stay in the research workspace; DOI, source version, extraction path and SHA are in materials_literature_audit.json.
All mixed-temperature/single-pass diagnostics remain marked nonphysical.
