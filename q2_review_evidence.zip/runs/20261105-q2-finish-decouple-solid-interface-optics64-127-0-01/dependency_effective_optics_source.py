def optics(a):
 from scipy.linalg import expm
 from scipy.interpolate import RegularGridInterpolator
 from experiments import q2_closure_coupling as coupled
 old=coupled.model.old;src=np.load(a.fields/'fields.npz');thermal=src
 dlc=np.loadtxt(ROOT/'data/q2_finish_material_20261105/SiNx_spectrum/DLC_4keV_vector_digitized.csv',delimiter=',',skiprows=1)
 zn=np.loadtxt(ROOT/'runs/20261105-q2-finish-material-ZnO-hires-input-01/ZnO2022_Fig5d_hires_exactnodes_tail_linear_scenario.csv',delimiter=',',skiprows=1)
 loss=np.loadtxt(ROOT/'data/q2_parallel_loss_20261105/Wu2002_E7_graph_alpha_k.csv',delimiter=',',skiprows=1)
 nx=128;xx=(np.arange(nx)+.5)/nx;zz=(np.arange(a.slices)+.5)/a.slices;cache={};m=np.arange(-a.order,a.order+1);N=len(m);count=N*N
 def texture(kind,V,ti):
  key=(kind,V,ti)
  if key in cache:return cache[key]
  dat=thermal if kind=='thermal'else src;pre=f'{"thermal"if kind=="thermal"else"electric"}_T{[25,50][ti]}_V{V:g}'
  shift=-.25 if kind=='thermal' else (.25 if kind=='compensator' else 0.)
  X,Z=np.meshgrid((xx+shift)%1,zz,indexing='ij');pts=np.stack([X,Z],-1)
  def it(q):return RegularGridInterpolator((np.linspace(0,1,len(q)+1),np.linspace(0,1,q.shape[1])),np.r_[q,q[:1]])(pts)
  t=it(dat[pre+'__theta_rad']);u=it(dat[pre+'__phi_correction_rad']);p=2*np.pi*xx[:,None]+u+(np.pi/2 if kind=='compensator' else 0.)
  cache[key]=t,p;return t,p
 def cell(kind,V,ti,lam):
  th,ph=texture(kind,V,ti);ne,no=indices([25,50][ti],lam);k=float(np.interp(lam,loss[:,0],loss[:,1]))*lam*1e-4/(4*np.pi);ne+=1j*k;no+=1j*k
  support=complex(old.index('Al2O3_Franta',np.array([lam]))[0]);dn=complex(np.interp(lam,dlc[:,0],dlc[:,1]),np.interp(lam,dlc[:,0],dlc[:,2]));znn=complex(np.interp(lam,zn[:,0],zn[:,1]),np.interp(lam,zn[:,0],zn[:,2]));iso=lambda n:old.dielectric(n,n,np.zeros(nx),np.zeros(nx))
  electrode=[(iso(znn),.0998)]if kind=='driven'else[]
  front=8. if kind=='driven' else 4.;back=8. if kind=='thermal' else 4.;d=9.8 if kind=='thermal' else a.d
  body=[(iso(dn),.02)]+[(old.dielectric(ne,no,th[:,j],ph[:,j]),d/a.slices)for j in range(a.slices)]+[(iso(dn),.02)]
  if kind=='driven':layers=[(iso(support),0.08302889342260214)]+electrode+[(iso(support),8.)]+body+[(iso(support),8.)]+electrode+[(iso(support),0.08302889342260214)]
  else:layers=[(iso(support),8. if kind=='compensator' else 4.)]+body+[(iso(support),back)]
  S=[np.zeros((2*count,2*count),complex)for _ in range(4)];cond=0.
  for fixed,mf in enumerate(m):
   if kind!='thermal':qx,qy=lam*m/24,np.full(N,lam*mf/48);idx=np.arange(N)+fixed*N
   else:qx,qy=np.full(N,lam*mf/24),lam*m/48;idx=np.arange(N)*N+fixed
   M=np.eye(4*N,dtype=complex)
   for ep,dd in layers:M=expm(2j*np.pi/lam*dd*old.generator(ep,np.diag(qx),np.diag(qy),m))@M
   local=old.to_scattering(M,old.admittance(qx,qy));ii=np.r_[idx,idx+count]
   for b,c in zip(S,local):b[np.ix_(ii,ii)]=c
   cond=max(cond,float(np.linalg.cond(M)))
  return S,cond
 waves=np.load(a.grid)['wavelength_um'] if a.grid else (np.unique(np.r_[np.linspace(.4,.78,41),np.linspace(.78,2.5,87)]) if a.dense else np.array([.4,.45,.55,.65,.78,1.,1.25,1.6,2.,2.5]));waves=waves[a.shard::a.shards];vals={};di=[];tic=time.perf_counter()
 mx,my=np.meshgrid(m,m,indexing='xy');qx,qy=mx.ravel()/24,my.ravel()/48;incident=np.zeros((2*count,2));incident[a.order*N+a.order,0]=1;incident[count+a.order*N+a.order,1]=1
 for lam in waves:
  Y=old.admittance(lam*qx,lam*qy);diagn=[]
  for ti in range(2):
   c,cc=cell('compensator',0,ti,lam);t,ct=cell('thermal',0,ti,lam);after,err=coupled.cascade(c,t);gap=coupled.uniform_layer(1.,2.,float(lam),lam*qx,lam*qy);after,er_gap=coupled.cascade(gap,after);err=max(err,er_gap)
   for vi,V in enumerate([0.,a.bias]):
    e,ce=cell('driven',V,ti,lam);S,er=coupled.cascade(e,after);forward=S[2]@incident;back=S[0]@incident;T=float(np.real(np.sum(forward.conj()*(Y@forward)))/2);R=float(np.real(np.sum(back.conj()*(Y@back)))/2)
    for label,field in [('E',forward),('G',Y@forward)]:vals.setdefault(f'V{vi}T{ti}__{label}',[]).append(np.stack([field[:count],field[count:]],axis=1).reshape(N,N,2,2))
    diagn.append({'vi':vi,'Tindex':ti,'T':T,'R':R,'A':1-T-R,'maxcondition':max(cc,ct,ce),'cascade_residual':max(err,er)})
  di.append({'wavelength_um':float(lam),'states':diagn});print(json.dumps({'done':len(di),'total':len(waves),'elapsed_s':time.perf_counter()-tic}),flush=True)
 np.savez_compressed(a.out/'scattered_fields.npz',wavelength_um=waves,harmonics=m,**{k:np.array(v)for k,v in vals.items()})
 (a.out/'results.json').write_text(json.dumps({'scope':'same-device fixed0/bias V crossed passiveE7 compensation, same25/50C, full vector three-cell cascading','d_electric_um':a.d,'bias_V':a.bias,'main_layer_count':19,'physical_supports':5,'order':a.order,'slices':a.slices,'diagnostics':di,'limits':['1D screening is separate; this usesactual2Drelaxedfields','compensator has no electrode; quarter-domain lateral registration shifts same8step physical texture bypi/2','thermal field usesproper spatial/axis90deg rotation','periodic full vector scattering; finite aperture separate envelope projection','same A film optical/electrical/anchoring transfers remain; peripheral inventory unclosed']},indent=2))
