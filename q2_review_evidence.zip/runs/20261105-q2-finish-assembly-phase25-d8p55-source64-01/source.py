"""Bundle one actual8.55um thermal control with unchanged source25 electric states."""
from pathlib import Path
import argparse,json,hashlib
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False)
    base=ROOT/'runs/20261105-q2-finish-source25-combined64-01';control=ROOT/'runs/20261105-q2-finish-assembly-phase25-01';old=np.load(base/'fields.npz');new=np.load(control/'thermal_control_fields.npz');meta=json.loads((control/'results.json').read_text());data={k:old[k]for k in old.files}
    for k in new.files:assert k.startswith('thermal_T');data[k]=new[k]
    rows=meta['single_control']['new_true_Frank_states'];assert len(rows)==2 and all(r['success']and r['d_um']==8.55 for r in rows)
    np.savez_compressed(a.out/'fields.npz',**data);cfg=json.loads((base/'results.json').read_text())['parameters'];cfg['thermal_d_um']=8.55
    result={'parameters':cfg,'fields_SHA256':sha(a.out/'fields.npz'),'actual_thermal_Frank_rows':rows,'source_input_SHA256':{str((base/'fields.npz').relative_to(ROOT)):sha(base/'fields.npz'),str((control/'thermal_control_fields.npz').relative_to(ROOT)):sha(control/'thermal_control_fields.npz')},'electric_states':'Fouractualsource25electricstatesbyteidenticalarrays,notnewtemperatureorvoltagechoice','thermal_states':'Actuallyrelaxed8.55um25/50CFrank64x33states77/100iterations,not9.8rescaling','keys':list(new.files),'all_shapes64x33':all(new[k].shape==(64,33)for k in new.files),'selection_rule':meta['single_control']['rule'],'phase_only_prediction':meta['thermal_Jones_phase_projection']['single_cutoff_lobe_control_actual64'],'readout_geometry_if_tested':'Originalfixedinner600/yhalf600maskasmatchedthicknesscontrol;notcombiney750andd8.55togetheryet','layer_count':19,'min_pattern_feature_um':1.5,'scope':'Areadyonegeometrycontrolsourceonly;noMaxwellordevicethresholdclaim.'}
    (a.out/'results.json').write_text(json.dumps(result,indent=2),encoding='utf-8');(a.out/'source.py').write_bytes(Path(__file__).read_bytes());print(json.dumps({'fields_SHA':result['fields_SHA256'],'thermal_d':cfg['thermal_d_um'],'thermalkeys':result['keys']},indent=2))
if __name__=='__main__':main()
