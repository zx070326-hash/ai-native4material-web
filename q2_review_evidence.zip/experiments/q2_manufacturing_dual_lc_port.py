"""Two orthogonal LC gratings: explicit finite-port mechanism diagnostic.

This is NOT total hemispherical transmission modulation and NOT a fabricated
four-state cell. It tests if separating diffraction directions can remove the
serial absorption bottleneck before spending effort on the physical LC box.
Real-index source models, their extrapolation, and missing k are kept explicit.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
from scipy.special import ndtr
from scipy.optimize import differential_evolution

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from src.optics import four_state_metrics

DATA=ROOT/'data/q2_current'


def cauchy(w,co):return co[0]+co[1]/w**2+co[2]/w**4


def interval_prob(lo,hi,mean,sigma):
    a=(lo-mean)/sigma;b=(hi-mean)/sigma
    # Stable in either tail.
    return np.where(a>=0,ndtr(-a)-ndtr(-b),ndtr(b)-ndtr(a))


def setup(points=(401,1721),source2004=False):
    w=np.unique(np.r_[np.linspace(.38,.78,points[0]),np.linspace(.78,2.5,points[1])])
    tab=np.loadtxt(DATA/'Li2005_E7_Cauchy.csv',delimiter=',',skiprows=1)
    nE=[]
    for temp in ([29.9,36.1]if source2004 else[25,40]):
        row=np.array([temp,*[np.interp(temp,tab[:,0],tab[:,j])for j in range(1,7)]])
        nE.append((cauchy(w,row[1:4]),cauchy(w,row[4:7])))
    if source2004:
        from experiments.q2_manufacturing_lc_materials import CB
        row=next(r for r in CB['rows']if r['T_C_text']==29.9)
        nT=[cauchy(w,row['e']),cauchy(w,row['o'])]
    else:
        source=json.loads((DATA/'Li2005_5CB_thesis_source.json').read_text())
        nT=[cauchy(w,source['extraordinary_A_B_C']),cauchy(w,source['ordinary_A_B_C'])]
    return w,np.array(nE),np.array(nT)


def calc(w,nE,nT,dE,dT,cutE,cutT,residual=0.,birefringence_scale=1.,z=40000.,waist=100.,periodE=12.,periodT=16.):
    # mm-scale collector dimensions derived from spectral cut positions.
    # Propagation uses paraxial Gaussian widths and exact ray centers. This
    # hybrid scalar approximation must be checked by an angular-spectrum model.
    sigma=.5*waist*np.sqrt(1+(z*w/(np.pi*waist**2))**2)
    def shift(period):
        s=w/period
        return z*s/np.sqrt(1-s*s)
    xe,yt=shift(periodE),shift(periodT)
    edgeE=z*(cutE/periodE)/np.sqrt(1-(cutE/periodE)**2)
    edgeT=z*(cutT/periodT)/np.sqrt(1-(cutT/periodT)**2)
    center=.20*z/40 # 200um at40mm. No clipping of NIR zero order.
    outside=1.1*float(xe.max())+4*float(sigma.max())
    def x_prob(mu):
        return (interval_prob(-center,center,mu,sigma)+interval_prob(edgeE,outside,mu,sigma)
                +interval_prob(-outside,-edgeE,mu,sigma))
    X0,X1=x_prob(0.),x_prob(xe)
    Y0=interval_prob(-edgeT,edgeT,0.,sigma)
    Y1=interval_prob(-edgeT,edgeT,yt,sigma)
    dnE=nE[:,0]-nE[:,1]
    dnT=(nT[0]-nT[1])*birefringence_scale
    etaT=np.array([np.sin(np.pi*dnT*dT/w)**2,np.zeros_like(w)])
    tt=np.empty((2,2,len(w)))
    for voltage in range(2):
        etaE=np.sin(np.pi*dnE*dE*(1. if voltage==0 else residual)/w)**2
        tt[voltage]=((1-etaE)*X0+etaE*X1)*((1-etaT)*Y0+etaT*Y1)
    geom={'E7_period_um':periodE,'5CB_period_um':periodT,'distance_um':z,'Gaussian_waist_1_over_e_field_um':waist,
          'collector_x_intervals_um':[[-outside,-edgeE],[-center,center],[edgeE,outside]],
          'collector_y_interval_um':[-edgeT,edgeT],
          '8step_photoalignment_cell_widths_um':[periodE/8,periodT/8]}
    return tt,geom


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,required=True)
    p.add_argument('--source2004',action='store_true');args=p.parse_args()
    args.out.mkdir(parents=True,exist_ok=False)
    w,nE,nT=setup((121,401),args.source2004);bands={'visible':(.38,.78),'nir':(.78,2.5)}
    def objective(x):
        tt,_=calc(w,nE,nT,*x)
        m=four_state_metrics(w,tt,bands)['summary']
        # Fixed, declared score: balance the two original amplitude thresholds;
        # lightly penalize crossover rather than inventing a decoupling cutoff.
        return -min(m['visible_voltage_delta_min']/.3,m['nir_temperature_delta_min']/.2)+.5*(m['nir_voltage_cross_max']+m['visible_temperature_cross_max'])
    bounds=[(.8,2.5),(2.5,6.),(.73,.85),(.73,.85)]
    opt=differential_evolution(objective,bounds,seed=20261102,popsize=10,maxiter=70,tol=2e-5)
    w,nE,nT=setup(source2004=args.source2004);t,geom=calc(w,nE,nT,*opt.x);m=four_state_metrics(w,t,bands)
    wr,er,tr=setup((801,3441),args.source2004);ref,_=calc(wr,er,tr,*opt.x)
    refined=four_state_metrics(wr,ref,bands)
    scenarios=[]
    for residual in [0.,.1,.2,.3]:
        for scale in [.9,1.,1.1]:
            ts,_=calc(w,nE,nT,*opt.x,residual=residual,birefringence_scale=scale)
            met=four_state_metrics(w,ts,bands)
            scenarios.append({'residual_E7_retardance_fraction':residual,'5CB_birefringence_scale':scale,'metrics':met})
    # Eight equal director-angle steps obey >1um drawn-cell widths. The zeroth
    # Fourier lobe's phase-conversion efficiency is sinc(1/8)^2. We do not
    # assign all other diffracted orders to the port or call this full RCWA.
    q=float(np.sinc(1/8)**2)
    leakage_bound=1-q*q
    md=m['summary']
    min_survival=max(.3/md['visible_voltage_delta_min'],.2/md['nir_temperature_delta_min'])
    conservative_survival=max(.3/max(md['visible_voltage_delta_min']-2*leakage_bound,1e-12),
                              .2/max(md['nir_temperature_delta_min']-2*leakage_bound,1e-12))
    result={'scope':'Lossless LC phase-screen finite-port hypothesis; not a full original-problem pass.',
            'temperatures_C':[29.9,36.1]if args.source2004 else[25,40],
            'E7_cold_hot_models':'Li2005 measured-temperature Cauchy, coefficients interpolated between adjacent reported temperatures; broadband model, k absent',
            '5CB_cold_model':'LiWu2004 TableIII29.9C Cauchy; NIR extrapolation'if args.source2004 else'Li2005 thesis25C Cauchy; NIR extrapolation',
            '5CB_hot_model':'Isotropic with zero birefringence; k absent. 36.1C is source isotropic row, temperature label ambiguity remains.'if args.source2004 else'Isotropic with zero birefringence; absolute hot n and k not supplied by this Jones diagnostic',
            'voltage_values_V':None,'electrical_high_state':'Homeotropic ideal; finite residual retardance is a diagnostic, not a voltage solution',
            'selected':{'E7_d_um':float(opt.x[0]),'5CB_d_um':float(opt.x[1]),'cut_wavelengths_um':opt.x[2:].tolist(),**geom},
            'metrics':m,'refined_metrics':refined,'diagnostic_scenarios':scenarios,
            'index_550nm':{'E7_ne_no_by_T':[[float(np.interp(.55,w,z))for z in row]for row in nE],
                           '5CB_ne_no_cold':[float(np.interp(.55,w,z))for z in nT]},
            'common_gray_survival_required_exclusive':min_survival,
            '8step_main_conversion_efficiency':q,'8step_at_least_one_nonmain_order_power_bound':leakage_bound,
            'gray_survival_after_2state_nonmain_power_subtraction_ONLY_IF_incoherent_or_disjoint_modes':conservative_survival,
            'limits':['Normal unpolarized input, scalar Gaussian order-port model; full anisotropic Maxwell/interface solution not done.',
                      'For a lossless device collecting all outgoing orders, all four total transmissions equal one and both modulations vanish.',
                      'Finite collection windows are part of the measurement definition; this does not establish a window-film total-transmission result.',
                      'Supports, electrodes, alignment layers, seals, spacer area, reflections and material k remain absent from this mechanism diagnostic.',
                      'Common gray survival is only a diagnostic; actual dispersive/state-dependent loss must enter the four-state operator.',
                      'No actual V-to-director, finite anchoring, 3D stability, cool-back reset or thermal mechanical process has been solved.',
                      '8step nonmain power is NOT an unconditional finite-port error bound: coherent cross terms require mode-separation or Gram-matrix verification; the 2state subtraction is conditional only.',
                      'Each-axis exact ray center is not exact simultaneous 2D propagation: diagonal orders require kz depending on both transverse components. This scalar-screen run awaits that correction.',
                      'Model extrapolation does not certify full-band spectral-index branch or all operating-state refractive indices.'],
            'source_sha256':{},'actual_complete_device_pass':False}
    for path in [Path(__file__),DATA/'Li2005_E7_Cauchy.csv',DATA/'Li2005_5CB_thesis_source.json',ROOT/'experiments/q2_manufacturing_lc_materials.py']:
        result['source_sha256'][str(path.relative_to(ROOT))]=hashlib.sha256(path.read_bytes()).hexdigest()
    (args.out/'results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    np.savez_compressed(args.out/'spectra.npz',wavelength_um=w,finite_port_T=t)
    print(json.dumps({k:result[k]for k in ['selected','metrics','common_gray_survival_required_exclusive','gray_survival_after_2state_nonmain_power_subtraction_ONLY_IF_incoherent_or_disjoint_modes']},indent=2))


if __name__=='__main__':main()
