"""Manufacturing restart: measured EC spectral budgets, not a complete device.

This calculation isolates what an electrical branch can contribute before
combining it with a thermal branch. It preserves the difference between real
endpoint optical constants and unverified assembled-cell operation. No new
optical solver or material fit is introduced.
"""
from pathlib import Path
import argparse
import hashlib
import json
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from src.optics import stack_rt, band_mean, index

OLD = ROOT
BANDS = {'visible': (.38, .78), 'nir': (.78, 2.5)}
SOURCES = {}


def load(path, w):
    a = np.loadtxt(path, delimiter=',', skiprows=1)
    if min(w) < a[0, 0] - 1e-12 or max(w) > a[-1, 0] + 1e-12:
        raise ValueError(f'Extrapolation prohibited: {path}')
    key = str(path.relative_to(ROOT)).replace('\\', '/')
    SOURCES[key] = hashlib.sha256(path.read_bytes()).hexdigest()
    return np.interp(w, a[:, 0], a[:, 1]) + 1j*np.interp(w, a[:, 0], a[:, 2])


def ec(name, w):
    if name in ('NiO', 'WO3', 'VWO3'):
        return np.array([load(OLD/f'data/nk/{name}_{s}.csv', w) for s in ('clear', 'dark')])
    return np.array([load(OLD/f'data/q2_device/{name}_{s}.csv', w)
                     for s in ('lithiated', 'unlithiated')])


def summarize(w, t):
    means = np.array([band_mean(w, t, b) for b in BANDS.values()]).T
    return {'T_by_voltage_band': means.tolist(),
            'VIS_delta': float(abs(means[1, 0]-means[0, 0])),
            'NIR_voltage_cross': float(abs(means[1, 1]-means[0, 1])),
            'NIR_mean_abs_spectral_cross': float(band_mean(w, abs(t[1]-t[0]), BANDS['nir'])),
            'NIR_transmission_min_of_voltage_means': float(means[:, 1].min())}


def area_requirements(delta):
    # Disjoint macroscopic sectors, uniform incident irradiance, all transmitted
    # flux collected, no coherent interaction at edges. Strict thresholds.
    if delta <= .3:
        return {'f_EC_min_exclusive': None, 'thermal_delta_min_exclusive': None,
                'can_reach_VIS_30pp': False}
    f = .3/delta
    return {'f_EC_min_exclusive': f,
            'thermal_delta_min_exclusive': .2/(1-f),
            'can_reach_VIS_30pp': True,
            'criterion': '0.3/a_EC + 0.2/b_TC < 1 (independent sector responses)'}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=False)
    w = np.unique(np.r_[np.linspace(.38, .78, 401), np.linspace(.78, 2.5, 1721)])
    ds = np.geomspace(.01, 10., 601)
    records, exports = [], {'wavelength_um': w}
    for name in ('NiO', 'WO3', 'VWO3', 'V2O5', 'LiCoO2', 'SnO2'):
        ns = ec(name, w)
        tt = np.array([stack_rt(w, n[None], ds[:, None])[1] for n in ns])
        dv = np.abs(band_mean(w, tt[1]-tt[0], BANDS['visible']))
        j = int(np.argmax(dv))
        s = summarize(w, tt[:, j])
        rec = {'material': name, 'stage': 'active_film_only', 'thickness_nm': float(1000*ds[j]),
               'n_range': [float(ns.real.min()), float(ns.real.max())],
               'index_pass': bool(ns.real.min() >= 1.5 and ns.real.max() <= 3),
               'missing': ['electrodes', 'ion conductor', 'counter electrode', 'support', 'voltage/temperature relation'],
               **s, 'lateral_area_budget': area_requirements(s['VIS_delta']),
               'actual_device_pass': False}
        records.append(rec)
        exports[name+'_best_active_T'] = tt[:, j]
        np.savetxt(args.out/(name+'_active_scan.csv'), np.c_[ds*1000, dv,
            band_mean(w,tt[0],BANDS['nir']),band_mean(w,tt[1],BANDS['nir'])],
            delimiter=',', comments='', header='thickness_nm,VIS_delta,NIR_T_V0,NIR_T_V1')

    # Actual complementary chemistry and both electrodes are retained, but the
    # ion conductor and support spectra still have explicit specimen gaps.
    C = load(OLD/'data/q2_route_materials/ZnO_Bohorquez2022.csv', w)
    W, N = ec('WO3', w), ec('NiO', w)
    I, S = index('Ta2O5_Franta', w), index('Al2O3_Franta', w)
    for name in ('Ta2O5_Franta', 'Al2O3_Franta'):
        p = ROOT/f'data/nk/{name}.csv'
        SOURCES[str(p.relative_to(ROOT)).replace('\\','/')] = hashlib.sha256(p.read_bytes()).hexdigest()
    dw = np.geomspace(.01*219/68, 3., 401)
    for support in (False, True):
        ns = np.array([[C, W[v], I, N[v], C] + ([S] if support else []) for v in range(2)])
        d = np.c_[np.full(len(dw), .0998), dw, np.full(len(dw), .3), dw*68/219,
                  np.full(len(dw), .0998)]
        if support:
            d = np.c_[d, np.full(len(dw), 5.)]
        tt = np.array([stack_rt(w, n, d)[1] for n in ns])
        dv = np.abs(band_mean(w,tt[1]-tt[0],BANDS['visible']))
        # Also select the strongest NIR-preserving specimen meeting VIS30pp.
        min_nir = np.minimum(band_mean(w,tt[0],BANDS['nir']),band_mean(w,tt[1],BANDS['nir']))
        selections = {'maximum_VIS': int(np.argmax(dv))}
        feasible = np.flatnonzero(dv > .3)
        if len(feasible):
            selections['maximum_NIR_given_VIS30'] = int(feasible[np.argmax(min_nir[feasible])])
        tag = 'cell_supported' if support else 'cell_no_support'
        np.savetxt(args.out/(tag+'_scan.csv'), np.c_[dw*1000,dv,min_nir], delimiter=',',
                   comments='', header='WO3_nm,VIS_delta,min_NIR_T')
        for select, j in selections.items():
            s = summarize(w,tt[:,j])
            records.append({'material': 'WO3_NiO_complementary', 'stage': tag, 'selection': select,
                'layer_names': ['ZnO','WO3','Ta2O5_OPTICAL_PROXY','NiO','ZnO']+(['Al2O3_SUPPORT_PROXY']if support else []),
                'thickness_nm': (d[j]*1000).tolist(), 'functional_finite_layer_count': int(len(d[j])),
                'charge_mC_cm2': float(dw[j]*68),
                'charge_capacity_ratio_WO3_NiO': 68/219,
                'n_range': [float(ns.real.min()),float(ns.real.max())],
                'index_pass': bool(ns.real.min()>=1.5 and ns.real.max()<=3),
                **s,'lateral_area_budget':area_requirements(s['VIS_delta']),
                'actual_device_pass':False})
            exports[tag+'_'+select+'_T'] = tt[:,j]
    electrodes = {}
    for name in ('ITO_LBNL','FTO_LBNL','IOH216_digitized'):
        n=load(OLD/f'data/q2_device/{name}.csv',w)
        electrodes[name]={'n_min':float(n.real.min()),'n_max':float(n.real.max()),
                          'index_pass':bool(n.real.min()>=1.5 and n.real.max()<=3)}
    electrodes['ZnO_Bohorquez2022']={'n_min':float(C.real.min()),'n_max':float(C.real.max()),
        'index_pass':bool(C.real.min()>=1.5 and C.real.max()<=3),
        'qualification':'Bulk optical fit; source roughness, electrochemical compatibility and DC contact behavior not established by this calculation.'}

    result={'purpose':'Electrical component and area/throughput budgets for manufacturing restart; not a completed Q2 device',
        'bands_um':BANDS,'incidence':'normal unpolarized; coherent planar layers; air ports',
        'records':records,'electrodes':electrodes,'source_sha256':SOURCES,
        'sources':{'EC':'https://windows.lbl.gov/optical-indices-electrochromic-materials',
                   'ZnO':'https://doi.org/10.1021/acsaelm.1c01026',
                   'all_solid_process_example':'https://doi.org/10.1016/j.cej.2020.125628'},
        'limits':['Electrical states are measured charge endpoints, not demonstrated common voltages at both thermal endpoints.',
                  'No optical-temperature dependence or electrochemical temperature drift is supplied.',
                  'Ta2O5_Franta n,k is not the lithiation-dependent electrolyte specimen in a working cell.',
                  '5um Al2O3 thin-film-source constants are only a support diagnostic, not a released or thinned crystal fabrication proof.',
                  'ZnO fitted bulk is from a different specimen and substrate than the assembled cell.',
                  'The independent-sector area relation is exact within its stated incoherent flux model; optical resonances and edges are excluded.',
                  'These finite scans and proxy-cell results do not bound all EC materials, matching stacks or layouts.'],
        'actual_complete_device_pass':False}
    np.savez_compressed(args.out/'electrical_endpoint_spectra.npz',**exports)
    (args.out/'results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({'records':[{k:r[k]for k in ('material','stage','VIS_delta','NIR_voltage_cross','lateral_area_budget')}for r in records],
                      'electrodes':electrodes},indent=2))


if __name__ == '__main__':
    main()
