"""Coherent finite-aperture Fresnel/CZT test of the same twelve-layer LC device.

The registered post region is excluded (zero field), not assigned invented resin
optics. Seven circular-Jones paths retain their coherent same-polarization terms.
This thin-screen/paraxial model is not a full grating-Maxwell or post-device proof.
"""
import os
for key in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']:
    os.environ[key]='1'
import argparse,json,time,hashlib,sys
from pathlib import Path
import numpy as np
from scipy.signal import CZT
from scipy.special import erf
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments.q2_manufacturing_lc_layer_budget import amplitude,DATA,metrics
from experiments.q2_manufacturing_lc_materials import ALIGNMENT,CB,cauchy,lorentz
from experiments.q2_manufacturing_ec_budget import load,OLD
from src.optics import index

GEOMFILE=ROOT/'runs/20261102-q2-manufacturing-dual-lc-port-02/results.json'
DIRECTOR=ROOT/'runs/20261102-q2-manufacturing-lc-director-02/director_optics.npz'
SPECTRAL_GRID=np.array([.4,.45,.5,.55,.6,.65,.7,.75,.78,.80,.81,.82,.83,.84,.86,.9,1.,1.25,1.5,1.75,2.,2.25,2.5])


def layer_coefficients(w,g):
    """Complex a,b, not intensity-only efficiencies, from actual4V source texture."""
    z=np.load(DIRECTOR);prefix='source_scale_W8e-4__'
    pei=index('PEI_Zhang',w);con=load(OLD/'data/q2_device/IOH216_digitized.csv',w)
    align=[lorentz(w,ALIGNMENT['parameters_post_UV'][s])for s in ['e','o']]
    tab=np.loadtxt(DATA/'Li2005_E7_Cauchy.csv',delimiter=',',skiprows=1)
    result={};checks=[]
    for ti,temp in enumerate([29.9,36.1]):
        co=[np.interp(temp,tab[:,0],tab[:,j])for j in range(1,7)]
        e7=[cauchy(w,co[:3]),cauchy(w,co[3:])]
        row=next(q for q in CB['rows']if q['T_C_text']==temp)
        cb=[cauchy(w,row[s])for s in ['e','o']]
        for mat,V,inds in [('E7',0,e7),('E7',4,e7),('5CB',0,cb)]:
            theta=z[f'{prefix}{mat}_V{V}__theta_rad'];mid=(theta[:-1]+theta[1:])/2
            ne,no=inds
            extraordinary=ne[None,:]*no[None,:]/np.sqrt(ne[None,:]**2*np.sin(mid[:,None])**2+no[None,:]**2*np.cos(mid[:,None])**2)
            ordinary=np.broadcast_to(no,extraordinary.shape);amps=[]
            d=g['E7_d_um']if mat=='E7'else g['5CB_d_um']
            for pol,nlayer in enumerate([extraordinary,ordinary]):
                pre=[pei,con,align[pol]]if mat=='E7'else[pei,align[pol]]
                post=[align[pol],con,pei]if mat=='E7'else[align[pol],pei]
                ds_pre=[4,.099,.015]if mat=='E7'else[4,.015]
                ds_post=[.015,.099,4]if mat=='E7'else[.015,4]
                r,t=amplitude(w,np.vstack([*pre,nlayer,*post]),ds_pre+[d/len(mid)]*len(mid)+ds_post)
                amps.append(t)
            result[f'{mat}_V{V}_T{ti}']=np.array([(amps[0]+amps[1])/2,(amps[0]-amps[1])/2])
    return result


def coefficients_at(coeff,j,v,t):
    ae,be=coeff[f'E7_V{[0,4][v]}_T{t}'][:,j];ac,bc=coeff[f'5CB_V0_T{t}'][:,j]
    # Basis [1, exp(+iX), exp(-iX), exp(+iY), exp(-iY), exp(iX-iY), exp(-iX+iY)].
    C=np.zeros((4,7),complex)
    C[0,0]=C[3,0]=ac*ae;C[0,5]=C[3,6]=bc*be
    C[1,2]=C[2,1]=ac*be;C[1,4]=C[2,3]=bc*ae
    return C


def power(C,gram):
    return float(.5*np.real(np.einsum('ib,bc,ic->',C,gram,C.conj())))


def make_basis(g,dx,halfwidth,pattern,position):
    N=int(round(2*halfwidth/dx));x=(np.arange(N)-(N-1)/2)*dx;y=x.copy()
    X=x[None,:];Y=y[:,None]
    G=np.exp(-(X*X+Y*Y)/g['Gaussian_waist_1_over_e_field_um']**2)
    if position=='none':mask=np.ones((N,N),bool)
    else:
        cx,cy=(0.,0.)if position=='post_center'else(100.,75.)
        ex=(X-cx+100)%200-100;ey=(Y-cy+75)%150-75
        mask=(ex/50)**2+(ey/25)**2>1
    def phase(coord,period):
        if pattern=='continuous':return 2*np.pi*coord/period
        return (np.floor(coord/(period/8))+.5)*2*np.pi/8
    px=phase(X,g['E7_period_um']);py=phase(Y,g['5CB_period_um'])
    B=np.empty((7,N,N),complex);B[0]=G*mask
    B[1]=B[0]*np.exp(1j*px);B[2]=B[0]*np.exp(-1j*px)
    B[3]=B[0]*np.exp(1j*py);B[4]=B[0]*np.exp(-1j*py)
    B[5]=B[0]*np.exp(1j*(px-py));B[6]=B[0]*np.exp(1j*(-px+py))
    P0=np.pi*g['Gaussian_waist_1_over_e_field_um']**2/2
    flat=B.reshape(7,-1);gram=dx*dx/P0*(flat@flat.conj().T)
    return x,y,B,gram,{'input_grid_points_each_axis':N,'input_dx_um':dx,'input_halfwidth_um':halfwidth,
        'Gaussian_power_analytic':P0,'Gaussian_power_numeric':float(np.sum(G*G)*dx*dx),
        'beam_weighted_open_fraction':float(gram[0,0].real),
        'pattern':pattern,'post_position':position,
        'post_ellipse_diameters_um':[100,50],'post_period_um':[200,150],
        'post_identity':'Both registered cells share one zero-field aperture mask; actual transparent post material unmodeled.'}


def output_axis(lo,hi,maxstep):
    n=int(np.ceil((hi-lo)/maxstep));step=(hi-lo)/n
    return lo+(np.arange(n)+.5)*step,step


def propagate_port(x,y,B,w,g,maxstep):
    z=g['distance_um'];dx=x[1]-x[0];dy=y[1]-y[0]
    yp,dyp=output_axis(*g['collector_y_interval_um'],maxstep)
    fy0=yp[0]/(w*z);dfy=dyp/(w*z)
    ty=CZT(n=len(y),m=len(yp),w=np.exp(-2j*np.pi*dfy*dy),a=np.exp(2j*np.pi*fy0*dy))
    phase=np.exp(1j*np.pi*(y[:,None]**2+x[None,:]**2)/(w*z))
    middle=ty(B*phase[None,:,:],axis=1)
    P0=np.pi*g['Gaussian_waist_1_over_e_field_um']**2/2
    gram=np.zeros((7,7),complex);windows=[]
    for lo,hi in g['collector_x_intervals_um']:
        xp,dxp=output_axis(lo,hi,maxstep);fx0=xp[0]/(w*z);dfx=dxp/(w*z)
        tx=CZT(n=len(x),m=len(xp),w=np.exp(-2j*np.pi*dfx*dx),a=np.exp(2j*np.pi*fx0*dx))
        field=tx(middle,axis=2)*(dx*dy/(w*z))
        # Omitted common output chirp and origin phase cancel in every Gram product.
        f=field.reshape(7,-1);part=(f@f.conj().T)*(dxp*dyp/P0)
        gram+=part;windows.append(part)
    return gram,np.array(windows)


def spectral_diagnostics(x,y,B,w,C_by_state):
    """Fourier norm outside light cone: proxy-screen warning, not power flux certificate."""
    dx=x[1]-x[0];dy=y[1]-y[0];N=len(x);M=len(y)
    kx=np.fft.fftfreq(N,dx);ky=np.fft.fftfreq(M,dy)
    rho2=ky[:,None]**2+kx[None,:]**2
    F=np.fft.fft2(B,axes=(-2,-1));norm=dx*dy/(N*M)
    result=[]
    for j,lam in enumerate(w):
        take=rho2>1/lam**2
        f=F[:,take];gram=(f@f.conj().T)*norm
        total=F.reshape(7,-1);gramall=(total@total.conj().T)*norm
        vals=[]
        for C in C_by_state[j]:
            denom=power(C,gramall);vals.append(power(C,gram)/denom if denom else 0.)
        result.append(vals)
    return np.array(result)


def validation(g):
    # Independent direct finite Fourier sum vs SciPy CZT, including arbitrary origin.
    rng=np.random.default_rng(4);a=rng.normal(size=21)+1j*rng.normal(size=21)
    x=-3.1+np.arange(21)*.3;freq=np.linspace(-.41,.37,33)
    f0=freq[0];df=freq[1]-freq[0]
    c=CZT(n=len(x),m=len(freq),w=np.exp(-2j*np.pi*df*.3),a=np.exp(2j*np.pi*f0*.3))
    num=c(a)*np.exp(-2j*np.pi*freq*x[0]);direct=np.exp(-2j*np.pi*freq[:,None]*x[None,:])@a
    x,y,B,ig,di=make_basis(g,1,400,'continuous','none')
    tests=[]
    for lam in [.4,.82,2.5]:
        pg,_=propagate_port(x,y,B,lam,g,10)
        wz=g['Gaussian_waist_1_over_e_field_um']*np.sqrt(1+(g['distance_um']*lam/(np.pi*g['Gaussian_waist_1_over_e_field_um']**2))**2)
        lo,hi=g['collector_y_interval_um'];py=.5*(erf(np.sqrt(2)*hi/wz)-erf(np.sqrt(2)*lo/wz))
        px=sum(.5*(erf(np.sqrt(2)*hi/wz)-erf(np.sqrt(2)*lo/wz))for lo,hi in g['collector_x_intervals_um'])
        tests.append({'lambda_um':lam,'CZT_constant_path_port_fraction':float(pg[0,0].real),
                      'analytic_paraxial_Gaussian_port_fraction':float(px*py),
                      'abs_error':float(abs(pg[0,0].real-px*py))})
    return {'CZT_vs_direct_DFT_complex_max_error':float(np.max(np.abs(num-direct))),
            'Gaussian_checks':tests,'input_gaussian_relative_truncation_quadrature_error':abs(di['Gaussian_power_numeric']/di['Gaussian_power_analytic']-1)}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--dx',type=float,default=1.);parser.add_argument('--out-step',type=float,default=12.)
    parser.add_argument('--halfwidth',type=float,default=400.);parser.add_argument('--wavelengths',type=str)
    parser.add_argument('--positions',type=str,default='none,post_center,gap_center')
    parser.add_argument('--patterns',type=str,default='continuous,8step');parser.add_argument('--skip-validation',action='store_true')
    args=parser.parse_args();args.out.mkdir(parents=True,exist_ok=False)
    g=json.loads(GEOMFILE.read_text())['selected']
    w=SPECTRAL_GRID if args.wavelengths is None else np.array([float(x)for x in args.wavelengths.split(',')])
    co=layer_coefficients(w,g);C_by_state=[[coefficients_at(co,j,v,t)for v in range(2)for t in range(2)]for j in range(len(w))]
    arrays={'wavelength_um':w};cases=[]
    for pattern in args.patterns.split(','):
        for pos in args.positions.split(','):
            start=time.perf_counter();x,y,B,gin,grid=make_basis(g,args.dx,args.halfwidth,pattern,pos)
            port=np.zeros((2,2,len(w)));local=port.copy();incoherent=port.copy();portwindows=np.zeros((2,2,3,len(w)));grams=[]
            for j,lam in enumerate(w):
                gr,gw=propagate_port(x,y,B,lam,g,args.out_step);grams.append(gr)
                for v in range(2):
                    for t in range(2):
                        C=coefficients_at(co,j,v,t)
                        port[v,t,j]=power(C,gr);local[v,t,j]=power(C,gin)
                        incoherent[v,t,j]=power(C,np.diag(np.diag(gr)))
                        portwindows[v,t,:,j]=[power(C,q)for q in gw]
            evanescent=spectral_diagnostics(x,y,B,w,C_by_state)
            name=pattern+'__'+pos;arrays[name+'__port_T']=port;arrays[name+'__local_screen_T']=local
            arrays[name+'__incoherent_paths_T']=incoherent;arrays[name+'__per_window_T']=portwindows
            arrays[name+'__receiver_path_Gram']=np.array(grams);arrays[name+'__spatial_norm_outside_propagating_cone']=evanescent
            row={'id':name,'grid':grid,'out_step_max_um':args.out_step,'elapsed_seconds':time.perf_counter()-start,
                 'port_T_by_voltage_temperature_wavelength':port.tolist(),
                 'coherent_minus_path_incoherent_max_abs':float(np.max(np.abs(port-incoherent))),
                 'collected_over_local_screen_power_max':float(np.max(port/np.maximum(local,1e-30))),
                 'nonpropagating_spatial_norm_fraction_max':float(evanescent.max())}
            max_x=max(abs(v)for pair in g['collector_x_intervals_um']for v in pair)
            max_y=max(abs(v)for v in g['collector_y_interval_um'])
            row['receiver_exceeds_input_Nyquist_at_wavelength_um']=[float(lam)for lam in w if max(max_x,max_y)/(lam*g['distance_um'])>.5/args.dx]
            if w[0]==.4 and w[-1]==2.5 and .78 in w:
                row['sparse_grid_band_estimate_NOT_certified']=metrics(w,port)
            cases.append(row);print(json.dumps({k:row[k]for k in ['id','elapsed_seconds','coherent_minus_path_incoherent_max_abs','nonpropagating_spatial_norm_fraction_max']},ensure_ascii=False),flush=True)
    checks={}if args.skip_validation else validation(g)
    limits=['Fresnel paraxial propagation at40mm after a collocated local Jones product; no inter-cell separation diffraction or backward reflections.',
            'Eight-step high orders near/beyond light cone are not modeled physically by Fresnel. Reported Fourier norm outside cone is a warning, not an error bound or lost flux.',
            'Columns are a binary excluded-field region. Actual transparent post index, polarization and director distortion are unknown; this is not a universal conservative bound.',
            'Identical registered post masks on both cells; relative misregistration, phase registration and inputbeam position tolerance untested.',
            'No full patterned Maxwell propagation inside LC; same finite-anchoring fixed-phi4Vrms director source; source material/temperature transfer and k omissions inherited.',
            'PEI supports are source proxies, not demonstrated same-process thin-cell supports; all optical model extrapolations remain.',
            'Sparse wavelength integration is exploratory. Coarse/fine comparison at selected wavelengths cannot certify the entire band or full-field solution.',
            'Receiver frequencies outside input Nyquist are explicitly flagged: a1um grid aliases outer receiver locations in the blue. No extrapolated convergence claim is made.',
            'Full port normalization is to original incident Gaussian power; no renormalization by open area or transmitted power.',
            'The input beam is unpolarized: propagated intensities from two independent circular input polarizations are averaged. Paths within each Jones element interfere coherently.']
    result={'scope':__doc__,'geometry':g,'temperature_source_labels_C':[29.9,36.1],'drive_terminal_rms_V':[0,4],
            'wavelength_um':w.tolist(),'finite_physical_layers':12,'cases':cases,'verification':checks,'limits':limits,
            'actual_complete_device_pass':False,'hashes':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()for p in [Path(__file__),GEOMFILE,DIRECTOR,ROOT/'experiments/q2_manufacturing_lc_layer_budget.py']}}
    (args.out/'results.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf8')
    (args.out/'source.py').write_bytes(Path(__file__).read_bytes())
    np.savez_compressed(args.out/'spectra.npz',**arrays)
    print(json.dumps(checks,indent=2))


if __name__=='__main__':main()
