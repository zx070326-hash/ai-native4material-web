"""Two orthogonal periodic LC cells joined by their full vector scattering.

1D Fourier-Maxwell per conserved transverse momentum in each cell; assembled
2D plane-wave scattering and exact2um air-gap return solve. Finite beam/post
envelope is a subsequent approximation, not hidden inside periodic Maxwell.
"""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import sys,argparse,json,time
import numpy as np
from scipy.linalg import expm
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments.q2_gap_optics import texture,FOUR,ZERO,GEOMFILE,DATA,ALIGNMENT,CB,cauchy,lorentz,load,OLD,index
from experiments.q2_gap_rcwa_check import convolution
SOURCE4=FOUR
SOURCE0=ZERO

def generator(eps,Kx,Ky,m):
    iz=1/eps[:,2,2];N=len(m);cv=lambda v:convolution(v,m);I=np.eye(N);Z=np.zeros_like(I)
    A=[[cv(eps[:,i,j]-eps[:,i,2]*iz*eps[:,2,j])for j in range(2)]for i in range(2)];xz=cv(iz*eps[:,0,2]);yz=cv(iz*eps[:,1,2]);zz=cv(iz)
    G=np.block([[-Kx@xz,-Kx@yz,I-Kx@zz@Kx,-Kx@zz@Ky],[-Ky@xz,-Ky@yz,-Ky@zz@Kx,I-Ky@zz@Ky],
                [A[0][0]-Ky@Ky,A[0][1]+Ky@Kx,-xz@Kx,-xz@Ky],[A[1][0]+Kx@Ky,A[1][1]-Kx@Kx,-yz@Kx,-yz@Ky]])
    return G

def dielectric(ne,no,th,ph):
    n=np.stack([np.cos(th)*np.cos(ph),np.cos(th)*np.sin(ph),np.sin(th)],-1)
    return no*no*np.eye(3)[None]+(ne*ne-no*no)*n[:,:,None]*n[:,None,:]

def admittance(qx,qy):
    qz=np.sqrt(1-qx*qx-qy*qy+0j)
    return np.block([[np.diag((1-qy*qy)/qz),np.diag(qx*qy/qz)],[np.diag(qx*qy/qz),np.diag((1-qx*qx)/qz)]])

def to_scattering(M,Y):
    I=np.eye(len(Y));W=np.block([[I,I],[Y,-Y]]);D=np.linalg.solve(W,M@W);N=len(Y);A,B,C,DD=D[:N,:N],D[:N,N:],D[N:,:N],D[N:,N:];inv=np.linalg.inv(DD)
    return -inv@C,B@inv,A-B@inv@C,inv

def single_cell(mat,V,ti,lam,g,m,nz,nx=128):
    theta,phi,easy=texture(mat,V,nx,nz,four=SOURCE4,zero=SOURCE0);temp=[29.9,36.1][ti];tab=np.loadtxt(DATA/'Li2005_E7_Cauchy.csv',delimiter=',',skiprows=1)
    if mat=='E7':co=[np.interp(temp,tab[:,0],tab[:,j])for j in range(1,7)];ne,no=[complex(cauchy(np.array(lam),v))for v in [co[:3],co[3:]]]
    else:row=next(r for r in CB['rows']if r['T_C_text']==temp);ne,no=[complex(cauchy(np.array(lam),row[s]))for s in ['e','o']]
    pei=complex(index('PEI_Zhang',np.array([lam]))[0]);io=complex(load(OLD/'data/q2_device/IOH216_digitized.csv',np.array([lam]))[0]);al=[complex(lorentz(np.array(lam),ALIGNMENT['parameters_post_UV'][s]))for s in ['e','o']]
    pre=[(dielectric(pei,pei,easy*0,easy*0),4)]
    if mat=='E7':pre.append((dielectric(io,io,easy*0,easy*0),.099))
    pre.append((dielectric(*al,easy*0,easy),.015));layers=pre+[(dielectric(ne,no,theta[:,iz],phi[:,iz]),g[mat+'_d_um']/nz)for iz in range(nz)]+pre[::-1]
    N=len(m);S=[np.zeros((2*N*N,2*N*N),complex)for _ in range(4)];condition=0.
    for fixedindex,mf in enumerate(m):
        if mat=='E7':qx=lam*m/(2*g['E7_period_um']);qy=np.full(N,lam*mf/(2*g['5CB_period_um']));idx=np.arange(N)+fixedindex*N
        else:qx=np.full(N,lam*mf/(2*g['E7_period_um']));qy=lam*m/(2*g['5CB_period_um']);idx=np.arange(N)*N+fixedindex
        Kx=np.diag(qx);Ky=np.diag(qy);M=np.eye(4*N,dtype=complex)
        for ep,dd in layers:M=expm(2j*np.pi/lam*dd*generator(ep,Kx,Ky,m))@M
        local=to_scattering(M,admittance(qx,qy));idx=np.r_[idx,idx+N*N]
        for a,b in zip(S,local):a[np.ix_(idx,idx)]=b
        condition=max(condition,float(np.linalg.cond(M)))
    return S,condition

def device(lam,g,order,nz):
    m=np.arange(-order,order+1);N=len(m);mx,my=np.meshgrid(m,m,indexing='xy');qx=lam*mx.ravel()/(2*g['E7_period_um']);qy=lam*my.ravel()/(2*g['5CB_period_um']);qz=np.sqrt(1-qx*qx-qy*qy+0j)
    Y=admittance(qx,qy);phase=np.tile(np.exp(2j*np.pi/lam*2*qz),2);src=np.zeros((2*N*N,2));ind=order*N+order;src[ind,0]=1;src[N*N+ind,1]=1;states={};di=[]
    for ti in range(2):
        c,cc=single_cell('5CB',0,ti,lam,g,m,nz)
        for vi,V in enumerate([0,4]):
            e,ce=single_cell('E7',V,ti,lam,g,m,nz)
            # a=T1 src+R1,right P R2,left P a.
            rt=e[1]@(phase[:,None]*c[0]*phase[None,:]);a=np.linalg.solve(np.eye(2*N*N)-rt,e[2]@src)
            out=c[2]@(phase[:,None]*a);back=e[0]@src+e[3]@(phase[:,None]*(c[0]@(phase[:,None]*a)))
            Tout=float(np.real(np.sum(out.conj()*(Y@out)))/2);Rout=float(np.real(np.sum(back.conj()*(Y@back)))/2)
            Em=np.stack([out[:N*N],out[N*N:]],axis=1).reshape(N,N,2,2);Gout=Y@out;Gm=np.stack([Gout[:N*N],Gout[N*N:]],axis=1).reshape(N,N,2,2)
            states[f'V{vi}T{ti}__E']=Em;states[f'V{vi}T{ti}__G']=Gm
            di.append({'V':V,'T_index':ti,'T':Tout,'R':Rout,'A':1-Tout-Rout,'cell_transfer_condition_max':max(ce,cc),'cavity_residual_inf':float(abs((np.eye(2*N*N)-rt)@a-e[2]@src).max())})
    return states,di

def main():
    global SOURCE4,SOURCE0
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,required=True);p.add_argument('--wavelengths',default='.4,.55,.78,.82,1.25,2,2.5');p.add_argument('--inverse-grid',type=int);p.add_argument('--order',type=int,default=4);p.add_argument('--nz',type=int,default=32);p.add_argument('--shard',type=int,default=0);p.add_argument('--shards',type=int,default=1);p.add_argument('--four',type=Path,default=FOUR);p.add_argument('--zero',type=Path,default=ZERO);p.add_argument('--midpoints',action='store_true');p.add_argument('--min-wavelength',type=float,default=0);a=p.parse_args();SOURCE4=a.four;SOURCE0=a.zero;a.out.mkdir(parents=True,exist_ok=False);g=json.loads(GEOMFILE.read_text())['selected']
    w=np.unique(np.r_[1/np.linspace(1/2.5,1/.4,a.inverse_grid),.4,.78,2.5])if a.inverse_grid else np.array([float(s)for s in a.wavelengths.split(',')]);w=(w[:-1]+w[1:])/2 if a.midpoints else w;w=w[w>=a.min_wavelength];w=w[a.shard::a.shards];arrays={'wavelength_um':w,'harmonics':np.arange(-a.order,a.order+1)};vals={};di=[];tic=time.perf_counter()
    for lam in w:
        s,d=device(lam,g,a.order,a.nz)
        for k,v in s.items():vals.setdefault(k,[]).append(v)
        di.append({'lambda_um':float(lam),'states':d});print(json.dumps({'lambda_um':float(lam),'done':len(di),'total':len(w),'T':[q['T']for q in d],'A':[q['A']for q in d],'condition':max(q['cell_transfer_condition_max']for q in d),'elapsed_s':time.perf_counter()-tic}),flush=True)
        if len(di)%25==0:(a.out/'partial_results.json').write_text(json.dumps(di,indent=2),encoding='utf8')
    arrays.update({k:np.array(v)for k,v in vals.items()});np.savez_compressed(a.out/'scattered_fields.npz',**arrays)
    result={'scope':__doc__,'wavelength_count':len(w),'order':a.order,'nz':a.nz,'fourier_samples':128,'source4V':str(SOURCE4),'source0V':str(SOURCE0),'geometry':g,'air_gap_um':2.,'phase_origin':'Physical continuous coordinates; Fourier sample-center phase already corrected, no extra originshift in output.','thermal_director_frame':'5CB source x-modulated Frank field is rotated90deg and shifted-Lambda/2 to retain lab-frame8step boundary registration.','diagnostics':di,'limits':['Periodic plane-wave vectorMaxwell Galerkin model; finite-order andz-slice convergence still required.','FiniteGaussian/post/receiver are not included here; any envelope mapping must be separately labeled.','Source material and director/temperature assumptions unchanged; realpost/seal optics and thermal reset remain unclosed.']}
    (a.out/'results.json').write_text(json.dumps(result,indent=2),encoding='utf8');(a.out/'source.py').write_bytes(Path(__file__).read_bytes())

if __name__=='__main__':main()
