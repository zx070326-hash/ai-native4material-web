"""Restricted Frank director and actual-voltage closure for the two-LC candidate.

phi=pi*x/period is imposed and only theta(z) relaxes. Fixed conductor-to-conductor
RMS voltage uses self-consistent 1D series dielectric capacitance, including two
alignment layers. This is a controlled restricted-family test, not a 3D proof.
"""
import os
for _key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:
    os.environ[_key]='1'
import argparse,json,hashlib,sys
from pathlib import Path
import numpy as np
import autograd.numpy as anp
from autograd import value_and_grad,hessian
from scipy.optimize import minimize,brentq
from scipy.linalg import eigh
from scipy.integrate import solve_bvp,cumulative_trapezoid

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments.q2_manufacturing_lc_layer_budget import amplitude,port_weights,metrics,DATA
from experiments.q2_manufacturing_lc_materials import ALIGNMENT,CB,cauchy,lorentz
from experiments.q2_manufacturing_ec_budget import load,OLD
from src.optics import index
EPS0=8.8541878128e-12

SOURCE={
 'E7_elastic_dielectric':{'doi':'10.3390/ma15072453','primary':'https://pmc.ncbi.nlm.nih.gov/articles/PMC8999608/',
   'K_pN':[11.1,6.5,17.1],'eps_perp':5.2,'eps_parallel':19,
   'identity':'Parameters used by Nys2022 for E7 room-temperature director simulation; not measured on Li2005 optical specimen at29.9/36.1C.'},
 '5CB_elastic':{'doi':'10.1038/s41598-024-68812-x','primary':'https://pmc.ncbi.nlm.nih.gov/articles/PMC11292029/',
   'K_pN':[5.6,3.7,8.2],'temperature_C_approx':22,
   'identity':'Bankova2024 Table1 measured means; transfer to29.9C explicit. Thermal cell uses no applied voltage.'},
 'alignment_anchoring':{'doi':'10.1889/1.2720326','primary':'https://eekwok.home.ece.ust.hk/publications/2005/p_124.pdf',
   'material':'SD1/SDA2 40:60, V65 2% relative to SDA2, about10nm, UV>=1J/cm2,150C1h',
   'polar_W_J_m2':8e-4,'azimuthal_W_J_m2':1.4e-4,
   'LC_specimen':'MLC-9000-100 on ITO-coated PES, with glass references',
   'identity':'Demonstrated anchoring scale, not measured E7/5CB or our15nm film. Wphi is documented but not solved in this fixed-phi family.'},
 'alignment_low_frequency_permittivity':{'values':[2,3,5],
   'identity':'Explicit unmeasured dielectric scenarios; optical n squared is NOT assumed to be DC/1kHz epsilon.'},
 'drive':{'frequency_Hz_design':1000,
   'V_RMS_terminal':[0,3,4],
   'identity':'Sinusoidal uniform plate-electrode drive, RMS conductor-to-conductor values. No ionic conduction, impedance phase, lead/fringe fields or dynamics solved.'}}


def functional(d_um,period_um,K_pN,W,V,eps_perp=5.2,eps_parallel=19,eps_align=3,alignment_um=.015,nodes=129):
    d=d_um*1e-6;K=np.array(K_pN)*1e-12;h=1/(nodes-1)
    q=np.pi*d_um/period_um;b=K[1]/K[0];c=K[2]/K[0];wa=W*d/K[0]
    series=2*alignment_um/(d_um*eps_align)
    def energy(t):
        mid=(t[:-1]+t[1:])/2;der=(t[1:]-t[:-1])/h
        co=anp.cos(mid)**2;si=1-co
        bulk=.5*(co+c*si)*der**2+q*q/4*(co+b*si*co+c*co**2)
        denom=anp.sum(h/(eps_perp+(eps_parallel-eps_perp)*si))+series
        electric=-EPS0*V*V/(2*K[0])*(1/denom-1/(1/eps_perp+series))
        return anp.sum(bulk)*h+wa/2*(anp.sin(t[0])**2+anp.sin(t[-1])**2)+electric
    return energy


def solve(d_um,period_um,K_pN,W,V,eps_perp=5.2,eps_parallel=19,eps_align=3,nodes=129):
    energy=functional(d_um,period_um,K_pN,W,V,eps_perp,eps_parallel,eps_align,nodes=nodes)
    vg=value_and_grad(energy);u=np.linspace(0,1,nodes)
    seeds=[np.zeros(nodes),.2*np.sin(np.pi*u),1.3*np.sin(np.pi*u),np.full(nodes,1.3),np.full(nodes,np.pi/2)]
    solutions=[]
    for seed in seeds:
        sol=minimize(vg,seed,jac=True,method='L-BFGS-B',bounds=[(0,np.pi/2)]*nodes,
            options={'maxiter':8000,'maxls':60,'maxcor':30,'ftol':2e-14,'gtol':2e-8})
        solutions.append(sol)
    best=min(solutions,key=lambda a:a.fun);theta=best.x
    grad=best.jac.copy();grad[(theta<1e-8)&(grad>0)]=0;grad[(theta>np.pi/2-1e-8)&(grad<0)]=0
    mid=(theta[:-1]+theta[1:])/2;ez=eps_perp+(eps_parallel-eps_perp)*np.sin(mid)**2
    inv=np.mean(1/ez);sa=2*.015/(d_um*eps_align);lc_fraction=inv/(inv+sa)
    field=V/(d_um*(inv+sa)*ez)
    d=d_um*1e-6;K1,K2,K3=np.array(K_pN)*1e-12
    qe=np.pi/(period_um*1e-6)*np.sqrt((K1-K2+2*K3)/(2*K1))
    Wcrit=K1*qe*np.tan(qe*d/2)if qe*d<np.pi else None
    kval=brentq(lambda k:K1*k*np.tan(k*d/2)-W,1.,np.pi/d*(1-1e-10))
    stiff=K1*(kval*kval-qe*qe)
    vlc=d*np.sqrt(max(0,stiff)/(EPS0*(eps_parallel-eps_perp)))
    vterminal=vlc*(1+sa*eps_perp)
    diag={'d_um':d_um,'period_um':period_um,'K_pN':K_pN,'W_polar_J_m2':W,'V_terminal_rms':V,
        'eps_perp':eps_perp,'eps_parallel':eps_parallel,'eps_alignment_scenario':eps_align,
        'nodes':nodes,'theta_surface_deg':float(np.rad2deg(theta[0])),
        'theta_midplane_deg':float(np.rad2deg(theta[nodes//2])),
        'theta_max_deg':float(np.rad2deg(theta.max())),
        'LC_voltage_rms':float(V*lc_fraction),'alignment_pair_voltage_rms':float(V*(1-lc_fraction)),
        'LC_field_V_per_um_minmax':[float(field.min()),float(field.max())],
        'relative_energy_to_planar_J_m2':float((best.fun-energy(np.zeros(nodes)))*K1/d),
        'seed_energies_J_m2':[float(s.fun*K1/d)for s in solutions],
        'optimizer_success':bool(best.success),'optimizer_message':str(best.message),
        'projected_gradient_inf_dimensionless':float(abs(grad).max()),
        'restricted_zero_V_polar_critical_W_J_m2':Wcrit,
        'restricted_zero_V_lowest_stiffness_Pa':float(stiff),
        'restricted_planar_small_tilt_threshold_terminal_Vrms':float(vterminal)}
    return theta,diag


def field_checks(geometry):
    d=geometry['E7_d_um'];period=geometry['E7_period_um'];K=SOURCE['E7_elastic_dielectric']['K_pN']
    n=65;W=8e-4;en=functional(d,period,K,W,0,nodes=n)
    H=hessian(en)(np.zeros(n));h=1/(n-1);M=np.zeros((n,n))
    for i in range(n-1):M[i:i+2,i:i+2]+=h/6*np.array([[2,1],[1,2]])
    lam=float(eigh(H,M,subset_by_index=[0,0])[0][0])
    _,diag=solve(d,period,K,W,0,nodes=n)
    exact=diag['restricted_zero_V_lowest_stiffness_Pa']*(d*1e-6)**2/(K[0]*1e-12)
    # A central difference gradient check away from the bounds at nonzero voltage.
    f=functional(d,period,K,8e-4,3,nodes=17);x=.4+.2*np.sin(np.linspace(0,np.pi,17))
    value,g=value_and_grad(f)(x);fd=[]
    for j in range(len(x)):
        e=np.zeros_like(x);e[j]=1e-6;fd.append((f(x+e)-f(x-e))/2e-6)
    return {'zero_field_Hessian_lowest_dimensionless':lam,'Robin_exact_lowest_dimensionless':exact,
        'Hessian_vs_Robin_relative_error':abs(lam-exact)/abs(exact),
        'fixed_voltage_gradient_finite_difference_max_error':float(np.max(np.abs(g-fd)))}


def independent_bvp(geometry,V,theta):
    """Independent analytic Euler-Lagrange BVP, including series-capacitance integral."""
    d=geometry['E7_d_um'];q=np.pi*d/geometry['E7_period_um']
    K1,K2,K3=np.array(SOURCE['E7_elastic_dielectric']['K_pN'])*1e-12
    b=K2/K1;c=K3/K1;wa=8e-4*d*1e-6/K1;sa=2*.015/(3*d);ep=5.2;de=13.8
    u=np.linspace(0,1,len(theta));A=lambda t:np.cos(t)**2+c*np.sin(t)**2
    integ=cumulative_trapezoid(1/(ep+de*np.sin(theta)**2),u,initial=0)
    init=np.array([theta,A(theta)*np.gradient(theta,u),integ])
    def ode(u,y,par):
        t,p,I=y;co=np.cos(t)**2;si=1-co;s2=np.sin(2*t);a=co+c*si
        deriv=p/a;ez=ep+de*si
        Uprime=q*q/4*s2*(-1+b*(co-si)-2*c*co)
        Eprime=-EPS0*V*V*de/(2*K1*(par[0]+sa)**2)*s2/ez**2
        return np.array([deriv,.5*(c-1)*s2*deriv**2+Uprime+Eprime,1/ez])
    def bc(ya,yb,par):
        return np.array([ya[1]-wa/2*np.sin(2*ya[0]),yb[1]+wa/2*np.sin(2*yb[0]),ya[2],yb[2]-par[0]])
    sol=solve_bvp(ode,bc,u,init,p=[integ[-1]],tol=2e-8,max_nodes=12000)
    tbvp=sol.sol(u)[0]
    return {'V_RMS_terminal':V,'success':bool(sol.success),'message':sol.message,
            'adaptive_nodes':len(sol.x),'max_ODE_RMS_residual':float(sol.rms_residuals.max()),
            'max_theta_difference_deg_against_midpoint_energy129':float(np.rad2deg(np.max(np.abs(theta-tbvp)))),
            'BVP_theta_surface_mid_deg':[float(np.rad2deg(tbvp[0])),float(np.rad2deg(tbvp[len(u)//2]))]},tbvp


def optical(w,geometry,profiles):
    pei=index('PEI_Zhang',w);con=load(OLD/'data/q2_device/IOH216_digitized.csv',w)
    align=[lorentz(w,ALIGNMENT['parameters_post_UV'][s])for s in ['e','o']]
    tab=np.loadtxt(DATA/'Li2005_E7_Cauchy.csv',delimiter=',',skiprows=1)
    G=port_weights(w,geometry);port=np.zeros((3,2,len(w)));total=port.copy();retardance={}
    def cell(ne,no,theta,kind):
        d=geometry['E7_d_um']if kind=='E7' else geometry['5CB_d_um']
        mid=(theta[:-1]+theta[1:])/2
        extra=ne[None,:]*no[None,:]/np.sqrt(ne[None,:]**2*np.sin(mid[:,None])**2+no[None,:]**2*np.cos(mid[:,None])**2)
        ordinary=np.broadcast_to(no,extra.shape);amps=[]
        for pol,nlayer in enumerate([extra,ordinary]):
            pre=[pei,con,align[pol]]if kind=='E7'else[pei,align[pol]]
            post=[align[pol],con,pei]if kind=='E7'else[align[pol],pei]
            ds_pre=[4,.099,.015]if kind=='E7'else[4,.015]
            ds_post=[.015,.099,4]if kind=='E7'else[.015,4]
            ns=np.vstack([*pre,nlayer,*post]);ds=ds_pre+[d/len(mid)]*len(mid)+ds_post
            rr,tt=amplitude(w,ns,ds);amps.append(tt)
        phase=np.mean(extra-no[None,:],axis=0)
        return abs((amps[0]+amps[1])/2)**2,abs((amps[0]-amps[1])/2)**2,phase
    for ti,temp in enumerate([29.9,36.1]):
        co=[np.interp(temp,tab[:,0],tab[:,j])for j in range(1,7)]
        ne=cauchy(w,co[:3]);no=cauchy(w,co[3:])
        row=next(x for x in CB['rows']if x['T_C_text']==temp)
        cn=[cauchy(w,row[s])for s in ['e','o']]
        c0,c1,_=cell(cn[0],cn[1],profiles['5CB_V0'],'5CB')
        for vi,V in enumerate([0,3,4]):
            e0,e1,dn=cell(ne,no,profiles[f'E7_V{V}'],'E7')
            retardance[f'E7_V{V}_T{temp:g}_integrated_dn']=dn
            retardance[f'E7_V{V}_T{temp:g}_fraction_of_planar']=dn/(ne-no)
            port[vi,ti]=e0*c0*G[0]+e1*c0*G[1]+e0*c1*G[2]+e1*c1*G[3]
            total[vi,ti]=(e0+e1)*(c0+c1)
    return port,total,retardance


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,required=True)
    args=p.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    if (args.out/'results.json').exists():raise RuntimeError('Refusing to overwrite prior result')
    geometry_path=ROOT/'runs/20261102-q2-manufacturing-dual-lc-port-02/results.json'
    geometry=json.loads(geometry_path.read_text())['selected']
    w=np.unique(np.r_[np.linspace(.4,.78,381),np.linspace(.78,2.5,1721)])
    K0=SOURCE['E7_elastic_dielectric']['K_pN'];Kc=SOURCE['5CB_elastic']['K_pN']
    scenarios=[('source_scale_W8e-4',8e-4,3,1,1,129),
               ('grid65',8e-4,3,1,1,65),
               ('W8e-5',8e-5,3,1,1,129),('W8e-6',8e-6,3,1,1,129),
               ('W8e-7',8e-7,3,1,1,129),('W8e-8_negative_control',8e-8,3,1,1,129),
               ('alignment_eps2',8e-4,2,1,1,129),('alignment_eps5',8e-4,5,1,1,129),
               ('K_high25pct_Deltaeps_low20pct',8e-4,3,1.25,.8,129)]
    rows=[];arrays={'wavelength_um':w};diaglist=[]
    for name,W,epsa,ks,des,nodes in scenarios:
        profiles={};case_diag=[]
        for material,V,d,period,K in [('E7',v,geometry['E7_d_um'],geometry['E7_period_um'],[x*ks for x in K0])for v in [0,3,4]]+[
            ('5CB',0,geometry['5CB_d_um'],geometry['5CB_period_um'],[x*ks for x in Kc])]:
            theta,diag=solve(d,period,K,W,V,eps_perp=5.2,eps_parallel=5.2+13.8*des,eps_align=epsa,nodes=nodes)
            key=f'{material}_V{V}';profiles[key]=theta;arrays[name+'__'+key+'__theta_rad']=theta
            diag['material']=material
            if material=='5CB':
                diag['eps_perp']=None;diag['eps_parallel']=None
                diag['restricted_planar_small_tilt_threshold_terminal_Vrms']=None
                diag['electrical_parameters_identity']='Not evaluated: thermal cell has no applied voltage.'
            case_diag.append(diag)
        port,total,ret=optical(w,geometry,profiles)
        arrays[name+'__port_T_V0_V3_V4']=port;arrays[name+'__all_orders_T_V0_V3_V4']=total
        for key,val in ret.items():arrays[name+'__'+key]=val
        row={'id':name,'W_polar_J_m2':W,'eps_alignment_unmeasured':epsa,'K_scale':ks,'Deltaeps_scale':des,
            'director':case_diag,'four_states_V0_V3':metrics(w,port[[0,1]]),
            'four_states_V0_V4':metrics(w,port[[0,2]]),
            'all_orders_V0_V4':metrics(w,total[[0,2]]),
            'E7_high_voltage_retardance_fraction_ranges':{
                key:[float(val.min()),float(val.max())]for key,val in ret.items()if 'fraction' in key and 'V0'not in key}}
        rows.append(row)
        print(json.dumps({'case':name,'theta_mid_deg':[r['theta_midplane_deg']for r in case_diag],
            'VIS_lower_V3_V4':[row['four_states_V0_V3']['full_380_780_VIS_voltage_delta_guaranteed_lower_using_passivity_only'],
                               row['four_states_V0_V4']['full_380_780_VIS_voltage_delta_guaranteed_lower_using_passivity_only']],
            'NIR_min_V3_V4':[row['four_states_V0_V3']['summary']['nir_temperature_delta_min'],row['four_states_V0_V4']['summary']['nir_temperature_delta_min']]}),flush=True)
    checks=field_checks(geometry)
    bvp_profiles={'E7_V0':arrays['source_scale_W8e-4__E7_V0__theta_rad'],
                  '5CB_V0':arrays['source_scale_W8e-4__5CB_V0__theta_rad']}
    checks['independent_Euler_Lagrange_BVP']=[]
    for voltage in [3,4]:
        diag,theta=independent_bvp(geometry,voltage,arrays[f'source_scale_W8e-4__E7_V{voltage}__theta_rad'])
        checks['independent_Euler_Lagrange_BVP'].append(diag)
        bvp_profiles[f'E7_V{voltage}']=theta
        arrays[f'independent_BVP_E7_V{voltage}__theta_rad']=theta
    bvp_port,_,_=optical(w,geometry,bvp_profiles)
    checks['BVP_vs_midpoint_energy129_port_max_difference']=float(np.max(np.abs(bvp_port-arrays['source_scale_W8e-4__port_T_V0_V3_V4'])))
    # Grid comparison at the same optical wavelengths and physical controls.
    checks['grid65_129_port_max_difference']=float(np.max(np.abs(arrays['source_scale_W8e-4__port_T_V0_V3_V4']-arrays['grid65__port_T_V0_V3_V4'])))
    checks['grid65_129_VISlower_V4_difference']=abs(rows[0]['four_states_V0_V4']['full_380_780_VIS_voltage_delta_guaranteed_lower_using_passivity_only']-rows[1]['four_states_V0_V4']['full_380_780_VIS_voltage_delta_guaranteed_lower_using_passivity_only'])
    out={'scope':__doc__,'geometry':geometry,'sources':SOURCE,'cases':rows,'verification':checks,
       'physical_finite_layer_count':12,'LC_numeric_slices_are_same_physical_layer':True,
       'limits':['Fixed azimuth phi=pi*x/period; x-dependent tilt, azimuthal relaxation, defects, lateral fields and saddle-splay excluded. Positive restricted stability is not 3D stability.',
                'Multiple deterministic minimizer seeds are not a proof of global minimization or dynamic reachability. No cooling-reset hysteresis/dynamics solved.',
                'Nys E7 and Bankova5CB K are source-based but transferred in temperature/specimen; one conservative K/Deltaeps scenario is not a confidence bound.',
                'Polar W=8e-4 is measured on another LC and substrate; transfer to E7/5CB and15nm thickness is unproved. Azimuthal W documented, not solved.',
                'Alignment low-frequency permittivity is unknown. Voltage sharing uses explicitly hypothetical eps2/3/5; actual impedance/ion screening and frequency dependence remain.',
                '5CB dielectric numbers in zero-voltage diagnostics are dummy unused values; no5CB voltage response is claimed.',
                'Optics uses independent local 1D anisotropic-effective-index slices plus Jones/Gaussian port treatment. No full patterned Maxwell solution or beam-post interaction.',
                'PEI substrate is a proxy, LC k absent, Cauchy and alignment spectral extensions retained from root model. Posts/seals excluded. This is not a complete-device certificate.'],
       'actual_complete_device_pass':False,
       'hashes':{str(path.relative_to(ROOT)):hashlib.sha256(path.read_bytes()).hexdigest()for path in [Path(__file__),geometry_path,ROOT/'experiments/q2_manufacturing_lc_layer_budget.py']}}
    (args.out/'results.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    (args.out/'source.py').write_bytes(Path(__file__).read_bytes())
    np.savez_compressed(args.out/'director_optics.npz',**arrays)
    print(json.dumps(checks,indent=2))


if __name__=='__main__':main()
