"""New25/50C source-supported dielectric pilot; independently frozen optics.

Requires genuinely new four electric and two9.8um thermal director fields.
The19physical layers,83.028893nm fixed AR and2um coherent air gap retain the
previously audited external-electrode geometry. No oldT15 field relabeling.
"""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import sys,json,time,hashlib,argparse
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments import q2_finish_decouple_20261105_external_ar as ar
base=ar.base;source=ar.source
old="thermal=np.load(ROOT/'runs/20261105-q2-package-A-director64-d1p45-02/fields.npz')"
assert source.count(old)==1 and source.count('[15,50]')==2 and source.count('8.353152083061113')==1
source=source.replace(old,"thermal=src").replace('[15,50]','[25,50]').replace('8.353152083061113','9.8').replace('same15/50C','same25/50C')
assert 'T15'not in source and '[15,50]'not in source and '8.353152083061113'not in source
exec(source,base.__dict__)

def main():
 p=argparse.ArgumentParser();p.add_argument('action',choices=['optics']);p.add_argument('--out',type=Path,required=True);p.add_argument('--fields',type=Path,required=True);p.add_argument('--bias',type=float,default=9.235);p.add_argument('--d',type=float,default=2.5);p.add_argument('--slices',type=int,default=32);p.add_argument('--order',type=int,default=4);p.add_argument('--dense',action='store_true');p.add_argument('--grid',type=Path);p.add_argument('--shards',type=int,default=1);p.add_argument('--shard',type=int,default=0);a=p.parse_args()
 a.fields=a.fields.resolve();a.out=a.out.resolve()
 if a.bias!=9.235 or a.d!=2.5:raise ValueError('This fixed source-supported pilot requiresd2.5um andV9.235.')
 fp=a.fields/'fields.npz';fields=np.load(fp);keys=[f'electric_T{T}_V{V:g}__{s}'for T in [25,50]for V in [0,9.235]for s in ['theta_rad','phi_correction_rad']]+[f'thermal_T{T}_V0__{s}'for T in [25,50]for s in ['theta_rad','phi_correction_rad']]
 for k in keys:
  if k not in fields:raise ValueError(f'Missing genuinely new source:{k}')
  if fields[k].shape!=(64,33)or not np.isfinite(fields[k]).all():raise ValueError((k,fields[k].shape))
 acp=ROOT/'runs/20261105-q2-finish-source25-config-01/config.json';ac=json.loads(acp.read_text())['parameters']
 assert ac['temperatures_C']==[25,50] and ac['thermal_d_um']==9.8 and ac['fixed_external_V_RMS']==[0,9.235] and ac['electric_comp_d_um']==2.5
 assert ac['epsilon_perp_by_T']==[4.886949076291233]*2 and ac['delta_epsilon_by_T']==[12.34304932735426,9.80080245456691]
 files=[Path(__file__),Path(ar.__file__),Path(ar.ext.__file__),Path(ar.ext.adapter.__file__),Path(base.__file__)];frozen={f.name:f.read_bytes()for f in files};material_files=[ROOT/'data/q2_current/Li2005_E7_Cauchy.csv',ROOT/'data/q2_finish_material_20261105/SiNx_spectrum/DLC_4keV_vector_digitized.csv',ROOT/'data/q2_package_A_20261105/ZnO2022_Fig5d_passive_digitized.csv',ROOT/'data/q2_parallel_loss_20261105/Wu2002_E7_graph_alpha_k.csv',acp,a.fields/'results.json']
 config={'time_unix':time.time(),'argv':sys.argv,'source_sha256':{n:hashlib.sha256(v).hexdigest()for n,v in frozen.items()},'input_sha256':{str(f.relative_to(ROOT)):hashlib.sha256(f.read_bytes()).hexdigest()for f in material_files+[fp]},'temperatures_C':[25,50],'fixed_terminal_voltage_V':9.235,'source_keys':keys,'main_path_layers':19,'physical_supports':5,'supports_um':[8.]*5,'drive_LC_um':2.5,'passive_LC_um':2.5,'thermal_LC_um':9.8,'thermal_period_um':24,'electric_period_um':12,'AR_each_um':ar.thickness,'AR_material':'sameFrantaAl2O3complexspectrum','AR_design_wavelength_um':.55,'environment_gap_um':2.,'electrodes':'twoZnO99.8nmonexternalfacesofdrivermodule','constitutive':{'delta_epsilon25_50_1kHz':[12.34304932735426,9.80080245456691],'delta_epsilon_source':'BasuKehr2025doi10.3390/mi16040457Fig4bpureE7redsymbols','epsilon_perp_fixed':4.886949076291233,'epsilon_perp_status':'Measuredgraphplateau25Conly;temperatureconstantisstillmodel','K25_pN':[11.1,6.5,17.1],'K_scaling':'Li2005dn589(T)/dn589(25) squared;MODEL notsamebatchmeasuredK33(T)','Wa_Wp_J_m2_scenario':[1.14e-4,2e-4],'SiNx_epsilon_scenario':7.5,'Al2O3_epsilon_scenario':9},'conditions':['AllfourV/Tstatesusesamephysical19layersandonefixedexternalvoltage.','Allnew25/50electricand9.8umthermal2Dsource;notoldT15renamingor8.353umrescaling.','SiNx20nmcomplexspectrum/anchoring/thicknessmigrationconditionsremain.','E7opticalLi2005anddielectricBasu2025arecross-batch/processsourcecombination.','Wu2002isotropic70Clossgraphtransferredtoboth25/50Caxes,notanisotropiclossmeasurement.','ExternalARregionleavescontact/landopen;depositionbeforealignment/fillingcondition.','NoA/manufacturing/fullfiniteMaxwell/strictdecouplingcertificate.']}
 a.out.mkdir(parents=True,exist_ok=False)
 # Freeze the actual execution state BEFORE the optical computation.
 for n,v in frozen.items():(a.out/('dependency_'+n)).write_bytes(v)
 (a.out/'source.py').write_bytes(frozen[Path(__file__).name]);(a.out/'effective_optics_source.py').write_text(source);(a.out/'launch.json').write_text(json.dumps(config,indent=2))
 base.optics(a)
 r=json.loads((a.out/'results.json').read_text());r['physical_override']=config;r['temperatures_C']=[25,50];r['thermal_LC_um']=9.8;r['scope']='Newsource25/50samefixed9.235V19layerARthreecellactual64directorpilot';r['limits']=config['conditions'];(a.out/'results.json').write_text(json.dumps(r,indent=2))
if __name__=='__main__':main()
