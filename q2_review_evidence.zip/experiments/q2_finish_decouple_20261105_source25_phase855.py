"""One predicted thermal-phase branch, same corrected-ZnO19-layer device.

Only thermal LC9.8->8.55 and its genuinely relaxed twoTdirector change.
The fixed600/y600mask,9.235V/electricfields,AR and material spectrum stay matched.
"""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import sys,json,hashlib,argparse,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments import q2_finish_decouple_20261105_external_ar_source25 as pilot
base=pilot.base
EFFECTIVE=ROOT/'runs/20261105-q2-finish-material-ZnO-hires-new25-optics127-0-01/effective_optics_source.py'
source=EFFECTIVE.read_text();assert source.count('d=9.8 if kind==')==1
source=source.replace('d=9.8 if kind==','d=8.55 if kind==');assert '[15,50]'not in source and '8.353152083061113'not in source
exec(source,base.__dict__)

def main():
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--fields',type=Path,default=ROOT/'runs/20261105-q2-finish-assembly-phase25-d8p55-source64-01');p.add_argument('--shards',type=int,default=2);p.add_argument('--shard',type=int,default=0);p.add_argument('--grid',type=Path);a=p.parse_args();a.out=a.out.resolve();a.fields=a.fields.resolve();a.d=2.5;a.bias=9.235;a.order=4;a.slices=32;a.dense=True
 if a.grid:a.grid=a.grid.resolve()
 fp=a.fields/'fields.npz';params=json.loads((a.fields/'results.json').read_text())['parameters'];assert params['temperatures_C']==[25,50]and params['thermal_d_um']==8.55 and params['fixed_external_V_RMS']==[0,9.235]
 fresh=np.load(fp);old=np.load(ROOT/'runs/20261105-q2-finish-source25-combined64-01/fields.npz');same=[]
 for T in [25,50]:
  for V in [0,9.235]:
   for s in ['theta_rad','phi_correction_rad','potential_V']:
    k=f'electric_T{T}_V{V:g}__{s}';assert np.array_equal(fresh[k],old[k]);same.append(k)
  for s in ['theta_rad','phi_correction_rad']:assert fresh[f'thermal_T{T}_V0__{s}'].shape==(64,33)
 zno=ROOT/'runs/20261105-q2-finish-material-ZnO-hires-input-01/ZnO2022_Fig5d_hires_exactnodes_tail_linear_scenario.csv';assert hashlib.sha256(zno.read_bytes()).hexdigest()=='2504682932f858210bcb30b01d8d7d2b27208af0df143cb2adbcca9899c0b18e'
 deps=[Path(__file__),Path(pilot.__file__),Path(pilot.ar.__file__),Path(pilot.ar.ext.__file__),Path(pilot.ar.ext.adapter.__file__),Path(base.__file__),EFFECTIVE];frozen={f.name:f.read_bytes()for f in deps};data=[fp,a.fields/'results.json',zno,ROOT/'data/q2_current/Li2005_E7_Cauchy.csv',ROOT/'data/q2_finish_material_20261105/SiNx_spectrum/DLC_4keV_vector_digitized.csv',ROOT/'data/q2_parallel_loss_20261105/Wu2002_E7_graph_alpha_k.csv']
 config={'time_unix':time.time(),'argv':sys.argv,'source_sha256':{n:hashlib.sha256(v).hexdigest()for n,v in frozen.items()},'input_sha256':{str(f.relative_to(ROOT)):hashlib.sha256(f.read_bytes()).hexdigest()for f in data},'temperatures_C':[25,50],'main_path_layers':19,'physical_supports':5,'fixed_terminal_voltage_V':9.235,'drive_LC_um':2.5,'passive_LC_um':2.5,'thermal_LC_um':8.55,'AR_each_um':pilot.ar.thickness,'environment_gap_um':2.,'electric_fields_bitwise_identical_keys':same,'matched_corrected_ZnO_thermal9p8_control':['runs/20261105-q2-finish-material-ZnO-hires-new25-optics127-0-01','runs/20261105-q2-finish-material-ZnO-hires-new25-optics127-1-01'],'selection_rule':'Singlepredictedbranch: actual600tiltcutofflambda1.41221um meanthermalOPD=lambda;noMaxwellspectrumfit, no thickness/voltage scan','ZnO_tail':'rawcolorcolumnunion335nodes;smallnegativekfloor0;tail2444.805to2500nmlinearcontinuationscenario k2500=.041801115572,notmeasuredbound','conditions':params['model_conditions'] if 'model_conditions'in params else ['K(T),epsilonperp50,anchoringandmaterialprocessmigrationremainmodelconditions'],'geometry':'original xinner600 / yhalf600 finite screen, no simultaneous y750 change'}
 if a.grid:data.append(a.grid);config['actual_grid_path']=str(a.grid.relative_to(ROOT));config['actual_grid_sha256']=hashlib.sha256(a.grid.read_bytes()).hexdigest();config['input_sha256'][str(a.grid.relative_to(ROOT))]=config['actual_grid_sha256']
 a.out.mkdir(parents=True,exist_ok=False);(a.out/'launch.json').write_text(json.dumps(config,indent=2));(a.out/'effective_optics_source.py').write_text(source)
 for n,v in frozen.items():(a.out/('dependency_'+n)).write_bytes(v)
 (a.out/'source.py').write_bytes(frozen[Path(__file__).name]);base.optics(a)
 r=json.loads((a.out/'results.json').read_text());r['physical_override']=config;r['temperatures_C']=[25,50];r['thermal_LC_um']=8.55;r['scope']='Singlepredictedthermalphase8.55branch,correctedZnO,25/50fixed9.235V19layeractualfourstatepilot';(a.out/'results.json').write_text(json.dumps(r,indent=2))
 (a.out/'optical_postflight.json').write_text(json.dumps({'all_used_input_hashes_still_match':all(hashlib.sha256(f.read_bytes()).hexdigest()==config['input_sha256'][str(f.relative_to(ROOT))]for f in data),'all_declared_script_dependency_hashes_still_match':all(hashlib.sha256(f.read_bytes()).hexdigest()==config['source_sha256'][f.name]for f in deps),'unused_future_readout_not_optics_dependency':True},indent=2))
if __name__=='__main__':main()
