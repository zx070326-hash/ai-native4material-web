"""Relaxed director -> anisotropic normal-incidence scattering -> nonlocal cavity.

Each cell retains its full local 4x4 stack. Transverse propagation is an
explicit reference-index split-screen approximation, not patterned Maxwell.
"""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import sys,argparse,json,time,hashlib
import numpy as np
from scipy.interpolate import RegularGridInterpolator
from scipy.fft import fft2,ifft2
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments.q2_manufacturing_lc_layer_budget import DATA,metrics,amplitude
from experiments.q2_manufacturing_lc_materials import ALIGNMENT,CB,cauchy,lorentz
from experiments.q2_manufacturing_ec_budget import load,OLD
from experiments.q2_manufacturing_lc_coherent_posts import GEOMFILE
from src.optics import index
ZERO=ROOT/'runs/20261102-q2-manufacturing-lc-director2d-zero-fine-01/director_fields.npz'
FOUR=ROOT/'runs/20261102-q2-gap-director-fine-01/director_fields.npz'


def layer(ne,no,d,phi,lam):
    """Tangential [Ex,Ey,Hy Z0,-Hx Z0], transfer from left to right."""
    ne,no,phi,lam=np.broadcast_arrays(ne,no,phi,lam);c=np.cos(phi);s=np.sin(phi)
    def rot(e,o):
        out=np.empty((*ne.shape,2,2),complex);out[...,0,0]=c*c*e+s*s*o;out[...,1,1]=s*s*e+c*c*o;out[...,0,1]=out[...,1,0]=c*s*(e-o)
        return out
    phasee=2*np.pi*ne*d/lam;phaseo=2*np.pi*no*d/lam
    co=rot(np.cos(phasee),np.cos(phaseo));b=1j*rot(np.sin(phasee)/ne,np.sin(phaseo)/no);cc=1j*rot(np.sin(phasee)*ne,np.sin(phaseo)*no)
    out=np.empty((*ne.shape,4,4),complex);out[...,:2,:2]=co;out[...,2:,2:]=co;out[...,:2,2:]=b;out[...,2:,:2]=cc
    return out


def scattering(M):
    A,B,C,D=M[...,:2,:2],M[...,:2,2:],M[...,2:,:2],M[...,2:,2:]
    aa=(A+B+C+D)/2;bb=(A-B+C-D)/2;cc=(A+B-C-D)/2;dd=(A-B-C+D)/2
    inv=np.linalg.inv(dd);rl=-inv@cc;tr=inv;rr=bb@inv;tl=aa+bb@rl
    return np.stack([rl,rr,tl,tr],axis=-3)


def texture(mat,V,nx,nz=None,four=FOUR,zero=ZERO,seed='tilted'):
    q=np.load(four if V else zero);prefix=seed if V else mat+'__linear_phi'
    th=q[prefix+'__theta_rad'];u=q[prefix+'__phi_correction_rad'];nz=th.shape[1]-1 if nz is None else nz
    xx=(np.arange(nx)+.5)/nx;zz=(np.arange(nz)+.5)/nz
    # 5CB's source Frank solve has its modulation along x. In the device it is
    # along y. Rotate the source frame90deg and translate by-Lambda/2 so that
    # the original lab-frame8step easy-axis registration remains unchanged.
    sample_x=(xx-.25)%1 if mat=='5CB' else xx
    X,Z=np.meshgrid(sample_x,zz,indexing='ij');points=np.stack([X,Z],-1)
    def interp(t):return RegularGridInterpolator((np.linspace(0,1,len(t)+1),np.linspace(0,1,t.shape[1])),np.r_[t,t[:1]])(points)
    return interp(th),2*np.pi*xx[:,None]+interp(u),(np.floor(xx*16)+.5)*np.pi/8


def cells(w,g,nx=64,four=FOUR,zero=ZERO,nz=None,seed='tilted'):
    w=np.asarray(w);pei=index('PEI_Zhang',w);con=load(OLD/'data/q2_device/IOH216_digitized.csv',w)
    align=[lorentz(w,ALIGNMENT['parameters_post_UV'][s])for s in ['e','o']]
    tab=np.loadtxt(DATA/'Li2005_E7_Cauchy.csv',delimiter=',',skiprows=1);out={}
    for mat,V in [('E7',0),('E7',4),('5CB',0)]:
        theta,phi,easy=texture(mat,V,nx,nz,four,zero,seed);d=g[mat+'_d_um']
        for ti,temp in enumerate([29.9,36.1]):
            if mat=='E7':
                co=[np.interp(temp,tab[:,0],tab[:,j])for j in range(1,7)];ne,no=cauchy(w,co[:3]),cauchy(w,co[3:])
            else:
                row=next(r for r in CB['rows']if r['T_C_text']==temp);ne,no=[cauchy(w,row[s])for s in ['e','o']]
            M=np.broadcast_to(np.eye(4,dtype=complex),(len(w),nx,4,4)).copy()
            layers=[(pei,pei,4.,easy*0)]
            if mat=='E7':layers.append((con,con,.099,easy*0))
            layers.append((align[0],align[1],.015,easy))
            for ee,oo,dd,pp in layers:M=layer(ee[:,None],oo[:,None],dd,pp[None],w[:,None])@M
            for iz in range(theta.shape[1]):
                t=theta[:,iz][None];ee=ne[:,None]*no[:,None]/np.sqrt(ne[:,None]**2*np.sin(t)**2+no[:,None]**2*np.cos(t)**2)
                M=layer(ee,no[:,None],d/theta.shape[1],phi[None,:,iz],w[:,None])@M
            for ee,oo,dd,pp in layers[::-1]:M=layer(ee[:,None],oo[:,None],dd,pp[None],w[:,None])@M
            out[f'{mat}_V{V}_T{ti}']=scattering(M)
    return out


def propagator(lam,g,fx,fy,ti,mode='center',gap=2.):
    """Air gap plus transverse-only half-cell reference propagation.

    Local stacks already contain axial phase. Half-cell reference propagation
    contributes only kz-n*k. Local reflection planes are assigned to LC mids.
    Principal LC optical anisotropy is retained in local stacks, not in this
    scalar transverse reference propagator. No effective medium n compliance.
    """
    rho=fy[:,None]**2+fx[None,:]**2;k=2*np.pi/lam
    if mode=='local':return np.full(rho.shape,np.exp(1j*k*gap))
    phase=k*gap*np.sqrt(1-(lam**2*rho)+0j)
    if mode=='center':
        pei=float(index('PEI_Zhang',np.array([lam]))[0].real);io=float(load(OLD/'data/q2_device/IOH216_digitized.csv',np.array([lam]))[0].real)
        al=float(np.mean([lorentz(np.array([lam]),ALIGNMENT['parameters_post_UV'][s])[0].real for s in ['e','o']]))
        tab=np.loadtxt(DATA/'Li2005_E7_Cauchy.csv',delimiter=',',skiprows=1);temp=[29.9,36.1][ti];co=[np.interp(temp,tab[:,0],tab[:,j])for j in range(1,7)];en=float(cauchy(np.array(lam),co[3:]));row=next(r for r in CB['rows']if r['T_C_text']==temp);cn=float(cauchy(np.array(lam),row['o']))
        for d,n in [(8,pei),(.099,io),(.030,al),(g['E7_d_um']/2,en),(g['5CB_d_um']/2,cn)]:phase+=k*d*(np.sqrt(n*n-lam*lam*rho+0j)-n)
    return np.exp(1j*phase)


def periodic(c,lam,g,nx,mode='center',returns=12):
    fx=np.fft.fftfreq(nx,d=2*g['E7_period_um']/nx);fy=np.fft.fftfreq(nx,d=2*g['5CB_period_um']/nx)
    out={};di=[]
    for vi,V in enumerate([0,4]):
        for ti in range(2):
            e=c[f'E7_V{V}_T{ti}'];cb=c[f'5CB_V0_T{ti}'];t1=e[None,:,2];r1=e[None,:,1];t2=cb[:,None,2];r2=cb[:,None,0]
            P=propagator(lam,g,fx,fy,ti,mode)
            def prop(a):return ifft2(fft2(a,axes=(0,1),workers=1)*P[...,None,None],axes=(0,1),workers=1)
            a=np.broadcast_to(t1,(nx,nx,2,2)).copy();total=prop(a);single=t2@total;last=0.
            for it in range(returns):
                a=r1@prop(r2@prop(a));term=prop(a);total+=term;last=float(np.sqrt(np.mean(abs(t2@term)**2)))
            field=t2@total
            out[f'V{vi}T{ti}']=np.fft.fft2(field,axes=(0,1))/(nx*nx)
            out[f'single_V{vi}T{ti}']=np.fft.fft2(single,axes=(0,1))/(nx*nx)
            di.append({'V':V,'T_index':ti,'last_return_Jones_field_RMS':last,'output_periodic_power':float(np.mean(np.sum(abs(field)**2,axis=(-2,-1)))/2)})
    return out,di


def validation():
    err=0.;energy=0.;rec=0
    for lam in [.4,.55,.82,1.25,2.5]:
        M=layer(1.7,1.5,.7,.3,lam)@layer(2.1+.03j,2.1+.03j,.1,0,lam);S=scattering(M)
        rec=max(rec,float(abs(S[2]-S[3].T).max()))
        M=layer(1.7,1.7,.7,0,lam)@layer(2.1+.03j,2.1+.03j,.1,0,lam);S=scattering(M)
        r,t=amplitude(np.array([lam]),np.array([[2.1+.03j],[1.7]]),[.1,.7]);err=max(err,abs(S[0,0,0]-r[0]),abs(S[2,0,0]-t[0]))
        S=scattering(layer(1.7,1.5,.7,.3,lam)@layer(2.1,1.9,.1,.8,lam));energy=max(energy,float(abs(S[2].conj().T@S[2]+S[0].conj().T@S[0]-np.eye(2)).max()))
    return {'isotropic_vs_independent_scalar_recursive_complex_error':float(err),'lossless_matrix_flux_error':energy,'reciprocal_transmission_transpose_error':rec}


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--wavelengths',default='.4,.55,.78,.82,1.25,2,2.5');ap.add_argument('--dense-step',type=float);ap.add_argument('--nx',type=int,default=64);ap.add_argument('--returns',type=int,default=10);ap.add_argument('--modes',default='local,center');ap.add_argument('--four',type=Path,default=FOUR);ap.add_argument('--zero',type=Path,default=ZERO);ap.add_argument('--nz',type=int);ap.add_argument('--seed',default='tilted');ap.add_argument('--all-harmonics',action='store_true');ap.add_argument('--no-single',action='store_true')
    a=ap.parse_args();a.out.mkdir(parents=True,exist_ok=False);g=json.loads(GEOMFILE.read_text())['selected'];w=np.unique(np.r_[np.arange(.4,.78,a.dense_step),np.arange(.78,2.5,a.dense_step),2.5])if a.dense_step else np.array([float(v)for v in a.wavelengths.split(',')])
    check=validation();print(json.dumps({'validation':check}),flush=True);arrays={'wavelength_um':w};ids={};di=[];maxcoeff={};modes=np.fft.fftfreq(a.nx)*a.nx
    # Store only a centered21x21 mode window plus exact omitted periodic norm.
    keep=np.arange(a.nx)if a.all_harmonics else np.where(abs(modes)<=10)[0];arrays['harmonics']=modes[keep].astype(int);tic=time.perf_counter()
    for start in range(0,len(w),16):
        ww=w[start:start+16];cc=cells(ww,g,a.nx,a.four,a.zero,a.nz,a.seed)
        for j,lam in enumerate(ww):
            c={k:v[j]for k,v in cc.items()}
            for mode in a.modes.split(','):
                coef,diagnostic=periodic(c,lam,g,a.nx,mode,a.returns)
                for k,v in coef.items():
                    if a.no_single and k.startswith('single_'):continue
                    key=mode+'__'+k
                    if key not in ids:ids[key]=[];ids[key+'__omitted_power']=[]
                    cut=v[keep[:,None],keep[None,:]];ids[key].append(cut);ids[key+'__omitted_power'].append(float((np.sum(abs(v)**2)-np.sum(abs(cut)**2))/2))
                di.append({'lambda_um':float(lam),'mode':mode,'states':diagnostic})
        print(json.dumps({'done':min(start+16,len(w)),'total':len(w),'seconds':time.perf_counter()-tic}),flush=True)
    for k,v in ids.items():arrays[k]=np.array(v)
    np.savez_compressed(a.out/'periodic_coefficients.npz',**arrays)
    result={'scope':__doc__,'wavelength_count':len(w),'nx':a.nx,'returns_after_direct':a.returns,'geometry':g,'air_gap_um':2.,'validation':check,'diagnostics':di,
            'source_4V':str(a.four),'source_0V':str(a.zero),'retained_harmonic_indices':arrays['harmonics'].tolist(),'actual_complete_device_pass':False,
            'limits':['Complete local normal-incidence anisotropic12-layer scattering, exact in each specified local layered stack.','Transverse diffraction uses an explicit scalar reference-index split screen between LC midplanes. This is not internal patterned vector Maxwell; angular cell impedance and nonlocal reflection within each cell omitted.','Reference propagation includes both4um innerPEI supports, oneIOH film, twoalignmentfilms, half of eachLC, and2um air.','Periodic illumination calculation has no finiteGaussian, posts, seal or collector until remapped.','Cauchy/oscillator extrapolation, absentLCk, PEI proxy, source temperature/anchoring transfer remain.']}
    result['hashes']={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in [Path(__file__),a.four,a.zero]};(a.out/'results.json').write_text(json.dumps(result,indent=2),encoding='utf8');(a.out/'source.py').write_bytes(Path(__file__).read_bytes())

if __name__=='__main__':main()
