"""Fixed all-solid spectral refinement, actual missing710 nodes only; no scan."""
import os
for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='1'
from pathlib import Path
import sys,json,hashlib,argparse
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
PREFIX='20261105-q2-finish-decouple-solid-interface-'
LAUNCH=ROOT/'runs'/f'{PREFIX}dense-launch-01'
def optics(a):
 from experiments import q2_finish_decouple_20261105_solid_interface as solid
 config,deps,data=solid.provenance();grid=LAUNCH/'missing710.npz';data.append(grid);deps.append(Path(__file__).resolve());config['input_sha256'][str(grid.relative_to(ROOT))]=sha(grid);config['source_sha256'][str(Path(__file__).resolve().relative_to(ROOT))]=sha(Path(__file__))
 audit=ROOT/'runs'/f'{PREFIX}merge127-01/results.json';r=json.loads(audit.read_text());assert r['passed']and r['identity']['effective_source_sha256']==config['effective_source_sha256'];config['merge_audit_sha256']=sha(audit)
 config['sampling_scope']='Only710 missing standard713 nodes; preserve original127, form exact713 and actualunion837 separately.'
 for f in deps:(a.out/('dependency_'+f.name)).write_bytes(f.read_bytes())
 (a.out/'launch.json').write_text(json.dumps(config,indent=2));(a.out/'effective_optics_source.py').write_text(solid.source)
 a.fields=solid.FIELDS;a.d=2.5;a.bias=9.235;a.order=4;a.slices=32;a.dense=True;a.grid=grid;solid.base.optics(a)
 r=json.loads((a.out/'results.json').read_text());r['physical_override']=config;r['temperatures_C']=[25,50];r['thermal_LC_um']=8.55;r['scope']='Fixed all-solid d8.55/source25/9.235V/correctedZnO actual missing710 refinement';r['limits']=config['conditions'];(a.out/'results.json').write_text(json.dumps(r,indent=2))
 (a.out/'optical_postflight.json').write_text(json.dumps({'all_input_hashes_match':all(sha(f)==config['input_sha256'][str(f.relative_to(ROOT))]for f in data),'all_declared_dependency_hashes_match':all(sha(f)==config['source_sha256'][str(f.relative_to(ROOT))]for f in deps)},indent=2))
def launch(a):
 old=ROOT/'runs/20261105-q2-finish-decouple-source25-phase855-dense-launch-01';pilot=np.unique(np.r_[np.linspace(.4,.78,41),np.linspace(.78,2.5,87)]);standard=np.load(old/'standard713.npz')['wavelength_um'];missing=standard[~np.isin(standard,pilot)];missing=np.r_[missing[missing>=.78],missing[missing<.78]];union=np.unique(np.r_[standard,pilot]);assert len(pilot)==127 and len(standard)==713 and len(missing)==710 and len(union)==837
 for name,w in [('pilot127',pilot),('standard713',standard),('missing710',missing),('union837',union)]:np.savez_compressed(a.out/f'{name}.npz',wavelength_um=w)
 (a.out/'results.json').write_text(json.dumps({'scope':'Frozen all-solid127 actualpilot preserved; standard713 missing710 actual solves, NIR first; no physical parameter scan.','pilot127':127,'standard713':713,'new_missing710':710,'union837':837,'grid_source':str(old.relative_to(ROOT)),'reader_sha256':sha(ROOT/'experiments/q2_finish_decouple_20261105_readout.py')},indent=2))
def select(a):
 runs=[ROOT/'runs'/f'{PREFIX}optics64-127-{i}-01'for i in [0,1]]+[ROOT/'runs'/f'{PREFIX}optics64-missing713-{i}-01'for i in range(4)];zs=[np.load(q/'scattered_fields.npz')for q in runs];meta=[json.loads((q/'results.json').read_text())for q in runs];w=np.concatenate([z['wavelength_um']for z in zs]);sort=np.argsort(w);w=w[sort];assert len(w)==837 and len(np.unique(w))==837
 for key in ['d_electric_um','bias_V','main_layer_count','physical_supports','temperatures_C','thermal_LC_um']:assert all(m[key]==meta[0][key]for m in meta)
 assert all(m['physical_override']['internal_air_gap_um']==0 and m['physical_override']['solid_replacement_um']==1.8 for m in meta)
 h=zs[0]['harmonics'];assert all(np.array_equal(z['harmonics'],h)for z in zs);arrays={k:np.concatenate([z[k]for z in zs])[sort]for k in zs[0].files if k not in ['wavelength_um','harmonics']};di={d['wavelength_um']:d for m in meta for d in m['diagnostics']};assert len(di)==837
 receipt={'all_source_field_sha256':{str((q/'scattered_fields.npz').relative_to(ROOT)):sha(q/'scattered_fields.npz')for q in runs},'each_wavelength_computed_once_no_interpolation':True}
 for name,grid in [('standard713',np.load(LAUNCH/'standard713.npz')['wavelength_um']),('union837',w)]:
  ix=np.searchsorted(w,grid);assert np.array_equal(w[ix],grid);out=a.out/name;out.mkdir(exist_ok=False);np.savez_compressed(out/'scattered_fields.npz',wavelength_um=grid,harmonics=h,**{k:v[ix]for k,v in arrays.items()});r=dict(meta[0]);r['diagnostics']=[di[float(x)]for x in grid];r['scope']=f'Exact{name} actual computed selection, ONE fixed all-solid candidate';r['spectral_selection']=dict(receipt,name=name,count=len(grid));(out/'results.json').write_text(json.dumps(r,indent=2))
 (a.out/'results.json').write_text(json.dumps(receipt,indent=2))
def summarize(a):
 from experiments.q2_finish_decouple_20261105_phase855_dense import stats
 from experiments.q2_finish_decouple_20261105_solid_report import COUNTS
 rows=[];views={}
 for grid in ['713','837']:
  for hole in [600,700]:
   path=ROOT/'runs'/f'{PREFIX}readout64-{grid}-{hole}-01';z=np.load(path/'spectra.npz');w=z['wavelength_um'];T=z['total_T'];r=json.loads((path/'results.json').read_text());r['identity']['layer_count_identity']=COUNTS;(path/'results.json').write_text(json.dumps(r,indent=2));st=stats(w,T);assert np.max(abs(np.array(st['main_pp'])-[r['main']['VIS_conditional_lower_pp'],r['main']['NIR_model_pp']]))<1e-10
   half=np.unique(np.r_[np.arange(0,len(w),2),np.argmin(abs(w-.78)),len(w)-1]);hs=stats(w[half],T[:,:,half]);old=json.loads((ROOT/'runs'/f'{PREFIX}readout64-127-{hole}-01/results.json').read_text());peaks={}
   for name,arr,mask in [('VIS_thermal',T[:,1]-T[:,0],w<=.78),('NIR_electric',T[1]-T[0],w>=.78)]:
    ids=np.flatnonzero(mask);peaks[name]=[{'branch':i,'wavelength_um':float(w[ids[int(np.argmax(abs(y[mask])))]]),'absolute_peak_pp':float(100*np.max(abs(y[mask])))}for i,y in enumerate(arr)]
   row={'grid':grid,'actual_wavelengths':len(w),'hole_inner_um':hole,'independent':st,'half_actual_count':len(half),'half_samefields':hs,'half_minus_full_main_pp':(np.array(hs['main_pp'])-st['main_pp']).tolist(),'full_minus127_main_pp':(np.array(st['main_pp'])-[old['main']['VIS_conditional_lower_pp'],old['main']['NIR_model_pp']]).tolist(),'sampled_peaks':peaks,'periodic_numerics':r['periodic_numerics'],'spectra_sha256':sha(path/'spectra.npz')};rows.append(row);views[grid,hole]=(w,T)
 delta={str(h):{k:(np.array(next(r for r in rows if r['grid']=='837'and r['hole_inner_um']==h)['independent'][k])-np.array(next(r for r in rows if r['grid']=='713'and r['hole_inner_um']==h)['independent'][k])).tolist()for k in ['main_pp','VIS_thermal_meanabs_pp','NIR_electric_meanabs_pp']}for h in [600,700]}
 (a.out/'results.json').write_text(json.dumps({'scope':'ONE fixed all-solid candidate, exact713 and union837 actual spectral quadrature separately; no physical tuning.','layer_count_identity':COUNTS,'rows':rows,'union837_minus_standard713':delta,'limitations':['All constitutive/source/process/zero-void bond conditions retained.','Grid agreement/nested half-grid are diagnostics, not strict global error or manufacturing/decoupling certificates.','Screen remains10mm after final thermalAl exit. Air candidate retained as separate historical control.']},indent=2))
 import matplotlib;matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 w,T=views['837',600];fig,axs=plt.subplots(2,2,figsize=(12,8),constrained_layout=True)
 for vi in range(2):
  for ti in range(2):
   for ax in axs[0]:ax.plot(w,100*T[vi,ti],lw=.8,label=f'{[0,9.235][vi]:g}V / {[25,50][ti]}C')
 for ax,lim,title in [(axs[0,0],(.4,.78),'VIS four states'),(axs[0,1],(.78,2.5),'NIR four states')]:ax.set(xlim=lim,title=title,ylabel='Port T (%)')
 for vi in range(2):axs[1,0].plot(w,100*(T[vi,1]-T[vi,0]),lw=.8,label=f'{[0,9.235][vi]:g}V')
 for ti in range(2):axs[1,1].plot(w,100*(T[1,ti]-T[0,ti]),lw=.8,label=f'{[25,50][ti]}C')
 axs[1,0].set(xlim=(.4,.78),title='VIS thermal cross response',ylabel='Hot - cold (pp)');axs[1,1].set(xlim=(.78,2.5),title='NIR electrical cross response',ylabel='9.235V - 0V (pp)')
 for ax,ys,mask in [(axs[1,0],100*(T[:,1]-T[:,0]),w<=.78),(axs[1,1],100*(T[1]-T[0]),w>=.78)]:
  lo=float(ys[:,mask].min());hi=float(ys[:,mask].max());pad=.06*(hi-lo);ax.set_ylim(lo-pad,hi+pad)
 for ax in axs.ravel():ax.set_xlabel('Wavelength (um)');ax.grid(alpha=.2);ax.legend(fontsize=8)
 fig.suptitle('Fixed all-solid interface / source25 / thermal8.55um / 837 actual wavelengths / original600 screen',fontsize=11)
 for ext in ['png','svg']:fig.savefig(a.out/f'solid_interface_837.{ext}',dpi=150)
 plt.close(fig);print(json.dumps({'rows':rows,'delta':delta},indent=2))
def main():
 p=argparse.ArgumentParser();p.add_argument('action',choices=['launch','optics','select','summarize']);p.add_argument('--out',type=Path,required=True);p.add_argument('--shards',type=int,default=4);p.add_argument('--shard',type=int,default=0);a=p.parse_args();a.out=a.out.resolve();a.out.mkdir(parents=True,exist_ok=False);globals()[a.action](a);(a.out/'source.py').write_bytes(Path(__file__).read_bytes())
if __name__=='__main__':main()
