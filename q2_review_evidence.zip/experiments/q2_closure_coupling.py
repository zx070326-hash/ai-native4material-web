"""Continuous two-cell Q2 device with a genuine 2um isotropic coupling layer.

The layer has full vector scattering, including impedance and both interface
reflections. Air eigenvectors used at zero-distance algebraic cuts are a basis,
not extra physical air. Saved continuous director fields and all cell layers
are unchanged; unknown optical loss must be a separately named scenario.
"""
import os
for key in ['OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'OMP_NUM_THREADS']:
    os.environ[key] = '1'
from pathlib import Path
from functools import lru_cache
import argparse, hashlib, json, sys, time
import numpy as np
from scipy.linalg import expm
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from experiments import q2_simple_shared as model

ZERO = ROOT/'runs/20261103-q2-balance-continuous-zero-01/director_fields.npz'
FOUR = ROOT/'runs/20261103-q2-balance-continuous-four-01/director_fields.npz'


def install_continuous_director():
    @lru_cache(maxsize=16)
    def director(mat, V, nx, nz):
        theta, phi, _ = model.old.texture(mat, V, nx, nz, four=FOUR, zero=ZERO)
        return theta, phi, 2*np.pi*(np.arange(nx)+.5)/nx
    model.solid.director = director


def uniform_layer(n, thickness, lam, qx, qy):
    """Block-diagonal exact isotropic Maxwell transfer, then air-basis scattering."""
    count = len(qx)
    scattering = [np.zeros((2*count, 2*count), complex) for _ in range(4)]
    ep = model.old.dielectric(n, n, np.zeros(1), np.zeros(1))
    for j, (xx, yy) in enumerate(zip(qx, qy)):
        gen = model.old.generator(ep, np.array([[xx]]), np.array([[yy]]), np.array([0]))
        transfer = expm(2j*np.pi/lam*thickness*gen)
        local = model.old.to_scattering(transfer, model.old.admittance(np.array([xx]), np.array([yy])))
        ids = [j, j+count]
        for block, value in zip(scattering, local):
            block[np.ix_(ids, ids)] = value
    return scattering


def cascade(left, right):
    """Redheffer composition for (r_left,r_right,t_forward,t_backward)."""
    rl, rr, tf, tb = left
    sl, sr, sf, sb = right
    operator = np.eye(len(rr))-rr@sl
    y = np.linalg.solve(operator, np.c_[tf, rr@sb])
    yl, yr = y[:, :len(rr)], y[:, len(rr):]
    result = (rl+tb@sl@yl, sr+sf@yr, sf@yl, tb@(sl@yr+sb))
    residual = float(abs(operator@y-np.c_[tf, rr@sb]).max())
    return result, residual


def device(lam, g, coupling_n, thickness=2., order=4, nz=32, uniform=False):
    m = np.arange(-order, order+1); N = len(m); count = N*N
    mx, my = np.meshgrid(m, m, indexing='xy')
    qx, qy = lam*mx.ravel()/(2*g['E7_period_um']), lam*my.ravel()/(2*g['5CB_period_um'])
    Y = model.old.admittance(qx, qy)
    middle = uniform_layer(coupling_n, thickness, lam, qx, qy)
    src = np.zeros((2*count, 2)); src[order*N+order, 0] = 1; src[count+order*N+order, 1] = 1
    states, diagnostics = {}, []
    for ti in range(2):
        thermal, ct = model.cell('5CB', 0, ti, lam, g, m, nz, shared=False, uniform=uniform)
        after, cascade_error = cascade(middle, thermal)
        for vi, V in enumerate([0, 4]):
            electrical, ce = model.cell('E7', V, ti, lam, g, m, nz, shared=False, uniform=uniform)
            op = np.eye(2*count)-electrical[1]@after[0]
            internal = np.linalg.solve(op, electrical[2]@src)
            forward = after[2]@internal
            backward = electrical[0]@src+electrical[3]@(after[0]@internal)
            T = float(np.real(np.sum(forward.conj()*(Y@forward)))/2)
            R = float(np.real(np.sum(backward.conj()*(Y@backward)))/2)
            for label, field in [('E', forward), ('G', Y@forward)]:
                states[f'V{vi}T{ti}__{label}'] = np.stack([field[:count], field[count:]], axis=1).reshape(N, N, 2, 2)
            diagnostics.append({'V': V, 'T_index': ti, 'T': T, 'R': R, 'A': 1-T-R,
                                'cell_transfer_condition_max': max(ct, ce),
                                'coupling_thermal_cascade_residual': cascade_error,
                                'cavity_residual_inf': float(abs(op@internal-electrical[2]@src).max())})
    return states, diagnostics


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--grid', type=Path, default=ROOT/'data/q2_solid_pilot_grid.npz')
    p.add_argument('--index-csv', type=Path, help='Three numeric columns wavelength_um,n,k; no extrapolation.')
    p.add_argument('--constant-n', type=float, default=1.52)
    p.add_argument('--constant-k', type=float, default=0.)
    p.add_argument('--material-label', default='constant-index interface diagnostic, not measured adhesive')
    p.add_argument('--source-description', default='Explicit diagnostic optical input; not a source-complete material claim.')
    p.add_argument('--thickness', type=float, default=2.)
    p.add_argument('--shard', type=int, default=0)
    p.add_argument('--shards', type=int, default=1)
    a = p.parse_args(); a.out.mkdir(parents=True, exist_ok=False)
    install_continuous_director()
    g = json.loads(model.old.GEOMFILE.read_text())['selected']
    g.pop('8step_photoalignment_cell_widths_um', None)
    g['alignment_pattern'] = 'continuous azimuth phi=pi*x/period, periods12/16um; no discrete step-width feature'
    w = np.load(a.grid)['wavelength_um'][a.shard::a.shards]
    if a.index_csv:
        table = np.loadtxt(a.index_csv, delimiter=',', skiprows=1, usecols=(0, 1, 2))
        assert np.all(np.diff(table[:, 0]) > 0) and np.all(np.isfinite(table))
        if w.min() < table[0, 0] or w.max() > table[-1, 0]:
            raise ValueError('Coupling table does not cover the requested grid; no silent extrapolation allowed.')
        ns = np.interp(w, table[:, 0], table[:, 1])+1j*np.interp(w, table[:, 0], table[:, 2])
    else:
        ns = np.full(len(w), complex(a.constant_n, a.constant_k))
    vals, di = {}, []
    tic = time.perf_counter()
    for lam, n in zip(w, ns):
        fields, diagnostic = device(float(lam), g, complex(n), a.thickness)
        for key, field in fields.items():
            vals.setdefault(key, []).append(field)
        di.append({'lambda_um': float(lam), 'coupling_n': float(n.real), 'coupling_k': float(n.imag), 'states': diagnostic})
        if len(di) == 1 or len(di) % 25 == 0 or len(di) == len(w):
            print(json.dumps({'done': len(di), 'total': len(w), 'lambda_um': float(lam), 'elapsed_s': time.perf_counter()-tic}), flush=True)
    np.savez_compressed(a.out/'scattered_fields.npz', wavelength_um=w, harmonics=np.arange(-4, 5),
                        **{key: np.array(value) for key, value in vals.items()})
    layers = model.physical_layers(g)
    layers = layers[:6]+[{'material': 'PEI', 'd_um': 8., 'function': 'E7 lower support'},
                         {'material': a.material_label, 'd_um': a.thickness, 'function': 'actual optical coupling layer'},
                         {'material': 'PEI', 'd_um': 8., 'function': '5CB upper support'}]+layers[7:]
    result = {'scope': __doc__, 'material_label': a.material_label, 'source_description': a.source_description,
              'index_csv': str(a.index_csv) if a.index_csv else None,
              'constant_index_only_if_no_csv': [a.constant_n, a.constant_k] if not a.index_csv else None,
              'geometry': g, 'physical_layer_sequence': layers, 'physical_layer_count': 15,
              'coupling_layer_thickness_um': a.thickness, 'physical_internal_air_gap_um': 0.,
              'LC_midpoint_distance_um': g['E7_d_um']/2+g['5CB_d_um']/2+.099+.030+.05+16+a.thickness,
              'continuous_director_sources': [str(ZERO), str(FOUR)], 'order': 4, 'nz': 32,
              'wavelength_count': len(w), 'elapsed_seconds': time.perf_counter()-tic, 'diagnostics': di,
              'complete_device_pass': False,
              'conditions': ['Both independent LC cells keep their existing source materials and continuous director fields.',
                             'Full coupling-layer impedance/reflections and all cell-to-cell returns are included; no phase-only index replacement.',
                             'Finite 20mm aperture/collector readout is a separately stated projection.',
                             'Adhesive dispersion, loss, cure, thermal and assembly transfer must follow the supplied source description.',
                             'Adding a coupling layer may mechanically couple the two completed cells; fixed planar gap and director conditions are retained.']}
    deps = [Path(__file__), Path(model.__file__), ZERO, FOUR, a.grid]
    if a.index_csv:
        deps.append(a.index_csv)
    result['hashes_sha256'] = {str(q.resolve().relative_to(ROOT)): hashlib.sha256(q.read_bytes()).hexdigest() for q in deps}
    (a.out/'results.json').write_text(json.dumps(result, indent=2), encoding='utf8')
    (a.out/'source.py').write_bytes(Path(__file__).read_bytes())


if __name__ == '__main__':
    main()
