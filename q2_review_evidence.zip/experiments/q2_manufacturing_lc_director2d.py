"""Periodic two-dimensional Frank diagnostic of the unchanged 8-step LC cells.

Both theta and phi vary in x and z. The two-period vector domain has a fixed
smooth angular winding sector, so this is not global director stability.
Zero-voltage stage; no prescribed electric field is substituted for Gauss law.
"""
import os
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import argparse,json,sys,time,hashlib
import numpy as np
import autograd.numpy as anp
from autograd import value_and_grad
from scipy.optimize import minimize
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments.q2_manufacturing_lc_director import SOURCE


def problem(d_um,period_um,K_pN,nx,nz,Wp=8e-4,Wa=1.4e-4,pattern='8step'):
    d=d_um*1e-6;K=np.array(K_pN)*1e-12;A=2*period_um/d_um
    dx=A/nx;dz=1/(nz-1);q=np.pi*d_um/period_um
    g=[.5-.5/np.sqrt(3),.5+.5/np.sqrt(3)]
    x=np.arange(nx)[:,None]
    def corners(u):return (u[:,:-1],anp.roll(u,-1,axis=0)[:,:-1],u[:,1:],anp.roll(u,-1,axis=0)[:,1:])
    def quad(c,a,b):
        v=(1-a)*(1-b)*c[0]+a*(1-b)*c[1]+(1-a)*b*c[2]+a*b*c[3]
        vx=((1-b)*(c[1]-c[0])+b*(c[3]-c[2]))/dx
        vz=((1-a)*(c[2]-c[0])+a*(c[3]-c[1]))/dz
        return v,vx,vz
    def easy(a):
        ph=2*np.pi*(x[:,0]+a)/nx
        return (anp.floor(ph/(np.pi/8))+.5)*np.pi/8 if pattern=='8step'else ph
    def components(vec):
        t=anp.reshape(vec[:nx*nz],(nx,nz));u=anp.reshape(vec[nx*nz:],(nx,nz));ct=corners(t);cu=corners(u)
        bulk=0.
        for a in g:
            for b in g:
                th,tx,tz=quad(ct,a,b);uu,ux,uz=quad(cu,a,b)
                ph=2*np.pi*(x+a)/nx+uu;px=q+ux;pz=uz
                co=anp.cos(th);si=anp.sin(th);cp=anp.cos(ph);sp=anp.sin(ph)
                nn=anp.stack([co*cp,co*sp,si],axis=-1)
                dt=anp.stack([-si*cp,-si*sp,co],axis=-1)
                dp=anp.stack([-co*sp,co*cp,anp.zeros_like(co)],axis=-1)
                nxv=dt*tx[...,None]+dp*px[...,None];nzv=dt*tz[...,None]+dp*pz[...,None]
                div=nxv[...,0]+nzv[...,2]
                curl=anp.stack([-nzv[...,1],nzv[...,0]-nxv[...,2],nxv[...,1]],axis=-1)
                dot=anp.sum(nn*curl,axis=-1)
                dens=.5*(div**2+(K[1]/K[0])*dot**2+(K[2]/K[0])*(anp.sum(curl**2,axis=-1)-dot**2))
                bulk+=anp.mean(dens)/4
        surface=0.
        for edge in [0,-1]:
            ts=t[:,edge];us=u[:,edge]
            for a in g:
                th=(1-a)*ts+a*anp.roll(ts,-1);ph=2*np.pi*(x[:,0]+a)/nx+(1-a)*us+a*anp.roll(us,-1)
                surface+=anp.mean(.5*Wp*d/K[0]*anp.sin(th)**2+.5*Wa*d/K[0]*(anp.cos(th)*anp.sin(ph-easy(a)))**2)/2
        return bulk,surface
    def energy(vec):a,b=components(vec);return a+b
    return energy,components,{'d_um':d_um,'period_um':period_um,'domain_periods':2,'nx':nx,'nz':nz,'K_pN':K_pN,'Wpolar_J_m2':Wp,'Wazimuthal_J_m2':Wa,'pattern':pattern,'energy_unit_J_m2':K[0]/d}


def initial(nx,nz,seed):
    x=2*np.pi*np.arange(nx)[:,None]/nx;z=np.linspace(0,1,nz)[None,:]
    if seed=='linear_phi':t=np.zeros((nx,nz));u=np.zeros_like(t)
    else:
        t=.06*np.cos(x)*np.sin(np.pi*z)+.025*np.sin(2*x)*np.cos(np.pi*z)
        u=.08*np.sin(x)*np.cos(np.pi*z)+.05*np.cos(3*x)*np.sin(np.pi*z)
    return np.r_[t.ravel(),u.ravel()]


def validation():
    fun,parts,meta=problem(1.2,12,[10,10,10],16,9,pattern='continuous')
    v=initial(16,9,'linear_phi');expected=.5*(np.pi*1.2/12)**2
    f,g=value_and_grad(fun)(v)
    vf=initial(16,9,'perturbed');ff,gg=value_and_grad(fun)(vf);rng=np.random.default_rng(623);direction=rng.normal(size=len(vf));direction/=np.linalg.norm(direction)
    eps=1e-6;fd=(fun(vf+eps*direction)-fun(vf-eps*direction))/(2*eps)
    return {'one_constant_linear_planar_energy':float(f),'exact_one_constant_linear_planar_energy':float(expected),'energy_absolute_error':float(abs(f-expected)),
        'directional_gradient_autodiff':float(gg@direction),'directional_gradient_finite_difference':float(fd),'directional_gradient_absolute_error':float(abs(fd-gg@direction)),
        'comment':'Finite polar anchoring admits nonzero surface polar torque even for this linear-phi zero-tilt reference; energy check is not a stationarity claim.'}


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--nx',type=int,default=64);ap.add_argument('--nz',type=int,default=33);ap.add_argument('--maxiter',type=int,default=2500)
    args=ap.parse_args();args.out.mkdir(parents=True,exist_ok=False)
    geompath=ROOT/'runs/20261102-q2-manufacturing-dual-lc-port-02/results.json';geom=json.loads(geompath.read_text())['selected']
    rows=[];arrays={};verification=validation();print(json.dumps({'validation':verification}),flush=True)
    for material in ['E7','5CB']:
        d=geom[material+'_d_um'];period=geom[material+'_period_um'];ks=SOURCE['E7_elastic_dielectric'if material=='E7'else'5CB_elastic']['K_pN']
        fun,parts,meta=problem(d,period,ks,args.nx,args.nz);vg=value_and_grad(fun)
        for seed in ['linear_phi','perturbed']:
            tic=time.perf_counter();v=initial(args.nx,args.nz,seed);initial_energy=float(fun(v));initial_grad=vg(v)[1]
            sol=minimize(vg,v,jac=True,method='L-BFGS-B',bounds=[(-np.pi/2+1e-5,np.pi/2-1e-5)]*(args.nx*args.nz)+[(None,None)]*(args.nx*args.nz),options={'maxiter':args.maxiter,'maxcor':40,'maxls':40,'ftol':2e-14,'gtol':1e-9})
            t=sol.x[:args.nx*args.nz].reshape(args.nx,args.nz);u=sol.x[args.nx*args.nz:].reshape(args.nx,args.nz);bulk,surface=parts(sol.x)
            cid=material+'__'+seed;arrays[cid+'__theta_rad']=t;arrays[cid+'__phi_correction_rad']=u
            easy=(np.floor((2*np.pi*np.arange(args.nx)/args.nx)/(np.pi/8)+1e-10)+.5)*np.pi/8
            phi=2*np.pi*np.arange(args.nx)[:,None]/args.nx+u
            angle=np.angle(np.exp(2j*(phi-easy[:,None])))/2
            row={'id':cid,**meta,'V_terminal_rms':0,'initial_energy_J_m2':initial_energy*meta['energy_unit_J_m2'],'final_energy_J_m2':float(sol.fun*meta['energy_unit_J_m2']),
                 'bulk_energy_J_m2':float(bulk*meta['energy_unit_J_m2']),'surface_energy_J_m2':float(surface*meta['energy_unit_J_m2']),
                 'energy_decrease_J_m2':float((initial_energy-sol.fun)*meta['energy_unit_J_m2']),
                 'theta_absmax_deg':float(np.rad2deg(abs(t).max())),'theta_rms_deg':float(np.rad2deg(np.sqrt(np.mean(t*t)))),
                 'phi_midplane_correction_absmax_deg':float(np.rad2deg(abs(u[:,args.nz//2]).max())),
                 'phi_vs_step_easy_midplane_rms_deg':float(np.rad2deg(np.sqrt(np.mean(angle[:,args.nz//2]**2)))),
                 'optimizer_success':bool(sol.success),'optimizer_message':str(sol.message),'iterations':int(sol.nit),'evaluations':int(sol.nfev),
                 'gradient_inf_dimensionless':float(abs(sol.jac).max()),'initial_gradient_inf_dimensionless':float(abs(initial_grad).max()),'elapsed_seconds':time.perf_counter()-tic}
            rows.append(row);print(json.dumps(row),flush=True)
            # Preserve progress after every state without pretending unfinished states exist.
            (args.out/'partial_results.json').write_text(json.dumps(rows,indent=2),encoding='utf8');np.savez_compressed(args.out/'director_fields.npz',**arrays)
    comparison=[]
    for material in ['E7','5CB']:
        a=arrays[material+'__linear_phi__theta_rad'];b=arrays[material+'__perturbed__theta_rad']
        ua=arrays[material+'__linear_phi__phi_correction_rad'];ub=arrays[material+'__perturbed__phi_correction_rad']
        n=lambda t,u:np.stack([np.cos(t)*np.cos(u+2*np.pi*np.arange(args.nx)[:,None]/args.nx),np.cos(t)*np.sin(u+2*np.pi*np.arange(args.nx)[:,None]/args.nx),np.sin(t)],axis=-1)
        na=n(a,ua);nb=n(b,ub);dot=np.abs(np.sum(na*nb,axis=-1))
        comparison.append({'material':material,'seed_director_headtail_angle_max_deg':float(np.rad2deg(np.arccos(np.clip(dot,-1,1))).max())})
    out={'scope':__doc__,'geometry':geom,'cases':rows,'seed_comparisons':comparison,'validation':verification,'sources':SOURCE,
         'limits':['Fixed angular winding sector on2-period smooth director domain; no defect nucleation, global minimization, dynamics or3D stability certificate.',
                   'K24 saddle-splay omitted; same source K and anchoring transfer assumptions as prior director run.',
                   'Photopattern surface is8-step, but bulk director is continuous and free. A discontinuous hard8step bulk field has divergent continuum Frank energy, so is not used as a finite physical energy reference.',
                   'Only0V in this stage. No prescribedEz field and no4V result are supplied.',
                   'No optical claims follow until relaxed fields have been mapped through local anisotropic optics and the unchanged finite port.'],
         'actual_complete_device_pass':False,'hashes':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()for p in [Path(__file__),geompath]}}
    (args.out/'results.json').write_text(json.dumps(out,indent=2),encoding='utf8');(args.out/'source.py').write_bytes(Path(__file__).read_bytes())

if __name__=='__main__':main()
