"""Twelve-layer local Jones model for the proposed two-LC finite-port device.

Includes finite PEI supports, IOH electrodes, anisotropic alignment films and
source-temperature LC real indices. Explicitly lacks measured LC broadband k,
post scattering, actual V/director and full grating Maxwell fields. This is a
conditional layer-loss diagnostic, never a complete-device certificate.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
from scipy.special import ndtr

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments.q2_manufacturing_lc_materials import ALIGNMENT,CB,lorentz,cauchy
from experiments.q2_manufacturing_dual_lc_port import interval_prob,DATA
from experiments.q2_manufacturing_ec_budget import load,OLD,SOURCES
from src.optics import index,band_mean,four_state_metrics


def amplitude(w,layers,ds):
    n=np.vstack([np.ones_like(w),layers,np.ones_like(w)])
    r=(n[-2]-n[-1])/(n[-2]+n[-1]);t=2*n[-2]/(n[-2]+n[-1])
    for i in range(len(n)-3,-1,-1):
        phase=np.exp(2j*np.pi*n[i+1]*ds[i]/w)
        ri=(n[i]-n[i+1])/(n[i]+n[i+1]);ti=2*n[i]/(n[i]+n[i+1]);den=1+ri*r*phase**2
        t=ti*t*phase/den;r=(ri+r*phase**2)/den
    return r,t


def port_weights(w,geometry):
    z=geometry['distance_um'];waist=geometry['Gaussian_waist_1_over_e_field_um']
    sigma=.5*waist*np.sqrt(1+(z*w/(np.pi*waist**2))**2)
    def aperture(x,y):
        px=sum(interval_prob(lo,hi,x,sigma)for lo,hi in geometry['collector_x_intervals_um'])
        lo,hi=geometry['collector_y_interval_um'];py=interval_prob(lo,hi,y,sigma)
        return px*py
    sx=w/geometry['E7_period_um'];sy=w/geometry['5CB_period_um'];kz=np.sqrt(1-sx*sx-sy*sy)
    return np.array([aperture(0,0),aperture(z*sx/np.sqrt(1-sx*sx),0),
                     aperture(0,z*sy/np.sqrt(1-sy*sy)),aperture(z*sx/kz,-z*sy/kz)])


def calculate(w,geometry,dp=4.,da=.015,residual=.0,lc_k=0.,dscale=1.,swap_alignment=False):
    pei=index('PEI_Zhang',w);con=load(OLD/'data/q2_device/IOH216_digitized.csv',w)
    align=[lorentz(w,ALIGNMENT['parameters_post_UV'][s])for s in ['e','o']]
    if swap_alignment:align.reverse()
    tab=np.loadtxt(DATA/'Li2005_E7_Cauchy.csv',delimiter=',',skiprows=1)
    G=port_weights(w,geometry);ports=np.zeros((2,2,len(w)));total=ports.copy();reflect=[];check=[]
    components={}
    for t,temp in enumerate([29.9,36.1]):
        co=[np.interp(temp,tab[:,0],tab[:,j])for j in range(1,7)]
        e7=[cauchy(w,co[:3])+1j*lc_k,cauchy(w,co[3:])+1j*lc_k]
        row=next(q for q in CB['rows']if q['T_C_text']==temp)
        cb=[cauchy(w,row[s])+1j*lc_k for s in ['e','o']]
        thermal=[]
        for pol in range(2):
            ns=np.array([pei,align[pol],cb[pol],align[pol],pei]);ds=[dp,da,geometry['5CB_d_um']*dscale,da,dp]
            r,amp=amplitude(w,ns,ds);thermal.append(amp);check.append((ns,ds,r,amp))
        tc0=abs((thermal[0]+thermal[1])/2)**2;tc1=abs((thermal[0]-thermal[1])/2)**2
        for v in range(2):
            electrical=[]
            for pol in range(2):
                N=e7[pol]if v==0 or pol==1 else e7[1]+residual*(e7[0]-e7[1])
                ns=np.array([pei,con,align[pol],N,align[pol],con,pei]);ds=[dp,.099,da,geometry['E7_d_um']*dscale,da,.099,dp]
                r,amp=amplitude(w,ns,ds);electrical.append(amp);check.append((ns,ds,r,amp))
            ec0=abs((electrical[0]+electrical[1])/2)**2;ec1=abs((electrical[0]-electrical[1])/2)**2
            ports[v,t]=ec0*tc0*G[0]+ec1*tc0*G[1]+ec0*tc1*G[2]+ec1*tc1*G[3]
            total[v,t]=(ec0+ec1)*(tc0+tc1)
            components[f'V{v}T{t}_order_powers']=np.array([ec0,ec1,tc0,tc1])
    return ports,total,components,check


def metrics(w,t):
    m=four_state_metrics(w,t,{'visible':(.4,.78),'nir':(.78,2.5)})
    # Missing blue can oppose the signed difference by at most its5% fraction.
    vislower=max(0,.95*m['summary']['visible_voltage_delta_min']-.05)
    m['full_380_780_VIS_voltage_delta_guaranteed_lower_using_passivity_only']=vislower
    m['full_VIS_temperature_cross_upper_using_passivity_only']=.95*m['summary']['visible_temperature_cross_max']+.05
    m['known_VIS_domain_um']=[.4,.78]
    m['conditional_amplitude_pass_with_adversarial_unknown_blue']=bool(vislower>.3 and m['summary']['nir_temperature_delta_min']>.2)
    return m


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False)
    src=ROOT/'runs/20261102-q2-manufacturing-dual-lc-port-02/results.json';geometry=json.loads(src.read_text())['selected']
    w=np.unique(np.r_[np.linspace(.4,.78,761),np.linspace(.78,2.5,3441)])
    t,total,components,checks=calculate(w,geometry)
    error=0.;from tmm import coh_tmm
    for ns,ds,r,amp in checks:
        for j in [0,173,760,1500,-1]:
            sol=coh_tmm('s',[1,*ns[:,j],1],[np.inf,*ds,np.inf],0,w[j])
            error=max(error,abs(sol['t']-amp[j]),abs(sol['r']-r[j]))
    scenarios=[]
    for name,cfg in [('PEI7um',{'dp':7.}),('PEI9um',{'dp':9.}),('residual10pct',{'residual':.1}),
                     ('residual20pct',{'residual':.2}),('LC_k0p001_UNMEASURED',{'lc_k':.001}),
                     ('LC_k0p005_UNMEASURED',{'lc_k':.005}),('LC_gap_minus6p2pct',{'dscale':.938}),
                     ('LC_gap_plus6p2pct',{'dscale':1.062}),('alignment_axis_swap',{'swap_alignment':True})]:
        ts,_,_,_=calculate(w,geometry,**cfg);scenarios.append({'id':name,'parameters':cfg,'metrics':metrics(w,ts)})
    result={'scope':'Two finite multilayer local-Jones screens plus diagonal-corrected Gaussian collection; conditional optical model, not manufacturing closure.',
            'temperatures_C':[29.9,36.1],'index_branch':'nominal550nm only; SD1/SDA2 fails strict branch',
            'geometry':geometry,'finite_layer_count':12,
            'electrical_cell':['PEI4um','IOH99nm','SD1/SDA2 15nm','E7','SD1/SDA2 15nm','IOH99nm','PEI4um'],
            'thermal_cell':['PEI4um','SD1/SDA2 15nm','5CB','SD1/SDA2 15nm','PEI4um'],
            'metrics':metrics(w,t),'all_orders_transmission_metrics':metrics(w,total),
            'scenarios':scenarios,'independent_complex_amplitude_TMM_max_error':float(error),
            'limits':['PEI_Zhang is not the same grade or process as the10umPI coat-debond LC demonstration; commercial4umPEI thickness alone does not close process.',
                      'LC k is zero in nominal conditional model because no full source k is available; constant-k cases are imposed diagnostics, not measured specimens or confidence bounds.',
                      'LC Cauchy and alignment Lorentz are continued beyond source coverage, explicitly; both control temperatures are source-model labels, with0.15-0.2K source ambiguity.',
                      'Local uniform stack/Jones treatment neglects diffraction inside each rotating-director cell; phi/tilt profile, finite anchoring and V-to-director are not solved.',
                      'Grating high-voltage state is ideal homeotropic with retained alignment anisotropy; no actual voltage prescribed.',
                      'Multiple reflections between the separated cells, angular changes at the second cell, and coherent overlap of diffraction orders are not covered.',
                      'No spacer/edge-seal opaque fraction, support-induced scatter, post-nearby distorted LC or patterned electrode leads are included.',
                      'Gray aperture factors cannot replace a finite patterned-post optical calculation when only a few posts intercept the100um-waist beam.',
                      'Full-halfspace total transmission modulation is reported separately and does not inherit finite-port pass.',
                      'Per-layer nominal dimensions meet bounds, but real fabrication tolerances and all sealing materials are not certified.'],
            'source_sha256':SOURCES,'actual_complete_device_pass':False}
    for path in [Path(__file__),src,ROOT/'experiments/q2_manufacturing_lc_materials.py',ROOT/'data/nk/PEI_Zhang.csv',DATA/'Li2005_E7_Cauchy.csv']:
        result['source_sha256'][str(path.relative_to(ROOT))]=hashlib.sha256(path.read_bytes()).hexdigest()
    (a.out/'results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    (a.out/'source.py').write_bytes(Path(__file__).read_bytes())
    np.savez_compressed(a.out/'spectra.npz',wavelength_um=w,port_T=t,all_orders_T=total,**components)
    print(json.dumps({'nominal':result['metrics'],'all_orders':result['all_orders_transmission_metrics']['summary'],
                      'error':error,'scenarios':[{k:r[k]for k in ['id','metrics']}for r in scenarios]},indent=2))


if __name__=='__main__':main()
