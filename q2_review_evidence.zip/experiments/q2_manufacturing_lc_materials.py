"""Traceable LC/photoalignment data and thin-cell manufacturing limits.

This is a material/process evidence packet, not a full-device certification.
Out-of-coverage dispersion extensions are separate, explicitly named columns.
"""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np


ALIGNMENT = {
    'doi': '10.1002/pssc.200777881',
    'author_fulltext_url': 'https://www.researchgate.net/publication/230043369_UV-induced_in-plane_anisotropy_in_layers_of_mixture_of_the_azo-dyes_SD-1SDA-2_characterized_by_spectroscopic_ellipsometry',
    'material': 'SD-1/SDA-2 40:60; V-65 initiator 2% relative to SDA-2',
    'sample': 'Spin-coated on silicon/native oxide; post-UV fitted thickness 10.1 nm',
    'temperature': 'room temperature; numerical temperature not supplied',
    'measured_wavelength_um': [0.2, 1.35],
    'sampling_nm': 10,
    'preparation': ['DMF solution', '800 rpm 5 s, 3000 rpm 30 s',
                    '100 C 10 min solvent removal',
                    'linearly polarized UV 8.3 mW/cm2 15 min',
                    '150 C 1 h vacuum polymerization'],
    'formula': 'N=sqrt(eps_inf+sum A/(E0**2-E**2-1j*Gamma*E)); E[eV]=1.2398419843320026/lambda[um]',
    'parameters_post_UV': {
        'e': {'eps_inf': 2.03, 'A_Gamma_E0': [[1.074,.628,3.510],[.545,1.008,4.746],[2.455,.990,6.322]]},
        'o': {'eps_inf': 2.27, 'A_Gamma_E0': [[.848,.374,3.543],[.464,1.159,4.788],[1.865,.718,6.058]]}},
    'limitations': ['Not pure SD-1 and not polyimide.',
                    'No measurement beyond 1.35 um; extension is an unvalidated oscillator continuation.',
                    'No measured 30/40 C dependence.',
                    '10.1 nm leaves only 0.1 nm nominal lower-thickness margin.',
                    '15 or 20 nm design uses an explicit thickness transfer.',
                    'Optical tensor versus LC director orientation must be retained.',
                    'Measured on Si, not proposed electrode/polymer substrates.']}

CB = {
    'doi': '10.1063/1.1635971',
    'title': 'Extended Cauchy equations for the refractive indices of liquid crystals',
    'author_url': 'https://lcd.creol.ucf.edu/publications/2004/JAP95_896_2004.pdf',
    'table': 'Table III',
    'retrieval': 'Author PDF indexed primary-source text; direct download now redirects to group home, so no local original PDF received.',
    'formula': 'n=A+B/lambda_um**2+C/lambda_um**4; real index only',
    'coverage_um': [.4,.8],
    'rows': [
        {'T_C_text':25.1,'T_K_table':298.1,'e':[1.67946,.00482,.00273],'o':[1.51866,.00163,.00114]},
        {'T_C_text':27.2,'T_K_table':300.2,'e':[1.67649,.00489,.00266],'o':[1.51864,.00163,.00116]},
        {'T_C_text':29.9,'T_K_table':302.9,'e':[1.67030,.00462,.00257],'o':[1.52012,.00158,.00121]},
        {'T_C_text':32.6,'T_K_table':305.6,'e':[1.65866,.00440,.00248],'o':[1.52369,.00174,.00125]},
        {'T_C_text':34.8,'T_K_table':307.8,'e':[1.64304,.00380,.00217],'o':[1.53028,.00183,.00135]},
        {'T_C_text':36.1,'T_K_table':309.1,'e':[1.57209,.00210,.00161],'o':[1.57209,.00210,.00161]}],
    'limitations': ['Paper text C versus Table III K labels have 0.15-0.2 K inconsistency; preserve both.',
                    'No full-band k; do not silently set measured absorption to zero.',
                    'Extension to 0.38 or 2.5 um is not measured data.',
                    '36.1 C isotropic coefficients are not measured 40 C coefficients.']}

FAB = {
    'doi': '10.1587/transele.E99.C.1228',
    'url': 'https://globals.ieice.org/en_transactions/electronics/10.1587/transele.E99.C.1228/_pdf',
    'material': 'Mitsui ECRIOS VICT-Bnp polyimide substrate; JSR AL1254 alignment; JNC TD-1016LA LC; PR-200 posts',
    'substrate_um': 10,
    'LC_gap_um': 4.5,
    'post_ellipse_diameters_um': [100,50],
    'post_spacing_series_um': list(range(100,1001,100)),
    'successful_demonstrated_spacing_um': 100,
    'reported_limit': 'Text says below 0.2 mm; do not convert this to <=0.2 mm guarantee.',
    'preparation': ['PI on glass temporary carrier: 270 C 2 h N2',
                    'Pattern negative PR-200 posts, 150 C 1 h',
                    'AL1254 coating, 200 C 1 h, rub',
                    'Seal and laminate; debond first carrier',
                    'Vacuum fill; debond second carrier'],
    'observed_failure': 'Larger unsupported spans change gap upon release and redistribute LC to edges.',
    'limitations': ['Measured absolute substrate n,k not supplied.',
                    'Exact optical-mask footprint cannot be inferred without resolving center versus edge post spacing.',
                    'No demonstrated E7/5CB patterned photoalignment and electrode stack in this paper.',
                    'A 10 um nominal substrate is exactly at the upper thickness bound, not a manufacturing-tolerance guarantee.',
                    'Posts cannot be omitted from aperture, layer/material and alignment analysis.']}


def lorentz(w, q):
    E=1.2398419843320026/np.asarray(w)
    eps=np.full(np.shape(E),q['eps_inf'],dtype=complex)
    for A,G,E0 in q['A_Gamma_E0']:
        eps += A/(E0*E0-E*E-1j*G*E)
    return np.sqrt(eps)


def cauchy(w, abc):
    return abc[0]+abc[1]/w**2+abc[2]/w**4


def avg(w,x,low,high):
    take=(w>=low)&(w<=high)
    return float(np.trapezoid(x[take],w[take])/(high-low))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out',type=Path,required=True)
    args=p.parse_args(); args.out.mkdir(parents=True,exist_ok=True)
    w=np.unique(np.r_[np.linspace(.38,.78,401),np.linspace(.78,2.5,1721)])
    coverage=(w>=.2)&(w<=1.35)
    align=np.array([lorentz(w,ALIGNMENT['parameters_post_UV'][v]) for v in ['e','o']])
    np.savetxt(args.out/'SD1_SDA2_postUV_coverage_and_extension.csv',
               np.c_[w,np.where(coverage,align[0].real,np.nan),np.where(coverage,align[0].imag,np.nan),
                     np.where(coverage,align[1].real,np.nan),np.where(coverage,align[1].imag,np.nan),
                     align[0].real,align[0].imag,align[1].real,align[1].imag,coverage.astype(int)],
               delimiter=',',header='lambda_um,ne_covered,ke_covered,no_covered,ko_covered,ne_model_extension,ke_model_extension,no_model_extension,ko_model_extension,in_measured_domain',comments='')
    align_results=[]
    for pol,N in zip(['e','o'],align):
        N550=complex(lorentz(np.array(.55),ALIGNMENT['parameters_post_UV'][pol]))
        below=coverage&(N.real<1.5)
        align_results.append({'axis':pol,'n550':N550.real,'k550':N550.imag,
            'covered_n_min':float(N.real[coverage].min()),'covered_n_max':float(N.real[coverage].max()),
            'first_covered_lambda_below_1p5_um':float(w[below][0]) if np.any(below) else None,
            'nominal550_pass':bool(1.5<=N550.real<=3),
            'strict_covered_fail':bool(np.any(below))})
    losses=[]
    for d_nm in [10.1,15,20,50]:
        # Four alignment films, pessimistic principal-axis Beer attenuation.
        # This omits coherent reflections and is explicitly a propagation-only diagnostic.
        surv=np.exp(-4*np.pi*np.max(align.imag,axis=0)*(4*d_nm/1000)/w)
        losses.append({'four_films_each_nm':d_nm,
            'VIS_propagation_survival':avg(w,surv,.38,.78),
            'NIR_propagation_survival_model_extension':avg(w,surv,.78,2.5),
            'max_pointwise_absorption':float(1-surv.min()),
            'identity':'not a lower bound on full-stack T; NIR outside 1.35 um unvalidated'})
    cb_rows=[]
    for row in CB['rows']:
        ne=cauchy(w,row['e']);no=cauchy(w,row['o']);mask=(w>=.4)&(w<=.8)
        name=f"5CB_{row['T_C_text']:.1f}C"
        np.savetxt(args.out/(name+'_coverage_and_extension.csv'),
                   np.c_[w,np.where(mask,ne,np.nan),np.where(mask,no,np.nan),ne,no,mask.astype(int)],
                   delimiter=',',header='lambda_um,ne_covered,no_covered,ne_model_extension,no_model_extension,in_measured_domain',comments='')
        cb_rows.append({'label':name,'n550_e':float(cauchy(np.array(.55),row['e'])),
                        'n550_o':float(cauchy(np.array(.55),row['o'])),
                        'T_K_table':row['T_K_table']})
    posts=[]
    area=np.pi*50*25
    for label,px,py in [('100um_center_pitch',100,100),('100um_edge_gap',200,150),
                        ('200um_center_pitch_NOT_validated_as_stable',200,200)]:
        frac=float(area/(px*py))
        posts.append({'interpretation':label,'pitch_xy_um':[px,py],'post_area_fraction':frac,
                      'one_cell_open_fraction':1-frac,
                      'two_cells_aligned_registration_open_fraction_upper':1-frac,
                      'two_cells_uncorrelated_mean_open_fraction':(1-frac)**2,
                      'caution':'Geometric scenarios, not recovered source mask. Posts may transmit but do not provide intended LC grating.'})
    result={'status':'material and manufacturing evidence; no full-device claim',
            'alignment_index_results':align_results,'alignment_propagation_diagnostics':losses,
            '5CB_reference_index':cb_rows,'post_geometry_scenarios':posts,
            'layer_inventory_for_two_orthogonal_cells':{
                'electrical_cell':['support','electrode','alignment','E7 LC','alignment','electrode','support'],
                'thermal_cell':['support','alignment','5CB LC','alignment','support'],
                'finite_film_count':12,
                'notes':['Thermal cell does not require electrodes for its intended function.',
                         'Separators, gap-control posts, edge seal, receiver and encapsulation must be classified and counted where finite.',
                         'Carrier glass is removed; it cannot remain in the optical stack.',
                         'Neither PET-4um nor VICT-Bnp-10um is a verified complete material/process solution for this candidate.']}}
    for name,obj in [('alignment_source.json',ALIGNMENT),('5CB_source.json',CB),('thin_LC_cell_source.json',FAB),('results.json',result)]:
        (args.out/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False),encoding='utf-8')
    receipts=[]
    for path in sorted(args.out.glob('*.csv')):
        receipts.append({'file':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    (args.out/'data_hashes.json').write_text(json.dumps(receipts,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2,ensure_ascii=False))


if __name__=='__main__':main()
