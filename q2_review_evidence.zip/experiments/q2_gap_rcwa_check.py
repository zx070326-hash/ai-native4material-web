"""Independent 1D vector Fourier-Maxwell check of diffraction INSIDE each cell.

Normal incidence, no posts. Both tangential polarizations and tilted epsilon_xz,
epsilon_yz are retained. This is not the orthogonal two-cell complete2D solve.
"""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import sys,json,argparse,time
import numpy as np
from scipy.linalg import expm
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments.q2_gap_optics import texture,cells,FOUR,ZERO,GEOMFILE,DATA,ALIGNMENT,CB,cauchy,lorentz,load,OLD,index

def convolution(a,m):
    n=len(a);f=np.fft.fft(a)/n;delta=m[:,None]-m[None,:]
    # Samples at(j+.5)/N, not atj/N.
    return f[delta%n]*np.exp(-1j*np.pi*delta/n)

def generator(ne,no,theta,phi,lam,period,m):
    n=np.stack([np.cos(theta)*np.cos(phi),np.cos(theta)*np.sin(phi),np.sin(theta)],-1);ep=no*no;de=ne*ne-no*no
    eps=ep*np.eye(3)[None]+de*n[:,:,None]*n[:,None,:];iz=1/eps[:,2,2];K=np.diag(lam*m/(2*period));N=len(m);G=np.zeros((4*N,4*N),complex);I=np.eye(N)
    cv=lambda v:convolution(v,m)
    xx=cv(eps[:,0,0]-eps[:,0,2]*iz*eps[:,2,0]);xy=cv(eps[:,0,1]-eps[:,0,2]*iz*eps[:,2,1]);yx=cv(eps[:,1,0]-eps[:,1,2]*iz*eps[:,2,0]);yy=cv(eps[:,1,1]-eps[:,1,2]*iz*eps[:,2,1]);xz=cv(iz*eps[:,0,2]);yz=cv(iz*eps[:,1,2]);zi=cv(iz)
    G[:N,:N]=-K@xz;G[:N,N:2*N]=-K@yz;G[:N,2*N:3*N]=I-K@zi@K;G[N:2*N,3*N:]=I
    G[2*N:3*N,:N]=xx;G[2*N:3*N,N:2*N]=xy;G[2*N:3*N,2*N:3*N]=-xz@K
    G[3*N:,:N]=yx;G[3*N:,N:2*N]=yy-K@K;G[3*N:,2*N:3*N]=-yz@K
    return G

def calc(mat,V,ti,lam,g,order=8,nz=64,nx=128):
    m=np.arange(-order,order+1);N=len(m);L=g[mat+'_period_um'];theta,phi,easy=texture(mat,V,nx,nz)
    temp=[29.9,36.1][ti];tab=np.loadtxt(DATA/'Li2005_E7_Cauchy.csv',delimiter=',',skiprows=1)
    if mat=='E7':co=[np.interp(temp,tab[:,0],tab[:,j])for j in range(1,7)];ne,no=[complex(cauchy(np.array(lam),v))for v in [co[:3],co[3:]]]
    else:row=next(r for r in CB['rows']if r['T_C_text']==temp);ne,no=[complex(cauchy(np.array(lam),row[s]))for s in ['e','o']]
    pei=complex(index('PEI_Zhang',np.array([lam]))[0]);con=complex(load(OLD/'data/q2_device/IOH216_digitized.csv',np.array([lam]))[0]);al=[complex(lorentz(np.array(lam),ALIGNMENT['parameters_post_UV'][s]))for s in ['e','o']]
    pre=[(pei,pei,4,easy*0)]
    if mat=='E7':pre.append((con,con,.099,easy*0))
    pre.append((*al,.015,easy));M=np.eye(4*N,dtype=complex)
    for ee,oo,dd,pp in pre:M=expm(2j*np.pi/lam*dd*generator(ee,oo,np.zeros(nx),pp,lam,L,m))@M
    for iz in range(nz):M=expm(2j*np.pi/lam*g[mat+'_d_um']/nz*generator(ne,no,theta[:,iz],phi[:,iz],lam,L,m))@M
    for ee,oo,dd,pp in pre[::-1]:M=expm(2j*np.pi/lam*dd*generator(ee,oo,np.zeros(nx),pp,lam,L,m))@M
    q=np.sqrt(1-(lam*m/(2*L))**2+0j);Y=np.diag(np.r_[1/q,q]);I=np.eye(2*N);W=np.block([[I,I],[Y,-Y]]);D=np.linalg.solve(W,M@W)
    A,B,C,DD=D[:2*N,:2*N],D[:2*N,2*N:],D[2*N:,:2*N],D[2*N:,2*N:];src=np.zeros((2*N,2));src[order,0]=1;src[N+order,1]=1
    reflected=-np.linalg.solve(DD,C@src);trans=A@src+B@reflected
    tr=np.stack([trans[:N],trans[N:]],axis=1);rr=np.stack([reflected[:N],reflected[N:]],axis=1);weight=np.stack([np.real(1/q),q.real],axis=1)
    pT=np.sum(abs(tr)**2*weight[:,:,None],axis=(1,2))/2;pR=np.sum(abs(rr)**2*weight[:,:,None],axis=(1,2))/2
    local=cells(np.array([lam]),g,nx,nz=nz)[f'{mat}_V{V}_T{ti}'][0,:,2];f=np.fft.fft(local,axis=0)/nx;f=f[m%nx]*np.exp(-1j*np.pi*m/nx)[:,None,None];pLoc=np.sum(abs(f)**2,axis=(1,2))/2
    return {'material':mat,'V':V,'T_index':ti,'lambda_um':lam,'order':order,'nz':nz,'orders':m.tolist(),'rcwa_order_T':pT.tolist(),'local_order_norm':pLoc.tolist(),'T':float(pT.sum()),'R':float(pR.sum()),'A':float(1-pT.sum()-pR.sum()),'local_retained_T':float(pLoc.sum()),'main_order0_T':float(pT[order]),'main_first_pair_T':float(pT[np.isin(m,[-2,2])].sum()),'local_main_order0_T':float(pLoc[order]),'local_first_pair_T':float(pLoc[np.isin(m,[-2,2])].sum()),'transfer_condition_number':float(np.linalg.cond(M))}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,required=True);p.add_argument('--wavelengths',default='.55,.82,1.25,2.5');p.add_argument('--order',type=int,default=8);p.add_argument('--nz',type=int,default=64);p.add_argument('--cases',default='E7_0_0,E7_4_0,5CB_0_0');a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False);g=json.loads(GEOMFILE.read_text())['selected'];rows=[];tic=time.perf_counter()
    for case in a.cases.split(','):
        mat,V,ti=case.split('_')
        for lam in [float(s)for s in a.wavelengths.split(',')]:
            row=calc(mat,int(V),int(ti),lam,g,a.order,a.nz);rows.append(row);print(json.dumps({**row,'elapsed_s':time.perf_counter()-tic}),flush=True);(a.out/'partial_results.json').write_text(json.dumps(rows,indent=2),encoding='utf8')
    result={'scope':__doc__,'cases':rows,'limits':['Uniform incident plane wave at one cell, no orthogonal second-cell coupling, finite beam or posts.','Direct convolution of Schur-eliminated dielectric functions; finite Fourier order andz slicing require controls, especially atdiscontinuous alignment axes.','Transfer matrices used only in stated low-order regime; conditioning andRTA reported, high-evanescent regimes need scattering stabilization.','Tests internal diffraction which reference-center screen omits; not a substitute for a complete vector two-grating solution.']}
    (a.out/'results.json').write_text(json.dumps(result,indent=2),encoding='utf8');(a.out/'source.py').write_bytes(Path(__file__).read_bytes())

if __name__=='__main__':main()
