"""Combined Q2 periodic-vector scenarios: PEI support, thermal barrier and 5CB k.

Reuses the frozen Fourier-Maxwell generator/scattering conventions. All four
supports change together; the two Al2O3 films are inside the thermal cell only.
Loss outside explicitly covered intervals is the frozen k=0 assumption.
"""
import os
for key in ['OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'OMP_NUM_THREADS']:
    os.environ[key] = '1'
from pathlib import Path
from functools import lru_cache
import argparse, hashlib, json, sys, time
import numpy as np
from scipy.linalg import expm
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from experiments import q2_gap_vector_device as old

LOSS_SOURCE = ROOT/'runs/20261102-constraints-gap-materials-01/5CB_Fig3_union_upper_envelope.csv'
LOSS_INTERVALS = ((1.105, 2.435), (2.48, 2.5))
LOSS_FACTORS = {'none': (0., 0., 0.), 'isotropic': (1., 1., 1.),
                'parallel': (3., 0., 1.), 'perpendicular': (0., 1.5, 1.)}


@lru_cache(maxsize=16)
def director(mat, V, nx, nz):
    return old.texture(mat, V, nx, nz, four=old.SOURCE4, zero=old.SOURCE0)


@lru_cache(maxsize=1)
def loss_segments():
    table = np.loadtxt(LOSS_SOURCE, delimiter=',', skiprows=1, usecols=(0, 1, 2, 3))
    # Split before interpolation: never bridge the unresolved/clipped peak.
    good = np.isfinite(table[:, 3])
    return [table[good & (table[:, 0] < 2.44)], table[good & (table[:, 0] > 2.47)]]


def apparent_k(lam):
    for (lo, hi), segment in zip(LOSS_INTERVALS, loss_segments()):
        if lo <= lam <= hi:
            assert segment[0, 0] <= lam <= segment[-1, 0]
            return float(np.interp(lam, segment[:, 0], segment[:, 3]))
    return 0.


@lru_cache(maxsize=1)
def e7_table():
    return np.loadtxt(old.DATA/'Li2005_E7_Cauchy.csv', delimiter=',', skiprows=1)


def single_cell(mat, V, ti, lam, g, m, nz, support=4., barrier=0., loss='none', nx=128):
    theta, phi, easy = director(mat, V, nx, nz)
    temp = [29.9, 36.1][ti]
    if mat == 'E7':
        tab = e7_table()
        co = [np.interp(temp, tab[:, 0], tab[:, j]) for j in range(1, 7)]
        ne, no = [complex(old.cauchy(np.array(lam), v)) for v in [co[:3], co[3:]]]
    else:
        row = next(r for r in old.CB['rows'] if r['T_C_text'] == temp)
        ne, no = [complex(old.cauchy(np.array(lam), row[s])) for s in ['e', 'o']]
        fe, fo, fh = LOSS_FACTORS[loss]
        ke, ko = (fh, fh) if ti else (fe, fo)
        kval = apparent_k(lam)
        ne += 1j*ke*kval
        no += 1j*ko*kval
    pei = complex(old.index('PEI_Zhang', np.array([lam]))[0])
    io = complex(old.load(old.OLD/'data/q2_device/IOH216_digitized.csv', np.array([lam]))[0])
    al = [complex(old.lorentz(np.array(lam), old.ALIGNMENT['parameters_post_UV'][s])) for s in ['e', 'o']]
    iso = lambda n: old.dielectric(n, n, easy*0, easy*0)
    pre = [(iso(pei), support)]
    if mat == 'E7':
        pre.append((iso(io), .099))
    elif barrier:
        alumina = complex(old.index('Al2O3_Franta', np.array([lam]))[0])
        pre.append((iso(alumina), barrier))
    pre.append((old.dielectric(*al, easy*0, easy), .015))
    layers = pre + [(old.dielectric(ne, no, theta[:, iz], phi[:, iz]), g[mat+'_d_um']/nz)
                    for iz in range(nz)] + pre[::-1]
    N = len(m)
    S = [np.zeros((2*N*N, 2*N*N), complex) for _ in range(4)]
    condition = 0.
    for fixedindex, mf in enumerate(m):
        if mat == 'E7':
            qx = lam*m/(2*g['E7_period_um'])
            qy = np.full(N, lam*mf/(2*g['5CB_period_um']))
            idx = np.arange(N)+fixedindex*N
        else:
            qx = np.full(N, lam*mf/(2*g['E7_period_um']))
            qy = lam*m/(2*g['5CB_period_um'])
            idx = np.arange(N)*N+fixedindex
        Kx, Ky = np.diag(qx), np.diag(qy)
        M = np.eye(4*N, dtype=complex)
        for ep, dd in layers:
            M = expm(2j*np.pi/lam*dd*old.generator(ep, Kx, Ky, m))@M
        local = old.to_scattering(M, old.admittance(qx, qy))
        idx = np.r_[idx, idx+N*N]
        for a, b in zip(S, local):
            a[np.ix_(idx, idx)] = b
        condition = max(condition, float(np.linalg.cond(M)))
    return S, condition


def device(lam, g, order=4, nz=32, support=4., barrier=0., loss='none'):
    m = np.arange(-order, order+1)
    N = len(m)
    mx, my = np.meshgrid(m, m, indexing='xy')
    qx, qy = lam*mx.ravel()/(2*g['E7_period_um']), lam*my.ravel()/(2*g['5CB_period_um'])
    qz = np.sqrt(1-qx*qx-qy*qy+0j)
    Y = old.admittance(qx, qy)
    phase = np.tile(np.exp(2j*np.pi/lam*2*qz), 2)
    src = np.zeros((2*N*N, 2))
    ind = order*N+order
    src[ind, 0], src[N*N+ind, 1] = 1, 1
    states, di = {}, []
    for ti in range(2):
        c, cc = single_cell('5CB', 0, ti, lam, g, m, nz, support, barrier, loss)
        for vi, V in enumerate([0, 4]):
            e, ce = single_cell('E7', V, ti, lam, g, m, nz, support, barrier, loss)
            rt = e[1]@(phase[:, None]*c[0]*phase[None, :])
            a = np.linalg.solve(np.eye(2*N*N)-rt, e[2]@src)
            out = c[2]@(phase[:, None]*a)
            back = e[0]@src+e[3]@(phase[:, None]*(c[0]@(phase[:, None]*a)))
            Tout = float(np.real(np.sum(out.conj()*(Y@out)))/2)
            Rout = float(np.real(np.sum(back.conj()*(Y@back)))/2)
            for label, field in [('E', out), ('G', Y@out)]:
                states[f'V{vi}T{ti}__{label}'] = np.stack([field[:N*N], field[N*N:]], axis=1).reshape(N, N, 2, 2)
            di.append({'V': V, 'T_index': ti, 'T': Tout, 'R': Rout, 'A': 1-Tout-Rout,
                       'cell_transfer_condition_max': max(ce, cc),
                       'cavity_residual_inf': float(abs((np.eye(2*N*N)-rt)@a-e[2]@src).max())})
    return states, di


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--wavelengths', default='.4,.55,.78,1.25,2,2.5')
    p.add_argument('--grid', type=Path)
    p.add_argument('--midpoints', action='store_true')
    p.add_argument('--support', type=float, default=4.)
    p.add_argument('--barrier', type=float, default=.05)
    p.add_argument('--loss', choices=list(LOSS_FACTORS), default='isotropic')
    p.add_argument('--order', type=int, default=4)
    p.add_argument('--nz', type=int, default=32)
    p.add_argument('--shard', type=int, default=0)
    p.add_argument('--shards', type=int, default=1)
    a = p.parse_args()
    a.out.mkdir(parents=True, exist_ok=False)
    g = json.loads(old.GEOMFILE.read_text())['selected']
    w = np.load(a.grid)['wavelength_um'] if a.grid else np.array([float(v) for v in a.wavelengths.split(',')])
    if a.midpoints:
        w = (w[:-1]+w[1:])/2
    w = w[a.shard::a.shards]
    vals, di = {}, []
    tic = time.perf_counter()
    for lam in w:
        s, d = device(float(lam), g, a.order, a.nz, a.support, a.barrier, a.loss)
        for k, v in s.items():
            vals.setdefault(k, []).append(v)
        di.append({'lambda_um': float(lam), 'apparent_5CB_k': apparent_k(float(lam)), 'states': d})
        print(json.dumps({'lambda_um': float(lam), 'done': len(di), 'total': len(w),
                          'elapsed_s': time.perf_counter()-tic, 'A_min': min(x['A'] for x in d)}), flush=True)
        if len(di) % 25 == 0:
            (a.out/'partial_results.json').write_text(json.dumps(di, indent=2), encoding='utf8')
    np.savez_compressed(a.out/'scattered_fields.npz', wavelength_um=w,
                        harmonics=np.arange(-a.order, a.order+1), **{k: np.array(v) for k, v in vals.items()})
    deps = [Path(__file__), Path(old.__file__), ROOT/'experiments/q2_gap_optics.py',
            old.SOURCE4, old.SOURCE0, old.GEOMFILE, LOSS_SOURCE]
    result = {'scope': __doc__, 'elapsed_seconds': time.perf_counter()-tic, 'wavelength_count': len(w),
              'support_um_each_of_four': a.support, 'thermal_Al2O3_um_each_side': a.barrier,
              'main_optical_material_layers': 14 if a.barrier else 12, 'air_gap_um': 2.,
              'midpoint_distance_um': g['E7_d_um']/2+g['5CB_d_um']/2+2*a.support+.099+.030+2+a.barrier,
              'receiver_distance_from_second_cell_exit_um': 40000., 'loss_case': a.loss,
              'loss_factors_cold_e_o_hot': LOSS_FACTORS[a.loss], 'covered_loss_intervals_um': LOSS_INTERVALS,
              'loss_interpolation': 'Independently interpolate the two source segments; no interpolation across the unresolved peak.',
              'order': a.order, 'nz': a.nz, 'fourier_samples': 128, 'geometry': g, 'diagnostics': di,
              'complete_device_pass': False,
              'limits': ['Uncovered 5CB wavelengths, E7 and plot-clipped peak retain frozen k=0; not measured zero.',
                         'Apparent isotropic 50C source loss transferred to both source temperatures; unchanged Cauchy n is not a globally causal KK fit.',
                         'Al2O3_Franta optical proxy is not evidence of continuous solvent barrier on dense PEI.',
                         'Director, same-formulation anchoring, low-frequency permittivity and thermal reset conditions remain.',
                         'Finite Gaussian/post/receiver projection is separate; unknown transparent posts and seals are not certified.',
                         'Support thickness changes all four Maxwell layers. No fixed midpoint approximation is used.',
                         'Reference nominal-index B only; pointwise index A and strict decoupling are not claimed.'],
              'hashes_sha256': {str(q.relative_to(ROOT)): hashlib.sha256(q.read_bytes()).hexdigest() for q in deps}}
    (a.out/'results.json').write_text(json.dumps(result, indent=2), encoding='utf8')
    (a.out/'source.py').write_bytes(Path(__file__).read_bytes())


if __name__ == '__main__':
    main()
