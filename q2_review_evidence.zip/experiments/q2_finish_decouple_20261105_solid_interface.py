"""ONE fixed all-solid counterpart; no thickness, bias, or source scan.

Replace internal air2um by Franta Al2O3 1.8um. The adjacent exit AR83nm
and passive entrance Al8um merge into9.883028893um. Physical passive plate
is9.8um oxide-bonded to the exit AR; old standoff removed, no retained glue.
"""
import os
for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='1'
from pathlib import Path
import sys,json,hashlib,argparse,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments import q2_finish_decouple_20261105_source25_phase855 as matched
from experiments import q2_closure_coupling as coupled
base=matched.base
AIR='gap=coupled.uniform_layer(1.,2.,float(lam),lam*qx,lam*qy)'
SOLID="gap=coupled.uniform_layer(complex(old.index('Al2O3_Franta',np.array([lam]))[0]),1.8,float(lam),lam*qx,lam*qy)"
assert matched.source.count(AIR)==1
source=matched.source.replace(AIR,SOLID)
assert source.count(SOLID)==1 and AIR not in source
exec(source,base.__dict__)
FIELDS=ROOT/'runs/20261105-q2-finish-assembly-phase25-d8p55-source64-01'
FIELD_SHA='d281beb19c1504927f336eaac1dd74231ccd7d711903fb167ee0195d4e587e7e'
ZN=ROOT/'runs/20261105-q2-finish-material-ZnO-hires-input-01/ZnO2022_Fig5d_hires_exactnodes_tail_linear_scenario.csv'
ZN_SHA='2504682932f858210bcb30b01d8d7d2b27208af0df143cb2adbcca9899c0b18e'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def provenance():
 assert sha(FIELDS/'fields.npz')==FIELD_SHA and sha(ZN)==ZN_SHA
 params=json.loads((FIELDS/'results.json').read_text())['parameters']
 assert params['temperatures_C']==[25,50] and params['thermal_d_um']==8.55 and params['fixed_external_V_RMS']==[0,9.235]
 dependencies=[Path(__file__).resolve(),Path(matched.__file__),Path(matched.pilot.__file__),Path(matched.pilot.ar.__file__),Path(matched.pilot.ar.ext.__file__),Path(matched.pilot.ar.ext.adapter.__file__),Path(base.__file__),matched.EFFECTIVE,Path(coupled.__file__),Path(coupled.model.__file__),Path(coupled.model.old.__file__)]
 data=[FIELDS/'fields.npz',FIELDS/'results.json',ZN,ROOT/'data/nk/Al2O3_Franta.csv',ROOT/'data/q2_current/Li2005_E7_Cauchy.csv',ROOT/'data/q2_finish_material_20261105/SiNx_spectrum/DLC_4keV_vector_digitized.csv',ROOT/'data/q2_parallel_loss_20261105/Wu2002_E7_graph_alpha_k.csv']
 config={'time_unix':time.time(),'argv':sys.argv,'source_sha256':{str(f.relative_to(ROOT)):sha(f)for f in dependencies},'input_sha256':{str(f.relative_to(ROOT)):sha(f)for f in data},'effective_source_sha256':hashlib.sha256(source.encode()).hexdigest(),'temperatures_C':[25,50],'main_path_layers':19,'physical_supports':5,'merged_optical_material_layers':18,'computational_retained_segments':20,'fixed_terminal_voltage_V':9.235,'drive_LC_um':2.5,'passive_LC_um':2.5,'thermal_LC_um':8.55,'electric_period_um':12.,'thermal_period_um':24.,'internal_air_gap_um':0.,'solid_replacement_um':1.8,'AR_each_um':matched.pilot.ar.thickness,'passive_entrance_plate_um':9.8,'contiguous_Al2O3_block_um':matched.pilot.ar.thickness+1.8+8.,'physical_interface':'One passive entrance Al2O3 plate9.8um oxide-bonded to existing driver exit AR83.028893nm; old intermodule standoff removed; no adhesive, void, or extra retained film. Contacts/fill tabs outside or notched from overlap; bond before filling.','field_invariance':'Exact same frozen64x33 LC arrays and ideal terminal Dirichlet Gauss boundaries as air d8.55 source.','screen_reference':'Unchanged original tilted carbon screen, z0=10000um measured from FINAL thermal Al2O3 exit face; original inner600/700 masks.','comparison_scope':'Only internal2um air replaced by1.8um same-source complex Al2O3. No thickness/voltage/source/window scan. External incident and final-exit air remain environmental.','conditions':params.get('model_conditions',[]) + ['Constitutive K(T),epsilon_perp(T), finite anchoring and anisotropic loss remain conditional; same source/process transfers retained.','Ideal direct oxide bond is an optical interface control, not evidence of flatness, process yield, or a mechanical tolerance certificate.','Existing five8um-plate bow results cannot certify the changed9.8um plate.','Finite envelope/Fresnel and periodic-vector approximation remain; no fullA/manufacturing/strict-decoupling declaration.']}
 assert config['contiguous_Al2O3_block_um']<10
 return config,dependencies,data
def main():
 p=argparse.ArgumentParser();p.add_argument('action',choices=['merge','optics']);p.add_argument('--out',type=Path,required=True);p.add_argument('--audit',type=Path);p.add_argument('--shards',type=int,default=2);p.add_argument('--shard',type=int,default=0);a=p.parse_args();a.out=a.out.resolve()
 config,deps,data=provenance();a.out.mkdir(parents=True,exist_ok=False)
 (a.out/'launch.json').write_text(json.dumps(config,indent=2));(a.out/'effective_optics_source.py').write_text(source)
 for f in deps:(a.out/('dependency_'+f.name)).write_bytes(f.read_bytes())
 if a.action=='merge':
  m=np.arange(-4,5);mx,my=np.meshgrid(m,m,indexing='xy');qx,qy=mx.ravel()/24,my.ravel()/48
  waves=np.unique(np.r_[np.linspace(.4,.78,41),np.linspace(.78,2.5,87)]);rows=[]
  for lam in waves:
   n=complex(coupled.model.old.index('Al2O3_Franta',np.array([lam]))[0]);segments=[coupled.uniform_layer(n,d,float(lam),lam*qx,lam*qy)for d in [config['AR_each_um'],1.8,8.]]
   first,r1=coupled.cascade(segments[0],segments[1]);joined,r2=coupled.cascade(first,segments[2]);merged=coupled.uniform_layer(n,config['contiguous_Al2O3_block_um'],float(lam),lam*qx,lam*qy)
   rows.append({'wavelength_um':float(lam),'n_real':n.real,'k':n.imag,'max_complex_block_error':[float(np.max(abs(u-v)))for u,v in zip(joined,merged)],'cascade_residual':max(r1,r2)})
  result={'scope':'All127actualpilotwavelengths, all81Floquetmodes/bothpolarizations, fourcomplexscatteringblocks; identicalAl2O3three-segmentvsmergedslab. Air-basis algebraic cuts do not add physical air.','contiguous_Al2O3_um':config['contiguous_Al2O3_block_um'],'max_complex_scattering_error':max(max(x['max_complex_block_error'])for x in rows),'max_cascade_residual':max(x['cascade_residual']for x in rows),'rows':rows,'identity':config}
  result['passed']=result['max_complex_scattering_error']<1e-10;assert result['passed'];(a.out/'results.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items()if k not in ['rows','identity']}))
 else:
  assert a.audit is not None
  audit=json.loads((a.audit/'results.json').read_text());assert audit['passed']and audit['identity']['effective_source_sha256']==config['effective_source_sha256']and audit['identity']['input_sha256']==config['input_sha256']
  config['merge_audit_sha256']=sha(a.audit/'results.json');config['merge_audit_path']=str(a.audit.resolve().relative_to(ROOT));(a.out/'launch.json').write_text(json.dumps(config,indent=2))
  a.fields=FIELDS;a.d=2.5;a.bias=9.235;a.order=4;a.slices=32;a.dense=True;a.grid=None;base.optics(a)
  r=json.loads((a.out/'results.json').read_text());r['physical_override']=config;r['temperatures_C']=[25,50];r['thermal_LC_um']=8.55;r['scope']='ONE fixed all-solid d8.55/source25/9.235V/correctedZnO four-state pilot';r['limits']=config['conditions'];(a.out/'results.json').write_text(json.dumps(r,indent=2))
 (a.out/'optical_postflight.json').write_text(json.dumps({'all_input_hashes_match':all(sha(f)==config['input_sha256'][str(f.relative_to(ROOT))]for f in data),'all_declared_dependency_hashes_match':all(sha(f)==config['source_sha256'][str(f.relative_to(ROOT))]for f in deps)},indent=2))
if __name__=='__main__':main()
