"""Three-PEI shared-plate dual-cavity Q2 construction, 13 physical material layers.

The shared 8um plate is factored into two adjacent 4um computational segments.
The air eigenbasis at that zero-distance cut is only a coordinate basis; exact
scattering composition cancels the artificial interfaces, with no physical air.
The two existing LC director fields are conditional prescribed inputs.
"""
import os
for key in ['OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'OMP_NUM_THREADS']:
    os.environ[key] = '1'
from pathlib import Path
import argparse, hashlib, json, sys, time
import numpy as np
from scipy.linalg import expm
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from experiments import q2_solid_vector_device as solid
old = solid.old


def physical_layers(g):
    return [
        {'material': 'PEI', 'd_um': 8., 'function': 'upper outer support'},
        {'material': 'IOH', 'd_um': .099, 'function': 'upper E7 electrode'},
        {'material': 'SD1/SDA2', 'd_um': .015, 'function': 'E7 x-pattern alignment'},
        {'material': 'E7', 'd_um': g['E7_d_um'], 'function': 'voltage cavity'},
        {'material': 'SD1/SDA2', 'd_um': .015, 'function': 'E7 x-pattern alignment'},
        {'material': 'IOH', 'd_um': .099, 'function': 'shared-plate E7-side electrode'},
        {'material': 'PEI', 'd_um': 8., 'function': 'single shared middle support'},
        {'material': 'Al2O3', 'd_um': .05, 'function': 'shared-plate thermal-side protective-film scenario'},
        {'material': 'SD1/SDA2', 'd_um': .015, 'function': '5CB y-pattern alignment'},
        {'material': '5CB', 'd_um': g['5CB_d_um'], 'function': 'temperature cavity'},
        {'material': 'SD1/SDA2', 'd_um': .015, 'function': '5CB y-pattern alignment'},
        {'material': 'Al2O3', 'd_um': .05, 'function': 'lower thermal protective-film scenario'},
        {'material': 'PEI', 'd_um': 8., 'function': 'lower outer support'},
    ]


def cell(mat, V, ti, lam, g, m, nz, shared=True, uniform=False, interface=None):
    theta, phi, easy = solid.director(mat, V, 128, nz)
    if uniform:
        theta, phi, easy = theta*0, phi*0, easy*0
    temp = [29.9, 36.1][ti]
    if mat == 'E7':
        tab = solid.e7_table()
        co = [np.interp(temp, tab[:, 0], tab[:, j]) for j in range(1, 7)]
        ne, no = [complex(old.cauchy(np.array(lam), v)) for v in [co[:3], co[3:]]]
    else:
        row = next(r for r in old.CB['rows'] if r['T_C_text'] == temp)
        ne, no = [complex(old.cauchy(np.array(lam), row[s]))+1j*solid.apparent_k(lam) for s in ['e', 'o']]
    pei = complex(old.index('PEI_Zhang', np.array([lam]))[0])
    coat = (complex(old.load(old.OLD/'data/q2_device/IOH216_digitized.csv', np.array([lam]))[0])
            if mat == 'E7' else complex(old.index('Al2O3_Franta', np.array([lam]))[0]))
    coat_d = .099 if mat == 'E7' else .05
    al = [complex(old.lorentz(np.array(lam), old.ALIGNMENT['parameters_post_UV'][s])) for s in ['e', 'o']]
    align_d = .015
    if interface is not None:
        al = [complex(interface['n'], interface['k'])]*2
        align_d = interface['d_um']
    iso = lambda n: old.dielectric(n, n, easy*0, easy*0)
    front, back = ((8., 4.) if mat == 'E7' else (4., 8.)) if shared else (8., 8.)
    align = old.dielectric(*al, easy*0, easy)
    coating = [(iso(coat), coat_d)] if mat == 'E7' or interface is None else []
    layers = [(iso(pei), front)] + coating + [(align, align_d)]
    layers += [(old.dielectric(ne, no, theta[:, iz], phi[:, iz]), g[mat+'_d_um']/nz) for iz in range(nz)]
    layers += [(align, align_d)] + coating + [(iso(pei), back)]
    N = len(m)
    S = [np.zeros((2*N*N, 2*N*N), complex) for _ in range(4)]
    condition = 0.
    for fixedindex, mf in enumerate(m):
        if mat == 'E7':
            qx, qy = lam*m/(2*g['E7_period_um']), np.full(N, lam*mf/(2*g['5CB_period_um']))
            idx = np.arange(N)+fixedindex*N
        else:
            qx, qy = np.full(N, lam*mf/(2*g['E7_period_um'])), lam*m/(2*g['5CB_period_um'])
            idx = np.arange(N)*N+fixedindex
        M = np.eye(4*N, dtype=complex)
        for ep, dd in layers:
            M = expm(2j*np.pi/lam*dd*old.generator(ep, np.diag(qx), np.diag(qy), m))@M
        local = old.to_scattering(M, old.admittance(qx, qy))
        idx = np.r_[idx, idx+N*N]
        for a, b in zip(S, local):
            a[np.ix_(idx, idx)] = b
        condition = max(condition, float(np.linalg.cond(M)))
    return S, condition


def device(lam, g, order=4, nz=32, shared=True, uniform=False):
    m = np.arange(-order, order+1)
    N = len(m)
    mx, my = np.meshgrid(m, m, indexing='xy')
    qx, qy = lam*mx.ravel()/(2*g['E7_period_um']), lam*my.ravel()/(2*g['5CB_period_um'])
    Y = old.admittance(qx, qy)
    gap = 0. if shared else 2.
    phase = np.tile(np.exp(2j*np.pi/lam*gap*np.sqrt(1-qx*qx-qy*qy+0j)), 2)
    src = np.zeros((2*N*N, 2))
    src[order*N+order, 0], src[N*N+order*N+order, 1] = 1, 1
    states, di = {}, []
    for ti in range(2):
        c, cc = cell('5CB', 0, ti, lam, g, m, nz, shared, uniform)
        for vi, V in enumerate([0, 4]):
            e, ce = cell('E7', V, ti, lam, g, m, nz, shared, uniform)
            rt = e[1]@(phase[:, None]*c[0]*phase[None, :])
            a = np.linalg.solve(np.eye(2*N*N)-rt, e[2]@src)
            out = c[2]@(phase[:, None]*a)
            back = e[0]@src+e[3]@(phase[:, None]*(c[0]@(phase[:, None]*a)))
            Tout = float(np.real(np.sum(out.conj()*(Y@out)))/2)
            Rout = float(np.real(np.sum(back.conj()*(Y@back)))/2)
            for label, field in [('E', out), ('G', Y@out)]:
                states[f'V{vi}T{ti}__{label}'] = np.stack([field[:N*N], field[N*N:]], axis=1).reshape(N, N, 2, 2)
            di.append({'V': V, 'T_index': ti, 'T': Tout, 'R': Rout, 'A': 1-Tout-Rout,
                       'cell_transfer_condition_max': max(ce, cc),
                       'cavity_residual_inf': float(abs((np.eye(2*N*N)-rt)@a-e[2]@src).max())})
    return states, di


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--grid', type=Path)
    p.add_argument('--wavelengths', default='.4,.55,.78,1.25,2,2.5')
    p.add_argument('--inverse-grid', type=int)
    p.add_argument('--separate-control', action='store_true')
    p.add_argument('--shard', type=int, default=0)
    p.add_argument('--shards', type=int, default=1)
    a = p.parse_args()
    a.out.mkdir(parents=True, exist_ok=False)
    g = json.loads(old.GEOMFILE.read_text())['selected']
    if a.grid:
        w = np.load(a.grid)['wavelength_um']
    elif a.inverse_grid:
        w = np.unique(np.r_[1/np.linspace(1/2.5, 1/.4, a.inverse_grid), .4, .78, 2.5,
                            1.105-1e-8, 1.105, 2.435, 2.435+1e-8, 2.48-1e-8, 2.48])
    else:
        w = np.array([float(x) for x in a.wavelengths.split(',')])
    w = w[a.shard::a.shards]
    vals, di = {}, []
    tic = time.perf_counter()
    for lam in w:
        s, d = device(float(lam), g, shared=not a.separate_control)
        for key, val in s.items():
            vals.setdefault(key, []).append(val)
        di.append({'lambda_um': float(lam), 'states': d})
        print(json.dumps({'done': len(di), 'total': len(w), 'lambda_um': float(lam),
                          'elapsed_s': time.perf_counter()-tic}), flush=True)
    np.savez_compressed(a.out/'scattered_fields.npz', wavelength_um=w, harmonics=np.arange(-4, 5),
                        **{key: np.array(val) for key, val in vals.items()})
    result = {'scope': __doc__, 'shared_plate': not a.separate_control, 'geometry': g,
              'physical_layer_sequence': physical_layers(g) if not a.separate_control else None,
              'physical_layer_count': 13 if not a.separate_control else 14,
              'PEI_piece_count': 3 if not a.separate_control else 4,
              'removed_from_previous_construction': ['one 8um PEI sheet', '2um free air gap', 'independent alignment of two completed cells'] if not a.separate_control else [],
              'midpoint_distance_um': g['E7_d_um']/2+g['5CB_d_um']/2+.099+.030+.05+(8 if not a.separate_control else 18),
              'air_gap_um': 0 if not a.separate_control else 2,
              'receiver_distance_after_exit_um': 40000., 'order': 4, 'nz': 32,
              'wavelength_count': len(w), 'elapsed_seconds': time.perf_counter()-tic, 'diagnostics': di,
              'loss_case': 'isotropic covered-interval source transfer', 'covered_5CB_k_um': solid.LOSS_INTERVALS,
              'conditions': ['Existing E7/5CB 2D director fields are prescribed, conditional on unchanged LC-facing alignment chemistry, registration, anchoring and gaps.',
                             'The E7 electrode/alignment/LC interior is unchanged, so its electrostatic boundary model is inherited at fixed flat geometry.',
                             'Shared-plate force balance and opposite-face processing can change both cavity gaps/anchoring; those are not solved by this optical calculation.',
                             'Three physical PEI sheets; the middle 4+4um mathematical split does not create a physical interface or extra layer.',
                             'Same finite-Gaussian/post receiver envelope only for comparison; lead separately assesses no-internal-post apertures.',
                             'Original partial-k, Cauchy dispersion, material-transfer, B-reference and thermal-reset conditions remain; strict A and complete fabrication are not asserted.'],
              'complete_device_pass': False}
    deps = [Path(__file__), Path(solid.__file__), Path(old.__file__), old.SOURCE4, old.SOURCE0, old.GEOMFILE, solid.LOSS_SOURCE]
    result['hashes_sha256'] = {str(q.relative_to(ROOT)): hashlib.sha256(q.read_bytes()).hexdigest() for q in deps}
    (a.out/'results.json').write_text(json.dumps(result, indent=2), encoding='utf8')
    (a.out/'source.py').write_bytes(Path(__file__).read_bytes())


if __name__ == '__main__':
    main()
