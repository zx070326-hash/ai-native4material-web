"""Two-angle Frank minimum with a freshly solved 2D anisotropic Gauss problem.

The voltage Legendre energy is differentiated at stationary potential (envelope
theorem); the potential is never minimized jointly with the director. Periodic
two-period Q1 mesh, 2x2 Gauss integration, two explicit alignment dielectrics.
"""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import sys,argparse,json,time,hashlib
import numpy as np
import autograd.numpy as anp
from autograd import value_and_grad
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve
from scipy.optimize import minimize
from scipy.interpolate import RegularGridInterpolator
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments.q2_manufacturing_lc_director2d import problem,initial
from experiments.q2_manufacturing_lc_director import SOURCE,EPS0


class Electric:
    def __init__(self,d,period,K,nx,nz,V,epsa=3,ep=5.2,de=13.8):
        self.nx,self.nz,self.V=nx,nz,V;self.A=2*period/d;self.dx=self.A/nx;self.K=K*1e-12
        self.ep,self.de,self.epsa=ep,de,epsa
        self.z=np.r_[-.015/d,np.linspace(0,1,nz),1+.015/d];self.dz=np.diff(self.z)
        self.x=np.arange(nx)[:,None];self.np=nz+2
        node=np.arange(nx*(nz+2)).reshape(nx,nz+2)
        self.conn=np.stack([node[:,:-1],np.roll(node,-1,axis=0)[:,:-1],node[:,1:],np.roll(node,-1,axis=0)[:,1:]],-1)
        self.ii=np.broadcast_to(self.conn[...,None],(*self.conn.shape,4)).ravel()
        self.jj=np.broadcast_to(self.conn[...,None,:],(*self.conn.shape,4)).ravel()
        self.free=node[:,1:-1].ravel();self.bound=node[:,[0,-1]].ravel();self.val=np.tile([0,V],nx)
        self.g=[.5-.5/np.sqrt(3),.5+.5/np.sqrt(3)];self.basis=[]
        for a in self.g:
            for b in self.g:
                bx=np.array([-(1-b),1-b,-b,b])/self.dx
                bz=np.array([-(1-a),-a,1-a,a])[None,:]/self.dz[:,None]
                self.basis.append((a,b,bx,bz))
        self.evg=value_and_grad(self.negative_at_fixed_potential)

    def eps(self,v,a,b):
        t=anp.reshape(v[:self.nx*self.nz],(self.nx,self.nz));u=anp.reshape(v[self.nx*self.nz:],(self.nx,self.nz))
        def mid(f):return (1-a)*(1-b)*f[:,:-1]+a*(1-b)*anp.roll(f,-1,0)[:,:-1]+(1-a)*b*f[:,1:]+a*b*anp.roll(f,-1,0)[:,1:]
        th=mid(t);ph=2*np.pi*(self.x+a)/self.nx+mid(u)
        xx=anp.cos(th)*anp.cos(ph);zz=anp.sin(th)
        return self.ep+self.de*xx*xx,self.de*xx*zz,self.ep+self.de*zz*zz

    def solve(self,v):
        ke=np.zeros((self.nx,self.nz+1,4,4));tensors=[]
        for a,b,bx,bz in self.basis:
            ex,ec,ez=self.eps(v,a,b);ex=np.pad(ex,((0,0),(1,1)),constant_values=self.epsa);ez=np.pad(ez,((0,0),(1,1)),constant_values=self.epsa);ec=np.pad(ec,((0,0),(1,1)))
            tensors.append((ex,ec,ez))
            ke+=(ex[...,None,None]*bx[None,None,:,None]*bx[None,None,None,:]+ec[...,None,None]*(bx[None,None,:,None]*bz[None,:,None,:]+bz[None,:,:,None]*bx[None,None,None,:])+ez[...,None,None]*bz[None,:,:,None]*bz[None,:,None,:])*(self.dx*self.dz[None,:,None,None]/4)
        mat=coo_matrix((ke.ravel(),(self.ii,self.jj)),shape=(self.nx*self.np,)*2).tocsr()
        psi=np.zeros(self.nx*self.np);psi[self.bound]=self.val
        rhs=-(mat[self.free][:,self.bound]@self.val);psi[self.free]=spsolve(mat[self.free][:,self.free],rhs)
        p=psi[self.conn];grads=[];integral=0
        for (_,_,bx,bz),(ex,ec,ez) in zip(self.basis,tensors):
            gx=np.sum(p*bx,axis=-1);gz=np.sum(p*bz[None],axis=-1);grads.append((gx[:,1:-1],gz[:,1:-1]))
            integral+=np.sum((ex*gx*gx+2*ec*gx*gz+ez*gz*gz)*self.dx*self.dz[None,:]/4)
        residual=mat@psi
        check={'Gauss_free_residual_inf':float(abs(residual[self.free]).max()),'electrode_charge_balance_abs':float(abs(residual[self.bound].sum())),
               'positive_electric_dimensionless':float(EPS0/self.K/(2*self.A)*integral),
               'electrostatic_energy_vs_terminal_charge_abs':float(abs(integral-psi@residual)),
               'LC_Ex_over_Ez_rms':float(np.sqrt(sum(np.sum(q[0]**2)for q in grads)/sum(np.sum(q[1]**2)for q in grads)))if self.V else 0}
        return grads,psi.reshape(self.nx,self.np),check

    def negative_at_fixed_potential(self,v,grads):
        val=0.
        for (a,b,_,_),(gx,gz)in zip(self.basis,grads):
            ex,ec,ez=self.eps(v,a,b)
            val-=EPS0/self.K/8*anp.mean(ex*gx*gx+2*ec*gx*gz+ez*gz*gz)
        return val


def validation():
    e=Electric(1.2,12,11.1,16,9,4);v=initial(16,9,'linear_phi');gr,p,c=e.solve(v)
    denom=1/5.2+2*.015/1.2/3;exact=EPS0/(11.1e-12)*16/(2*denom)
    v=initial(16,9,'perturbed');gr,p,c2=e.solve(v);_,grad=e.evg(v,gr)
    rng=np.random.default_rng(721);direction=rng.normal(size=len(v));direction/=np.linalg.norm(direction);h=1e-5
    def energy(q):return -e.solve(q)[2]['positive_electric_dimensionless']
    fd=(energy(v+h*direction)-energy(v-h*direction))/(2*h)
    return {'series_capacitor_energy_abs_error':abs(c['positive_electric_dimensionless']-exact),
            'envelope_gradient_directional':float(grad@direction),'fresh_Gauss_finite_difference':fd,'gradient_abs_error':abs(fd-grad@direction),**c2}


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,required=True);p.add_argument('--nx',type=int,default=64);p.add_argument('--nz',type=int,default=33);p.add_argument('--maxiter',type=int,default=3000);p.add_argument('--seeds',default='tilted,negative');p.add_argument('--epsa',type=float,default=3);p.add_argument('--warm',type=Path)
    a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False);g=json.loads((ROOT/'runs/20261102-q2-manufacturing-dual-lc-port-02/results.json').read_text())['selected']
    f,parts,meta=problem(g['E7_d_um'],g['E7_period_um'],SOURCE['E7_elastic_dielectric']['K_pN'],a.nx,a.nz)
    ev=Electric(g['E7_d_um'],g['E7_period_um'],11.1,a.nx,a.nz,4,a.epsa);fvg=value_and_grad(f)
    def fg(v):
        gr,psi,ck=ev.solve(v);fr,grad=fvg(v);_,eg=ev.evg(v,gr)
        return float(fr-ck['positive_electric_dimensionless']),grad+eg
    check=validation();print(json.dumps({'validation':check}),flush=True);rows=[];arrays={};tic=time.perf_counter()
    for seed in a.seeds.split(','):
        v=initial(a.nx,a.nz,'perturbed');z=np.linspace(0,1,a.nz)[None,:];x=2*np.pi*np.arange(a.nx)[:,None]/a.nx
        if a.warm:
            dat=np.load(a.warm);nt=dat[seed+'__theta_rad'];nu=dat[seed+'__phi_correction_rad'];xx,zz=np.meshgrid(np.arange(a.nx)/a.nx,np.linspace(0,1,a.nz),indexing='ij');pts=np.stack([xx,zz],-1)
            def interp(q):return RegularGridInterpolator((np.linspace(0,1,len(q)+1),np.linspace(0,1,q.shape[1])),np.r_[q,q[:1]])(pts)
            v=np.r_[interp(nt).ravel(),interp(nu).ravel()]
        else:
            sign=-1 if seed=='negative'else 1
            theta=sign*(1.35*np.sin(np.pi*z)+.03)*np.ones_like(x)
            if seed=='weak':theta=.05*np.sin(np.pi*z)*np.cos(x)+.03*np.sin(np.pi*z)
            v[:a.nx*a.nz]=theta.ravel()
        init=fg(v)[0];counter=[0]
        def cb(v):
            counter[0]+=1
            if counter[0]%100==0:print(json.dumps({'seed':seed,'iteration':counter[0],'seconds':time.perf_counter()-tic}),flush=True)
        sol=minimize(fg,v,jac=True,method='L-BFGS-B',bounds=[(-np.pi/2+1e-5,np.pi/2-1e-5)]*(a.nx*a.nz)+[(None,None)]*(a.nx*a.nz),callback=cb,options={'maxiter':a.maxiter,'maxls':40,'maxcor':40,'ftol':1e-13,'gtol':2e-8})
        theta=sol.x[:a.nx*a.nz].reshape(a.nx,a.nz);u=sol.x[a.nx*a.nz:].reshape(a.nx,a.nz);gr,psi,ck=ev.solve(sol.x);bulk,surf=parts(sol.x)
        arrays[seed+'__theta_rad']=theta;arrays[seed+'__phi_correction_rad']=u;arrays[seed+'__potential_V']=psi
        row={'seed':seed,**meta,'V_RMS':4,'alignment_eps_scenario':a.epsa,'energy_J_m2':float(sol.fun*meta['energy_unit_J_m2']),'initial_energy_J_m2':float(init*meta['energy_unit_J_m2']),
             'bulk_J_m2':float(bulk*meta['energy_unit_J_m2']),'anchoring_J_m2':float(surf*meta['energy_unit_J_m2']),'theta_midplane_deg_minmax':np.rad2deg([theta[:,a.nz//2].min(),theta[:,a.nz//2].max()]).tolist(),
             'phi_correction_absmax_deg':float(np.rad2deg(abs(u).max())),'gradient_inf':float(abs(sol.jac).max()),'iterations':sol.nit,'success':bool(sol.success),'message':str(sol.message),'electric_checks':ck,'elapsed_s':time.perf_counter()-tic}
        rows.append(row);print(json.dumps(row),flush=True);np.savez_compressed(a.out/'director_fields.npz',**arrays);(a.out/'partial_results.json').write_text(json.dumps(rows,indent=2),encoding='utf8')
    result={'scope':__doc__,'cases':rows,'validation':check,'geometry':g,'sources':SOURCE,'limits':['Same fixed smooth angular winding sector as zero-voltage run, not defect/global/3D stability.','Dielectric and Frank constants transferred from source room-temperature materials to both optical temperatures; alignment eps explicitly unmeasured scenario.','1kHz RMS dielectric equilibrium neglects ions, dissipation, frequency dispersion, electrode leads and thermal dynamics.','K24 omitted; finite anchoring assumed transferred; actual optical remapping required.'],'actual_complete_device_pass':False}
    result['hashes']={str(q.relative_to(ROOT)):hashlib.sha256(q.read_bytes()).hexdigest()for q in [Path(__file__),ROOT/'experiments/q2_manufacturing_lc_director2d.py']};(a.out/'results.json').write_text(json.dumps(result,indent=2),encoding='utf8');(a.out/'source.py').write_bytes(Path(__file__).read_bytes())

if __name__=='__main__':main()
