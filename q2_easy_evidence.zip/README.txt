python -X utf8 verify.py
python -X utf8 recompute.py
python -X utf8 independent_audit.py
Python3, NumPy2, SciPy, tmm0.2.0. The two calculations write NEW recomputed and independently_recomputed directories.
The independent characteristic-matrix audit imports neither src.optics nor recompute.py; path-only adaptations are supplied beside exact repository source snapshots.
This recomputes conditional optics, controls, and sensitivities, not actual common-voltage operation or fabrication.
All optical inputs are included; support and ion-layer proxies remain explicit.
