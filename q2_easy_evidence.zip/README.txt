python -X utf8 verify.py
python -X utf8 recompute.py
Python3, NumPy2, tmm0.2.0. Recompute writes a NEW recomputed directory.
This recomputes conditional optics, controls, and sensitivities, not actual common-voltage operation or fabrication.
All optical inputs are included; support and ion-layer proxies remain explicit.
