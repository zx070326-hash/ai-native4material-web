"""Q2 process-first validation, including negative specimen and process controls.

Keep the earlier split-region optical budget frozen. Examine phase averaging,
actual source-family dependence, four-state endpoint drift and process-simple
alternatives. All material and electrochemical transfers remain explicit.
"""
from pathlib import Path
import hashlib
import itertools
import json
import sys

import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from src.optics import stack_rt, band_mean, four_state_metrics

OUT = ROOT/'recomputed'
INPUTS = ROOT/'inputs'
BANDS = {'visible': (.38, .78), 'nir': (.78, 2.5)}


def main():
    OUT.mkdir(exist_ok=False)
    tables = {p.stem: np.loadtxt(p, delimiter=',', skiprows=1) for p in INPUTS.glob('*.csv')}
    exact_root = ROOT/'exact_ec'
    for k in ['WO3_clear', 'WO3_dark', 'NiO_clear', 'NiO_dark', 'ITO']:
        tables[k+'_exact'] = np.loadtxt(exact_root/(k+'_raw.csv'), delimiter=',', skiprows=1)
    native = np.concatenate([a[:, 0] for a in tables.values()])
    w = np.unique(np.r_[np.arange(380, 780.1, .5)/1000,
                        np.arange(780, 2500.1, .5)/1000,
                        native[(native >= .38) & (native <= 2.5)]])

    def nk(k):
        a = tables[k]
        assert w[0] >= a[0, 0]-1e-12 and w[-1] <= a[-1, 0]+1e-12
        return np.interp(w, a[:, 0], a[:, 1]) + 1j*np.interp(w, a[:, 0], a[:, 2])

    arrays = {k: nk(k) for k in tables}
    cap, ion, electrode = [arrays[k] for k in ['Al2O3_Franta', 'Ta2O5_Franta', 'ITO']]
    configs = {
        'frozen_Film4': dict(film=4, vo2=.11, tc_cap=.3, wo3=.49, ito=.5, ion=.3, f=.55),
        'sputter_family_Film1': dict(film=1, vo2=.069, tc_cap=.39, wo3=.49, ito=.3, ion=.2, f=.45),
        'sputter_family_Film1_thin_ITO': dict(film=1, vo2=.069, tc_cap=.39, wo3=.5, ito=.1, ion=.2, f=.43),
        'process_anchor_Dong2018_dimensions': dict(film=1, vo2=.069, tc_cap=.39, wo3=.5, ito=.3, ion=.2, f=.45, nio=.4),
        'shared_400nm_cap_round_recipe': dict(film=1, vo2=.07, tc_cap=.4, ec_cap=.4, wo3=.48, ito=.2, ion=.2, nio=.15, f=.44, raw_ec=True),
        'Dong_capacity_ratio_transfer_control': dict(film=1, vo2=.07, tc_cap=.4, ec_cap=.4, wo3=.48, ito=.2, ion=.2, nio=.4*(127/45)*(.48/.5), f=.44, raw_ec=True),
        'protected_two_pass_cap': dict(film=1, vo2=.07, tc_cap=.4, pre_cap=.02, ec_cap=.38, wo3=.48, ito=.2, ion=.2, nio=.15, f=.44, raw_ec=True)}

    def layers(c, state, thermal=False, n_mica=1.58, k_mica=0., mica=8.,
               film_scale=1., coat_scale=1., electrolyte_n=None, electrolyte_k=0.,
               ec_amplitude=1., hot_fraction=1.):
        support = np.full(len(w), n_mica+1j*k_mica)
        if thermal:
            cold = arrays[f'VO2_f{c["film"]}_30']
            hot = arrays[f'VO2_f{c["film"]}_100']
            # Endpoint-mixture sensitivity; not a calibrated phase law on mica.
            nvo = cold if state == 0 else np.sqrt(((1-hot_fraction)*cold**(2/3)+hot_fraction*hot**(2/3))**3)
            if 'pre_cap' in c:
                return np.array([support, nvo, cap, cap]), np.array([
                    mica, c['vo2']*film_scale, c['pre_cap'], (c['tc_cap']-c['pre_cap'])*coat_scale])
            return np.array([support, nvo, cap]), np.array([mica, c['vo2']*film_scale, c['tc_cap']*coat_scale])
        suffix = '_exact' if c.get('raw_ec') else ''
        wc, wd = arrays['WO3_clear'+suffix], arrays['WO3_dark'+suffix]
        nc, nd = arrays['NiO_clear'+suffix], arrays['NiO_dark'+suffix]
        el = arrays['ITO_exact'] if c.get('raw_ec') else electrode
        wn = wc if state == 0 else np.sqrt(wc**2+ec_amplitude*(wd**2-wc**2))
        nn = nc if state == 0 else np.sqrt(nc**2+ec_amplitude*(nd**2-nc**2))
        actual_ion = ion if electrolyte_n is None else np.full(len(w), electrolyte_n+1j*electrolyte_k)
        niod = c.get('nio', c['wo3']*68/219)
        return np.array([support, el, wn, actual_ion, nn, el, cap]), np.array([
            mica, c['ito']*coat_scale, c['wo3']*film_scale, c['ion'], niod*film_scale, c['ito']*coat_scale, c.get('ec_cap', .03)*coat_scale if 'ec_cap' in c else .03])

    def evaluate(c, coherence='coherent', angle=0., f=None, g=.02, ec_factors=(1., 1.), **kwargs):
        m, dm = kwargs.get('n_mica', 1.58), kwargs.get('mica', 8.)
        ee, hh, checks = [], [], []
        for thermal in [False, True]:
            states = []
            for s in range(2):
                ns, ds = layers(c, s, thermal, **kwargs)
                if coherence == 'coherent':
                    r, t, a = stack_rt(w, ns, ds, angle_deg=angle)
                else:
                    assert angle == 0. and kwargs.get('k_mica', 0.) == 0.
                    # Normal-incidence incoherent retained support, coherent
                    # functional coating. Reflection at support rear is retained.
                    rc, tc, _ = stack_rt(w, ns[1:], ds[1:], n_in=m, n_out=1.)
                    rf = ((1-m)/(1+m))**2
                    t = (1-rf)*tc/(1-rf*rc)
                    r = rf+(1-rf)**2*rc/(1-rf*rc)
                    a = 1-r-t
                states.append(t)
                checks.append([float(min(r.min(), t.min(), a.min())),
                               float(max(r.max(), t.max(), a.max()))])
            if thermal: hh = np.array(states)
            else: ee = np.array(states)
        ee = np.array([ee[0][None]+eta*(ee-ee[0][None]) for eta in ec_factors]).transpose(1, 0, 2)
        # The shared400nm cap covers the inactive strip as a real retained layer.
        gap_n = [np.full(len(w), m+1j*kwargs.get('k_mica', 0.))]
        gap_d = [dm]
        if 'ec_cap' in c:
            gap_n.append(cap)
            gap_d.append(c['ec_cap']*kwargs.get('coat_scale', 1.))
        gap = stack_rt(w, gap_n, gap_d, angle_deg=angle)[1]
        if coherence != 'coherent':
            rf = ((1-m)/(1+m))**2
            if 'ec_cap' in c:
                rc, tc, _ = stack_rt(w, [cap], [c['ec_cap']*kwargs.get('coat_scale', 1.)], n_in=m, n_out=1.)
                gap = (1-rf)*tc/(1-rf*rc)
            else:
                gap = np.full(len(w), (1-rf)/(1+rf))
        f = c['f'] if f is None else f
        joint = (1-g)*(f*ee+(1-f)*hh[None, :, :])+g*gap
        metrics = four_state_metrics(w, joint, BANDS)
        return metrics, joint, checks

    records, spectra = [], {}
    for name, c in configs.items():
        for coherence in ['coherent', 'incoherent_support']:
            met, t, checks = evaluate(c, coherence)
            records.append({'name': name, 'coherence': coherence, 'configuration': c,
                            'metrics': met, 'passive_extrema': checks})
            spectra[name+'_'+coherence] = t
    # Formula control against an independent mixed-coherence implementation.
    from tmm import inc_tmm
    error = []
    for name in ['frozen_Film4', 'sputter_family_Film1']:
        c = configs[name]
        for thermal, state in itertools.product([False, True], range(2)):
            ns, ds = layers(c, state, thermal)
            rc, tc, _ = stack_rt(w, ns[1:], ds[1:], n_in=1.58, n_out=1.)
            rf = ((1-1.58)/(1+1.58))**2
            tt = (1-rf)*tc/(1-rf*rc)
            rr = rf+(1-rf)**2*rc/(1-rf*rc)
            for lam in [.38, .55, .78, 1.34, 1.43, 2.5]:
                j = int(np.argmin(abs(w-lam)))
                z = inc_tmm('s', [1, *ns[:, j], 1], [np.inf, *ds, np.inf],
                             ['i', 'i']+['c']*(len(ds)-1)+['i'], 0., w[j])
                error += [abs(z['T']-tt[j]), abs(z['R']-rr[j])]
    assert max(error) < 1e-10

    sensitivity = []
    # Keep designs fixed, diagnose hypotheses that can overturn the budget.
    cases = [('nominal', {})]
    cases += [(f'angle_{a}', {'angle': a}) for a in [15., 30., 45., 60.]]
    cases += [(f'mica_k_{k}', {'k_mica': k}) for k in [1e-4, 1e-3]]
    cases += [(f'mica_n_{n}', {'n_mica': n}) for n in [1.55, 1.62]]
    cases += [(f'ion_n_{n}_k_{k}', {'electrolyte_n': n, 'electrolyte_k': k})
              for n, k in [(1.5, 0.), (1.8, 0.), (2.4, 0.), (2.8, 0.), (2.1, .01), (2.1, .05)]]
    cases += [(f'EC_hot_retention_{eta}', {'ec_factors': (1., eta)}) for eta in [.95, .9, .85, .8]]
    cases += [(f'VO2_hot_fraction_{eta}', {'hot_fraction': eta}) for eta in [.95, .9, .85, .8]]
    cases += [(f'dead_area_{g}', {'g': g}) for g in [.04, .06, .1]]
    for name in ['frozen_Film4', 'sputter_family_Film1', 'sputter_family_Film1_thin_ITO', 'shared_400nm_cap_round_recipe', 'protected_two_pass_cap']:
        for tag, kw in cases:
            met, _, checks = evaluate(configs[name], **kw)
            sensitivity.append({'name': name, 'case': tag, 'parameters': kw, 'summary': met['summary']})

    tolerance = []
    c = configs['protected_two_pass_cap']
    for fs, cs, nm, dm in itertools.product([.95, 1.05], [.95, 1.05], [1.55, 1.62], [5., 9.]):
        met, _, _ = evaluate(c, film_scale=fs, coat_scale=cs, n_mica=nm, mica=dm)
        tolerance.append({'name': 'protected_two_pass_cap', 'film_scale': fs, 'coating_scale': cs, 'mica_n': nm, 'mica_um': dm, 'summary': met['summary']})

    # Area feasibility at common temperatures must include EC-induced NIR
    # drift: it can cancel TC modulation in the colored state.
    def interval(summary, eta, f=.44, g=.02):
        a = summary['visible_voltage_delta_min']/((1-g)*f)
        b = summary['nir_temperature_delta_min']/((1-g)*(1-f))
        q = summary['nir_voltage_cross_max']/((1-g)*f)
        lo = .3/((1-g)*eta*a)
        hi = (b-.2/(1-g))/(b+(1-eta)*q)
        return lo, hi

    retention_intervals = []
    for eta in [1., .98, .95, .9]:
        spans = [interval(row['summary'], eta) for row in tolerance]
        lo, hi = max(x[0] for x in spans), min(x[1] for x in spans)
        retention_intervals.append({'hot_EC_contrast_retention': eta,
            'common_f_EC_lower_exclusive': lo, 'common_f_EC_upper_exclusive': hi,
            'common_interval_exists': bool(lo < hi),
            'fixed_f_EC0p44_all16_pass': bool(lo < .44 < hi)})

    # Common fixed-phase budget is not proof that those phases are reached at a
    # new temperature on a new substrate. This sensitivity uses no guessed Tc.
    bounds = []
    for row in records:
        met = row['metrics']['summary']
        dv, dt = met['visible_voltage_delta_min'], met['nir_temperature_delta_min']
        bounds.append({'name': row['name'], 'coherence': row['coherence'],
            'minimum_EC_contrast_retention_exclusive': .3/dv,
            'minimum_TC_contrast_retention_exclusive': .2/dt,
            'whole_aperture_VIS_opposing_drift_budget_pp': 100*(dv-.3),
            'whole_aperture_NIR_opposing_drift_budget_pp': 100*(dt-.2)})

    previous = json.loads((ROOT/'previous.json').read_text(encoding='utf-8'))
    base = records[0]['metrics']['summary']
    integration = {k: base[k]-previous['metrics']['summary'][k] for k in [
        'visible_voltage_delta_min', 'nir_temperature_delta_min', 'nir_voltage_cross_max', 'visible_temperature_cross_max']}
    result = {'scope': 'Q2 only: source/process controls and optical validation; no complete-device fabrication or common-voltage proof',
      'configs': configs, 'native_knots_and_half_nm_grid_count': len(w),
      'baseline_half_nm_minus_previous_1nm': integration,
      'mixed_coherence_formula_vs_tmm_max_RT_error': max(error),
      'records': records, 'sensitivity': sensitivity, 'sputter_design_16_scenarios': tolerance,
      'shared_cap_common_area_under_EC_thermal_drift': retention_intervals,
      'capacity_source_control': {
          'exact_LBNL_header_WO3_mC_cm2_per_um': 68.2,
          'exact_LBNL_header_LiNiO_mC_cm2_per_um': 219.,
          'HTML_header_note': 'The HTML labels mm^-1; linked raw files explicitly label um^-1. Use raw header for charge units, do not silently infer.',
          'new_480nm_WO3_charge_mC_cm2': .48*68.2,
          'new_150nm_LiNiO_charge_mC_cm2': .15*219,
          'Dong2018_measured_Q_C_m2': {'WO3_500nm': 127., 'NiO_400nm': 45.},
          'if_Dong_Q_scales_linearly_150nm_NiO_vs480nm_WO3_capacity_ratio': (45*(.15/.4))/(127*(.48/.5)),
          'NiO_um_for_matching_Dong_measured_capacity_ratio': .4*(127/45)*(.48/.5),
          'qualification': 'Different compounds, voltage windows and specimens: this is a transfer diagnostic, not an identified charge law for the proposed device. LBNL LiNiO endpoints cannot certify sputtered NiO operation.'},
      'retention_and_drift_budgets': bounds,
      'source_sha256': {**{p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in INPUTS.glob('*.csv')},
                       **{p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in exact_root.glob('*_raw.csv')}},
      'limits': ['EC factors scale spectral contrast only; not a physical voltage, ionic-diffusion or equilibrium model.',
       'Phase mixing is a fixed constitutive sensitivity with s=1/3, not a fitted transition on mica.',
       'NiO/WO3 source charge endpoints are not the working state spectra of Dong2018 device.',
       'Actual Dong2018 dimensions deliberately test the earlier capacity-ratio assumption; using different optical endpoints is still a process transfer.',
       'Mica and electrolyte remain proxies. Coherence/angle/loss/retention are finite diagnostics, not fabrication tolerances.',
       'Source Film1 is sputtered on Si; mica fabrication precedent narrows process choice but does not validate transferred n,k.',
       'Actual LiTaO3 optical/ionic response and common pair of applied voltages at both temperatures remain missing.'],
      'full_problem_solved': False, 'strict_A_known_failure_retained': True}
    (OUT/'results.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    np.savez_compressed(OUT/'spectra.npz', wavelength_um=w, **spectra)
    (OUT/'source.py').write_bytes(Path(__file__).read_bytes())
    print(json.dumps({'grid': len(w), 'integration_delta': integration, 'mixed_coherence_error': max(error),
      'nominals': [{'name': row['name'], 'coherence': row['coherence'], **row['metrics']['summary']} for row in records],
      'sputter_16_pass': sum(x['summary']['amplitude_thresholds_pass'] for x in tolerance)}))


if __name__ == '__main__':
    main()
