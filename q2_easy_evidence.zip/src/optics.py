"""Small replaceable optics workbench: passive planar films, n+ik, lengths in um.

Stable reflection/transmission recursion; incident and exit media are lossless.
No effective-medium, electrochemical, thermal balance, or fabrication model.
"""
from functools import lru_cache
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]


@lru_cache(maxsize=None)
def nk_table(material):
    table = np.loadtxt(ROOT / "data" / "nk" / f"{material}.csv", delimiter=",", skiprows=1)
    table.setflags(write=False)
    return table


def index(material, wavelength_um):
    w = np.asarray(wavelength_um, float)
    table = nk_table(material)
    if np.min(w) < table[0, 0]-1e-12 or np.max(w) > table[-1, 0]+1e-12:
        raise ValueError(f"{material}: requested range outside [{table[0,0]}, {table[-1,0]}] um")
    return np.interp(w, table[:,0], table[:,1]) + 1j*np.interp(w, table[:,0], table[:,2])


def stack_rt(wavelength_um, layer_n, thickness_um, angle_deg=0., polarization="unpolarized",
             n_in=1., n_out=1.):
    """Return R,T,A; thickness shape (L,) or (batch,L), n shape (L,wavelength).

    Supports isotropic passive films and propagating lossless boundary media.
    A is absorption in the finite layers only. Output is not clipped.
    """
    w = np.asarray(wavelength_um, float)
    d = np.asarray(thickness_um, float)
    single = d.ndim == 1
    d = np.atleast_2d(d)
    layers = np.asarray(layer_n, complex).reshape(-1, len(w))
    if d.ndim != 2 or layers.shape[0] != d.shape[1]:
        raise ValueError("index and thickness layer counts disagree")
    if not np.isfinite(d).all() or not np.isfinite(w).all() or np.any(d < 0) or np.any(w <= 0) or not 0 <= angle_deg < 90:
        raise ValueError("invalid wavelength, thickness, or angle")
    if not np.isfinite(layers).all() or np.any(layers.imag < -1e-12) or np.any(layers.real <= 0):
        raise ValueError("finite passive n+ik required")
    ni = np.broadcast_to(np.asarray(n_in, complex), w.shape)
    no = np.broadcast_to(np.asarray(n_out, complex), w.shape)
    if np.any(ni.imag != 0) or np.any(no.imag != 0) or np.any(ni.real <= 0) or np.any(no.real <= 0):
        raise ValueError("boundary media must be positive, real and lossless")
    n = np.vstack((ni, layers, no))
    transverse = ni*np.sin(np.deg2rad(angle_deg))
    kz = np.sqrt(n*n-transverse*transverse+0j)
    # Outgoing/passive branch. For the permitted materials this is principal sqrt.
    kz = np.where((kz.imag < 0) | ((kz.imag == 0) & (kz.real < 0)), -kz, kz)
    if np.any(kz[-1].real <= 0):
        raise ValueError("evanescent exit boundary unsupported in this small solver")

    def polarized(pol):
        q = kz if pol == "s" else n*n/kz
        r = np.broadcast_to((q[-2]-q[-1])/(q[-2]+q[-1]), (len(d),len(w))).copy()
        t = np.broadcast_to(2*q[-2]/(q[-2]+q[-1]), r.shape).copy()
        for i in range(len(n)-3, -1, -1):
            phase = np.exp(2j*np.pi*kz[i+1]*d[:,i,None]/w)
            ri = (q[i]-q[i+1])/(q[i]+q[i+1])
            ti = 2*q[i]/(q[i]+q[i+1])
            denominator = 1 + ri*r*phase*phase
            t = ti*t*phase/denominator
            r = (ri+r*phase*phase)/denominator
        R = np.abs(r)**2
        T = (q[-1].real/q[0].real)*np.abs(t)**2
        return R, T

    if polarization == "unpolarized":
        rs, ts = polarized("s")
        rp, tp = polarized("p")
        R, T = (rs+rp)/2, (ts+tp)/2
    elif polarization in ("s", "p"):
        R, T = polarized(polarization)
    else:
        raise ValueError("polarization must be s, p, or unpolarized")
    A = 1-R-T
    return tuple(x[0] if single else x for x in (R,T,A))


def band_mean(w, spectrum, band, weights=None):
    w, spectrum = np.asarray(w), np.asarray(spectrum)
    mask = (w >= band[0]-1e-12) & (w <= band[1]+1e-12)
    x = w[mask]
    if len(x) < 2 or abs(x[0]-band[0]) > 1e-9 or abs(x[-1]-band[1]) > 1e-9:
        raise ValueError(f"grid must contain exact band endpoints {band}")
    weight = np.ones_like(x) if weights is None else np.asarray(weights)[mask]
    return np.trapezoid(spectrum[...,mask]*weight, x=x, axis=-1)/np.trapezoid(weight, x=x)


def planck_weights(w, temperature_K=300.):
    w = np.asarray(w)
    return 1/(w**5*np.expm1(14387.768775/(w*temperature_K)))


def hemispherical_absorption(w, layer_n, thickness_um, quadrature=12):
    # Integral 2 int_0^1 A(arccos(mu)) mu dmu, unpolarized, air boundaries.
    nodes, weights = np.polynomial.legendre.leggauss(quadrature)
    mu, weights = (nodes+1)/2, weights/2
    answer = np.zeros(len(w))
    for m, weight in zip(mu, weights):
        a = stack_rt(w, layer_n, thickness_um, angle_deg=float(np.rad2deg(np.arccos(m))))[2]
        answer += 2*m*weight*a
    return answer


def four_state_metrics(w, transmissions, bands):
    """transmissions[V,temperature,wavelength], two settings for each control."""
    t = np.asarray(transmissions)
    if t.shape != (2,2,len(w)): raise ValueError("need all four V,temperature states")
    result = {}
    for name in ("visible", "nir"):
        mean = band_mean(w, t, bands[name])
        voltage = np.abs(mean[1,:]-mean[0,:])
        thermal = np.abs(mean[:,1]-mean[:,0])
        dv_spectral = band_mean(w, np.abs(t[1]-t[0]), bands[name])
        dt_spectral = band_mean(w, np.abs(t[:,1]-t[:,0]), bands[name])
        result[name] = {
            "T_by_voltage_temperature": mean.tolist(),
            "voltage_delta_by_temperature": voltage.tolist(),
            "temperature_delta_by_voltage": thermal.tolist(),
            "voltage_relative_delta": (voltage/np.maximum(np.max(mean,axis=0),1e-15)).tolist(),
            "temperature_relative_delta": (thermal/np.maximum(np.max(mean,axis=1),1e-15)).tolist(),
            "voltage_mean_abs_spectral_delta": dv_spectral.tolist(),
            "temperature_mean_abs_spectral_delta": dt_spectral.tolist(),
            "interaction_band_mean": float(mean[1,1]-mean[1,0]-mean[0,1]+mean[0,0]),
            "interaction_mean_abs_spectral": float(band_mean(w,np.abs(t[1,1]-t[1,0]-t[0,1]+t[0,0]),bands[name]))}
    dv = min(result["visible"]["voltage_delta_by_temperature"])
    dt = min(result["nir"]["temperature_delta_by_voltage"])
    cross_v = max(result["nir"]["voltage_delta_by_temperature"])
    cross_t = max(result["visible"]["temperature_delta_by_voltage"])
    result["summary"] = {"visible_voltage_delta_min": dv, "nir_temperature_delta_min": dt,
                         "nir_voltage_cross_max": cross_v, "visible_temperature_cross_max": cross_t,
                         "voltage_cross_over_main": cross_v/max(dv,1e-15),
                         "temperature_cross_over_main": cross_t/max(dt,1e-15),
                         "amplitude_thresholds_pass": bool(dv>0.3 and dt>0.2),
                         "decoupling_pass": None}
    return result


def material_range(material, bands):
    """Include native knots so a dense material resonance is not skipped."""
    table = nk_table(material)
    result = {}
    for name, (low, high) in bands.items():
        if low < table[0,0] or high > table[-1,0]:
            result[name] = {"covered": False, "index_in_1p5_to_3": None}
            continue
        native = table[(table[:,0] >= low) & (table[:,0] <= high),0]
        w = np.unique(np.r_[low, native, high])
        nk = index(material,w)
        result[name] = {"covered": True, "n_min": float(nk.real.min()),
                        "n_max": float(nk.real.max()), "k_max": float(nk.imag.max()),
                        "index_in_1p5_to_3": bool(np.all((nk.real>=1.5)&(nk.real<=3)))}
    return result


def layer_absorption(wavelength_um, layer_n, thickness_um, angle_deg=0., polarization="unpolarized"):
    """Absorbed power fraction per finite layer, via the independent tmm backend.

    Air ports, coherent planar isotropic layers; output shape (layer,wavelength).
    Use for shortlisted structures: the scalar reference calculation is slower.
    """
    from tmm import coh_tmm, absorp_in_each_layer
    w, nk, d = np.asarray(wavelength_um), np.asarray(layer_n), np.asarray(thickness_um)
    if nk.shape != (len(d), len(w)) or polarization not in ("s", "p", "unpolarized"):
        raise ValueError("invalid layer arrays or polarization")
    pols = ("s", "p") if polarization == "unpolarized" else (polarization,)
    result = np.zeros(nk.shape, dtype=float)
    for j, wavelength in enumerate(w):
        for pol in pols:
            solution = coh_tmm(pol, [1, *nk[:, j], 1], [np.inf, *d, np.inf],
                               np.deg2rad(angle_deg), wavelength)
            result[:, j] += absorp_in_each_layer(solution)[1:-1]/len(pols)
    return result
