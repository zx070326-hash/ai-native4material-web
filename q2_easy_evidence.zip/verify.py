from pathlib import Path
import json
import numpy as np
p=Path(__file__).resolve().parent
r=json.loads((p/'data.json').read_text(encoding='utf-8'))
a=np.loadtxt(p/'four_states.csv',delimiter=',',skiprows=1);w=a[:,0];t=a[:,1:].T.reshape(2,2,-1)
errors=[]
for name,(lo,hi) in {'visible':(.38,.78),'nir':(.78,2.5)}.items():
 m=(w>=lo)&(w<=hi)
 means=np.trapezoid(t[:,:,m],x=w[m],axis=-1)/(hi-lo)
 ref=r['chosen_conditional_configuration']['metrics'][name]['T_by_voltage_temperature']
 errors.append(float(abs(means-np.array(ref)).max()))
assert max(errors)<1e-12
x=np.loadtxt(p/'actual_mica_NIR_trace.csv',delimiter=',',skiprows=1)
d=float(np.trapezoid(x[:,1]-x[:,2],x=x[:,0])/(2.5-.78))
assert abs(d-r['actual_mica_specimen_trace']['NIR_mean_signed_thermal_delta'])<1e-12
print(json.dumps({'band_mean_max_error':max(errors),'primary_trace_error':abs(d-r['actual_mica_specimen_trace']['NIR_mean_signed_thermal_delta']),'fabrication_certified':False}))
