"""Bound untraced NIR edge contributions without assuming edge extrapolation."""
from pathlib import Path
import json
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
P = ROOT/'runs/20261106-q2-mica-primary-trace-01'
OUT = ROOT/'runs/20261106-q2-trace-edge-audit-02'

def main():
    OUT.mkdir(exist_ok=False)
    a = np.loadtxt(P/'native_pixel_trace.csv', delimiter=',', skiprows=1)
    old = json.loads((P/'results.json').read_text(encoding='utf-8'))
    x, delta = a[:,0], a[:,1]-a[:,2]
    missing = (x[0]-780)+(2500-x[-1])
    integral = float(np.trapezoid(delta,x=x))
    # Treat BOTH unknown edge intervals as arbitrary passive transmittances:
    # each phase's T is in[0,1], hence signed DeltaT in[-1,1].
    bounds = [(integral-missing)/1720, (integral+missing)/1720]
    # Combine this with each original vertical perturbation on the native
    # interior only. No claim about other tracing/calibration errors.
    vertical=[]
    for span in [-2,0,2]:
        for dc in [-2,2]:
            for dh in [-2,2]:
                d=.6*((a[:,5]+dh)-(a[:,4]+dc))/(215+span)
                v=float(np.trapezoid(d,x=x))
                vertical.extend([(v-missing)/1720,(v+missing)/1720])
    combined=[min(vertical),max(vertical)]
    r={
        'native_trace_range_nm': [float(x[0]),float(x[-1])],
        'untraced_width_nm': float(missing),
        'nominal_fixed_clamp_delta': old['NIR_mean_signed_thermal_delta'],
        'native_interior_integral_T_nm': integral,
        'arbitrary_passive_edge_signed_delta_bounds':bounds,
        'vertical_diagnostics_plus_arbitrary_passive_edges':combined,
        'old_45pct_TC_area_upper_diagnostic': .98*.45*combined[1],
        'old_area_failure_persists_under_this_diagnostic': bool(.98*.45*combined[1]<.2),
        'correction':'Original vertical diagnostics used fixed edge clamps; they did not include edge extrapolation uncertainty.',
        'limits':['Not a measurement confidence interval.',
                  'Does not include wavelength-axis calibration or pixel-selection ambiguity.',
                  'Does not transfer the120nm bare sample to the70nm capped candidate.']}
    (OUT/'results.json').write_text(json.dumps(r,indent=2),encoding='utf-8')
    (OUT/'source.py').write_bytes(Path(__file__).read_bytes())
    print(json.dumps(r))

if __name__=='__main__': main()
