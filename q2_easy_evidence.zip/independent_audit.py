"""Independent normal-incidence characteristic-matrix audit of the Q2 readout.

Does not import the project's optics kernel or validation entry. Rebuilds each
retained layer, endpoint table and area sum, checks both controls, and solves
the four-state linear area inequalities with scipy.linprog.
"""
from pathlib import Path
import hashlib
import itertools
import json

import numpy as np
from scipy.optimize import linprog

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT/'runs/20261106-q2-easy-validation-05'
OUT = ROOT/'independently_recomputed'


def main():
    OUT.mkdir(exist_ok=False)
    original = json.loads((ROOT/'data.json').read_text(encoding='utf-8'))['validation']
    checks = []
    for path, expected in original['source_sha256'].items():
        actual = hashlib.sha256((ROOT/('exact_ec/'+Path(path).name if str(path).startswith('data/') else 'inputs/'+Path(path).name)).read_bytes()).hexdigest()
        checks.append({'path': path, 'matches': actual == expected})
    assert all(x['matches'] for x in checks)

    saved = np.loadtxt(ROOT/'four_states.csv',delimiter=',',skiprows=1)
    w = saved[:,0]
    reference = saved[:,1:].T.reshape(2,2,-1)

    def load(path):
        a = np.loadtxt(ROOT/('exact_ec/'+Path(path).name if str(path).startswith('data/') else 'inputs/'+Path(path).name), delimiter=',', skiprows=1)
        assert w[0] >= a[0,0] and w[-1] <= a[-1,0]
        return np.interp(w,a[:,0],a[:,1])+1j*np.interp(w,a[:,0],a[:,2])

    prefix = 'data/q2_easy_fabrication_20261106/'
    ec = {k: load(prefix+k+'_raw.csv') for k in ['WO3_clear','WO3_dark','NiO_clear','NiO_dark','ITO']}
    cap = load('runs/20261106-q2-process-first-design-05/inputs/Al2O3_Franta.csv')
    ion = load('runs/20261106-q2-process-first-design-05/inputs/Ta2O5_Franta.csv')
    vo2 = [load('runs/20261106-q2-process-first-design-05/inputs/VO2_f1_'+str(temp)+'.csv') for temp in [30,100]]

    def characteristic(indices, thickness):
        # exp(-i omega t), passive n+ik; matrices map right fields to left.
        m = np.broadcast_to(np.eye(2,dtype=complex), (len(w),2,2)).copy()
        for n, d in zip(indices, thickness):
            phase = 2*np.pi*n*d/w
            cc, ss = np.cos(phase), np.sin(phase)
            layer = np.empty_like(m)
            layer[:,0,0] = layer[:,1,1] = cc
            layer[:,0,1] = -1j*ss/n
            layer[:,1,0] = -1j*ss*n
            m = m@layer
        den = m[:,0,0]+m[:,0,1]+m[:,1,0]+m[:,1,1]
        reflection = (m[:,0,0]+m[:,0,1]-m[:,1,0]-m[:,1,1])/den
        transmission = 2/den
        r, t = abs(reflection)**2, abs(transmission)**2
        return r,t,1-r-t

    def means(t):
        return np.array([np.trapezoid(t[...,mask],x=w[mask],axis=-1)/(hi-lo)
            for lo,hi in [(.38,.78),(.78,2.5)]
            for mask in [(w >= lo)&(w <= hi)]]).transpose(*range(1,t.ndim),0) if t.ndim > 1 else np.array([
                np.trapezoid(t[(w>=lo)&(w<=hi)],x=w[(w>=lo)&(w<=hi)])/(hi-lo) for lo,hi in [(.38,.78),(.78,2.5)]])

    def component(fs=1., cs=1., nm=1.58, dm=8.):
        mica = np.full(len(w),complex(nm))
        rr, tt, aa = [], [], []
        ee, hh = [], []
        for state in ['clear','dark']:
            r,t,a = characteristic([mica,ec['ITO'],ec['WO3_'+state],ion,ec['NiO_'+state],ec['ITO'],cap],
                [dm,.2*cs,.48*fs,.2,.15*fs,.2*cs,.38*cs])
            ee.append(t);rr.append(r);tt.append(t);aa.append(a)
        for state in range(2):
            r,t,a = characteristic([mica,vo2[state],cap,cap],[dm,.07*fs,.02,.38*cs])
            hh.append(t);rr.append(r);tt.append(t);aa.append(a)
        gap = characteristic([mica,cap],[dm,.38*cs])[1]
        return np.array(ee),np.array(hh),gap,np.array(rr),np.array(tt),np.array(aa)

    def combine(ee,hh,gap,f=.44,g=.02,eta=1.):
        # Explicit states; does not share the original transpose/broadcast code.
        out = np.empty((2,2,len(w)))
        for electric in range(2):
            for temperature in range(2):
                e = ee[electric]
                if electric == 1 and temperature == 1:
                    e = ee[0]+eta*(ee[1]-ee[0])
                out[electric,temperature] = (1-g)*(f*e+(1-f)*hh[temperature])+g*gap
        return out

    def summary(t):
        m = means(t)  # [electric,temperature,band]
        return {'visible_voltage_delta_min': float(min(abs(m[1,:,0]-m[0,:,0]))),
                'nir_temperature_delta_min': float(min(abs(m[:,1,1]-m[:,0,1]))),
                'nir_voltage_cross_max': float(max(abs(m[1,:,1]-m[0,:,1]))),
                'visible_temperature_cross_max': float(max(abs(m[:,1,0]-m[:,0,0])))}

    ee,hh,gap,rr,tt,aa = component()
    rebuilt = combine(ee,hh,gap)
    spectral_error = float(np.max(abs(rebuilt-reference)))
    assert spectral_error < 1e-11
    nominal = summary(rebuilt)
    old = next(x for x in original['records']if x['name']=='protected_two_pass_cap' and x['coherence']=='coherent')['metrics']['summary']
    nominal_error = max(abs(nominal[k]-old[k])for k in nominal)
    assert nominal_error < 1e-11

    records, parts = [], []
    for old_row in original['sputter_design_16_scenarios']:
        pars = [old_row[k]for k in ['film_scale','coating_scale','mica_n','mica_um']]
        a,b,c,*_ = component(*pars)
        parts.append((a,b,c))
        current = summary(combine(a,b,c))
        error = max(abs(current[k]-old_row['summary'][k])for k in current)
        assert error < 1e-11
        records.append({'parameters':pars,'summary':current,'error_to_original':error})

    # Solve area bounds directly from four independent reconstructed state
    # powers at f=0 and1, with no separate a,b,q sign assumption.
    intervals=[]
    for eta in [1.,.98,.95,.9]:
        a_ub,b_ub=[],[]
        for a,b,c in parts:
            m0 = means(combine(a,b,c,f=0.,eta=eta))
            m1 = means(combine(a,b,c,f=1.,eta=eta))
            for temperature in range(2):
                dv0 = m0[0,temperature,0]-m0[1,temperature,0]
                dv1 = m1[0,temperature,0]-m1[1,temperature,0]
                a_ub.append([-(dv1-dv0)]);b_ub.append(dv0-.3)
            for electric in range(2):
                dt0 = m0[electric,0,1]-m0[electric,1,1]
                dt1 = m1[electric,0,1]-m1[electric,1,1]
                a_ub.append([-(dt1-dt0)]);b_ub.append(dt0-.2)
        low = linprog([1.], A_ub=a_ub,b_ub=b_ub,bounds=[(0.,1.)],method='highs')
        high = linprog([-1.], A_ub=a_ub,b_ub=b_ub,bounds=[(0.,1.)],method='highs')
        prev = next(x for x in original['shared_cap_common_area_under_EC_thermal_drift']if x['hot_EC_contrast_retention']==eta)
        assert bool(low.success and high.success) == prev['common_interval_exists']
        if low.success:
            assert abs(low.x[0]-prev['common_f_EC_lower_exclusive'])<1e-10
            assert abs(high.x[0]-prev['common_f_EC_upper_exclusive'])<1e-10
        intervals.append({'eta':eta,'LP_feasible':bool(low.success and high.success),
            'LP_closed_interval': [float(low.x[0]),float(high.x[0])] if low.success else None,
            'note':'Strict optical thresholds require the interval interior; LP feasibility is used only when nonzero interval width is present.'})

    # Fresh all-layer n check; no hardcoded A pass/fail.
    index_records={}
    for name,n in {**ec,'Ta2O5_proxy':ion,'Al2O3_transfer':cap,'VO2_30C_transfer':vo2[0],'VO2_100C_transfer':vo2[1]}.items():
        j0,j1=int(n.real.argmin()),int(n.real.argmax())
        index_records[name]={'n_min':float(n.real[j0]),'n_min_wavelength_um':float(w[j0]),
            'n_max':float(n.real[j1]),'n_max_wavelength_um':float(w[j1]),
            'n_550nm':float(np.interp(.55,w,n.real)),
            'A_numerical_pass':bool(n.real.min()>=1.5 and n.real.max()<=3)}

    # Layer-level R/T/A cross-check against the third-party implementation at
    # selected wavelengths of the final protected construction itself.
    from tmm import coh_tmm,inc_tmm
    compare=[]
    mica=np.full(len(w),1.58+0j)
    for thermal,state in itertools.product([False,True],range(2)):
        if thermal:
            ns=[mica,vo2[state],cap,cap];ds=[8.,.07,.02,.38]
        else:
            st=['clear','dark'][state]
            ns=[mica,ec['ITO'],ec['WO3_'+st],ion,ec['NiO_'+st],ec['ITO'],cap]
            ds=[8.,.2,.48,.2,.15,.2,.38]
        cr,ct,ca=characteristic(ns,ds)
        for lam in [.38,.55,.78,1.34,1.43,2.5]:
            j=int(np.argmin(abs(w-lam)))
            z=coh_tmm('s',[1,*np.array(ns)[:,j],1],[np.inf,*ds,np.inf],0.,w[j])
            compare += [abs(z['R']-cr[j]),abs(z['T']-ct[j])]

    result={'input_files_checked':checks,'input_hashes_all_match':True,
      'independent_full_spectrum_max_T_error':spectral_error,'independent_band_metric_max_error':nominal_error,
      'independent_nominal_summary':nominal,'independent16':records,'independent_area_LP':intervals,
      'selected_final_design_RT_vs_tmm_max_error':float(max(compare)),
      'passivity_global_RTA_min_max':[float(min(rr.min(),tt.min(),aa.min())),float(max(rr.max(),tt.max(),aa.max()))],
      'fresh_index_checks':index_records,'strict_A_known_failure_confirmed':not all(x['A_numerical_pass']for x in index_records.values()),
      'conclusion':'Numerical spectra, area inequality and known strict-A failure independently confirmed. Common applied voltages, thermal electrochemistry, same-process material transfer and manufacturing remain unvalidated.',
      'scope':'Q2 audit, no new design optimization; scalar isotropic film and spatial flux-sum assumptions retained.'}
    (OUT/'results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    np.savez_compressed(OUT/'independent_spectra.npz',wavelength_um=w,T=rebuilt,R_components=rr,T_components=tt,A_components=aa)
    (OUT/'source.py').write_bytes(Path(__file__).read_bytes())
    print(json.dumps({k:result[k]for k in ['independent_full_spectrum_max_T_error','independent_band_metric_max_error','independent_nominal_summary','independent_area_LP','selected_final_design_RT_vs_tmm_max_error','passivity_global_RTA_min_max','strict_A_known_failure_confirmed']}))


if __name__=='__main__':
    main()
