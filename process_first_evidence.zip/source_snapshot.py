"""Process-first Q2 architecture decision; diagnostic, not a fabrication pass.

Two millimetre-scale regions on one retained mica sheet avoid serial optical
attenuation. Source charge endpoints do not establish common device voltages;
the constant-index mica and charge-state-independent electrolyte are explicit
proxies. No new field solver, temperature fit, or manufacturing yield is claimed.
"""
from pathlib import Path
import hashlib
import itertools
import json
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from src.optics import stack_rt, band_mean, four_state_metrics

OUT = ROOT / 'runs/20261106-q2-process-first-design-05'
BANDS = {'visible': (.38, .78), 'nir': (.78, 2.5)}


def main():
    OUT.mkdir(exist_ok=False)
    inputs = OUT / 'inputs'
    inputs.mkdir()
    source_hashes = {}
    arrays = {}

    def read(name, path):
        path = ROOT / path
        raw = path.read_bytes()
        (inputs / (name + '.csv')).write_bytes(raw)
        source_hashes[name] = {'path': path.relative_to(ROOT).as_posix(),
                               'sha256': hashlib.sha256(raw).hexdigest()}
        arrays[name] = np.loadtxt(path, delimiter=',', skiprows=1)

    for m in ['WO3_clear', 'WO3_dark', 'NiO_clear', 'NiO_dark', 'Ta2O5_Franta', 'Al2O3_Franta']:
        read(m, 'data/nk/' + m + '.csv')
    read('ITO', '.worktrees/q2-dual-response/data/q2_device/ITO_LBNL.csv')
    for f, temp in itertools.product(range(1, 5), [30, 100]):
        read(f'VO2_f{f}_{temp}', f'.worktrees/q2-dual-response/data/wan2019_author_20261101/film{f}_{temp}C.csv')
    knots = np.concatenate([a[:, 0] for a in arrays.values()])
    w = np.unique(np.r_[np.linspace(.38, .78, 401), np.linspace(.78, 2.5, 1721),
                        knots[(knots >= .38) & (knots <= 2.5)]])

    def nk(name):
        a = arrays[name]
        assert w[0] >= a[0, 0] and w[-1] <= a[-1, 0]
        return np.interp(w, a[:, 0], a[:, 1]) + 1j*np.interp(w, a[:, 0], a[:, 2])

    ito, electrolyte, cap = [nk(m) for m in ['ITO', 'Ta2O5_Franta', 'Al2O3_Franta']]
    ec = [np.array([nk('WO3_' + s), nk('NiO_' + s)]) for s in ['clear', 'dark']]
    v = {f: [nk(f'VO2_f{f}_{temp}') for temp in [30, 100]] for f in range(1, 5)}

    def electrical(n_mica=1.58, d_mica=8., d_wo=.49, d_ito=.5, d_cap=.03):
        m = np.full(len(w), n_mica+0j)
        ns = [np.array([m, ito, ec[s][0], electrolyte, ec[s][1], ito, cap]) for s in range(2)]
        # Charge matching is an optical endpoint capacity hypothesis, not kinetics.
        d = np.array([d_mica, d_ito, d_wo, .3, d_wo*68/219, d_ito, d_cap])
        rta = [stack_rt(w, n, d) for n in ns]
        return np.array([z[1] for z in rta]), ns, d, rta

    def thermal(f=4, n_mica=1.58, d_mica=8., d_vo=.11, d_cap=.3):
        m = np.full(len(w), n_mica+0j)
        ns = [np.array([m, n, cap]) for n in v[f]]
        d = np.array([d_mica, d_vo, d_cap])
        rta = [stack_rt(w, n, d) for n in ns]
        return np.array([z[1] for z in rta]), ns, d, rta

    def joint(te, tt, f_e=.55, dead=.02, n_mica=1.58, d_mica=8.):
        # Same common temperature in both regions. te(T) is unknown and held
        # fixed only for this screening; EC and TC cross-spectra are retained.
        gap = stack_rt(w, [np.full(len(w), n_mica+0j)], [d_mica])[1]
        t = (1-dead)*(f_e*te[:, None, :] + (1-f_e)*tt[None, :, :]) + dead*gap
        metrics = four_state_metrics(w, t, BANDS)
        return t, metrics

    def amplitude(t, band):
        return float(abs(band_mean(w, t[1]-t[0], BANDS[band])))

    te, ne, de, re = electrical()
    tt, nt, dt, rt = thermal()
    t, metrics = joint(te, tt)
    a, b = amplitude(te, 'visible'), amplitude(tt, 'nir')
    dead = .02
    lower = .3/((1-dead)*a)
    upper = 1-.2/((1-dead)*b)
    balanced = .3*b/(.2*a+.3*b)

    all_n = np.concatenate(ne+nt)
    index_records = {}
    for name in arrays:
        nn = nk(name)
        native = arrays[name]
        native = native[(native[:, 0] >= .38) & (native[:, 0] <= 2.5)]
        index_records[name] = {
            'n_min': float(min(nn.real.min(), native[:, 1].min())),
            'n_max': float(max(nn.real.max(), native[:, 1].max())),
            'n_550nm': float(np.interp(.55, arrays[name][:, 0], arrays[name][:, 1]))}

    scenarios = []
    low = np.full_like(t, np.inf)
    high = np.full_like(t, -np.inf)
    # Finite engineering scenarios only: not measured confidence bounds.
    for nm, dm, iw, it, tv, cp in itertools.product(
            [1.55, 1.62], [5., 9.], [.95, 1.05], [.95, 1.05], [.95, 1.05], [.28, .32]):
        ee, *_ = electrical(nm, dm, .49*iw, .5*it, .03)
        hh, *_ = thermal(4, nm, dm, .11*tv, cp)
        jt, met = joint(ee, hh, n_mica=nm, d_mica=dm)
        aa, bb = amplitude(ee, 'visible'), amplitude(hh, 'nir')
        lo, hi = .3/((1-dead)*aa), 1-.2/((1-dead)*bb)
        scenarios.append({'mica_proxy_n': nm, 'mica_um': dm, 'WO3_scale': iw,
            'ITO_scale': it, 'VO2_scale': tv, 'TC_cap_um': cp,
            'VIS_voltage_min': met['summary']['visible_voltage_delta_min'],
            'NIR_thermal_min': met['summary']['nir_temperature_delta_min'],
            'f_EC_open_interval': [lo, hi], 'area_interval_exists': bool(lo < hi)})
        low = np.minimum(low, jt)
        high = np.maximum(high, jt)

    film_comparison = []
    for f, thick in [(1, .069), (2, .13), (3, .12), (4, .11)]:
        hh, *_ = thermal(f=f, d_vo=thick)
        bb = amplitude(hh, 'nir')
        film_comparison.append({'film': f, 'source_thickness_um': thick,
             'NIR_thermal_delta': bb, 'f_EC_lower_exclusive': lower,
             'f_EC_upper_exclusive': 1-.2/((1-dead)*bb),
             'feasible_area_exists': bool(lower < 1-.2/((1-dead)*bb)),
             'source_process': 'sol-gel on silicon' if f == 4 else 'sputter on silicon/sapphire'})

    # Independent scalar implementation at selected wavelengths, both regions,
    # four actual charge/thermal endpoints; cannot validate the material proxies.
    from tmm import coh_tmm
    errors = []
    for ns, d, rta in [(ne, de, re), (nt, dt, rt)]:
        for state in range(2):
            for lam in [.38, .55, .78, 1.34, 1.43, 2., 2.5]:
                j = int(np.argmin(abs(w-lam)))
                z = coh_tmm('s', [1, *ns[state][:, j], 1], [np.inf, *d, np.inf], 0, w[j])
                errors.extend([abs(z['R']-rta[state][0][j]), abs(z['T']-rta[state][1][j])])
    assert max(errors) < 1e-10
    assert t.min() >= -1e-10 and t.max() <= 1+1e-10

    result = {'status': 'process-first architecture proposal with conditional optical budget; not a completed original-problem device',
      'layout': 'one retained mica sheet; side-by-side EC and TC regions; incoherent collected power over whole aperture',
      'aperture_mm': [2., 2.], 'inactive_bare_mica_strip_mm': [.04, 2.],
      'EC_fraction_of_usable_area': .55,
      'bands_um': BANDS, 'source_temperature_endpoints_C': [30, 100],
      'EC_voltage_endpoints': None, 'EC_temperature_response': 'unknown, held invariant only in this diagnostic',
      'electrical_region_names': ['mica_PROXY', 'ITO', 'WO3', 'Li-bearing-Ta2O5_OPTICAL_PROXY', 'LiNiO', 'ITO', 'Al2O3_cap'],
      'electrical_region_thickness_nm': (de*1000).tolist(),
      'thermal_region_names': ['mica_PROXY', 'VO2_film4_TRANSFER_UNVERIFIED', 'Al2O3_cap'],
      'thermal_region_thickness_nm': (dt*1000).tolist(),
      'layer_count_max_path': 7, 'retained_entities_union': 9,
      'counts_scope': 'patterned functional coupon plus two local caps and shared mica; edge frame/leads counted separately in process drawing',
      'nominal_component_amplitudes': {'EC_VIS': a, 'TC_NIR': b},
      'component_break_even_thresholds_exclusive': {'EC_VIS': .3/(.98*.55), 'TC_NIR': .2/(.98*.45)},
      'nominal_f_EC_feasible_open_interval': [lower, upper], 'balanced_f_EC': balanced,
      'metrics': metrics, 'strict_A_pass': bool(all_n.real.min() >= 1.5 and all_n.real.max() <= 3),
      'strict_A_evaluated_n_range': [float(all_n.real.min()), float(all_n.real.max())],
      'nominal_B_reference': '550 nm, 30 C, EC clear and VO2 insulating; support/electrolyte response remains proxy',
      'source_index_records': index_records,
      'finite_scenarios': scenarios,
      'finite_scenario_summary': {'count': len(scenarios),
         'joint_fixed_area_pass_count': sum(s['VIS_voltage_min'] > .3 and s['NIR_thermal_min'] > .2 for s in scenarios),
         'min_VIS_voltage': min(s['VIS_voltage_min'] for s in scenarios),
         'min_NIR_thermal': min(s['NIR_thermal_min'] for s in scenarios),
         'common_f_EC_lower_exclusive': max(s['f_EC_open_interval'][0] for s in scenarios),
         'common_f_EC_upper_exclusive': min(s['f_EC_open_interval'][1] for s in scenarios)},
      'source_film_comparison': film_comparison,
      'independent_TMM_max_RT_error': max(errors), 'source_sha256': source_hashes,
      'limits': [
        'Mica n=1.58,k=0 is a screening proxy, not measured complete 380-2500 nm tensor or two-temperature response.',
        'Published 400 C sputtered VO2/mica process does not establish transfer of Film4 sol-gel/Si optical constants.',
        'Lithium content, ionic transport, charge balance and common voltage endpoints at 30/100 C are not demonstrated.',
        'Li-bearing electrolyte is assigned neutral e-beam Ta2O5 optical constants; interface and state dependence are absent.',
        '30 nm EC and300 nm TC caps have no demonstrated barrier performance, interface compatibility or lifetime in this construction.',
        'Source VO2 tabulation gap1.34-1.43um is interpolated; no data extrapolation beyond source coverage.',
        'Full-aperture spatial average is not a pointwise uniform-window solution; illumination and collection must cover both regions.',
        'EC endpoint temperature invariance is unverified; retained cross-response metrics assume only this invariance.',
        'Natural film grains are not deliberately patterned features; no nanoparticle effective medium is introduced.',
        'Mica thickness/support/frame fabrication evidence at target5-9um is not a qualified process or yield.',
        'Finite scenario pass, independent solver agreement and nominal B indices do not constitute fabrication or strict A qualification.'],
      'actual_complete_device_pass': False}
    (OUT/'results.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    np.savez_compressed(OUT/'spectra.npz', wavelength_um=w, EC_T=te, TC_T=tt,
                        joint_T=t, scenario_joint_low=low, scenario_joint_high=high)
    np.savetxt(OUT/'four_states.csv', np.c_[w, t.reshape(4, -1).T], delimiter=',',
        header='wavelength_um,V0_30C,V0_100C,V1_30C,V1_100C', comments='')
    (OUT/'source.py').write_bytes(Path(__file__).read_bytes())
    print(json.dumps({k: result[k] for k in ['nominal_component_amplitudes', 'nominal_f_EC_feasible_open_interval',
          'finite_scenario_summary', 'strict_A_pass', 'strict_A_evaluated_n_range', 'independent_TMM_max_RT_error']}))


if __name__ == '__main__':
    main()
