from pathlib import Path
import json
import numpy as np
p=Path(__file__).resolve().parent
a=np.loadtxt(p/'four_states.csv',delimiter=',',skiprows=1)
r=json.loads((p/'data.json').read_text(encoding='utf-8'))
w=a[:,0]; t=a[:,1:].T.reshape(2,2,-1)
errors=[]
for name,(lo,hi) in r['bands_um'].items():
 m=(w>=lo-1e-12)&(w<=hi+1e-12)
 mean=np.trapezoid(t[:,:,m],x=w[m],axis=-1)/(hi-lo)
 expected=np.array(r['metrics'][name]['T_by_voltage_temperature'])
 errors.append(float(abs(mean-expected).max()))
assert max(errors)<1e-12
print(json.dumps({'maximum_absolute_band_mean_error':max(errors),'complete_device_pass':r['actual_complete_device_pass'],'strict_A_pass':r['strict_A_pass']}))
