Run verify.py, recompute_process.py, recompute_trace.py, recompute_target.py with Python3.13+ NumPy2 SciPy tmm Pillow PyMuPDF.
Only path destinations change in portable scripts; exact source snapshots retained.
All four-endpoint optics remain conditional, not verified common-voltage or fabrication performance.
