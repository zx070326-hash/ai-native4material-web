from pathlib import Path
import json,numpy as np
p=Path(__file__).resolve().parent;r=json.loads((p/'data.json').read_text(encoding='utf-8'))
a=np.loadtxt(p/'EC_specimen_VIS.csv',delimiter=',',skiprows=1)
d=float(np.trapezoid(a[:,1]-a[:,2],x=a[:,0])/.4)
assert abs(d-r['disclosed_device_trace']['VIS_voltage_delta'])<1e-12
z=np.load(p/'process_spectra.npz');w=z['wavelength_um'];errors=[]
for row in r['process_comparison']['records']:
 t=z[row['name']]
 for band,lo,hi in [('visible',.38,.78),('nir',.78,2.5)]:
  m=(w>=lo)&(w<=hi);v=np.trapezoid(t[:,:,m],x=w[m],axis=-1)/(hi-lo)
  errors.append(float(abs(v-np.array(row['metrics'][band]['T_by_voltage_temperature'])).max()))
assert max(errors)<1e-12
print(json.dumps({'all10_band_metrics_max_error':max(errors),'trace_delta_error':abs(d-r['disclosed_device_trace']['VIS_voltage_delta']),'fabrication_certified':False}))
