"""Compare process-order changes on the frozen Q2 optical inputs.

No new optical constants or electrochemical states are inferred. The question
is whether completing TC protection first can remove a deposition or a
heterogeneous interface without consuming the conditional optical budget.
"""
from pathlib import Path
import sys,json,itertools,hashlib
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from src.optics import stack_rt,four_state_metrics
OUT=ROOT/'runs/20261106-q2-process-order-03'

def main():
    OUT.mkdir(exist_ok=False)
    old=ROOT/'runs/20261106-q2-easy-validation-05'
    with np.load(old/'spectra.npz')as z:w=z['wavelength_um'];reference=z['protected_two_pass_cap_coherent']
    paths={}
    def load(name,path):
        paths[name]=str(path.relative_to(ROOT))
        a=np.loadtxt(path,delimiter=',',skiprows=1)
        assert w[0]>=a[0,0] and w[-1]<=a[-1,0]
        return np.interp(w,a[:,0],a[:,1])+1j*np.interp(w,a[:,0],a[:,2])
    exact=ROOT/'data/q2_easy_fabrication_20261106';inputs=ROOT/'runs/20261106-q2-process-first-design-05/inputs'
    n={k:load(k,exact/(k+'_raw.csv'))for k in ['ITO','WO3_clear','WO3_dark','NiO_clear','NiO_dark']}
    n['cap']=load('cap',inputs/'Al2O3_Franta.csv');n['ion']=load('ion',inputs/'Ta2O5_Franta.csv')
    n['cold']=load('cold',inputs/'VO2_f1_30.csv');n['hot']=load('hot',inputs/'VO2_f1_100.csv')
    n['mica']=np.full(len(w),1.58+0j)
    variants={
      'frozen_protected':{'ec_before':0.,'ec_after':.38,'tc_cap':.4,'split_tc':True,'gap_cap':.38,'entities':9,'depositions':8,'tc_layers':4},
      'finish_TC_first_separate_caps':{'ec_before':0.,'ec_after':.38,'tc_cap':.4,'gap_cap':0.,'entities':9,'depositions':8,'tc_layers':3},
      'single_blanket_cap_before_EC':{'ec_before':.4,'ec_after':0.,'tc_cap':.4,'gap_cap':.4,'entities':8,'depositions':7,'tc_layers':3},
      'blanket_before_EC_plus_terminal30':{'ec_before':.4,'ec_after':.03,'tc_cap':.4,'gap_cap':.4,'entities':9,'depositions':8,'tc_layers':3},
      'two_coupons_independent_process':{'ec_before':0.,'ec_after':.38,'tc_cap':.4,'gap_cap':None,'entities':10,'depositions':8,'tc_layers':3},
      'single_blanket_f44p5':{'ec_before':.4,'ec_after':0.,'tc_cap':.4,'gap_cap':.4,'entities':8,'depositions':7,'tc_layers':3,'f':.445},
      'single_blanket_LiNiO_first':{'ec_before':.4,'ec_after':0.,'tc_cap':.4,'gap_cap':.4,'entities':8,'depositions':7,'tc_layers':3,'reverse_ec':True},
      'finish_TC_first_LiNiO_first':{'ec_before':0.,'ec_after':.38,'tc_cap':.4,'gap_cap':0.,'entities':9,'depositions':8,'tc_layers':3,'reverse_ec':True},
      'patent_example9_functional_dimensions_cap_omitted_control':{'ec_before':.4,'ec_after':0.,'tc_cap':.4,'gap_cap':.4,'entities':8,'depositions':7,'tc_layers':3,'reverse_ec':True,'nio':.1,'ion':.06,'wo3':.3,'ito_top':.3},
      'patent_example9_dimensions_AlOx_substitution_control':{'ec_before':0.,'ec_after':.2,'tc_cap':.4,'gap_cap':0.,'entities':9,'depositions':8,'tc_layers':3,'reverse_ec':True,'nio':.1,'ion':.06,'wo3':.3,'ito_top':.3},
    }
    bands={'visible':(.38,.78),'nir':(.78,2.5)}
    def mean(t,lo,hi):
        m=(w>=lo)&(w<=hi);return np.trapezoid(t[...,m],x=w[m],axis=-1)/(hi-lo)
    def evaluate(c,fs=1.,cs=1.,mica_n=1.58,mica_d=8.,f=None,eta=1.):
        f=c.get('f',.44)if f is None else f
        mica=np.full(len(w),complex(mica_n));ee=[];hh=[];layers=[]
        for state in ['clear','dark']:
            ns=[mica];ds=[mica_d]
            if c['ec_before']:ns+=[n['cap']];ds+=[c['ec_before']*cs]
            if c.get('reverse_ec'):
                ns+=[n['ITO'],n['NiO_'+state],n['ion'],n['WO3_'+state],n['ITO']]
                ds += [.2*cs,c.get('nio',.15)*fs,c.get('ion',.2),c.get('wo3',.48)*fs,c.get('ito_top',.2)*cs]
            else:
                ns+=[n['ITO'],n['WO3_'+state],n['ion'],n['NiO_'+state],n['ITO']]
                ds += [.2*cs,.48*fs,.2,.15*fs,.2*cs]
            if c['ec_after']:ns+=[n['cap']];ds+=[c['ec_after']*cs]
            ee.append(stack_rt(w,np.array(ns),np.array(ds))[1]);layers.append((ns,ds))
        for state in ['cold','hot']:
            ns=[mica,n[state],n['cap']];ds=[mica_d,.07*fs,c['tc_cap']*cs]
            if c.get('split_tc'):ns=[mica,n[state],n['cap'],n['cap']];ds=[mica_d,.07*fs,.02,.38*cs]
            hh.append(stack_rt(w,np.array(ns),np.array(ds))[1]);layers.append((ns,ds))
        ee=np.array(ee);hh=np.array(hh)
        if c['gap_cap'] is None:gap=np.ones(len(w))  # open assembly slot; not an absorbing separator
        else:
            ns=[mica];ds=[mica_d]
            if c['gap_cap']:ns+=[n['cap']];ds+=[c['gap_cap']*cs]
            gap=stack_rt(w,np.array(ns),np.array(ds))[1]
        t=np.empty((2,2,len(w)))
        for v,temp in itertools.product(range(2),repeat=2):
            e=ee[v] if not(v==1 and temp==1)else ee[0]+eta*(ee[1]-ee[0])
            t[v,temp]=.98*(f*e+(1-f)*hh[temp])+.02*gap
        metrics=four_state_metrics(w,t,bands)
        # Positive contrast signs checked explicitly before deriving f bounds.
        a=float(mean(ee[0]-ee[1],.38,.78));q=float(mean(ee[0]-ee[1],.78,2.5));b=float(mean(hh[0]-hh[1],.78,2.5))
        assert min(a,q,b)>0
        lower=.3/(.98*eta*a)
        upper=(b-.2/.98)/(b+(1-eta)*q)
        return metrics,t,{'a_VIS_EC':a,'q_NIR_EC':q,'b_NIR_TC':b,'area_open_interval':[lower,upper],'exists':bool(lower<upper)},layers
    rows=[];spectra={};errors=[]
    from tmm import coh_tmm
    for name,c in variants.items():
        metrics,t,coeff,layers=evaluate(c);spectra[name]=t
        if name=='frozen_protected':assert np.max(abs(t-reference))<1e-11
        for ns,ds in layers:
            rt=stack_rt(w,np.array(ns),np.array(ds))
            for lam in [.38,.55,.78,1.5,2.5]:
                j=int(abs(w-lam).argmin());z=coh_tmm('s',[1,*np.array(ns)[:,j],1],[np.inf,*ds,np.inf],0.,w[j])
                errors.extend([abs(z['R']-rt[0][j]),abs(z['T']-rt[1][j])])
        scenario=[]
        for fs,cs,mn,md in itertools.product([.95,1.05],[.95,1.05],[1.55,1.62],[5.,9.]):
            m,_,co,_=evaluate(c,fs,cs,mn,md)
            scenario.append({'parameters':[fs,cs,mn,md],'summary':m['summary'],'area':co['area_open_interval']})
        thermal=[]
        for eta in [1.,.98,.95,.9]:
            intervals=[evaluate(c,fs,cs,mn,md,eta=eta)[2]['area_open_interval']for fs,cs,mn,md in itertools.product([.95,1.05],[.95,1.05],[1.55,1.62],[5.,9.])]
            lo=max(i[0]for i in intervals);hi=min(i[1]for i in intervals)
            thermal.append({'eta':eta,'common_area_open_interval':[lo,hi],'exists':bool(lo<hi)})
        rows.append({'name':name,'configuration':c,'metrics':metrics,'local_coefficients':coeff,'scenario16':scenario,'thermal_diagnostic_common_area':thermal,
                     'maximum_optical_path_layers':max(len(x[1])for x in layers),
                     'main_thresholds_nominal':bool(metrics['summary']['visible_voltage_delta_min']>.3 and metrics['summary']['nir_temperature_delta_min']>.2)})
    # Same-aperture serial alternative removes the area allocation penalty,
    # but adds the electrodes/EC absorption to the thermal optical path. Mica
    # is shared; light enters EC-cap/EC/mica/VO2/TC-cap. No multiplication of
    # independent free-space transmission curves is used.
    serial=np.empty((2,2,len(w)))
    for v,temp in itertools.product(range(2),repeat=2):
        st=['clear','dark'][v];phase=['cold','hot'][temp]
        ns=np.array([n['cap'],n['ITO'],n['NiO_'+st],n['ion'],n['WO3_'+st],n['ITO'],n['mica'],n[phase],n['cap']])
        ds=np.array([.38,.2,.15,.2,.48,.2,8.,.07,.4])
        rt=stack_rt(w,ns,ds);serial[v,temp]=rt[1]
        for lam in [.38,.55,.78,1.5,2.5]:
            j=int(abs(w-lam).argmin());z=coh_tmm('s',[1,*ns[:,j],1],[np.inf,*ds,np.inf],0.,w[j]);errors.extend([abs(z['R']-rt[0][j]),abs(z['T']-rt[1][j])])
    serial_metrics=four_state_metrics(w,serial,bands);spectra['same_aperture_serial_control']=serial
    assert max(errors)<1e-10
    result={'records':rows,'serial_control':{'metrics':serial_metrics,'retained_aperture_entities':9,'maximum_optical_path_layers':9,'limits':'Same assumed material endpoints; two-sided deposition and coating-exposure compatibility unvalidated.'},'wavelength_points':len(w),'independent_selected_RT_max_error':float(max(errors)),
      'source_files':{k:{'path':v,'sha256':hashlib.sha256((ROOT/v).read_bytes()).hexdigest()}for k,v in paths.items()},
      'limits':['Same transferred optical constants, chemical endpoints and scalar mica proxy as frozen candidate; no new material certification.',
                'Counts cover aperture solids only; carriers, contact leads and any final package must be counted after design.',
                'A single blanket cap before EC leaves no dedicated EC terminal protection; top ITO is not assumed hermetic.',
                '400nm sputtered AlOx is not proved equivalent to the source electron-beam optical input or to20+380nm two-pass oxide.',
                'No fixed pair of operating voltages or physical EC temperature dependence is supplied.',
                '16 scenarios are shared thickness groups, not independent full tolerances; new single400nm TC cap scales with coating group.',
                'Independent coupons remove shared deposition exposure but add a retained substrate and a thin-chip assembly requirement.',
                'Patent example9 actually includes200nm SiNx top protection; omitted-cap and AlOx-substitution rows are explicitly altered optical controls, not the disclosed prototype. LiTaO3 remains aTa2O5 optical proxy and LiNiO gradient is not modeled.'],
      'strict_A_pass':False,'fabrication_certified':False,'scope':'Process-topology comparison, no thickness/material/area optimization.'}
    (OUT/'results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    np.savez_compressed(OUT/'spectra.npz',wavelength_um=w,**spectra)
    (OUT/'source.py').write_bytes(Path(__file__).read_bytes())
    print(json.dumps({'selected_RT_error':max(errors),'designs':[{'name':x['name'],'main':x['metrics']['summary'],'pass':x['main_thresholds_nominal'],'eta':x['thermal_diagnostic_common_area']}for x in rows]}))

if __name__=='__main__':main()
