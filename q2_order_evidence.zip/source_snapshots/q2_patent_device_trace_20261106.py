"""Digitize a disclosed whole-solid EC device, not a substitute nk dataset."""
from pathlib import Path
import json,hashlib
import numpy as np
from PIL import Image,ImageDraw
import fitz

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data/q2_process_closure_20261106'
OUT=ROOT/'runs/20261106-q2-patent-device-trace-02'

def main():
    OUT.mkdir(exist_ok=False)
    pdf=fitz.open(DATA/'CN112649997A.pdf')
    images=[i for i in pdf[-1].get_images(full=True)if i[2]>900 and i[3]>600]
    assert len(images)==1
    raw=pdf.extract_image(images[0][0])['image']
    (OUT/'native_fig7.png').write_bytes(raw)
    im=Image.open(OUT/'native_fig7.png').convert('RGB');gray=np.asarray(im).mean(-1)
    # Native Figure7B:500nm atx592 and2500nm atx893;T0 at272,T100 at35.
    # Keep separated upper bleached and lower2.5V colored curves only.
    trace=[]
    for x in range(574,636):
        ys=np.flatnonzero(gray[70:269,x]<220)+70
        if 624<=x<=628:ys=ys[~((ys>=70)&(ys<=87))]
        # Remove the printed curve-number4, not a spectrum segment.
        if 621<=x<=633:ys=ys[~((ys>=254)&(ys<=267))]
        groups=np.split(ys,np.flatnonzero(np.diff(ys)>2)+1)
        groups=[g for g in groups if len(g)]
        if len(groups)<2:continue
        yc=float(np.median(groups[0]));yd=float(np.median(groups[-1]))
        trace.append([500+(x-592)*2000/301,(272-yc)/237,(272-yd)/237,x,yc,yd])
    a=np.array(trace)
    np.savetxt(OUT/'native_trace.csv',a,delimiter=',',comments='',header='wavelength_nm,T_bleached,T_colored2p5V,pixel_x,y_bleached,y_colored')
    lo,hi=380.,780.;w=np.unique(np.r_[lo,a[(a[:,0]>lo)&(a[:,0]<hi),0],hi])
    curves=np.array([np.interp(w,a[:,0],a[:,i])for i in [1,2]])
    delta=float(np.trapezoid(curves[0]-curves[1],x=w)/(hi-lo))
    clear=float(np.trapezoid(curves[0],x=w)/(hi-lo))
    # Independent vertical-trace shifts +/-2px each and span +/-2px.
    cases=[]
    for span in [-2,0,2]:
        for dc in [-2,2]:
            for dd in [-2,2]:
                d=((a[:,5]+dd)-(a[:,4]+dc))/(237+span)
                cases.append(float(np.trapezoid(np.interp(w,a[:,0],d),x=w)/400))
    frozen=json.loads((ROOT/'runs/20261106-q2-process-order-02/results.json').read_text())
    thermal=next(r for r in frozen['records']if r['name']=='finish_TC_first_separate_caps')['local_coefficients']['b_NIR_TC']
    fmin=.3/(.98*delta);fmax=1-.2/(.98*thermal)
    # Bound the0.399nm low-edge clamp separately;780nm is bracketed by native
    # pixels. This is still not a complete digitization confidence interval.
    iw=np.unique(np.r_[a[(a[:,0]>=a[0,0])&(a[:,0]<hi),0],hi])
    missing=max(0.,a[0,0]-lo)
    edge_cases=[]
    for span in [-2,0,2]:
        for dc in [-2,2]:
            for dd in [-2,2]:
                d=((a[:,5]+dd)-(a[:,4]+dc))/(237+span)
                integ=float(np.trapezoid(np.interp(iw,a[:,0],d),x=iw))
                edge_cases.extend([(integ-missing)/400,(integ+missing)/400])
    minimum_tc=.2/(.98-.3/delta)if .98>.3/delta else None
    result={'source_url':'https://patents.google.com/patent/CN112649997A/zh',
       'source_pdf_sha256':hashlib.sha256((DATA/'CN112649997A.pdf').read_bytes()).hexdigest(),
       'source_native_image_sha256':hashlib.sha256(raw).hexdigest(),
       'source_identity':'CN112649997A example9 Figure7B; disclosed whole device, not independent reproduction',
       'calibration':{'x_nm':[[592,500],[893,2500]],'y_fraction':[[272,0],[35,1]]},
       'native_trace_nm_range':[float(a[0,0]),float(a[-1,0])],
       'native_trace_count':len(a),'VIS_bleached_mean_T':clear,'VIS_voltage_delta':delta,
       'vertical_pixel_diagnostic_delta_range':[min(cases),max(cases)],
       'vertical_diagnostics_plus_arbitrary_low_edge':[min(edge_cases),max(edge_cases)],
       'conditional_current_TC_local_NIR_delta':thermal,
       'hypothetical_split_EC_area_lower_exclusive':fmin,'hypothetical_split_EC_area_upper_exclusive':fmax,
       'hypothetical_split_area_exists':bool(fmin<fmax),
       'even_best_vertical_plus_edge_case_split_area_exists':bool(.3/(.98*max(edge_cases))<fmax),
       'TC_local_delta_required_if_this_EC_contrast_transferred':minimum_tc,
       'limits':['Only a disclosed specimen at an unspecified plotted temperature and bleached bias; not a two-temperature common-voltage dataset.',
                 'Glass thickness and thin-mica process transfer remain unqualified.',
                 '2.5V is a reported colored endpoint, not an automatically safe voltage for the modeled design.',
                 'Figure trace uses fixed tiny band-edge interpolation/clamps and excludes curve-label4; vertical diagnostics do not include x-calibration or pixel-selection ambiguity.',
                 'Combining observed EC contrast with modeled TC contrast is an explicitly hypothetical budget, not a joint-device spectrum.',
                 'The optical failure does not deny other thicknesses, voltages or device architectures.'],
       'full_problem_solved':False}
    (OUT/'results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    np.savetxt(OUT/'VIS_trace.csv',np.c_[w/1000,curves.T],delimiter=',',comments='',header='wavelength_um,T_bleached,T_colored2p5V')
    draw=ImageDraw.Draw(im)
    for _,_,_,x,yc,yd in a:
        draw.point((round(x),round(yc)),fill='red');draw.point((round(x),round(yd)),fill='blue')
    im.save(OUT/'trace_overlay.png')
    (OUT/'source.py').write_bytes(Path(__file__).read_bytes())
    print(json.dumps(result))

if __name__=='__main__':main()
