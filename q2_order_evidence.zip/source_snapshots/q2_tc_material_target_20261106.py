"""Can two simple coatings reach the local TC target imposed by real EC contrast?

Compare three continuous source specimens; respect their reported thickness
intervals, retain their different source identities, and do not infer mica
optical constants from a structural-growth precedent. DE is a bounded candidate
search, never a proof of the global passive optimum.
"""
from pathlib import Path
import sys,json,hashlib
import numpy as np
from scipy.optimize import differential_evolution

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from src.optics import stack_rt
OUT=ROOT/'runs/20261106-q2-tc-material-target-01'

def main():
    OUT.mkdir(exist_ok=False)
    inputs=ROOT/'runs/20261106-q2-process-first-design-05/inputs'
    full=np.linspace(.78,2.5,1721);coarse=np.linspace(.78,2.5,345)
    def interp(path,w):
        a=np.loadtxt(path,delimiter=',',skiprows=1);assert a[0,0]<=w[0]and a[-1,0]>=w[-1]
        return np.interp(w,a[:,0],a[:,1])+1j*np.interp(w,a[:,0],a[:,2])
    ec=json.loads((ROOT/'runs/20261106-q2-patent-device-trace-02/results.json').read_text())
    av=ec['VIS_voltage_delta'];required=ec['TC_local_delta_required_if_this_EC_contrast_transferred']
    rows=[]
    for film,dmin,dmax,source in [(1,.061,.079,'70+/-9nm, sputtered onSi/nativeoxide'),(2,.113,.147,'130+/-17nm, sputtered onSi/nativeoxide'),(3,.108,.132,'120+/-12nm, sputtered on sapphire')]:
        for rear in [False,True]:
            def calculate(p,w):
                cap=interp(inputs/'Al2O3_Franta.csv',w);mica=np.full(len(w),1.58+0j)
                curves=[]
                for temp in [30,100]:
                    vo2=interp(inputs/f'VO2_f{film}_{temp}.csv',w)
                    ns=[mica,vo2,cap];ds=[8.,p[0],p[1]]
                    if rear:ns=[cap,*ns];ds=[p[2],*ds]
                    curves.append(stack_rt(w,np.array(ns),np.array(ds))[1])
                return float(np.trapezoid(curves[0]-curves[1],x=w)/1.72),np.array(curves)
            def objective(p):return -calculate(p,coarse)[0]
            bounds=[(dmin,dmax),(.01,1.)]+([(.01,.3)]if rear else[])
            solution=differential_evolution(objective,bounds,seed=1106,popsize=8,maxiter=35,tol=1e-6,polish=True)
            value,t=calculate(solution.x,full)
            need=.2/(.98-.3/av)
            fmin=.3/(.98*av);fmax=1-.2/(.98*value)
            # Also at the central source thickness; vary only passive top cap.
            rows.append({'film':film,'source_identity':source,'rear_AR':rear,'parameters_um':solution.x.tolist(),
                         'local_NIR_signed_delta':value,'required_TC_nominal_EC':need,
                         'hypothetical_common_area_open_interval':[fmin,fmax],
                         'hypothetical_nominal_area_exists':bool(fmin<fmax),
                         'optimizer':{'success':bool(solution.success),'iterations':solution.nit,'evaluations':solution.nfev,'message':str(solution.message)},
                         'coarse_to_fine_delta':value+float(solution.fun)})
            np.savez_compressed(OUT/f'film{film}_rear{int(rear)}.npz',wavelength_um=full,T=t)
    result={'EC_observed_VIS_delta':av,'target_TC_local_delta':required,'records':rows,
      'source_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()for p in [inputs/'Al2O3_Franta.csv',*[inputs/f'VO2_f{f}_{t}.csv'for f in [1,2,3]for t in [30,100]]]},
      'limits':['Bounded optical search only; no infeasibility theorem and no same-process fabrication certificate.',
                'Thickness intervals are the source characterization intervals, not a guarantee that optical constants remain unchanged through them.',
                'Source supports areSi/nativeoxide or sapphire;8um mica remains a scalar proxy, not a measured transferred specimen.',
                'The extra rear AR is a real retained coating and adds a back-side deposition/handling step.',
                'Two-temperature EC response and common applied voltages remain unavailable.',
                'The oxide cap uses the same electron-beam source spectrum; sputter-transfer uncertainty remains.',
                'No all-layer geometry/material tolerance certification is attempted for these screening candidates.']}
    (OUT/'results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    (OUT/'source.py').write_bytes(Path(__file__).read_bytes())
    print(json.dumps(result))

if __name__=='__main__':main()
