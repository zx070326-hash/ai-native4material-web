from pathlib import Path
import importlib.util,json,sys,subprocess
root=Path(__file__).resolve().parent
def module(name,folder='experiments'):
 p=root/folder/name
 spec=importlib.util.spec_from_file_location('replay_'+p.stem,p)
 mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod
module('q2_parallel_amplitude_20261106.py').main()
for script,target,folder in [('q2_parallel_fourstate_20261106.py','recomputed_fourstate','experiments'),('q2_parallel_process_20261106.py','recomputed_process','portable')]:
 subprocess.run([sys.executable,str(root/folder/script),'--out',target],check=True,cwd=root)
for script in ['q2_parallel_amplitude_frontcap_20261106.py','q2_ding_process_addendum_20261106.py','q2_parallel_joint_feasibility_20261106.py']:
 module(script,'portable' if script=='q2_ding_process_addendum_20261106.py' else 'experiments').main()
print('All six calculations completed in fresh output directories. Compare numeric results with reference/.')
