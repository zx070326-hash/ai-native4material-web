Python3 with NumPy2, SciPy, tmm, Pillow. Run recompute.py once in a fresh extraction.
Six calculations use bundled numerical inputs; exact source snapshots are retained. Earlier TC optimization is a frozen input, not rerun.
portable/ changes only full-paper digest rereads to recovery of recorded hashes. It does not verify omitted PDF bytes.
reference/ retains original numerical results; source paths and strings can vary by platform.
Full primary papers and failed403/404 download bodies are not included as scientific inputs.
The amplitude spectra are figure-mode diagnostics, not same-voltage/two-temperature measurements.
