"""Q2 charge-conserving four-state sensitivity, not a voltage calibration.

The two endpoint interpolation paths are unmeasured constitutive scenarios.
The same transferred Li areal charge is used in BOTH functional electrodes.
No relationship between voltage and this charge is inferred from endpoint n,k.
"""
from pathlib import Path
import argparse, hashlib, itertools, json, sys
import numpy as np
from scipy.optimize import brentq

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from src.optics import stack_rt, four_state_metrics


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', default='runs/20261106-q2-parallel-fourstate-01')
    args = parser.parse_args()
    out = ROOT/args.out
    out.mkdir(parents=True, exist_ok=False)
    previous = ROOT/'runs/20261106-q2-process-order-03'
    old = json.loads((previous/'results.json').read_text(encoding='utf-8'))
    target = next(r for r in old['records'] if r['name'] == 'finish_TC_first_LiNiO_first')
    with np.load(previous/'spectra.npz') as z:
        w = z['wavelength_um']
        frozen = z['finish_TC_first_LiNiO_first']
    source_files = {}
    def load(name):
        p = ROOT/old['source_files'][name]['path']
        source_files[str(p.relative_to(ROOT))] = hashlib.sha256(p.read_bytes()).hexdigest()
        a = np.loadtxt(p, delimiter=',', skiprows=1)
        assert w[0] >= a[0,0] and w[-1] <= a[-1,0]
        return np.interp(w,a[:,0],a[:,1])+1j*np.interp(w,a[:,0],a[:,2])
    n = {key:load(key) for key in old['source_files']}
    bands = {'visible':(.38,.78),'nir':(.78,2.5)}
    def mean(t, band):
        lo,hi=bands[band]; m=(w>=lo)&(w<=hi)
        return np.trapezoid(t[...,m],x=w[m],axis=-1)/(hi-lo)
    mica = np.full(len(w),1.58+0j)
    tc = np.array([stack_rt(w,np.array([mica,n[k],n['cap']]),[8.,.07,.4])[1]
                   for k in ['cold','hot']])
    gap = stack_rt(w,np.array([mica]),[8.])[1]
    qw, qni = .48*68.2, .15*219.
    qmax = min(qw,qni)
    cache = {}
    def ec(q, path):
        key=(float(q),path)
        if key not in cache:
            assert -1e-12 <= q <= qmax+1e-12
            fw,fn=q/qw,q/qni
            def interpolate(clear,dark,f):
                if path=='linear_epsilon':return np.sqrt((1-f)*clear**2+f*dark**2)
                if path=='linear_nk':return (1-f)*clear+f*dark
                raise ValueError(path)
            nw=interpolate(n['WO3_clear'],n['WO3_dark'],fw)
            nn=interpolate(n['NiO_clear'],n['NiO_dark'],fn)
            rt=stack_rt(w,np.array([mica,n['ITO'],nn,n['ion'],nw,n['ITO'],n['cap']]),
                        [8.,.2,.15,.2,.48,.2,.38])
            assert min(x.min() for x in rt)>-1e-10
            cache[key]=rt[1]
        return cache[key]
    def evaluate(qbc,qdc,qbh,qdh,path,f=.44):
        charges=[[qbc,qbh],[qdc,qdh]]
        t=np.array([[.98*(f*ec(charges[v][temp],path)+(1-f)*tc[temp])+.02*gap
                     for temp in range(2)] for v in range(2)])
        return four_state_metrics(w,t,bands),t
    def area(qbc,qdc,qbh,qdh,path):
        # Signed EC clear-to-dark and signed cold-to-hot responses. For each
        # temperature/voltage impose the desired positive sign, not abs()
        # which could disguise a reversal. All are affine in EC area fraction.
        eb=[ec(qbc,path),ec(qbh,path)];ed=[ec(qdc,path),ec(qdh,path)]
        lo,hi=0.,1.; rows=[]
        for temp in range(2):
            a=float(mean(eb[temp]-ed[temp],'visible'))
            rows.append({'constraint':f'VIS_temperature_{temp}','slope':.98*a,'intercept':0.,'threshold':.3})
        b=float(mean(tc[0]-tc[1],'nir'))
        for v,qs in enumerate([(qbc,qbh),(qdc,qdh)]):
            drift=float(mean(ec(qs[0],path)-ec(qs[1],path),'nir'))
            rows.append({'constraint':f'NIR_voltage_{v}','slope':.98*(drift-b),'intercept':.98*b,'threshold':.2})
        for row in rows:
            a,c,y=row['slope'],row['intercept'],row['threshold']
            if a>0:lo=max(lo,(y-c)/a)
            elif a<0:hi=min(hi,(y-c)/a)
            elif c<=y:lo,hi=1.,0.
        return {'f_lower_exclusive':lo,'f_upper_exclusive':hi,'exists':bool(lo<hi),'inequalities':rows}
    records=[]; spectra={}; capacities=[]; charge_windows=[]; residuals=[]; controls=[]; thermal_aid=[]
    for path in ['linear_epsilon','linear_nk']:
        base,t=evaluate(0,qmax,0,qmax,path)
        spectra[path+'_conserved_nominal']=t
        records.append({'name':'conserved_nominal','path':path,'charges_mC_cm2':[[0,0],[qmax,qmax]],'metrics':base,
                        'area':area(0,qmax,0,qmax,path)})
        # Require both temperatures to satisfy the main VIS criterion at fixed f.
        def vis(q):return .98*.44*float(mean(ec(0,path)-ec(q,path),'visible'))-.3
        minimum_dark=brentq(vis,0,qmax,xtol=1e-9)
        # Loss of hot dark charge can reverse the EC NIR contribution and cancel TC.
        def nir(q):return .98*(.44*float(mean(ec(qmax,path)-ec(q,path),'nir'))+.56*float(mean(tc[0]-tc[1],'nir')))-.2
        minimum_hot_nir=brentq(nir,0,qmax,xtol=1e-9)
        minimum_hot=max(minimum_dark,minimum_hot_nir)
        for residual in [0.,.1,.25,.5,1.,2.,4.]:
            a=area(0,qmax,residual,qmax,path)
            met,_=evaluate(0,qmax,residual,qmax,path)
            residuals.append({'path':path,'hot_bleached_residual_mC_cm2':residual,'area':a,'metrics':met['summary']})
        max_hot_clear=brentq(lambda q: .98*.44*float(mean(ec(q,path)-ec(qmax,path),'visible'))-.3,0,qmax,xtol=1e-9)
        charge_windows.append({'path':path,'minimum_dark_charge_at_both_temperatures_mC_cm2':minimum_dark,
            'minimum_hot_dark_charge_from_NIR_mC_cm2':minimum_hot_nir,
            'minimum_hot_dark_joint_mC_cm2':minimum_hot,
            'maximum_dark_charge_loss_hot_mC_cm2':qmax-minimum_hot,
            'maximum_bleached_residual_hot_from_VIS_mC_cm2':max_hot_clear,
            'warning':'Separate one-variable limits; not an independent box of simultaneous allowed errors.'})
        for cap in [2.59,3.22,4.20,4.5,6.4,10.,20.,25.,30.,qmax]:
            if cap>qmax:continue
            met,t=evaluate(0,cap,0,cap,path)
            capacities.append({'path':path,'common_reversible_charge_cap_mC_cm2':cap,
                'metrics':met['summary'],'area':area(0,cap,0,cap,path),
                'charge_values_are_not_transferred_material_measurements':True})
        # Geometric charge-state map: cold end points fixed, hot color and residual
        # constrained by charge conservation in the two electrodes, not arbitrary
        # independently chosen material states.
        grid=[]
        for qb,qd in itertools.product([0.,.25,.5,1.,2.],[28.,29.,30.,31.,32.,qmax]):
            met,_=evaluate(0,qmax,qb,qd,path)
            a=area(0,qmax,qb,qd,path)
            grid.append({'q_hot_clear_mC_cm2':qb,'q_hot_dark_mC_cm2':qd,'area':a,
                         'fixed_f_main':met['summary']})
        records.append({'name':'hot_charge_grid','path':path,'rows':grid})
        # A partial-charge SOURCE model can have the same scalar cold VIS
        # contrast as the patent while having entirely different spectra. This
        # is expressly a non-identifiability witness, not a patent n,k fit.
        # Ask whether hot Li uptake at BOTH voltages could help thermal NIR.
        patent_a=.5513720579783282
        qpartial=brentq(lambda q:float(mean(ec(0,path)-ec(q,path),'visible'))-patent_a,0,qmax,xtol=1e-9)
        candidates=[]; best_margin=-np.inf; best_infeasible=None
        # Scan the entire charge domain as well as the finely sampled low-q
        # edge. This remains a sampled diagnostic, not a continuum theorem.
        bleach_grid=np.unique(np.r_[np.linspace(0.,2.,81),np.linspace(0.,qmax,165)])
        for qb in bleach_grid:
            a=area(0,qpartial,float(qb),qmax,path)
            margin=a['f_upper_exclusive']-a['f_lower_exclusive']
            if margin>best_margin:best_margin=margin;best_infeasible={'q_hot_clear':float(qb),'area':a}
            if a['exists']:
                # Choose midpoint, avoiding strict-boundary equality.
                f=.5*(a['f_lower_exclusive']+a['f_upper_exclusive'])
                met,t=evaluate(0,qpartial,float(qb),qmax,path,f)
                candidates.append((min(met['summary']['visible_voltage_delta_min']/.3,
                                       met['summary']['nir_temperature_delta_min']/.2),float(qb),f,met,t,a))
        witness=None
        if candidates:
            _,qb,f,met,t,a=max(candidates,key=lambda x:x[0])
            spectra[path+'_thermal_aid_witness']=t
            witness={'hot_bleach_charge_mC_cm2':qb,'f':f,'hot_dark_charge_mC_cm2':qmax,
                     'metrics':met,'area':a,
                     'EC_local_NIR_cold_minus_hot_by_voltage':[
                         float(mean(ec(0,path)-ec(qb,path),'nir')),
                         float(mean(ec(qpartial,path)-ec(qmax,path),'nir'))]}
        helper_req=(.2/.98-(1-.3/(.98*patent_a))*float(mean(tc[0]-tc[1],'nir')))/(.3/(.98*patent_a))
        max_help=float(mean(ec(qpartial,path)-ec(qmax,path),'nir'))
        qhot_dark_req=None
        if max_help>helper_req:
            qhot_dark_req=brentq(lambda q:float(mean(ec(qpartial,path)-ec(q,path),'nir'))-helper_req,qpartial,qmax,xtol=1e-9)
        thermal_aid.append({'path':path,'cold_dark_partial_charge_mC_cm2':qpartial,
            'cold_local_VIS_contrast_matched_only_as_nonidentifiability_witness':patent_a,
            'hot_dark_charge_set_to_nominal_shared_max':qmax,'searched_hot_bleach_charge_range_mC_cm2':[0.,qmax],
            'hot_bleach_grid_points':len(bleach_grid),'best_sampled_area_margin':best_margin,
            'best_sampled_area_even_if_infeasible':best_infeasible,
            'EC_thermal_NIR_help_required_at_cold_VIS_min_area':helper_req,
            'hot_dark_charge_required_from_NIR_help_at_min_area_mC_cm2':qhot_dark_req,
            'hot_to_cold_dark_charge_ratio_required_at_min_area':None if qhot_dark_req is None else qhot_dark_req/qpartial,
            'feasible_grid_point_count':len(candidates),'best_found_witness':witness,
            'qualification':'Not the patent material, not inferred Q(V,T), not a measured thermal response. The two-path comparison tests identifiability; it does not identify a voltage-driven material.'})
        # Exact opposite charges transported; fractional endpoint mismatch is
        # intentional, because source capacities differ by 0.114mC/cm2.
        controls.append({'path':path,'source_WO3_fraction_at_qmax':qmax/qw,'source_LiNiO_fraction_at_qmax':qmax/qni,
            'difference_from_old_simultaneous_full_endpoint_max_T':float(abs(spectra[path+'_conserved_nominal']-frozen).max())})
    # Independent native-stack calculation checks for both interpolation paths.
    from tmm import coh_tmm
    errors=[]
    for path,q in itertools.product(['linear_epsilon','linear_nk'],[0.,16.,qmax]):
        fw,fn=q/qw,q/qni
        def mix(a,b,f):return np.sqrt((1-f)*a*a+f*b*b)if path=='linear_epsilon'else(1-f)*a+f*b
        ns=np.array([mica,n['ITO'],mix(n['NiO_clear'],n['NiO_dark'],fn),n['ion'],
                     mix(n['WO3_clear'],n['WO3_dark'],fw),n['ITO'],n['cap']])
        ds=[8.,.2,.15,.2,.48,.2,.38];rt=stack_rt(w,ns,ds)
        for lam in [.38,.55,.78,1.5,2.5]:
            j=int(abs(w-lam).argmin());z=coh_tmm('s',[1,*ns[:,j],1],[np.inf,*ds,np.inf],0.,w[j])
            errors.extend([abs(z['R']-rt[0][j]),abs(z['T']-rt[1][j])])
    assert max(errors)<1e-10
    # Direct four-state formula control independent of four_state_metrics.
    manual=[]; sampled_crosspeaks={}
    for path,t in spectra.items():
        vis=mean(t,'visible');nirv=mean(t,'nir')
        manual.append({'path':path,'min_VIS_voltage':float(abs(vis[1]-vis[0]).min()),
                       'min_NIR_temperature':float(abs(nirv[:,1]-nirv[:,0]).min())})
        mv=(w>=.38)&(w<=.78); mn=(w>=.78)&(w<=2.5)
        sampled_crosspeaks[path]={
            'VIS_temperature_max_abs_spectral_difference':float(abs(t[:,1,mv]-t[:,0,mv]).max()),
            'NIR_voltage_max_abs_spectral_difference':float(abs(t[1,:,mn]-t[0,:,mn]).max()),
            'qualification':'Maxima on saved 4405-point grid, not continuous-spectrum extrema.'}
    # Cross-check affine area inequalities against an independent optimizer.
    from scipy.optimize import linprog
    lp_errors=[]
    for row in thermal_aid:
        a=row['best_sampled_area_even_if_infeasible']['area'];ineq=a['inequalities']
        A=np.array([[-x['slope']]for x in ineq]);b=np.array([x['intercept']-x['threshold']for x in ineq])
        low=linprog([1.],A_ub=A,b_ub=b,bounds=[(0,1)],method='highs')
        high=linprog([-1.],A_ub=A,b_ub=b,bounds=[(0,1)],method='highs')
        assert bool(low.success and high.success)==a['exists']
        if low.success:
            lp_errors.extend([abs(low.x[0]-a['f_lower_exclusive']),abs(high.x[0]-a['f_upper_exclusive'])])
    result={'scope':'Shared Li-charge sensitivity and common-voltage identifiability; no physical Q(V,T) calibration',
        'thickness_um':[8.,.2,.15,.2,.48,.2,.38],
        'EC_materials':['mica_proxy','ITO','LiNiO','LiTaO3_as_Ta2O5_proxy','WO3','ITO','Al2O3'],
        'source_header_endpoint_charge_mC_cm2':{'WO3':qw,'LiNiO':qni,'shared_max':qmax},
        'records':records,'capacity_diagnostics':capacities,'one_variable_charge_limits':charge_windows,
        'thermal_aid_nonidentifiability_witnesses':thermal_aid,
        'hot_bleached_residual_diagnostics':residuals,'conserved_endpoint_control':controls,
        'manual_four_state_control':manual,'independent_tmm_max_RT_error':max(errors),
        'sampled_spectral_crosspeaks':sampled_crosspeaks,'area_linprog_max_boundary_error':max(lp_errors,default=0.),
        'EC_active_area_cm2':.04*.98*.44,'nominal_total_Li_charge_mC':qmax*.04*.98*.44,
        'source_sha256':source_files,
        'common_voltage_conditions':[
            'A single pair V_clear,V_dark must reach the computed charge region at both temperatures.',
            'Measured electrode equilibrium potentials U_W(q,T),U_N(q,T), charge-transfer losses and reversible Li inventory are absent.',
            'For a charge-limited voltage pulse, dQ_Li/dt=I_terminal-I_leak-I_side. Integrated terminal current alone is insufficient when side reactions are unknown.',
            'Changing pulse duration with temperature does not establish a common equilibrium pair, but is allowed as an explicitly defined protocol if the safe-voltage windows overlap.',
            'Open-circuit charge memory would require both thermal retention and reversible switching data; it is not assumed here.'],
        'limits':[
            'Linear epsilon and linear n,k versus shared charge are two explicit unmeasured paths, not measured electrochemical constitutive laws.',
            'LBNL header charge is a chemical endpoint label, not a measured reversible capacity of the proposed sputtered LiNiO/WO3 device.',
            'Charge at two temperatures may differ; there is no identification of voltage from n,k.',
            'EC intrinsic optical temperature dependence at fixed charge is held zero only as a diagnostic.',
            'Source VO2 30/100C response on Si is transferred conditionally; mica and LiTaO3 optical inputs remain proxies.',
            'Capacity data from different devices are used only as hypothetical caps; nonlinear thickness/capacity prevents their automatic transfer.',
            'Positive signed thermal response is imposed in the area inequalities. Other branch reversals are not explored.',
            'Temperature-cycling damage in other cells does not prove failure of this cell; it prevents assuming no effect.',
            'Strict A known failures remain, B complete device and fabrication not certified.'],
        'full_problem_solved':False,'common_voltage_certified':False}
    (out/'results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    np.savez_compressed(out/'spectra.npz',wavelength_um=w,**spectra)
    (out/'source.py').write_bytes(Path(__file__).read_bytes())
    print(json.dumps({'charge_windows':charge_windows,'thermal_aid':thermal_aid,'controls':controls,'manual':manual,'independent_RT':max(errors)},indent=2))

if __name__=='__main__':main()
