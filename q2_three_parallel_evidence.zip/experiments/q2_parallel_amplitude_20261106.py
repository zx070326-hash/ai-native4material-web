"""Recover high-contrast whole-device leads without treating figures as nk data.

Two independent source figures, retained calibration and pixel diagnostics.
These are one-temperature whole-device traces, not the required joint four states.
"""
from pathlib import Path
import hashlib,json
import numpy as np
from PIL import Image, ImageDraw

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data/q2_parallel_amplitude_20261106'
OUT=ROOT/'runs/20261106-q2-parallel-amplitude-02'

def groups(mask,offset):
    ys=np.flatnonzero(mask)+offset
    return [g for g in np.split(ys,np.flatnonzero(np.diff(ys)>2)+1) if len(g)]

def trace_ding():
    path=DATA/'Ding2025_Tsinghua_fig2.png'
    im=Image.open(path).convert('RGB');arr=np.asarray(im).astype(float)
    rows=[]
    for x in range(84,172):
        c=arr[620:794,x]
        red=(c[:,0]>160)&(c[:,0]>1.2*c[:,1])&(c[:,0]>1.1*c[:,2])
        rp=groups(red,620)
        c=arr[780:794,x]
        violet=(c[:,2]>150)&(c[:,0]>100)&(c[:,2]>1.15*c[:,0])&(c[:,1]<150)
        vp=groups(violet,780)
        if not rp or not vp:continue
        # The text is above this crop; the purple curve is the lowest group.
        rows.append([x,float(np.median(rp[-1])),float(np.median(vp[-1]))])
    return path,im,np.array(rows),{'x_nm_anchors':[[92,400],[170,800]],'T_anchors':[[789,0],[609,1]],'supersedes':'amplitude-01 used bottom frame y797 instead of the zero tick y789; Figure2d extends below zero. The source and old calculation remain frozen.','interpretation':'Figure2d Bright warming red / Dark cooling violet; Figure2f labels2V/-0.5V, but no assignment of all three spectral curves to voltage, side, temperature and measurement reference has yet been recovered.'}

def trace_venugopal():
    path=DATA/'Venugopal2021_fig5.jpg'
    im=Image.open(path).convert('RGB');arr=np.asarray(im).astype(float)
    rows=[];last_dark=None
    for x in range(250,540):
        c=arr[45:700,x]
        orange=(c[:,0]>170)&(c[:,1]>60)&(c[:,1]<190)&(c[:,2]<100)&(c[:,0]>1.2*c[:,1])
        navy=(c[:,0]<110)&(c[:,1]<110)&(c[:,2]>70)&(c[:,2]>1.5*c[:,0])
        op=groups(orange,45);np_=groups(navy,45)
        if not op or not np_:continue
        centers=[float(np.median(g)) for g in np_]
        yd=max(centers) if last_dark is None else min(centers,key=lambda y:abs(y-last_dark))
        if last_dark is not None:assert abs(yd-last_dark)<30
        last_dark=yd
        rows.append([x,float(np.median(op[0])),yd])
    return path,im,np.array(rows),{'x_nm_anchors':[[201,300],[408,600],[616,900]],'used_linear_calibration':[[201,300],[616,900]],'T_anchors':[[703,0],[42,1]],'interpretation':'Figure5a full-device +2.8V orange / -2.8V dark navy;2-electrode device distinct from Figure3 individual-electrode spectra. Temperature and optical reference not recovered from full main text.'}

def integrate(pixels,cal,shift_x=0,shift_clear=0,shift_dark=0,span_error=0):
    anchors=cal.get('used_linear_calibration',cal['x_nm_anchors'])
    (x0,w0),(x1,w1)=anchors
    y0=cal['T_anchors'][0][0];span=y0-cal['T_anchors'][1][0]+span_error
    w=w0+(pixels[:,0]+shift_x-x0)*(w1-w0)/(x1-x0)
    assert w[0]<380 and w[-1]>780
    grid=np.unique(np.r_[380,w[(w>380)&(w<780)],780])
    clear=np.interp(grid,w,(y0-pixels[:,1]-shift_clear)/span)
    dark=np.interp(grid,w,(y0-pixels[:,2]-shift_dark)/span)
    return float(np.trapezoid(clear-dark,x=grid)/400),grid,clear,dark

def main():
    OUT.mkdir(exist_ok=False)
    old=json.loads((ROOT/'runs/20261106-q2-patent-device-trace-02/results.json').read_text())
    b=old['conditional_current_TC_local_NIR_delta'];g=.02
    results=[]
    for name,fn,doi,url in [
      ('Ding2025',trace_ding,'10.1039/D5EE02750K','https://www.chemeng.tsinghua.edu.cn/en/info/1019/1080.htm'),
      ('Venugopal2021',trace_venugopal,'10.1016/j.cej.2021.130306','https://www.sciencedirect.com/science/article/pii/S1385894721018921')]:
        path,im,pix,cal=fn();a,w,tc,td=integrate(pix,cal)
        cases=[integrate(pix,cal,x,c,d,s)[0] for x in [-1,0,1] for c in [-2,2] for d in [-2,2] for s in [-2,2]]
        lo,hi=min(cases),max(cases)
        fmin=.3/((1-g)*a);fmax=1-.2/((1-g)*b)
        np.savetxt(OUT/f'{name}_pixels.csv',pix,delimiter=',',header='pixel_x,y_clear,y_dark',comments='')
        np.savetxt(OUT/f'{name}_VIS.csv',np.c_[w,tc,td],delimiter=',',header='wavelength_nm,T_clear,T_dark',comments='')
        dr=ImageDraw.Draw(im)
        for x,yc,yd in pix:dr.ellipse((x-1,yc-1,x+1,yc+1),fill='red');dr.ellipse((x-1,yd-1,x+1,yd+1),fill='cyan')
        im.save(OUT/f'{name}_trace_overlay.png')
        best=json.loads((ROOT/'runs/20261106-q2-tc-material-target-01/results.json').read_text())
        bbest=max(r['local_NIR_signed_delta'] for r in best['records'])
        budgets=[]
        for bt,label in [(b,'current_TC'),(bbest,'best_screened_TC')]:
            for av,case in [(a,'nominal_pixels'),(lo,'low_pixel_contrast'),(hi,'high_pixel_contrast')]:
                budgets.append(dict(TC_source=label,TC_amplitude=bt,EC_case=case,EC_amplitude=av,maximum_inactive_fraction_exclusive=1-.3/av-.2/bt,area_open_interval_at_two_percent_gap=[.3/((1-g)*av),1-.2/((1-g)*bt)]))
        results.append(dict(name=name,doi=doi,source_url=url,source_image=str(path.relative_to(ROOT)),source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),calibration=cal,trace_count=len(pix),VIS_signed_delta=a,VIS_clear=float(np.trapezoid(tc,x=w)/400),VIS_dark=float(np.trapezoid(td,x=w)/400),pixel_diagnostic_delta_range=[lo,hi],conditional_TC_delta=b,hypothetical_EC_area_open_interval=[fmin,fmax],hypothetical_area_exists=fmin<fmax,hypothetical_area_still_exists_at_low_pixel_contrast=.3/((1-g)*lo)<fmax,necessary_TC_delta_for_this_EC=.2/(1-g-.3/a),minimum_EC_contrast_for_current_TC=.3/(1-g-.2/b),hypothetical_gap_budgets=budgets))
    result=dict(records=results,gap_fraction=g,limits=[
      'No missing-wavelength clamp:380-780nm is bracketed by native extracted pixels for both sources.',
      'Pixel diagnostics shift x by1px, each y by2px and vertical span by2px; they are NOT experimental confidence intervals and exclude optical reference or curve-state assignment ambiguity.',
      'Ding figure reproduced by authors institution; full publisher text/SI retrieval returned403/404, and optical reference, exact spectral biases and test temperature remain unresolved.',
      'A whole-device transmission trace is not a transferable n/k input; no replacement of glass, electrolyte, electrode or active-layer thickness is validated by this diagnostic.',
      'Venugopal Figure5a and Figure5e have different bleached amplitudes; device history/measurement condition cannot be silently conflated.',
      'The hypothetical split calculation assumes zero adverse EC thermal drift and constant EC contrast at both temperatures; it is a necessary amplitude diagnostic only.',
      'Neither source supplies the required same-common-voltage two-temperature four states. No manufacturing or strictA/B certification.'],full_problem_solved=False)
    (OUT/'results.json').write_text(json.dumps(result,indent=2),encoding='utf8');(OUT/'source.py').write_bytes(Path(__file__).read_bytes());print(json.dumps(result))

if __name__=='__main__':main()
