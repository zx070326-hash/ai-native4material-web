"""A separate audit of the retained image trace against a single-front-cap TC."""
from pathlib import Path
import json,hashlib

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'runs/20261106-q2-parallel-amplitude-03'

def main():
    OUT.mkdir(exist_ok=False)
    paths=[ROOT/'runs/20261106-q2-parallel-amplitude-02/results.json',ROOT/'runs/20261106-q2-tc-material-target-01/results.json']
    amplitude,target=[json.loads(p.read_text())for p in paths]
    best=max((r for r in target['records']if not r['rear_AR']),key=lambda r:r['local_NIR_signed_delta'])
    ec=amplitude['records'][0];b=best['local_NIR_signed_delta'];rows=[]
    for name,a in [('nominal_pixels',ec['VIS_signed_delta']),('low_pixel_contrast',ec['pixel_diagnostic_delta_range'][0]),('high_pixel_contrast',ec['pixel_diagnostic_delta_range'][1])]:
        rows.append(dict(EC_case=name,EC_amplitude=a,TC_amplitude=b,maximum_inactive_fraction_exclusive=1-.3/a-.2/b,area_open_interval_at_two_percent_gap=[.3/(.98*a),1-.2/(.98*b)]))
    result=dict(TC_record=best,Ding_combinations=rows,source_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()for p in paths},limits=['Film1 source onSi/nativeoxide;79nm is within reported70+/-9nm source interval but constantnk through thickness range and transfer to8um mica remain assumptions.','Single375.187947nm front cap; no rear coating or handling is needed for this necessary-amplitude diagnostic.','Ding figure mode-to-common-voltage assignment, optical reference and EC two-temperature spectra remain unresolved.','Finite pixel scenarios are not measured confidence bounds; no manufacturing, tolerance, strictA/B or four-state pass.'],full_problem_solved=False)
    (OUT/'results.json').write_text(json.dumps(result,indent=2));(OUT/'source.py').write_bytes(Path(__file__).read_bytes());print(json.dumps(result))

if __name__=='__main__':main()
