"""Independent joint feasibility bounds for the three Q2 research lines.

This is an area-budget calculation, not a new optical/electrochemical model.
The factor m scales both original modulation targets together.  m <= 1
rules out this precise positive-contrast partition under the stated inputs,
including temperature-independent EC for the disclosed-device combination.
"""
from pathlib import Path
import hashlib
import json
import numpy as np
from scipy.optimize import linprog

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "runs/20261106-q2-parallel-joint-feasibility-02"


def solve(coefficients, gap=0.02, eta=1.0):
    # Variables f (fraction of active area assigned to EC) and m.
    # For each supplied scenario: VIS >= .30*m and NIR >= .20*m.
    matrix, upper = [], []
    for a, b, q in coefficients:
        matrix.extend([[-(1-gap)*eta*a, .30],
                       [(1-gap)*(b+(1-eta)*q), .20]])
        upper.extend([0.0, (1-gap)*b])
    opt = linprog([0.0, -1.0], A_ub=matrix, b_ub=upper,
                  bounds=[(0.0, 1.0), (0.0, None)], method="highs")
    if not opt.success:
        raise RuntimeError(opt.message)
    f, m = map(float, opt.x)
    value = np.array([[(1-gap)*eta*a*f,
                       (1-gap)*(b*(1-f)-(1-eta)*q*f)]
                      for a, b, q in coefficients])
    return {"EC_fraction_of_active_area": f, "common_target_factor": m,
            "worst_main_modulation": value.min(axis=0).tolist(),
            "strict_amplitude_targets_feasible": m > 1.0,
            "constraint_residual_max": float(np.max(np.array(matrix) @ opt.x - upper))}


def main():
    OUT.mkdir(exist_ok=False)
    paths = [ROOT / "runs/20261106-q2-process-order-03/results.json",
             ROOT / "runs/20261106-q2-patent-device-trace-02/results.json",
             ROOT / "runs/20261106-q2-tc-material-target-01/results.json"]
    process, trace, target = [json.loads(p.read_text(encoding="utf-8")) for p in paths]
    chosen = next(r for r in process["records"] if r["name"] == "finish_TC_first_LiNiO_first")
    c = chosen["local_coefficients"]
    nominal = [(c["a_VIS_EC"], c["b_NIR_TC"], c["q_NIR_EC"])]
    scenarios = []
    for row in chosen["scenario16"]:
        s = row["summary"]
        # Recover coefficients only under the original eta=1 partition model.
        scenarios.append((s["visible_voltage_delta_min"]/(.98*.44),
                          s["nir_temperature_delta_min"]/(.98*.56),
                          s["nir_voltage_cross_max"]/(.98*.44)))
    rows = []
    for eta in [1.0, .98, .95, .9]:
        rows.append({"case": "transferred_chemical_endpoints_nominal", "gap": .02,
                     "eta": eta, **solve(nominal, eta=eta)})
        rows.append({"case": "same_endpoints_16_specified_correlated_scenarios", "gap": .02,
                     "eta": eta, **solve(scenarios, eta=eta)})
    observed = trace["VIS_voltage_delta"]
    best_screened_tc = max(r["local_NIR_signed_delta"] for r in target["records"])
    for name, a in [("central_disclosed_EC", observed),
                    ("favourable_vertical_pixel_and_edge_EC", trace["vertical_diagnostics_plus_arbitrary_low_edge"][1])]:
        for thermal_name, b in [("current_conditional_TC", nominal[0][1]),
                                ("best_bounded_screen_TC", best_screened_tc)]:
            for gap in [.02, 0.0]:
                result = solve([(a, b, 0.0)], gap=gap)
                analytic = (1-gap)/(.30/a+.20/b)
                assert abs(result["common_target_factor"]-analytic) < 1e-12
                rows.append({"case": name+"_"+thermal_name, "gap": gap, "eta": 1.0,
                             "local_a": a, "local_b": b, "analytic_factor": analytic, **result})
    # Required a and b are strict thresholds, not achieved material values.
    required = {"current_TC_requires_EC_VIS_g02": .30/(.98-.20/nominal[0][1]),
                "best_screened_TC_requires_EC_VIS_g02": .30/(.98-.20/best_screened_tc),
                "central_disclosed_EC_requires_TC_NIR_g02": .20/(.98-.30/observed)}
    output = {"source_sha256": {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
              "rows": rows, "strict_required_local_amplitudes": required,
              "limits": ["Independent arithmetic/linear-program audit of the positive-contrast area model only.",
                         "Disclosed EC and modeled TC are different specimens/processes; their combination is hypothetical.",
                         "No raw four-state optical constants, common operating voltages or fabrication certification are inferred.",
                         "The disclosed-device combination assumes temperature-independent EC. Beneficial EC thermal response could relax this bound and is not excluded.",
                         "eta is the existing specific dark-state contraction model, not measured drift tolerance.",
                         "Sixteen scenarios are correlated finite optical scenarios, not independent process tolerances.",
                         "These bounds do not exclude other materials, overlaps, coherent structures or optical routing.",
                         "m=1 gives equality; the original targets require strictly greater values."],
              "full_problem_solved": False, "fabrication_certified": False}
    (OUT/"results.json").write_text(json.dumps(output, indent=2), encoding="utf-8")
    (OUT/"source.py").write_bytes(Path(__file__).read_bytes())
    print(json.dumps({"rows": rows, "required": required}, indent=2))


if __name__ == "__main__":
    main()
