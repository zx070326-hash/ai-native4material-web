"""Numeric geometry/mechanical checks for the separately identified Ding2025 EC.

No optical constants or manufacturing parameters are inferred from SEM.
"""
from pathlib import Path
import json,hashlib,sys
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'experiments'))
from q2_parallel_process_20261106 import laminate

def main():
    out=ROOT/'runs/20261106-q2-ding-process-addendum-01'
    out.mkdir(exist_ok=False)
    figure=ROOT/'data/q2_parallel_amplitude_20261106/Ding2025_Tsinghua_fig2.png'
    films=[{'name':'ITO_bottom','material':'ITO','d_nm':150},
      {'name':'NiO','material':'NiO','d_nm':850},
      {'name':'LiNbO3','material':'LiNbO3','d_nm':60},
      {'name':'WO3','material':'WO3','d_nm':700},
      {'name':'ITO_top','material':'ITO','d_nm':120}]
    new=sum(x['d_nm']for x in films);old_functional=200+150+200+480+200;old_cap=380
    counts=[]
    for extra_cap_nm in [0,380]:
        for supports in [1,2]:
            counts.append({'interpretation':'conditionalnewEC+TC processproposal, NOTreportedDingdevice',
              'EC_terminal_cap_nm':extra_cap_nm,'retained_mica_sheets':supports,
              'aperture_entity_count':supports+5+2+int(extra_cap_nm>0),
              'maximum_EC_path_layers':1+5+int(extra_cap_nm>0),
              'maximum_TC_path_layers':3,
              'EC_total_geometric_path_nm':8000+new+extra_cap_nm,
              'TC_total_geometric_path_nm':8000+70+400,
              'all_listed_layer_thicknesses_10_to10000nm':True,
              'layercount_le20':True,
              'limits':'sourceglass replaced bymica8um; neitherresponse nor processingcertified. Two supports meansside-by-side coupons, notserialstack.'})
    E={'ITO':150.,'NiO':150.,'LiNbO3':100.,'WO3':100.,'AlOx':200.}
    def layer(name,d,E):return{'name':name,'d_um':d,'E_GPa':E,'nu':.25}
    mechanical=[]
    for cap_nm in [0,380]:
        ls=[layer('mica',8.,178.3)]+[layer(x['name'],x['d_nm']/1000,E[x['material']])for x in films]
        if cap_nm:ls.append(layer('AlOx',cap_nm/1000,E['AlOx']))
        stress=np.r_[0.,np.full(len(ls)-1,100.)]
        mechanical.append({'cap_nm':cap_nm,'layers':ls,'held_flat_coating_stress_MPa':100,
            **laminate(ls,stress),
            'limits':'Allcoatingmoduli andPoisson aredeclaredproxies.100MPa isunitload notmeasuredstress. Localfreeequibiaxialstrip,nocoupledzoneplate orclamp solved.'})
    paths=['data/q2_parallel_amplitude_20261106/Ding2025_Tsinghua_fig2.png',
      'data/q2_parallel_amplitude_20261106/Ding2025_Tsinghua.html',
      'data/q2_parallel_amplitude_20261106/receipts.json',
      'data/q2_parallel_amplitude_20261106/followup2_receipts.json',
      'data/q1_gap_sources/Ke2016_ITO_mica_SI.pdf']
    result={'identity':'Dingetal2025DOI10.1039/D5EE02750K, separatefromLiNiO/LiTaO3candidate',
      'thickness_source':'AuthorinstitutionFigure2b yellowSEMannotations visuallyread, notnewSEMmeasurement',
      'reported_stack_bottom_up':['glass']+[x['material']for x in films],
      'reported_glass_thickness_nm':None,'glass_thickness_constraint_pass':None,
      'coating_layers':films,'reported_coating_count':5,'reported_finite_path_layers_if_glass_is_one':6,
      'reported_film_thickness_constraints_pass':all(10<=x['d_nm']<=10000 for x in films),
      'reported_total_coating_nm':new,'prior_functional_coating_nm':old_functional,
      'functional_thickness_increase_percent':100*(new/old_functional-1),
      'new_coating_vs_old_with_cap_increase_percent':100*(new/(old_functional+old_cap)-1),
      'new_plus380cap_vs_old_with_cap_increase_percent':100*((new+380)/(old_functional+old_cap)-1),
      'conditional_combination_ledger':counts,'mechanical_unit_diagnostics':mechanical,
      'original_process_evidence':{'method':'notrecoveredforDPRW','substrate_temperature_C':None,
        'anneal_C':None,'pressure_Pa':None,'gas_flow':None,'lithium_loading':None,
        'importantdistinction':'Tsinghuaofficialnews explicitlycalls opaqueSDRCR WO3nanocrystals magnetronsputtered. Thatdoesnotitselfestablish everyDPRWlayerprocess.',
        'SI':'Saved.pdfresponsesare403/404HTML, notsupportinginformation; priorretrievalreceiptsretained.'},
      'thin_support_evidence':{'for_exactDingstack':False,
        'nearbyprimary':'Ke2016SI demonstratesITOon<15ummica byRTPLD andseparateanneal; notNiO850/LiNbO360/WO3700 stack',
        'supportreplacement':'Replacingglasswith8ummicarequiresfreshoptical/thinfilm/processvalidation; fullglassdeviceTcannotbemappedbyBeerLambertalone.'},
      'required_changes':['Chooseactual<=10umsupportandverifyprocessing; originalglass thickness/compositionunknown.',
        'PreserveNiO/LiNbO3 identities: noLiNiO/LiTaO3 sourceconstants/capacity transfer.',
        'Foronesheetarea-splitprototype, completeVO2anditsprotectionbeforeDingEC; obtainDingmaxprocessTandplasmaexposuresfirst.',
        'IfECterminalcapisadded, revalidateactualprotecteddeviceoptics/capchemistry ratherthanreuseuncappedFigurespectrum.',
        'PatternseparateITOcontactlandswithfiniteguardandtopwindow; boundaryalignmentandshortingstillmatter.',
        'ObtainsamefixedvoltagepairatbothTCtemperatures; voltage-drivenNIR changeisnottemperaturemainresponse.',
        'Retainedsupports/leads/edge sealsmustbeincluded; removabletestfixturedoesnotcertifypackageddevice.'],
      'sourcefiles':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest()for p in paths},
      'A_status':'notcertified; noDingmatchingn/k; oldITO/hotVO2counterexamplecannotbeclaimedexactDingmeasurement',
      'B_status':'notcertified; noexactDingnominaln/kofNiO/LiNbO3/support',
      'fabrication_certified':False,'full_problem_solved':False}
    (out/'results.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf8')
    (out/'source.py').write_bytes(Path(__file__).read_bytes())
    print(json.dumps({'films_nm':new,'counts':counts,'mechanical_sag_um':[x['parabolic_2mm_chord_sag_um']for x in mechanical]},ensure_ascii=False))

if __name__=='__main__':main()
