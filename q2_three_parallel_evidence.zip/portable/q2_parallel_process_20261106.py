"""Q2 process ledger, stencil guard budget and local laminate sensitivity.

The optical calculation is an algebraic reweight of the frozen process-order
candidate.  It does not turn the transferred chemical endpoints into measured
four-state materials.  Mechanics uses stated unit loads, not measured stress.
"""
from pathlib import Path
import argparse, hashlib, json, itertools
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def laminate(layers, stress_mpa):
    """Free equibiaxial flat-reference laminate; z=0 is mica bottom.

    stress_mpa defines each layer's stress if held at zero reference strain,
    not its relaxed stress.  The plane-stress biaxial modulus is E/(1-nu).
    """
    z = np.r_[0., np.cumsum([x['d_um'] * 1e-6 for x in layers])]
    M = np.array([x['E_GPa'] * 1e9 / (1-x['nu']) for x in layers])
    eps_star = -np.asarray(stress_mpa) * 1e6 / M
    A = np.sum(M*np.diff(z))
    B = np.sum(M*np.diff(z*z)/2)
    D = np.sum(M*np.diff(z*z*z)/3)
    load = np.array([np.sum(M*eps_star*np.diff(z)),
                     np.sum(M*eps_star*np.diff(z*z)/2)])
    eps0, kappa = np.linalg.solve([[A, B], [B, D]], load)
    # Independent three-point Gauss integration checks resultant equilibrium.
    xx, ww = np.polynomial.legendre.leggauss(3)
    force = moment = energy = 0.
    for i in range(len(layers)):
        zg = (z[i]+z[i+1])/2 + xx*(z[i+1]-z[i])/2
        weight = ww*(z[i+1]-z[i])/2
        strain = eps0+kappa*zg-eps_star[i]
        sigma = M[i]*strain
        force += np.sum(sigma*weight)
        moment += np.sum(sigma*zg*weight)
        energy += np.sum(.5*M[i]*strain*strain*weight)
    assert abs(force) < 1e-7 and abs(moment) < 1e-11
    return {'midplane_strain': float(eps0+kappa*z[-1]/2),
            'curvature_m_inv': float(kappa),
            'parabolic_2mm_chord_sag_um': float(kappa*(2e-3)**2/8*1e6),
            'force_residual_N_per_m': float(force),
            'moment_residual_N': float(moment), 'energy_J_per_m2': float(energy)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default='runs/20261106-q2-parallel-process-04')
    args = ap.parse_args()
    out = ROOT / args.out
    out.mkdir(parents=True, exist_ok=False)
    source_path = ROOT/'runs/20261106-q2-process-order-03/results.json'
    source = json.loads(source_path.read_text())
    selected = next(r for r in source['records'] if r['name']=='finish_TC_first_LiNiO_first')
    summaries = [selected['metrics']['summary']] + [r['summary'] for r in selected['scenario16']]
    threshold = np.array([.3, .2])
    main_keys = ['visible_voltage_delta_min', 'nir_temperature_delta_min']
    base = np.array([[r[k] for k in main_keys] for r in summaries])
    base_gap, aperture_um = .02, 2000.
    # A deliberately patterned state-invariant bare-mica guard can be
    # widened while retaining the EC/TC ratio f=.44 in the remaining area.
    gap_max = 1-(1-base_gap)*np.max(threshold/base, axis=1)
    # A physical central stencil setback removes the same width from each
    # zone, so the remainingf changes slightly.  Ateta=1, ECtemperature
    # response andTCvoltage response are fixed, and eachmain comes solely
    # from its own zone. Recover the per-zone contrasts from frozen metrics.
    local=np.column_stack([base[:,0]/(.98*.44),base[:,1]/(.98*.56)])
    symmetric_s_max=np.min((base-threshold)*aperture_um/local,axis=1)
    guard_rows=[]
    for width in [40., 50., 60., 70., 80., 90., 100., 120.]:
        scale=(1-width/aperture_um)/(1-base_gap)
        mm=base*scale
        guard_rows.append({'guard_width_um': width,
            'nominal_VIS_NIR_pp': (100*mm[0]).tolist(),
            'minimum16_VIS_NIR_pp': (100*mm[1:].min(axis=0)).tolist(),
            'scenario16_passing': int(np.all(mm[1:]>threshold,axis=1).sum())})
    symmetric_rows=[]
    for width in [40.,50.,60.,70.,80.,90.,100.,120.]:
        setback=(width-40)/2
        mm=base-local*setback/aperture_um
        symmetric_rows.append({'total_guard_width_um':width,'each_zone_setback_um':setback,
            'remaining_EC_fraction':(.98*.44-setback/aperture_um)/(1-width/aperture_um),
            'nominal_VIS_NIR_pp':(100*mm[0]).tolist(),
            'minimum16_VIS_NIR_pp':(100*mm[1:].min(axis=0)).tolist(),
            'scenario16_passing':int(np.all(mm[1:]>threshold,axis=1).sum())})
    worst_width=float(gap_max[1:].min()*aperture_um)
    # These are geometric blur inputs, not a claimed sputtering angular
    # distribution.  Both deposited zones are deliberately set back.
    registration=[]
    for error, gap, angle in itertools.product([0.,5.,10.,20.,25.], [0.,25.,50.,100.], [5.,10.,20.]):
        blur=gap*np.tan(np.deg2rad(angle))
        width=40+2*(error+blur)
        m=base[1:]-local[1:]*(error+blur)/aperture_um
        registration.append({'single_edge_registration_um':error,
            'mask_sheet_gap_um':gap, 'flux_half_angle_deg':angle,
            'geometric_single_edge_blur_um':float(blur),
            'designed_guard_width_um':float(width),
            'minimum16_VIS_NIR_pp': (100*m.min(axis=0)).tolist(),
            'scenario16_passing':int(np.all(m>threshold,axis=1).sum())})
    # A separate bound treats newly unmodelled area p as capable of any
    # state-dependent 0<=T<=1 response; it cannot use the zero-response guard.
    # Removing p proportionally from the frozen functional area gives
    # Delta_lower = Delta0*(1-p/(1-g0))-p. This is not a shape prediction.
    arbitrary_p=(base-threshold)/(1+base/(1-base_gap))
    edge_bound={'nominal_total_arbitrary_edge_width_um':float(arbitrary_p[0].min()*aperture_um),
        'minimum16_total_arbitrary_edge_width_um':float(arbitrary_p[1:].min()*aperture_um),
        'formula':'D_lower=D0*(1-p/(1-g0))-p, proportional functional-area removal, p is total uncertain edge fraction',
        'limits':'A worst-case optical-area diagnostic, not a measured edge response or a new acceptance requirement.'}

    # All coating mechanical moduli and nu are explicit diagnostic values.
    # Mica E=178.3GPa is an in-plane tensile value on a different20um sheet;
    # AFM normal indentation5.4GPa must not silently replace it.
    def layer(name,d,E,nu=.25):
        return {'name':name,'d_um':d,'E_GPa':E,'nu':nu}
    ec=[layer('mica',8.,178.3),layer('ITO_bottom',.2,150),
        layer('LiNiO',.15,150),layer('LiTaO3_mechanics_proxy',.2,100),
        layer('WO3',.48,100),layer('ITO_top',.2,150),layer('AlOx',.38,200)]
    tc=[layer('mica',8.,178.3),layer('VO2',.07,140),layer('AlOx',.4,200)]
    mechanics_analytic=[]
    for ls in [ec,tc]:
        zero=laminate(ls,np.zeros(len(ls)))
        common_eigenstrain=1e-4
        imposed=[-x['E_GPa']*1e3/(1-x['nu'])*common_eigenstrain for x in ls]
        free=laminate(ls,imposed)
        assert abs(zero['curvature_m_inv'])<1e-12
        assert abs(free['curvature_m_inv'])<1e-10
        assert abs(free['midplane_strain']-common_eigenstrain)<1e-14
        mechanics_analytic.append({'layers':len(ls),'zero_load_curvature':zero['curvature_m_inv'],
            'common_eigenstrain_curvature':free['curvature_m_inv'],
            'common_eigenstrain_error':free['midplane_strain']-common_eigenstrain})
    mechanical=[]
    for name, layers in [('EC',ec),('TC',tc)]:
        for substrate_E in [115.,178.3,190.]:
            ls=[dict(x) for x in layers];ls[0]['E_GPa']=substrate_E
            for case in ['all_coatings_100MPa','cap_only_100MPa']:
                stress=np.r_[0.,np.full(len(ls)-1,100.)] if case.startswith('all') else np.r_[np.zeros(len(ls)-1),100.]
                mechanical.append({'zone':name,'mica_E_GPa':substrate_E,
                    'unit_load_case':case,'layers':ls,'held_flat_stress_MPa':stress.tolist(),
                    **laminate(ls,stress)})

    ledger=[
      {'entity':'shared_muscovite','d_nm':8000,'zone':'all','A_status':'unresolved matching tensor','B_status':'nominal literature support near532nm, no matching550nm30C datum'},
      {'entity':'VO2','d_nm':70,'zone':'TC','A_status':'fail: source hot n_min1.34022','B_status':'source-film nominal reference only; deposition migration unresolved'},
      {'entity':'TC_AlOx','d_nm':400,'zone':'TC','A_status':'source model condition','B_status':'electron-beam source != proposedDC-sputter'},
      {'entity':'EC_bottom_ITO','d_nm':200,'zone':'EC','A_status':'fail: n_min0.23','B_status':'source-film nominal reference only'},
      {'entity':'LiNiO','d_nm':150,'zone':'EC','A_status':'exact source table within1.5-3','B_status':'chemical endpoints not device voltages'},
      {'entity':'LiTaO3','d_nm':200,'zone':'EC','A_status':'unresolved; Ta2O5 optical proxy','B_status':'unresolved; Ta2O5 is notLiTaO3'},
      {'entity':'WO3','d_nm':480,'zone':'EC','A_status':'source model condition','B_status':'chemical endpoints not device voltages'},
      {'entity':'EC_top_ITO','d_nm':200,'zone':'EC','A_status':'fail: n_min0.23','B_status':'source-film nominal reference only'},
      {'entity':'EC_AlOx','d_nm':380,'zone':'EC','A_status':'source model condition','B_status':'electron-beam source != proposedDC-sputter'},
    ]
    perimeter=[
      {'part':'bottom/top contact lands and lead traces','retained':True,'proposal':'same200nmITO extends beyond aperture onto separate200um-wide lands; no new coating entity','open_issue':'ITO resistance/contact-interface and edge-step isolation; overlap pattern must keep opposite electrodes separated'},
      {'part':'external electrical probes','retained':False,'proposal':'removable probes land on exposedITO outside optical aperture','open_issue':'not a packaged/free-operating device; if bonded wires/paste are retained they require new material/geometry entries'},
      {'part':'high-temperature clamp and process carrier','retained':False,'proposal':'edge-only clean mechanical clamp, fresh mica initially8um; avoid adhesive sacrificial stack and avoid post-EC peeling','open_issue':'8um sample handling, thermal contact, slip, particle and residual-curvature evidence missing; permanent frame may not be silently excluded'},
      {'part':'perimeter seal','retained':'not designed','proposal':'top cap deposited through dedicated pad-window mask, all functional edges deliberately recessed','open_issue':'top coverage is not sidewall or terminal-edge hermeticity. No seal material/thickness/compatibility has been certified'},
      {'part':'optional permanent support or backing','retained':'not included','proposal':'no thick glass or polymer backing in optical aperture','open_issue':'adding a backing is a design change: enforce10-10000nm per layer and include full n/k and path count'},
    ]
    sequence=[
      {'step':0,'operation':'prepare final-thickness8um mica and reserve uncoated handling/contact border','retained_additions':0,'condition':'pre-cleave; do not grow on thick mica then claim post-EC cleavage preserves multilayer'},
      {'step':1,'operation':'mechanically hold perimeter; fresh cleave surface; deposit70nmVO2 onTC zone','retained_additions':1,'condition':'400C pulsed sputter demonstrated17-180nm on mica, not same8um sample/full optical constants'},
      {'step':2,'operation':'deposit400nmTCAlOx through zone mask beforeEC processing','retained_additions':1,'condition':'Ji2014 only10-100nm on1mmglass;400nm stress/barrier/plasma compatibility open'},
      {'step':3,'operation':'200nmITO bottom with exposed separate contact land','retained_additions':1,'condition':'150C patent setting; not reuse500CITO post-anneal afterVO2/EC'},
      {'step':4,'operation':'150nmLiNiO /200nmLiTaO3 /480nmWO3 /200nmITO top on progressively registered masks','retained_additions':4,'condition':'RT settings are patent analogs; Li loading, capacity and source n/k migration not proved'},
      {'step':5,'operation':'380nmECAlOx while leaving contact windows open','retained_additions':1,'condition':'no full edge seal inferred; guard calculation assumes intentionally film-free mica, not partially coated tails'},
      {'step':6,'operation':'remove process clamp without peeling optical stack; use border for characterization','retained_additions':0,'condition':'free-sheet plan only; a durable retained mount remains an explicit missing assembly'},
    ]
    sources={
      'Ke2016_SI':{'path':'data/q1_gap_sources/Ke2016_ITO_mica_SI.pdf','url':'https://ndownloader.figshare.com/files/6481191','finding':'fresh-cleaved<15um mica, RTPLD ITO, separate0-500Canneal30min; optics200-800nm'},
      'Ekstrom2023':{'path':'data/q2_process_closure_20261106/Ekstrom2023_mica.pdf','url':'https://www.diva-portal.org/smash/get/diva2%3A1894586/FULLTEXT01.pdf','finding':'400CVO2 on mica17-180nm; weak interface/stress-free crystal does not imply cap-stack stress-free'},
      'Ji2014':{'path':'data/q2_process_closure_20261106/AlOx2014_protection.pdf','url':'https://www.diva-portal.org/smash/get/diva2%3A766395/FULLTEXT02.pdf','finding':'unheatedAlOx10/30/100nm onVO280nm/1mmglass; no400nm thinmica barrier certificate'},
      'CN112649997A':{'path':'data/q2_process_closure_20261106/CN112649997A.pdf','url':'https://patents.google.com/patent/CN112649997A/zh','finding':'example9 has6finite films onglass, bottomITO150C, subsequentRTsetpoints; gas wording inconsistent'},
      'Hayrapetyan2026':{'path':'data/q1_gap_sources/Hayrapetyan2026_mica.pdf','finding':'measured tensor250-1000nm, model extrapolation1000-1800nm, ny1.595@532nm; no8um30/100CfullNIRtable'},
      'Alghamdi2011':{'url':'https://yjes.researchcommons.org/yjes/vol3/iss1/4/','finding':'in-plane tensile178.3GPa on20um mica and115GPa on94um; not certified8um modulus'},
      'Jin2018':{'url':'https://qfml.cafe24.com/publication/112.pdf','finding':'normalAFMHertz mean5.4GPa; authors distinguish bulk-sensitive moduli; not valid substitute forin-plane tensile stiffness'},
      'Kim2025':{'url':'https://research.knu.ac.kr/en/publications/resistive-and-photocurrent-switching-behaviors-of-a-flexible-vosu/','finding':'author university abstract confirms3umVO2/mica andstableMIT under±0.2mm^-1; fullmethodnotrecovered, notwindowfourstates'},
    }
    for record in sources.values():
        if 'path' in record:
            record['sha256']=next(v['sha256'] for v in json.loads((ROOT/'reference/process/results.json').read_text(encoding='utf-8'))['sources'].values() if v.get('path')==record['path'])
    # Rebuild selected nominal spectra, then change actual area widths rather
    # than just scaling reported band numbers. This checks bothguard models.
    sys.path.insert(0,str(ROOT))
    from src.optics import stack_rt, four_state_metrics
    with np.load(source_path.parent/'spectra.npz') as zz:
        w=zz['wavelength_um'].copy()
        reference=zz[selected['name']].copy()
    n={}
    for name, rec in source['source_files'].items():
        a=np.loadtxt(ROOT/rec['path'],delimiter=',',skiprows=1)
        assert w[0]>=a[0,0] and w[-1]<=a[-1,0]
        n[name]=np.interp(w,a[:,0],a[:,1])+1j*np.interp(w,a[:,0],a[:,2])
    mica=np.full(len(w),1.58+0j)
    e=[];t=[]
    for state in ['clear','dark']:
        ns=np.array([mica,n['ITO'],n['NiO_'+state],n['ion'],n['WO3_'+state],n['ITO'],n['cap']])
        e.append(stack_rt(w,ns,np.array([8.,.2,.15,.2,.48,.2,.38]))[1])
    for temp in ['cold','hot']:
        t.append(stack_rt(w,np.array([mica,n[temp],n['cap']]),np.array([8.,.07,.4]))[1])
    bare=stack_rt(w,np.array([mica]),np.array([8.]))[1]
    spectral_checks=[];saved={}
    for width in [40.,80.,100.]:
        for model in ['fixed_f','symmetric']:
            g=width/aperture_um
            f=.44 if model=='fixed_f' else (.98*.44-(width-40)/2/aperture_um)/(1-g)
            tt=np.array([[(1-g)*(f*e[v]+(1-f)*t[temp])+g*bare for temp in range(2)]for v in range(2)])
            mm=four_state_metrics(w,tt,{'visible':(.38,.78),'nir':(.78,2.5)})['summary']
            got=np.array([mm[k] for k in main_keys])
            want=base[0]*(1-g)/.98 if model=='fixed_f' else base[0]-local[0]*(width-40)/2/aperture_um
            error=float(np.max(abs(got-want)))
            assert error<1e-12
            if width==40:assert np.max(abs(tt-reference))<1e-12
            spectral_checks.append({'width_um':width,'model':model,'band_error':error})
            saved[model+'_'+str(int(width))+'um']=tt
    np.savez_compressed(out/'spectra.npz',wavelength_um=w,**saved)
    result={'scope':'Q2 process closure contribution; no new material or four-state certification',
      'selected_configuration':selected['name'], 'source_sha256':hashlib.sha256(source_path.read_bytes()).hexdigest(),
      'guard_model':{'fixed_remaining_EC_fraction':.44,'base_guard_um':40.,'aperture_width_um':2000.,
        'nominal_max_total_guard_um_exclusive':float(gap_max[0]*aperture_um),
        'minimum16_max_total_guard_um_exclusive':worst_width,
        'minimum16_single_edge_extra_budget_um_exclusive':(worst_width-40)/2,
        'rows':guard_rows,'registration_diagnostics':registration,
        'limits':'ProportionalEC/TCarea reduction at fixedf, uniform incident power and fullaperture collection. Intentionally baremica has zero response. Lateral boundary diffraction/partialfilm tails not solved. eta=1 only; eta<1 joint failures cannot inherit thisbudget.'},
      'symmetric_central_setback':{'nominal_each_zone_setback_um_exclusive':float(symmetric_s_max[0]),
        'minimum16_each_zone_setback_um_exclusive':float(symmetric_s_max[1:].min()),
        'minimum16_max_total_guard_um_exclusive':float(40+2*symmetric_s_max[1:].min()),
        'rows':symmetric_rows,
        'limits':'Equal geometric setback on each zone. Remainingf is recomputed, not held at.44. eta=1 only, localcontrastrecovers currentfixedtemperatureEC assumption. Mechanical/opticalboundaryquality remainsconditional.'},
      'arbitrary_edge_bound':edge_bound,'local_strip_mechanics':mechanical,
      'mechanical_limits':['Equibiaxial isotropic layer diagnostic, no measured residualstress or thermalstrain; coatingmoduli andPoisson are declared proxies.',
        'No coupled twozone plate shape, interlayer slip/delamination/fracture, boundaryclamp or opticalfeedback solved.',
        'Unit100MPa load is a sensitivity probe, not a manufacturing range or strain acceptance threshold.',
        'Local curvature can make mask gaps important; free-sheet results do not certify process-held surface shape.'],
      'mechanics_analytic_controls':mechanics_analytic,
      'retained_aperture_ledger':ledger,'perimeter_ledger':perimeter,'proposed_sequence':sequence,'sources':sources,
      'aperture_entities':len(ledger),'maximum_EC_path_layers':7,'maximum_TC_path_layers':3,
      'EC_total_geometric_path_um':sum(x['d_um'] for x in ec),
      'TC_total_geometric_path_um':sum(x['d_um'] for x in tc),
      'nominal_reference_550nm_source_model':{
          k:{'n':float(np.interp(.55,w,v.real)),'k':float(np.interp(.55,w,v.imag))}for k,v in n.items()},
      'nominal_reference_limits':'These are source-film/model entries, not allsameprocess nor all30C. ion denotesTa2O5proxy notLiTaO3; sourceVO2 cold30C/hot100C. Mica nominaln1.58 is a separate scalarproxy. Passing individualn atreference doesnot certify physicalfullB.',
      'aperture_layer_thickness_constraints_pass':all(10<=x['d_nm']<=10000 for x in ledger),
      'full_spectrum_guard_crosscheck':spectral_checks,
      'strict_A_pass':False,'full_B_certified':False,'fabrication_certified':False,'full_problem_solved':False}
    (out/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'source.py').write_bytes(Path(__file__).read_bytes())
    print(json.dumps({'guard_limits':{k:v for k,v in result['guard_model'].items() if k not in ['rows','registration_diagnostics','limits']},
      'edge_bounds':edge_bound,'mechanics':[{'zone':x['zone'],'E':x['mica_E_GPa'],'case':x['unit_load_case'],'sag_um':x['parabolic_2mm_chord_sag_um']}for x in mechanical]},ensure_ascii=False))


if __name__=='__main__':
    main()
