"""New25/50C source-supported dielectric scenario; actual64x33 source solves.

Four external-electrode Gauss/Frank states and two9.8um zero-field thermal
states. Original15/50C fields are initial guesses only, never renamed outputs.
"""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import argparse,hashlib,importlib.metadata,json,sys,time
from pathlib import Path
import numpy as np
from scipy.interpolate import RegularGridInterpolator
from scipy.optimize import minimize
from autograd import value_and_grad
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments.q2_finish_external_gauss_20261105 import ExternalElectric,EPS0
from experiments.q2_manufacturing_lc_director2d import problem,initial

CONSTITUTIVE=ROOT/'runs/20261105-q2-finish-decouple-E7-constitutive-digitized-01/results.json'
PREDICTION=ROOT/'runs/20261105-q2-finish-decouple-source25-1D-02/results.json'
EWARM=ROOT/'runs/20261105-q2-finish-external-director64-support32-01/fields.npz'
TWARM=ROOT/'runs/20261105-q2-package-A-director64-d1p45-02/fields.npz'
NX,NZ,NS,VFIX=64,33,32,9.235
TEMPS=[25,50]
TAB=np.loadtxt(ROOT/'data/q2_current/Li2005_E7_Cauchy.csv',delimiter=',',skiprows=1)


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,d):Path(p).write_text(json.dumps(d,indent=2),encoding='utf-8')
def K_at(T):
    def dn(temp):
        row=TAB[TAB[:,0]==temp];assert len(row)==1
        r=row[0,1:];w=.589
        return r[0]-r[3]+(r[1]-r[4])/w**2+(r[2]-r[5])/w**4
    return np.array([11.1,6.5,17.1])*(dn(T)/dn(25))**2
def parameters():
    src=json.loads(CONSTITUTIVE.read_text())['dielectric_source'];ep=float(src['epsilon_perp25_lowV_approx']);de=[float(src[f'delta_epsilon{T}'])for T in TEMPS]
    assert ep==4.886949076291233 and de==[12.34304932735426,9.80080245456691]
    return {'temperatures_C':TEMPS,'epsilon_perp_by_T':[ep,ep],'delta_epsilon_by_T':de,'K_pN_by_T':[K_at(T).tolist()for T in TEMPS],'electric_comp_d_um':2.5,'electric_comp_P_um':12,'thermal_d_um':9.8,'thermal_P_um':24,'fixed_external_V_RMS':[0,VFIX],'Wa_Wp_J_m2':[1.14e-4,2e-4],'LC_nx_nz':[NX,NZ],'support_cells_each_side':NS,'support_um_each':8,'support_epsilon':9,'SiNx_um_each':.02,'SiNx_epsilon':7.5,'dielectric_source':src,'model_conditions':['epsilonperp25only;fixedat50ismodel','AllK25=[11.1,6.5,17.1]scaledbyLi2005dn589ratio^2ismodel,K3notnewmeasuredsource','SiNx/AlstaticpermittivityandWa/Wptransfers','Differentbatchdielectric/optics/anchoring;notmatchingdevicecertificate','Smoothfixedwindingsector,noions/conduction/dynamics/globaldefects']}


class Source25Electric(ExternalElectric):
    def __init__(self,d,P,K,nx,nz,V,ep,de,ns=NS):
        super().__init__(d,P,K,nx,nz,V,ns)
        self.ep=float(ep);self.de=float(de)


def checked(folder):
    c=json.loads((folder/'config.json').read_text())
    for p,h in c['SHA256'].items():assert sha(ROOT/p)==h, 'Frozen source changed: '+p
    assert c['parameters']==parameters()
    return c


def validate():
    rows=[];rng=np.random.default_rng(2026110525);nx,nz=16,9;cfg=parameters()
    for ti,T in enumerate(TEMPS):
        K=K_at(T);ep=cfg['epsilon_perp_by_T'][ti];de=cfg['delta_epsilon_by_T'][ti];ev=Source25Electric(2.5,12,K[0],nx,nz,VFIX,ep,de)
        flat=initial(nx,nz,'linear_phi');gr,psi,ck=ev.solve(flat);exact=EPS0/(K[0]*1e-12)*VFIX**2/(2*(1/ep+2*.02/(7.5*2.5)+16/(9*2.5)))
        q=initial(nx,nz,'perturbed');q[:nx*nz]+=.7*np.sin(np.linspace(0,np.pi,nz))[None,:].repeat(nx,0).ravel();direction=rng.normal(size=q.size);direction/=np.linalg.norm(direction);gr,_,qc=ev.solve(q);_,gg=ev.evg(q,gr);h=1e-5
        fd=(-ev.solve(q+h*direction)[2]['positive_electric_dimensionless']+ev.solve(q-h*direction)[2]['positive_electric_dimensionless'])/(2*h)
        f,_,_=problem(9.8,24,K.tolist(),nx,nz,Wp=2e-4,Wa=1.14e-4,pattern='8step');fv,fg=value_and_grad(f)(q);ffd=(f(q+h*direction)-f(q-h*direction))/(2*h)
        rows.append({'T_C':T,'epsilon_perp':ep,'delta_epsilon':de,'uniform_series_relative_error':float(abs(ck['positive_electric_dimensionless']/exact-1)),'fresh_Gauss_envelope_directional_gradient_abs_error':float(abs(fd-gg@direction)),'thermal9p8_Frank_directional_gradient_abs_error':float(abs(ffd-fg@direction)),'uniform_Gauss_residual':ck['Gauss_free_residual_inf']})
    assert max(r['uniform_series_relative_error']for r in rows)<1e-11
    assert max(r['fresh_Gauss_envelope_directional_gradient_abs_error']for r in rows)<1e-6
    assert max(r['thermal9p8_Frank_directional_gradient_abs_error']for r in rows)<1e-7
    return rows


def freeze(a):
    a.config.mkdir(parents=True,exist_ok=False)
    inputs=[Path(__file__).resolve(),CONSTITUTIVE,PREDICTION,CONSTITUTIVE.parent/'Basu2025_Fig4b_pureE7_1kHz.csv',CONSTITUTIVE.parent/'source.py',PREDICTION.parent/'source.py',EWARM,TWARM,ROOT/'data/q2_current/Li2005_E7_Cauchy.csv']
    for p in json.loads(CONSTITUTIVE.read_text())['input_sha256']:inputs.append(ROOT/p)
    for module in list(sys.modules.values()):
        fn=getattr(module,'__file__',None)
        if fn:
            p=Path(fn).resolve()
            if p.suffix=='.py'and p.is_relative_to(ROOT)and '.venv'not in p.parts:inputs.append(p)
    inputs=sorted(set(inputs))
    for p in inputs:
        target=a.config/'frozen'/p.relative_to(ROOT);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
    c={'parameters':parameters(),'SHA256':{str(p.relative_to(ROOT)):sha(p)for p in inputs},'validation':validate(),'warm_mapping_only':{'new25C':'old15C initial guess;equilibriumresolves25C','new50C':'old50C initialguess;newdielectricandnewthermal9.8resolve','electric_on_seed':'old12.235V initialguess;actualnewV9.235','thermal_thickness_seed':'old8.353152um normalized-coordinateinitialguess;actualnew9.8um'},'software_versions':{n:importlib.metadata.version(n)for n in ['numpy','scipy','autograd']},'fixed_voltage_rounding':'9.235VRMSselectedfrom1Dcommonroot9.23530,noTdependenttuning','scope':'Newindependent25/50Ctwo-dimensionalsources,notrenamedoldarrays;noopticalsolve'}
    save(a.config/'config.json',c);print(json.dumps({'config':str(a.config.relative_to(ROOT)),'validation':c['validation'],'parameters':c['parameters']},indent=2),flush=True)


def initial_from(warm,key,nx=NX,nz=NZ):
    X,Z=np.meshgrid(np.arange(nx)/nx,np.linspace(0,1,nz),indexing='ij');pts=np.stack([X,Z],-1)
    def it(q):return RegularGridInterpolator((np.linspace(0,1,len(q)+1),np.linspace(0,1,q.shape[1])),np.r_[q,q[:1]])(pts)
    return np.r_[it(warm[key+'__theta_rad']).ravel(),it(warm[key+'__phi_correction_rad']).ravel()]


def run_states(a):
    cfg=checked(a.config);a.out.mkdir(parents=True,exist_ok=False);par=cfg['parameters'];kind=a.action;electric=kind=='electric';d,P=(2.5,12)if electric else(9.8,24);warm=np.load(EWARM if electric else TWARM);arr={};rows=[];tic=time.perf_counter()
    for ti,T in enumerate(TEMPS):
        K=K_at(T);ep=par['epsilon_perp_by_T'][ti];de=par['delta_epsilon_by_T'][ti]
        for V in ([0,VFIX]if electric else[0]):
            key=f'{kind}_T{T}_V{V:g}';oldT=15 if T==25 else 50;oldkey=f'{kind}_T{oldT}_V{12.235 if V else 0:g}';v=initial_from(warm,oldkey);v0=v.copy();f,parts,meta=problem(d,P,K.tolist(),NX,NZ,Wp=2e-4,Wa=1.14e-4,pattern='8step');fvg=value_and_grad(f);ev=Source25Electric(d,P,K[0],NX,NZ,V,ep,de)if electric else None
            def fg(q):
                fr,gg=fvg(q)
                if V:
                    gr,psi,ck=ev.solve(q);_,ge=ev.evg(q,gr);return float(fr-ck['positive_electric_dimensionless']),gg+ge
                return float(fr),gg
            start=float(fg(v)[0]);counter=[0]
            def cb(q):
                counter[0]+=1
                if counter[0]%100==0:print(json.dumps({'key':key,'iter':counter[0],'elapsed_s':time.perf_counter()-tic}),flush=True)
            sol=minimize(fg,v,jac=True,method='L-BFGS-B',bounds=[(-np.pi/2+1e-5,np.pi/2-1e-5)]*(NX*NZ)+[(None,None)]*(NX*NZ),callback=cb,options={'maxiter':a.maxiter,'maxcor':40,'maxls':40,'ftol':1e-13,'gtol':2e-8})
            theta=sol.x[:NX*NZ].reshape(NX,NZ);u=sol.x[NX*NZ:].reshape(NX,NZ);bulk,surf=parts(sol.x);energy,gradient=fg(sol.x);refine=[];gauss=None
            if electric:
                _,psi,gauss=ev.solve(sol.x);arr[key+'__potential_V']=psi;arr[key+'__LC_potential_V']=psi[:,NS+1:NS+1+NZ];arr['electric_z_over_LC_d']=ev.z
                for ns in [32,64]:
                    ee=Source25Electric(d,P,K[0],NX,NZ,V,ep,de,ns);_,pp,cc=ee.solve(sol.x);refine.append({'support_cells_each_side':ns,'electric_energy_relative_to_source':float(abs(cc['positive_electric_dimensionless']/gauss['positive_electric_dimensionless']-1))if V else 0.,'LC_voltage_mean_V':cc['LC_terminal_voltage_mean_minmax_V'][0],'Gauss_free_residual_inf':cc['Gauss_free_residual_inf']})
            else:arr['thermal_z_over_LC_d']=np.linspace(0,1,NZ)
            arr[key+'__theta_rad']=theta;arr[key+'__phi_correction_rad']=u
            def director(q):
                th=q[:NX*NZ].reshape(NX,NZ);ph=2*np.pi*np.arange(NX)[:,None]/NX+q[NX*NZ:].reshape(NX,NZ);return np.stack([np.cos(th)*np.cos(ph),np.cos(th)*np.sin(ph),np.sin(th)],-1)
            angle=np.degrees(np.arccos(np.clip(abs(np.sum(director(v0)*director(sol.x),axis=-1)),0,1)))
            positive=gauss['positive_electric_dimensionless']if gauss else 0.
            row={'key':key,'T_C':T,'V_external_RMS':V,'epsilon_perp':ep,'delta_epsilon':de,**meta,'support_cells_each_side':NS if electric else None,'warm_key_initial_guess_only':oldkey,'warm_physical_d_um':2.5 if electric else 8.353152083061113,'actual_new_d_um':d,'success':bool(sol.success),'message':str(sol.message),'nit':int(sol.nit),'initial_energy_dimensionless':start,'final_energy_dimensionless':energy,'energy_J_m2':float(energy*meta['energy_unit_J_m2']),'Frank_bulk_J_m2':float(bulk*meta['energy_unit_J_m2']),'anchoring_J_m2':float(surf*meta['energy_unit_J_m2']),'positive_electric_J_m2':float(positive*meta['energy_unit_J_m2']),'energy_decomposition_identity_abs':float(abs(energy-(bulk+surf-positive))),'fresh_final_gradient_inf':float(abs(gradient).max()),'theta_absmax_deg':float(np.degrees(abs(theta).max())),'axis_change_from_initial_guess_max_deg':float(angle.max()),'Gauss':gauss,'fixed_director_support_refinement':refine,'elapsed_s':time.perf_counter()-tic}
            rows.append(row);np.savez_compressed(a.out/'fields.npz',**arr);save(a.out/'results.json',{'kind':kind,'parameters':par,'rows':rows,'config':str(a.config.relative_to(ROOT)),'config_SHA256':sha(a.config/'config.json'),'source_SHA256':sha(__file__),'scope':'Actualnew64x33Gauss/Frankstates;noopticalresult,notglobalorbatchmatchedcertificate'});print(json.dumps({k:row[k]for k in ['key','success','nit','fresh_final_gradient_inf','theta_absmax_deg','energy_J_m2','axis_change_from_initial_guess_max_deg','elapsed_s']}),flush=True)
    checked(a.config);(a.out/'source.py').write_bytes(Path(__file__).read_bytes());save(a.out/'postflight.json',{'all_frozen_inputs_match':True,'config_SHA256':sha(a.config/'config.json')})


def bow_check():
    # Existingexplicitventedfive-boardscenario;notcoupledintoopticalflatfields.
    E,nu,t,a=170e9,.22,8e-6,150e-6;D=E*t**3/(12*(1-nu**2));C0=a**4/(64*D);Q=np.array([[2,0,0],[0,2,-1],[0,-1,2.]])
    d=np.array([2.5,2.5,9.8]);h=d+.04;records=[]
    for gamma in [.025,.03,.035]:
        p=-2*gamma*(1/(h*1e-6)+1/20e-6);bow=C0*(Q@p)*1e6;records.append({'gamma_N_m':gamma,'contact_cos_scenario':1,'liquid_gauge_pressure_Pa':p.tolist(),'center_LC_thickness_um':(d+bow).tolist(),'center_bare_gap_um':(h+bow).tolist(),'thermal_LC_max_um':float(d[2]+max(0,bow[2])),'within10um':bool(d[2]+max(0,bow[2])<=10)})
    return {'scope':'Ventedcapillaryscenario,ambientgas,zeroprestress,clampedcirculara150um8umAlE170GPa;gammaexamplesnotmeasured25/50range.NoMaxwellstress/CTE/residualbowcoupling.','C0_m_Pa':C0,'thermal_Qpressure_combination_to_reach10um_Pa':.2e-6/C0,'thermal_LC_flat_um':9.8,'thermal_bare_spacer_height_um':9.84,'records':records,'note':'Flatnominalsource9.8andcalculatedbowmapsareseparate;notaflat-gapopticaltolerancecertificate.'}


def collect(a):
    cfg=checked(a.config);a.out.mkdir(parents=True,exist_ok=False);arr={};rows=[]
    for p,n in [(a.electric,4),(a.thermal,2)]:
        assert json.loads((p/'postflight.json').read_text())['all_frozen_inputs_match'];r=json.loads((p/'results.json').read_text());assert len(r['rows'])==n;rows+=r['rows'];z=np.load(p/'fields.npz')
        for k in z.files:assert k not in arr;arr[k]=z[k]
    expected=[f'electric_T{T}_V{V:g}'for T in TEMPS for V in [0,VFIX]]+[f'thermal_T{T}_V0'for T in TEMPS]
    assert set(expected)=={r['key']for r in rows}and all(r['success']for r in rows)
    np.savez_compressed(a.out/'fields.npz',**arr);result={'keys':expected,'parameters':cfg['parameters'],'rows':rows,'field_shapes':{k:list(v.shape)for k,v in arr.items()},'fields_SHA256':sha(a.out/'fields.npz'),'config_SHA256':sha(a.config/'config.json'),'inputs_SHA256':{str((p/'fields.npz').relative_to(ROOT)):sha(p/'fields.npz')for p in [a.electric,a.thermal]},'thermal_bow_scenario':bow_check(),'optical_handoff':'Actuallymaptemperaturearray25/50;readthermal9.8andallnew6keysfromthispackage;comp0useselectric0.Rotate/translatephysicalaxesaspreviousauditedmapping.NoVratioorold15Crenaming.','scope':'Sixnewactual64sourceswithnewdielectricanisotropy;K3/epsilonperp50/anchoring/batchremainmodels.No127spectrumclaimed.'}
    save(a.out/'results.json',result);(a.out/'source.py').write_bytes(Path(__file__).read_bytes());print(json.dumps({'keys':expected,'fields_SHA':result['fields_SHA256'],'thermal_bow':result['thermal_bow_scenario']},indent=2),flush=True)


def main():
    p=argparse.ArgumentParser();p.add_argument('action',choices=['freeze','electric','thermal','collect']);p.add_argument('--config',type=Path,required=True);p.add_argument('--out',type=Path);p.add_argument('--electric',type=Path);p.add_argument('--thermal',type=Path);p.add_argument('--maxiter',type=int,default=3000);a=p.parse_args()
    for k in ['config','out','electric','thermal']:
        v=getattr(a,k,None)
        if v is not None:setattr(a,k,v.resolve())
    {'freeze':freeze,'electric':run_states,'thermal':run_states,'collect':collect}[a.action](a)


if __name__=='__main__':main()
