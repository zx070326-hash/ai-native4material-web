"""Reproducible source-pixel extraction, with explicit sample/range limits."""
from pathlib import Path
import sys,json,hashlib,csv
import numpy as np
from PIL import Image,ImageDraw
from scipy import ndimage
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments.q2_finish_decouple_20261105_constitutive import ratio

def main():
 out=ROOT/'runs/20261105-q2-finish-decouple-E7-constitutive-digitized-01';out.mkdir(exist_ok=False)
 src=ROOT/'runs/20261105-q2-finish-decouple-E7-constitutive-source-01';ip=src/'E7_2025_Figure4_native.jpeg';im=Image.open(ip);a=np.asarray(im).astype(float)
 red=(a[:,:,0]>150)&(a[:,:,0]>1.5*(a[:,:,1]+1))&(a[:,:,0]>1.5*(a[:,:,2]+1));labels,n=ndimage.label(red)
 components=[]
 for i in range(1,n+1):
  yy,xx=np.where(labels==i)
  if len(xx)>12:components.append({'pixels':len(xx),'x':float(xx.mean()),'y':float(yy.mean())})
 ts=[25,30,35,40,45,50,51,52,53,54,55,56,57,58,59];rows=[];draw=ImageDraw.Draw(im)
 for T in ts:
  ex=849.994+(T-25)*(1218.637-849.994)/25
  candidates=[c for c in components if c['x']>830 and abs(c['x']-ex)<5]
  assert len(candidates)==1,(T,candidates)
  c=candidates[0];de=(475-c['y'])*15/(475-29);rows.append({'T_C':T,'delta_epsilon_1kHz_pureE7':de,'x_pixel':c['x'],'y_pixel':c['y'],'component_pixel_count':c['pixels']})
  draw.ellipse((c['x']-9,c['y']-9,c['x']+9,c['y']+9),outline='green',width=2)
 with (out/'Basu2025_Fig4b_pureE7_1kHz.csv').open('w',newline='')as f:
  writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
 # Separate low-voltage plateau, not high-voltage extrapolation.
 low=[c for c in components if c['x']<135];assert len(low)==1;epsp=4+(475-low[0]['y'])*14/446
 # Huang2010 Fig4 native raster: hand-selected marker centers, retained as pixels.
 # T identity follows caption, not text's separate20C comparison statement.
 krows=[]
 # Three observed pretilts: nearest low markers1.1deg and2.5deg; last plateau7.2deg.
 positions={1.1:([229,250,284,321],[541,558,581,600]),2.5:([158,175,236,271],[509,527,548,560]),7.2:([78,117,171,204],[462,489,514,526])}
 # Top-panel K11 ticks12 at11px,9.5 at166px,7 at320px.
 # Bottom K22 ticks12 at356px,9 at515px,6 at674px.
 for beta,(yy1,yy2) in positions.items():
  for T,y1,y2 in zip([25,30,35,40],yy1,yy2):
   krows.append({'pretilt_deg_approx':beta,'T_C':T,'K11_pN':12-(y1-11)*5/309,'K22_pN':12-(y2-356)*6/318,'K11_y_pixel':y1,'K22_y_pixel':y2})
 with (out/'Huang2010_Fig4_pretilt_specific_K.csv').open('w',newline='')as f:
  writer=csv.DictWriter(f,fieldnames=list(krows[0]));writer.writeheader();writer.writerows(krows)
 d25=rows[0]['delta_epsilon_1kHz_pureE7'];d50=next(r['delta_epsilon_1kHz_pureE7']for r in rows if r['T_C']==50)
 result={'dielectric_source':{'doi':'10.3390/mi16040457','figure':'4b pure E7 red squares ONLY','frequency_Hz':1000,'measured_temperature_range_C':[25,60],'digitized_temperature_range_C':[25,59],'delta_epsilon25':d25,'delta_epsilon50':d50,'ratio50_over25':d50/d25,'epsilon_perp25_lowV_approx':epsp,'epsilon_perp_T_dependence':'NOT acquired; do not treat25C value as measured at50C','q_effective25to50_vs_Li2005_dn589':float(np.log(d50/d25)/np.log(ratio(50))),'pixel_calibration':{'y_at_delta0':475,'y_at_delta15':29,'delta_per_pixel':15/446,'stated_digitization_sensitivity_delta':.10},'sample':'EMD E7 pure control, ethanol processing/4h vacuum degassing; rubbed commercial planar20um cell; TNI60C; different batch/process from Li2005 and SiNx proposed cell','limitations':['No15C data: do not extrapolate toold15/50C device.','One1kHz source/sample; no combined samebatchK/n/anchoring certificate.','Fig4a plateau at25C only; temperature-independent epsilon_perp is still model.']},'elastic_source':{'doi':'10.1016/j.cap.2009.07.022','url':'http://www.yxhuang.cn/paper/paper/dependence.pdf','figure':'4 native raster, caption25/30/35/40C','K_types':['K11','K22'],'sample':'Slichem E7, clearing58C, rubbed polymer planar25umcell, pretilt varied; source text names PVA methods and polyimide discussion','pixel_digitization_error_sensitivity_pN':.07,'pretilt_values_approx_deg':[1.1,2.5,7.2],'rows':krows,'limits':['NoK33 and no15/50C plotted values.','Pretilt-specific apparent constants cannotbe merged into one intrinsicK(T).','Below1deg immeasurable isnot a license tosetK=0.','SeparatetextK11(20C)=11.25pNdoesnotrelabeltheFig4caption25Ccurve;notanestablishedcontradiction.','Opticalne^2-no^2 used in scatteringextraction isnot staticdielectricanisotropy.']},'input_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()for p in [ip,src/'Huang2010_native_2.png',Path(__file__)]}}
 (out/'results.json').write_text(json.dumps(result,indent=2));im.save(out/'pureE7_selected_markers.png');(out/'source.py').write_bytes(Path(__file__).read_bytes());print(json.dumps(result,indent=2))
if __name__=='__main__':main()
