"""One fixed vented-capillary calculation for the bonded four-wall device.

Linear clamped circular Kirchhoff plates, perfect no-slip composite, no
residual/CTE stress. Thin ZnO contributes its geometric separation but no
extensional/bending stiffness. This is not a bond or optical certificate.
"""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import argparse,hashlib,json
from pathlib import Path
import numpy as np
from scipy.optimize import brentq
ROOT=Path(__file__).resolve().parents[1]


def laminate(layers,E,nu):
    # Same Poisson ratio for load-bearing alumina; zero-stiffness ZnO retains
    # its physical thickness in lever arms. Perfect kinematic bond is imposed.
    records=[];z=0.;A=0.;Az=0.
    for name,t_um,active in layers:
        t=t_um*1e-6;Q=E/(1-nu**2) if active else 0.;zc=z+t/2;records.append({'material':name,'thickness_um':t_um,'z0_m':z,'z1_m':z+t,'Q_Pa':Q,'stiffness_included':active});A+=Q*t;Az+=Q*t*zc;z+=t
    neutral=Az/A;D=sum(q['Q_Pa']*((q['z1_m']-neutral)**3-(q['z0_m']-neutral)**3)/3 for q in records)
    # Independent numerical through-thickness integration of Q(z-z_N)^2.
    x,w=np.polynomial.legendre.leggauss(8);numeric=0.
    for q in records:
        h=(q['z1_m']-q['z0_m'])/2;zz=(q['z1_m']+q['z0_m'])/2+h*x;numeric+=q['Q_Pa']*np.sum(w*(zz-neutral)**2)*h
    assert abs(numeric/D-1)<1e-12
    return {'layers':records,'physical_depth_um':z*1e6,'load_bearing_Al_thickness_um':sum(q['thickness_um']for q in records if q['stiffness_included']),'neutral_axis_from_lower_composite_face_um':neutral*1e6,'A_N_m':A,'D_N_m':D,'independent_D_quadrature_relative_error':float(abs(numeric/D-1))}


def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False)
    E,nu,rad=170e9,.22,150e-6;AR=.08302889342260214
    comp=laminate([('Al2O3_driver_plate',8.,True),('ZnO',.0998,False),('Al2O3_exit_oxide',AR,True),('Al2O3_passive_plate',9.8,True)],E,nu)
    D8=E*(8e-6)**3/(12*(1-nu**2));D=np.array([D8,comp['D_N_m'],D8,D8]);C=rad**4/(64*D)
    B=np.array([[-1.,1,0,0],[0,-1,1,0],[0,0,-1,1]])
    G=B@np.diag(C)@B.T
    explicit=np.array([[C[0]+C[1],-C[1],0],[-C[1],C[1]+C[2],-C[2]],[0,-C[2],C[2]+C[3]]])
    assert np.max(abs(G-explicit))<1e-25 and np.linalg.eigvalsh(G).min()>0
    homogeneous=laminate([('Al2O3',17.982828893422602,True)],E,nu)
    assert abs(homogeneous['D_N_m']/(E*(17.982828893422602e-6)**3/(12*(1-nu**2)))-1)<1e-12
    r=np.linspace(0,rad,1001);rho=r/rad;f=(1-rho*rho)**2;df=-4*rho*(1-rho*rho)/rad
    flat=np.array([2.5,2.5,8.55])*1e-6;bare=np.array([2.54,2.54,8.59])*1e-6;rows=[];normal_profiles=[];vertical_profiles=[];wall_profiles=[]
    def shape(x):return (1-(x/rad)**2)**2
    for gamma in [.025,.03,.035]:
        pressure=-2*gamma*(1/bare+1/20e-6)
        wall_load=B.T@pressure;W=C*wall_load;center=G@pressure
        assert np.max(abs(B@W-center))<1e-22
        vertical=flat[:,None]+center[:,None]*f;normal=np.zeros_like(vertical)
        # Intersect each LC-face graph with the normal to its local midsurface.
        # Centre and clamped rim normals are vertical; numerical radial check
        # verifies these remain the normal-gap extrema in this small-slope model.
        for k in range(3):
            for j,x in enumerate(r):
                mid=(flat[k]+(W[k]+W[k+1])*f[j])/2;slope=(W[k]+W[k+1])*df[j]/2;nr=-slope/np.sqrt(1+slope*slope);nz=1/np.sqrt(1+slope*slope)
                lower=lambda s:mid+s*nz-W[k]*shape(x+s*nr)
                upper=lambda s:mid+s*nz-flat[k]-W[k+1]*shape(x+s*nr)
                tlo=brentq(lower,-2*flat[k],2*flat[k],xtol=1e-18);thi=brentq(upper,-2*flat[k],2*flat[k],xtol=1e-18);normal[k,j]=thi-tlo
        expected_lo=np.minimum(flat,flat+center);expected_hi=np.maximum(flat,flat+center)
        assert np.max(abs(normal.min(axis=1)-expected_lo))<1e-15 and np.max(abs(normal.max(axis=1)-expected_hi))<1e-15
        # Axisymmetric plate energy equals one half pressure dot gap-volume.
        Cv=G*np.pi*rad**2/3;work=.5*pressure@Cv@pressure
        gx,gw=np.polynomial.legendre.leggauss(12);gr=rad*(gx+1)/2
        numvol=2*np.pi*center*np.sum(gw*shape(gr)*gr)*rad/2
        assert np.max(abs(numvol-Cv@pressure))<1e-12*np.max(abs(Cv@pressure))
        rows.append({'gamma_N_m':gamma,'contact_cos_scenario':1.,'liquid_gauge_pressure_Pa':pressure.tolist(),'wall_net_pressure_Pa':wall_load.tolist(),'wall_center_displacement_um':(W*1e6).tolist(),'gap_center_change_nm':(center*1e9).tolist(),'center_normal_LC_um':((flat+center)*1e6).tolist(),'normal_LC_min_um':(normal.min(axis=1)*1e6).tolist(),'normal_LC_max_um':(normal.max(axis=1)*1e6).tolist(),'normal_LC_extrema_locations':'driven/passive minima ataxis,maximaatclampedrim;thermalminimumatrim,maximumataxis','normal_vs_same_r_vertical_max_difference_nm':float(abs(normal-vertical).max()*1e9),'max_wall_slope_rad':float(abs(W[:,None]*df).max()),'LC_driver_minus_passive_center_nm':float((center[0]-center[1])*1e9),'bare_substrate_gap_min_um':((bare+np.minimum(center,0))*1e6).tolist(),'bare_substrate_gap_max_um':((bare+np.maximum(center,0))*1e6).tolist(),'all_normal_LC_positive':bool(normal.min()>0),'all_normal_LC_below10um':bool(normal.max()<=10e-6),'elastic_energy_J':float(work),'numerical_volume_relative_error':float(abs(numvol-Cv@pressure).max()/abs(Cv@pressure).max()),'composite_wall_nominal_pressure_cancellation':bool(wall_load[1]==0.)})
        normal_profiles.append(normal*1e6);vertical_profiles.append(vertical*1e6);wall_profiles.append(W[:,None]*f*1e6)
    np.savez_compressed(a.out/'profiles.npz',radius_um=r*1e6,gamma_N_m=np.array([.025,.03,.035]),normal_LC_um=np.array(normal_profiles),vertical_LC_um=np.array(vertical_profiles),wall_displacement_um=np.array(wall_profiles))
    result={'geometry':'outerAl8 / bonded(Al8+ZnO.0998+oxide.083028893+Al9.8) / sharedAl8 / outerAl8;threeLC2.5/2.5/8.55','parameters':{'radius_um':150,'E_Al_Pa':E,'nu_Al':nu,'channel_width_um':20,'LC_flat_normal_um':(flat*1e6).tolist(),'bare_channel_um':(bare*1e6).tolist(),'boundary':'allfourwallssameclampedcircularradius,ventedgasambient,uniformliquidcapillarypressure,nohydrostatichead'},'bonded_composite':comp,'wall_D_N_m':D.tolist(),'wall_center_compliance_m_Pa':C.tolist(),'gap_center_compliance_matrix_m_Pa':G.tolist(),'gap_compliance_normalized_by_single8um_wall':(G/C[0]).tolist(),'gap_matrix_eigenvalues_m_Pa':np.linalg.eigvalsh(G).tolist(),'gap_volume_compliance_matrix_m3_Pa':(G*np.pi*rad**2/3).tolist(),'incidence_B':B.tolist(),'load_identity':'wallload=B.T@p;gapchange=B@diag(C_wall)@B.T@p','rows':rows,'nominal_symmetry':'p_driven=p_passive,becausebothbarechannels2.54um;thebondedwallnetloadiszero.Thereforethese3nominalcasesdonotconstrainrealbondstiffness.','normal_thickness_identity':'SolidAl8/Al9.8/oxide83nmnormalmaterialthicknessesareassignedlayers;doNOTaddwholewallbowor17.9828umcompositepackageheighttooneAlmateriallayer.LCfluidnormalgapchangesarecomputedseparately.','optical_stack_count':'19retainedphysicalentities/18mergedopticalmateriallayersincludingcarbon;contiguousoxide+passiveAl=9.883028893um,not18umoneAlopticalfilm.','limits':['Perfectno-slipbond;ZnOstiffnessneglectedbutits99.8nmgeometricseparationretainedinAlleverarms.','Exitoxideassignedsame170GPa/.22asAlplates;otherthinnonstructuralcoatingsnotincludedinwallD.','Noresidualstress,CTE,thermalgradient,bondslip/delamination,Maxwellstressorrealfiniteframeverification.','Gamma.025/.03/.035areexplicitexamples,notsource-backed25/50Twettinginterval.','Normalintersectionsareoflinearsmall-slopeLC-facegraphs;notlarge-deformation3Dsolidcontactmechanics.','Actualnormalgapsdifferfromflat2.5/2.5/8.55opticalsource;thisdoesnotcertifyacoupleddirector/opticalbowresult.'],'source_SHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (a.out/'results.json').write_text(json.dumps(result,indent=2),encoding='utf-8');(a.out/'source.py').write_bytes(Path(__file__).read_bytes());print(json.dumps({'D_composite_N_m':comp['D_N_m'],'C_wall':C.tolist(),'normalized_gap_C':(G/C[0]).tolist(),'rows':rows},indent=2),flush=True)
if __name__=='__main__':main()
