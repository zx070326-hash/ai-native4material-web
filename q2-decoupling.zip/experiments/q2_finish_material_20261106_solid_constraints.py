"""Frozen all-solid constraint addendum, existing n bounds only; no solver."""
from pathlib import Path
import json,hashlib,shutil
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'runs/20261106-q2-finish-material-solid-constraints-01'
ADAPTER=ROOT/'experiments/q2_finish_decouple_20261105_solid_interface.py'
RUN=ROOT/'runs/20261105-q2-finish-decouple-solid-interface-optics64-127-0-01'
EFFECTIVE=RUN/'effective_optics_source.py'
BASE=ROOT/'runs/20261105-q2-finish-material-final-constraints-01/results.json'
SUMMARY=ROOT/'runs/20261105-q2-finish-decouple-solid-interface-summary127-01/results.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected_adapter='b454d609a660f4694272a222f55d972c361709073f3950d2ede3283c1319431a'
expected_effective='f70b0d40f5d1893a8160e4dbcc6fba87313c4a43c9ac833fef4e10e0a700aabf'
effective_text_sha=hashlib.sha256(EFFECTIVE.read_text().encode()).hexdigest()
assert sha(ADAPTER)==expected_adapter and effective_text_sha==expected_effective
launch=json.loads((RUN/'launch.json').read_text());base=json.loads(BASE.read_text());summary=json.loads(SUMMARY.read_text())
assert launch['effective_source_sha256']==expected_effective
for name,digest in launch['input_sha256'].items():assert sha(ROOT/name)==digest
for name,digest in base['inputs_sha256'].items():assert sha(ROOT/name)==digest
assert launch['internal_air_gap_um']==0 and launch['passive_entrance_plate_um']==9.8 and launch['solid_replacement_um']==1.8
assert launch['temperatures_C']==[25,50] and launch['fixed_terminal_voltage_V']==9.235 and launch['thermal_LC_um']==8.55
counts=summary['layer_count_identity'];assert counts['physical_retained_entities_including_carbon']==19 and counts['merged_optical_material_layers_including_carbon']==18
block=launch['contiguous_Al2O3_block_um'];assert abs(block-(9.8+launch['AR_each_um']))<1e-12
source=EFFECTIVE.read_text()
assert 'gap=coupled.uniform_layer(1.,2.'not in source
assert "gap=coupled.uniform_layer(complex(old.index('Al2O3_Franta',np.array([lam]))[0]),1.8"in source
OUT.mkdir(parents=True,exist_ok=False)
inputs=[Path(__file__),ADAPTER,EFFECTIVE,RUN/'launch.json',BASE,SUMMARY]
before={str(p.relative_to(ROOT)):sha(p)for p in inputs}
result={
 'identity':'ONE fixed all-solid d8.55/source25/9.235V counterpart; bookkeeping addendum to existing material audit',
 'actual_adapter':{'path':str(ADAPTER.relative_to(ROOT)),'sha256':expected_adapter},
 'actual_effective':{'path':str(EFFECTIVE.relative_to(ROOT)),'execution_text_sha256':expected_effective,'on_disk_bytes_sha256':sha(EFFECTIVE),'hash_convention':'Launch computes SHA of source.encode(); read_text normalizes WindowsCRLF. RawbyteSHA separately preserved.'},
 'source_field_sha256':launch['input_sha256']['runs\\20261105-q2-finish-assembly-phase25-d8p55-source64-01\\fields.npz'],
 'ZnO_table_sha256':launch['input_sha256']['runs\\20261105-q2-finish-material-ZnO-hires-input-01\\ZnO2022_Fig5d_hires_exactnodes_tail_linear_scenario.csv'],
 'material_index_bounds_reused_from':str(BASE.relative_to(ROOT)),
 'rows_unchanged_from_existing_verified_bounds':base['rows'],
 'coverage_and_migration_unchanged':base['coverage_and_migration'],
 'A_model_range_pass':base['all_finite_solid_materials_A_model_range_pass'],
 'B_reference_550nm_25C_model_pass':base['all_finite_solid_materials_B_reference_pass'],
 'A_evidence_closed':False,'B_reference_is_not_A':True,'new_source_evidence':False,
 'interface':{'internal_air_gap_um':0.,'external_incident_final_exit_air':'Environment remains; not an internal retained layer. Algebraic air-mode bases do not imply retained air.','replacement_Al2O3_um':1.8,'physical_passive_plate_um':9.8,'driver_exit_oxide_um':launch['AR_each_um'],'contiguous_same_source_Al2O3_block_um':block,'retained_glue_or_void_assumed':False,'optical_merge_condition':'Identical complex scalar epsilon, contiguous contact, no intervening different material or interface law; exact continuum merge, not process evidence.'},
 'layer_account':counts,
 'thickness':{'merged_optical_min_nm':20.,'merged_optical_max_nm':block*1000,'merged_Al2O3_margin_to_10000nm_nm':(10-block)*1000,'all_merged_optical_layers_10_to_10000nm_model_pass':True,'physical_passive_plate_nm':9800.,'physical_exit_oxide_nm':launch['AR_each_um']*1000,'other_main_physical_thicknesses_nm':[83.02889342260214,99.8,8000.,20.,2500.,8550.,5000.],'min_easy_axis_band_um':1.5,'feature_gt1um_model_pass':True},
 'optical_status_at_addendum':{'completed127_inner600_main_pp':summary['rows'][0]['solid']['main_pp'],'completed127_status':'Conditional result, not density convergence or complete-device evidence certificate.','density837':'Running at parent handoff; no completion or result inferred in this addendum.'},
 'limits':[
  'Physical19entities, merged18opticalmateriallayers; computational20pre-screen/21includingcarbon are algebraic material segments, not21independentretainedentities.',
  'Three contiguous Al intervals merge; sharedAl4+4 also merges toAl8. LCnumericalslicesandairmodebasesdonotaddphysicalfilms.',
  'All complex spectra, source batches, temperature transfers, K(T)/K33, epsilon_perp50, anchoring, SiNx20nm/thicknessprocess, ZnO graph-tail/DCtransport, Al2O3 thicknessrelease and carbonfoil migrations remain as in material audit.',
  'Removing internal n1 gap closes that convention issue for this continuum optical counterpart only; no new continuous measured nk or perfect-bond/process evidence was acquired.',
  'E7Cauchy shortwave/NIRextrapolation,Wualpha380-400nmendholdandbothaxis/25-50transferremain;Amodelpointwisepass isnotA_evidence_closed.',
  'SameLCfields retained by specified ideal terminal boundaries; changed solidbond/mismatch/stress mechanics not inferred from oldair5x8umplates.',
  'No new Maxwell, search, parameter tuning, STATE or Git edits.'
 ],'inputs_sha256':before,'full_problem_solved':False}
assert abs(result['optical_status_at_addendum']['completed127_inner600_main_pp'][0]-38.83102314420567)<1e-10
assert abs(result['optical_status_at_addendum']['completed127_inner600_main_pp'][1]-23.02759042287894)<1e-10
result['input_readback_all_match']=all(sha(ROOT/p)==h for p,h in before.items())
assert result['input_readback_all_match']
(OUT/'results.json').write_text(json.dumps(result,indent=2));shutil.copy2(__file__,OUT/'source.py')
readback=json.loads((OUT/'results.json').read_text());assert readback['actual_adapter']['sha256']==sha(ADAPTER) and readback['actual_effective']['execution_text_sha256']==hashlib.sha256(EFFECTIVE.read_text().encode()).hexdigest()
assert readback['actual_effective']['on_disk_bytes_sha256']==sha(EFFECTIVE)
assert sha(OUT/'source.py')==sha(Path(__file__))
print(json.dumps({'output':str(OUT),'adapter_sha256':sha(ADAPTER),'effective_execution_text_sha256':effective_text_sha,'effective_on_disk_bytes_sha256':sha(EFFECTIVE),'readback_all_match':readback['input_readback_all_match'],'A_evidence_closed':readback['A_evidence_closed'],'block_um':block,'layer_counts':counts,'thickness':result['thickness'],'new_source_evidence':False},indent=2))
