"""Actual64-director thermal phase audit and one geometry-lobe control.

Path-ordered lossless Jones surrogate is explicitly separate from full19-layer
Maxwell. One thermal thickness is chosen from the existing screen cutoff, not
by maximizing a computed device spectrum. Its two Frank states are re-solved.
"""
import os
for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[k]='1'
import argparse,hashlib,json,sys
from pathlib import Path
import numpy as np
from scipy.interpolate import RegularGridInterpolator
from scipy.optimize import minimize
from autograd import value_and_grad
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments.q2_finish_source25_20261105 import K_at
from experiments.q2_manufacturing_lc_director2d import problem
from experiments.q2_finish_decouple_20261105 import indices
from experiments.q2_output_screen import tilted_project
OLD=ROOT/'runs/20261105-q2-package-A-director64-d1p45-02/fields.npz'
NEW=ROOT/'runs/20261105-q2-finish-source25-combined64-01/fields.npz'
READ=ROOT/'runs/20261105-q2-finish-decouple-source25-AR19-readout64-127-600-01/spectra.npz'
PREVIOUS=ROOT/'runs/20261105-q2-finish-lead-AR-aperture-01/inner600/spectra.npz'
NX,NS=128,64


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,d):Path(p).write_text(json.dumps(d,indent=2),encoding='utf-8')
def texture(data,key,thermal=True,slices=NS):
    x=(np.arange(NX)+.5)/NX;zz=(np.arange(slices)+.5)/slices;X,Z=np.meshgrid((x-.25)%1 if thermal else x,zz,indexing='ij');pts=np.stack([X,Z],-1)
    def it(q):return RegularGridInterpolator((np.linspace(0,1,len(q)+1),np.linspace(0,1,q.shape[1])),np.r_[q,q[:1]])(pts)
    return it(data[key+'__theta_rad']),2*np.pi*x[:,None]+it(data[key+'__phi_correction_rad'])


def jones(th,ph,d,T,lam):
    ne,no=indices(T,lam);nn=ne*no/np.sqrt(ne**2*np.sin(th)**2+no**2*np.cos(th)**2);opd=d*np.mean(nn-no,axis=1)
    J=np.broadcast_to(np.eye(2,dtype=complex),(len(th),2,2)).copy()
    for z in range(th.shape[1]):
        phase=np.exp(2j*np.pi/lam*(nn[:,z]-no)*d/th.shape[1]);c,s=np.cos(ph[:,z]),np.sin(ph[:,z]);step=np.zeros_like(J);step[:,0,0]=c*c*phase+s*s;step[:,0,1]=step[:,1,0]=c*s*(phase-1);step[:,1,1]=s*s*phase+c*c;J=step@J
    m=np.arange(-4,5);F=np.fft.fft(J,axis=0)/len(J);coeff=F[m%len(J)]*np.exp(-1j*np.pi*m/len(J))[:,None,None]
    power=.5*np.sum(abs(coeff)**2,axis=(1,2));ev=np.linalg.eigvals(J);angle=np.angle(ev[:,0]*ev[:,1].conj());net=np.abs(angle)
    return coeff,{'actual_theta_retardance_mean_um':float(opd.mean()),'actual_theta_retardance_minmax_um':[float(opd.min()),float(opd.max())],'net_Jones_principal_retardance_mean_rad':float(net.mean()),'net_Jones_unitarity_absmax':float(np.max(abs(np.swapaxes(J.conj(),1,2)@J-np.eye(2)))),'zero_order_power':float(power[4]),'thermal_first_orders_power':float(power[2]+power[6]),'retained9order_power':float(power.sum())}


def phase_projection(data,temps,d,waves):
    n=len(waves);N=9;h=np.arange(-4,5);z={'wavelength_um':waves,'harmonics':h};records=[]
    for ti,T in enumerate(temps):
        th,ph=texture(data,f'thermal_T{T}_V0');E=np.zeros((n,N,N,2,2),complex);G=np.zeros_like(E);rr=[]
        for i,lam in enumerate(waves):
            F,meta=jones(th,ph,d,T,float(lam));rr.append(meta)
            for iy,m in enumerate(h):
                q=lam*m/48;qz=np.sqrt(1-q*q);Y=np.array([1/qz,qz]);E[i,iy,4]=F[iy]/np.sqrt(Y)[:,None];G[i,iy,4]=Y[:,None]*E[i,iy,4]
        for v in range(2):z[f'V{v}T{ti}__E']=E;z[f'V{v}T{ti}__G']=G
        records.append(rr)
    gram=dict(np.load(ROOT/'runs/20261105-q2-package-device-kernels-01/inner600/gram.npz'));T=tilted_project(z,gram,25.,periods=(12.,24.))[0]
    delta=T[0]-T[1];signed=100*np.trapezoid(delta,waves)/1.72;absolute=100*np.trapezoid(abs(delta),waves)/1.72
    return T,{'thermal_only_signed_NIR_delta_pp':float(signed),'thermal_only_absolute_NIR_delta_pp':float(absolute),'negative_cancellation_contribution_pp':float((absolute-signed)/2),'mean_endpoints_retardance_um':[[r['actual_theta_retardance_mean_um']for r in x]for x in records],'scope':'Actualtheta/phi pathorderedlosslessJoneswithcoherent81modefixed600Fresnelprojection;noAR/support/electrode/absorption/intercellreflection,notdeviceT.'}


def new_thermal(d,new,out):
    rows=[];arr={};nx,nz=64,33
    for T in [25,50]:
        key=f'thermal_T{T}_V0';v=np.r_[new[key+'__theta_rad'].ravel(),new[key+'__phi_correction_rad'].ravel()];K=K_at(T);f,parts,meta=problem(d,24,K.tolist(),nx,nz,Wp=2e-4,Wa=1.14e-4,pattern='8step');sol=minimize(value_and_grad(f),v,jac=True,method='L-BFGS-B',bounds=[(-np.pi/2+1e-5,np.pi/2-1e-5)]*(nx*nz)+[(None,None)]*(nx*nz),options={'maxiter':2400,'maxcor':40,'maxls':40,'ftol':1e-13,'gtol':2e-8});arr[key+'__theta_rad']=sol.x[:nx*nz].reshape(nx,nz);arr[key+'__phi_correction_rad']=sol.x[nx*nz:].reshape(nx,nz);rows.append({'key':key,'T_C':T,**meta,'success':bool(sol.success),'nit':int(sol.nit),'gradient_inf':float(abs(sol.jac).max()),'energy_J_m2':float(sol.fun*meta['energy_unit_J_m2'])})
    assert all(r['success']for r in rows);np.savez_compressed(out/'thermal_control_fields.npz',**arr);return arr,rows


def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False);old=np.load(OLD);new=np.load(NEW);r=np.load(READ);w=r['wavelength_um'];w=w[w>=.78]
    # Optical-plane cutoff ofm_y=±2 at y=±589, including the actual25deg tilt.
    edge=589.;cuts=[24*edge/np.sqrt((10000+sgn*edge*np.tan(np.deg2rad(25)))**2+edge**2)for sgn in [1,-1]];cut=float(np.mean(cuts))
    opds=[]
    for T in [25,50]:
        th,ph=texture(new,f'thermal_T{T}_V0');_,meta=jones(th,ph,9.8,T,cut);opds.append(meta['actual_theta_retardance_mean_um'])
    d_raw=9.8*cut/np.mean(opds);d_control=float(round(d_raw,2));assert .01<=d_control<=10
    control,ctrlrows=new_thermal(d_control,new,a.out)
    specs={};summary={}
    for label,data,temps,d in [('old15_50_actual64',old,[15,50],8.353152083061113),('new25_50_actual64',new,[25,50],9.8),('single_cutoff_lobe_control_actual64',control,[25,50],d_control)]:
        T,meta=phase_projection(data,temps,d,w);specs[label]=T;summary[label]={'thermal_d_um':d,'temperatures_C':temps,**meta}
    points=[]
    for lam in [.78,1.,cut,1.6,2.,2.5]:
        row={'wavelength_um':lam}
        for label,data,temps,d in [('old',old,[15,50],8.353152083061113),('new',new,[25,50],9.8)]:
            vals=[]
            for T in temps:
                th,ph=texture(data,f'thermal_T{T}_V0');_,meta=jones(th,ph,d,T,lam);vals.append(meta)
            row[label]={'by_temperature':vals,'retardance_endpoint_mean_um':float(np.mean([q['actual_theta_retardance_mean_um']for q in vals])),'retardance_difference_um':float(vals[0]['actual_theta_retardance_mean_um']-vals[1]['actual_theta_retardance_mean_um'])}
        points.append(row)
    electric=[]
    for lam in [.55,1.,1.6,2.5]:
        rr={'wavelength_um':lam,'cases':{}}
        for label,data,temps,V in [('old',np.load(ROOT/'runs/20261105-q2-finish-external-director64-support32-01/fields.npz'),[15,50],12.235),('new',new,[25,50],9.235)]:
            values=[]
            for T in temps:
                opd=[]
                for v in [0,V]:
                    th,ph=texture(data,f'electric_T{T}_V{v:g}',False);_,meta=jones(th,ph,2.5,T,lam);opd.append(meta['actual_theta_retardance_mean_um'])
                values.append(opd[1]-opd[0])
            rr['cases'][label]={'on_minus0_retardance_byT_um':values,'hot_minus_cold_of_differential_um':float(values[1]-values[0])}
        electric.append(rr)
    actual=[]
    for label,path in [('old',PREVIOUS),('new',READ)]:
        s=np.load(path);ww=s['wavelength_um'];tt=s['total_T'];ix=ww>=.78;dd=tt[:,0,ix]-tt[:,1,ix];signed=100*np.trapezoid(dd,ww[ix],axis=-1)/1.72;absolute=100*np.trapezoid(abs(dd),ww[ix],axis=-1)/1.72;actual.append({'label':label,'NIR_signed_byV_pp':signed.tolist(),'NIR_absolute_byV_pp':absolute.tolist(),'opposite_sign_cancel_pp':((absolute-signed)/2).tolist()})
    files=[OLD,NEW,READ,PREVIOUS,ROOT/'runs/20261105-q2-finish-decouple-source25-diagnosis-01/results.json',ROOT/'runs/20261105-q2-finish-decouple-source25-commonfilter-bound-01/results.json',Path(__file__).resolve()]
    result={'actual19layer_comparison':actual,'actual_director_phase_points':points,'actual_electric_differential_phase':electric,'thermal_Jones_phase_projection':summary,'single_control':{'rule':'PutactualmeanthermalOPDatthefirstordergeometriccutoffononewholewave:meanOPD(lambda_cut)=lambda_cut;notdevice-spectrummoptimization','plus_minus_cutoffs_um':cuts,'lambda_cut_mean_um':cut,'thickness_raw_um':d_raw,'thickness_fixed_rounded_um':d_control,'new_true_Frank_states':ctrlrows,'fields_path':'thermal_control_fields.npz','layer_count_stays19':True,'all_LC_thicknesses_le10um':d_control<=10,'pattern_minimum_um':3.},'interpretation':['New0V NIRmainalreadybelow20;on-voltage/deltaepsiloncannotbetheprimarycauseofthe0Vfailure.','0Vdoesnotdependonstaticdielectricdata,thoughcoldtemperature/K/nandthermalgeometryallchange.','Compareactualθ/uandorderedJonesphaseaswellasdelta-n;whole19layercausalitystillneedsmatchedthermal-onlyMaxwellcontrol.','Thecommonfilter20.96ppLPisacoarsespectralattenuationupperboundnotaphysical20thfilmcertificate.'],'SHA256':{str(f.resolve().relative_to(ROOT)):sha(f)for f in files},'limits':['Jonesphaseprojectionisnotreflection-inclusivefull19layerMaxwellorrealdeviceT.','ControlthermalFrankisactuallyrelaxed,butonlyonethicknesschosenfromgeometricphase-lobecriterion;noscannedMaxwellspectrum.','Newgeometryhasunchangedmaterials/supports/AR,V,featuresand19layers;source/material/processconditionscarryover.','Oldandnewtemperature/electricconditionsaredifferent;noattributionofeverydifferenceonlytoepsilon.']}
    np.savez_compressed(a.out/'phase_projection.npz',wavelength_um=w,**specs);save(a.out/'results.json',result);(a.out/'source.py').write_bytes(Path(__file__).read_bytes());print(json.dumps({'actual':actual,'projection':{k:{q:v[q]for q in ['thermal_d_um','thermal_only_signed_NIR_delta_pp','thermal_only_absolute_NIR_delta_pp']}for k,v in summary.items()},'control':result['single_control']},indent=2),flush=True)


if __name__=='__main__':main()
