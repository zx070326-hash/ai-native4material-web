"""Independent Figure5d high-resolution digitization; never changes legacy inputs."""
import os
for _key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[_key] = "1"
import hashlib
import json
from pathlib import Path
import shutil
import sys
import numpy as np
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "runs/20261105-q2-finish-material-ZnO-hires-calibration-01"
SOURCE = ROOT / "data/q2_finish_lead_ZnO_source_20261105"
OLD = ROOT / "data/q2_package_A_20261105"

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def groups(mask, offset=0):
    chunks = []
    for value in np.flatnonzero(mask):
        if not chunks or value > chunks[-1][-1] + 1:
            chunks.append([])
        chunks[-1].append(int(value))
    return [[chunk[0]+offset, chunk[-1]+offset, float(np.mean(chunk)+offset)] for chunk in chunks]

def write_csv(path, array, header):
    np.savetxt(path, array, delimiter=",", header=header, comments="", fmt="%.12g")

def extract(rgb, ncoef, kcoef, xcoef, variant=0):
    rr, gg, bb = rgb[345:655, 800:1150].transpose(2, 0, 1)
    yy, xx = np.indices(rr.shape)
    if variant == 0:
        bn = (bb>120)&(bb>rr+45)&(bb>gg+25)
        gk = (gg>85)&(gg>rr+25)&(gg>bb+15)
    elif variant == 1:
        bn = (bb>105)&(bb>rr+35)&(bb>gg+20)
        gk = (gg>75)&(gg>rr+18)&(gg>bb+10)
    else:
        bn = (bb>140)&(bb>rr+65)&(bb>gg+40)
        gk = (gg>100)&(gg>rr+40)&(gg>bb+25)
    # Discard only observed legend regions; the actual curves remain below these
    # limits beyond 500 nm. Keep the pre-edge feature for source-domain audit.
    bn &= ((xx+800<=838)|(yy+345>450))
    gk &= ((xx+800<=838)|(yy+345>600))
    results = []
    for mask, coef in ((bn,ncoef),(gk,kcoef)):
        rows = []
        for x in np.flatnonzero(mask.any(0)):
            y = np.flatnonzero(mask[:,x])+345
            med = float(np.median(y))
            lam = float(np.polyval(xcoef,x+800))
            rows.append([lam,float(np.polyval(coef,med)),x+800,med,float(y.min()),float(y.max()),len(y)])
        results.append(np.array(rows))
    return results

def main():
    OUT.mkdir(parents=True, exist_ok=True)
    if (OUT/"results.json").exists():
        raise RuntimeError("Independent output already complete; preserve it.")
    inputs = [Path(__file__), SOURCE/"Figure5_original.png", SOURCE/"PMC9121516.1.pdf",
              SOURCE/"fullText.xml", OLD/"ZnO2022_Fig5d_n_raw.csv", OLD/"ZnO2022_Fig5d_k_raw.csv",
              OLD/"ZnO2022_Fig5d_passive_digitized.csv"]
    manifest = {str(p.relative_to(ROOT)):sha(p) for p in inputs}
    shutil.copy2(__file__,OUT/"source.py")
    (OUT/"launch_manifest.json").write_text(json.dumps({"argv":sys.argv,"inputs_sha256":manifest},indent=2),encoding="utf8")
    rgb = np.array(Image.open(SOURCE/"Figure5_original.png").convert("RGB")).astype(float)
    gray = rgb.mean(2)
    xticks=groups(np.sum(gray[674:682,810:1155]<70,axis=0)>=7,810)
    nticks=groups(np.sum(gray[345:655,802:811]<70,axis=1)>=8,345)
    kticks=groups(np.sum(gray[345:655,1149:1159]<70,axis=1)>=9,345)
    assert len(xticks)==5 and len(nticks)==5 and len(kticks)==6
    xv=np.array(xticks)[:,2]; nv=np.array(nticks)[:,2]; kv=np.array(kticks)[:,2]
    xcoef=np.polyfit(xv,[.5,1,1.5,2,2.5],1)
    ncoef=np.polyfit(nv,[2.4,2.2,2,1.8,1.6],1)
    kcoef=np.polyfit(kv,[.5,.4,.3,.2,.1,0],1)
    nraw,kraw=extract(rgb,ncoef,kcoef,xcoef)
    write_csv(OUT/"ZnO2022_Fig5d_hires_n_raw.csv",nraw,"lambda_um,n,x_pixel,y_center,y_min,y_max,pixel_count")
    write_csv(OUT/"ZnO2022_Fig5d_hires_k_raw.csv",kraw,"lambda_um,k,x_pixel,y_center,y_min,y_max,pixel_count")
    # All rows outside the measured domain are retained only in raw files.
    # A graph-domain table stops at the final visible green dash.
    last_k=float(kraw[-1,0])
    common=np.unique(np.r_[np.linspace(.38,last_k,501),.78])
    nk=np.column_stack([common,np.interp(common,*nraw[:,:2].T),np.interp(common,*kraw[:,:2].T)])
    write_csv(OUT/"ZnO2022_Fig5d_hires_graph_domain.csv",nk,"lambda_um,n,k")
    # Local graphical continuation is an explicit scenario, never a new measured
    # endpoint or a source uncertainty bound. Fit only actual colored dash pixels.
    extensions={}
    for window,degree in ((.15,1),(.3,1),(.5,1),(.5,2)):
        use=(kraw[:,0]>=last_k-window)&(kraw[:,0]<=last_k)
        coef=np.polyfit(kraw[use,0],kraw[use,1],degree)
        extensions[f"poly{degree}_last{window:g}um"]={"coef_descending":coef.tolist(),"k_2p5":float(np.polyval(coef,2.5)),"points":int(use.sum()),"fit_domain_um":[float(kraw[use,0].min()),last_k]}
    full=np.unique(np.r_[np.linspace(.38,2.5,713),.78])
    nfull=np.interp(full,*nraw[:,:2].T)
    kbase=np.interp(full,*kraw[:,:2].T)
    tail=full>last_k
    klinear=kbase.copy()
    coef=extensions["poly1_last0.3um"]["coef_descending"]
    # Anchor the continuation to the last pixel to avoid a discontinuity.
    klinear[tail]=kraw[-1,1]+coef[0]*(full[tail]-last_k)
    write_csv(OUT/"ZnO2022_Fig5d_hires_tail_linear_scenario.csv",np.column_stack([full,nfull,np.maximum(klinear,0)]),"lambda_um,n,k")
    write_csv(OUT/"ZnO2022_Fig5d_hires_tail_hold_scenario.csv",np.column_stack([full,nfull,np.maximum(kbase,0)]),"lambda_um,n,k")
    oldn=np.loadtxt(OLD/"ZnO2022_Fig5d_n_raw.csv",delimiter=",",skiprows=1)
    oldk=np.loadtxt(OLD/"ZnO2022_Fig5d_k_raw.csv",delimiter=",",skiprows=1)
    oldpass=np.loadtxt(OLD/"ZnO2022_Fig5d_passive_digitized.csv",delimiter=",",skiprows=1)
    comparison={}
    for name,new,old in (("n",nraw,oldn),("k",kraw,oldk)):
        domain=[.38,float(min(new[-1,0],old[-1,0]))]
        grid=np.linspace(*domain,2001)
        diff=np.interp(grid,*new[:,:2].T)-np.interp(grid,*old.T)
        comparison[name]={"same_domain_um":domain,"rms":float(np.sqrt(np.mean(diff*diff))),"mean":float(diff.mean()),"max_abs":float(abs(diff).max()),"max_abs_at_um":float(grid[abs(diff).argmax()])}
        write_csv(OUT/f"new_minus_old_{name}.csv",np.column_stack([grid,diff]),f"lambda_um,new_minus_old_{name}")
    variants=[]
    for variant in (1,2):
        vn,vk=extract(rgb,ncoef,kcoef,xcoef,variant)
        variants.append({"variant":variant,"n_max_common_abs_diff":float(np.max(np.abs(np.interp(nk[:,0],*vn[:,:2].T)-nk[:,1]))),"k_max_common_abs_diff":float(np.max(np.abs(np.interp(nk[:,0],*vk[:,:2].T)-nk[:,2]))),"k_last_visible_um":float(vk[-1,0])})
    pointtable=[]
    for lam in (.38,.4,.5,.55,.78,1,1.5,2,2.423076923,2.444805195,2.5):
        n=float(np.interp(lam,*nraw[:,:2].T))
        kval=float(np.interp(lam,*kraw[:,:2].T)) if lam<=last_k else None
        old=np.array([np.interp(lam,oldpass[:,0],oldpass[:,j]) for j in (1,2)])
        klin=float(np.interp(lam,full,klinear))
        pointtable.append({"lambda_um":lam,"n_hires":n,"k_hires_graph":kval,"k_linear_scenario":klin,"n_old_passive":float(old[0]),"k_old_passive":float(old[1]),"phase_change_per_99p8nm_rad":float(2*np.pi*.0998*(n-old[0])/lam),"optical_depth_change_per_99p8nm_linear_scenario":float(4*np.pi*.0998*(max(klin,0)-old[1])/lam)})
    overlay=Image.fromarray(rgb.astype('uint8')).resize((2508,1494))
    draw=ImageDraw.Draw(overlay)
    for raw,color in ((nraw,"red"),(kraw,"orange")):
        for row in raw[::4]:
            x,y=row[2]*2,row[3]*2
            draw.ellipse((x-2,y-2,x+2,y+2),fill=color)
    for x in xv:draw.line((x*2,669*2,x*2,687*2),fill="magenta",width=2)
    for y in nv:draw.line((799*2,y*2,813*2,y*2),fill="magenta",width=2)
    for y in kv:draw.line((1148*2,y*2,1162*2,y*2),fill="magenta",width=2)
    overlay.crop((1560,650,2508,1494)).save(OUT/"selected_points_and_calibration.png")
    result={"status":"independent_graph_calibration_not_new_ellipsometry","source_sha256":manifest,"doi":"10.1021/acsaelm.1c01026","figure_size_px":[1254,747],"authors_measured_range_um":[.35,2.5],"plot_identity":"Figure5d undoped ZnO reference n/k model-derived curves on SiO2/Si(100), not a new Zr-doped curve","calibration":{"x_ticks_pixel_runs":xticks,"x_values_um":[.5,1,1.5,2,2.5],"n_ticks_pixel_runs":nticks,"n_values":[2.4,2.2,2,1.8,1.6],"k_ticks_pixel_runs":kticks,"k_values":[.5,.4,.3,.2,.1,0],"x_to_lambda_um":xcoef.tolist(),"y_to_n":ncoef.tolist(),"y_to_k":kcoef.tolist(),"nominal_half_pixel_n_sensitivity":float(abs(ncoef[0])*.5),"nominal_half_pixel_k_sensitivity":float(abs(kcoef[0])*.5),"sensitivity_is_not_experimental_uncertainty":True},"raw_n_domain_um":[float(nraw[0,0]),float(nraw[-1,0])],"raw_k_domain_um":[float(kraw[0,0]),last_k],"k_last_visible_nm":1000*last_k,"last_uncolored_interval_to_2500_nm":1000*(2.5-last_k),"n_covers_2500_by_visible_pixels":bool(nraw[-1,0]>=2.5),"old_n_last_um":float(oldn[-1,0]),"old_k_last_um":float(oldk[-1,0]),"raw_k_min":float(kraw[:,1].min()),"raw_k_negative_point_count":int((kraw[:,1]<0).sum()),"same_domain_comparison":comparison,"threshold_sensitivity":variants,"tail_scenarios":extensions,"tail_linear_continuity_anchored_k_2p5":float(klinear[-1]),"tail_hold_k_2p5":float(kbase[-1]),"selected_values":pointtable,"interpretation":["The author's 350-2500nm measurement domain is explicit in the original text.","Visible dashed k pixels end before2500nm because line styling has blank segments; this does not prove author data were absent in the last segment.","Graph-domain table retains raw signed k; separately named scenario tables apply passive max(k,0) projection and disclose their tail continuation.","Source Eq5 normalization ambiguity remains separate; no author equation has been corrected.","No shared input or prior calculation was changed, and no new Maxwell sweep was run."]}
    result["postflight_source_sha_all_match"]=all(sha(ROOT/p)==digest for p,digest in manifest.items())
    assert result["postflight_source_sha_all_match"]
    (OUT/"results.json").write_text(json.dumps(result,indent=2),encoding="utf8")
    print(json.dumps({k:result[k] for k in ("calibration","raw_n_domain_um","raw_k_domain_um","same_domain_comparison","threshold_sensitivity","tail_linear_continuity_anchored_k_2p5","tail_hold_k_2p5","postflight_source_sha_all_match")},indent=2))

if __name__=="__main__":main()
