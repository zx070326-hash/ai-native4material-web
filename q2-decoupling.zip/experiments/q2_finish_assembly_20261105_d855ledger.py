"""One d8.55 AR19 physical ledger/clearance and existing analytic bow checks."""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import argparse,hashlib,json
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False)
    old=ROOT/'runs/20261105-q2-finish-source25-combined64-01';new=ROOT/'runs/20261105-q2-finish-assembly-phase25-d8p55-source64-01';thermal=ROOT/'runs/20261105-q2-finish-assembly-phase25-01/thermal_control_fields.npz';u=np.load(old/'fields.npz');v=np.load(new/'fields.npz');tc=np.load(thermal)
    unchanged=[]
    for key in u.files:
        if key.startswith('thermal_')and key.endswith(('__theta_rad','__phi_correction_rad')):continue
        assert key in v and np.array_equal(u[key],v[key]);unchanged.append(key)
    assert all(np.array_equal(v[key],tc[key])for key in tc.files)
    AR=.08302889342260214
    seq=[('AR_Al2O3',AR),('ZnO',.0998),('Al2O3',8),('SiNx',.02),('E7_drive',2.5),('SiNx',.02),('Al2O3',8),('ZnO',.0998),('AR_Al2O3',AR),('ambient_air',2),('Al2O3',8),('SiNx',.02),('E7_comp',2.5),('SiNx',.02),('Al2O3',8),('SiNx',.02),('E7_thermal',8.55),('SiNx',.02),('Al2O3',8)]
    z=0;rows=[]
    for name,t in seq:rows.append({'material_role':name,'thickness_um':t,'start_um':z,'end_um':z+t});z+=t
    solid=[q for q in rows if q['material_role']!='ambient_air'];assert len(solid)+1==19 and all(.01<=q['thickness_um']<=10 for q in solid)
    E,nu,t,rad=170e9,.22,8e-6,150e-6;D=E*t**3/(12*(1-nu**2));C0=rad**4/(64*D);Q=np.array([[2,0,0],[0,2,-1],[0,-1,2.]])
    d=np.array([2.5,2.5,8.55]);h=d+.04;bow=[]
    for gamma in [.025,.03,.035]:
        press=-2*gamma*(1/(h*1e-6)+1/20e-6);delta=C0*(Q@press)*1e6;maximum=np.maximum(d,d+delta);baremax=np.maximum(h,h+delta)
        bow.append({'gamma_scenario_N_m':gamma,'cos_theta_scenario':1,'pressure_Pa':press.tolist(),'center_LC_thickness_um':(d+delta).tolist(),'max_LC_thickness_um':maximum.tolist(),'max_bare_gap_um':baremax.tolist(),'all_LC_below10um':bool(np.all(maximum<=10)),'all_bare_gaps_below10um':bool(np.all(baremax<=10))})
    manifest=ROOT/'runs/20261105-q2-finish-source25-config-01/config.json';inputs=json.loads(manifest.read_text())['SHA256'];inputcheck={p:sha(ROOT/p)==h for p,h in inputs.items()};assert all(inputcheck.values())
    result={'axial_main_sequence':rows,'main_envelope_excluding_external_screen_um':z,'support_total_um':40,'main_retained_material_layers_before_screen':18,'main_including_screen_excluding_ambient':19,'main_if_ambient_air_also_counted':20,'whole_named_inventory_vented':25,'per_path_retained_max_including_screen':{'main':19,'liquid_ring':11,'bare_external_electrode_intermodule_standoff':9,'vented_fill_branch':11,'carbon_contact':13},'thermal_LC_um':8.55,'bare_thermal_spacer_height_um':8.59,'clearance':{'AR_footprint_square_um':[-105,105],'liquid_ring_radius_um':[150,170],'standoff_radius_um':[180,200],'bare_ZnO_to_compensator_Al2O3_standoff_um':2+AR,'actual_AR_outerface_to_compensator_Al2O3_air_um':2.,'if_old2um_standoff_is_kept_actual_air_um':2-AR,'correction':'BecauseARisopticalregiononlyandstandofftouchesbareZnO,use2.083028893umAlstandofftoimplementthealreadycomputed2umair.Noextraretainedlayer.','ARcorner_to_liquid_ring_um':150-105*np.sqrt(2),'ARcorner_to_standoff_um':180-105*np.sqrt(2),'fill_ports_um':[[250,300],[250,400],[250,500]],'port_width_um':20,'branch_width_um':20,'caps_retained':0,'global_pattern_min_um':1.5},'bow':{'C0_m_Pa':C0,'pressure_matrix':Q.tolist(),'thermal_pressure_combination_to_LC10um_Pa':(10-8.55)*1e-6/C0,'scenarios':bow,'limits':['Uniformcapillarypressure,ventedambientgas,a150circularclamp,8umAlE170GPa,nu.22,zeroresidualstress.','Gammaexamplesnotameasured25/50thermalinterval.','NoMaxwellstress/CTE/releasedresidualbowincluded;flatopticalsourceisnotbow-coupleddevicecertificate.']},'source_identity':{'old_combined_SHA256':sha(old/'fields.npz'),'d855_combined_SHA256':sha(new/'fields.npz'),'true_d855_thermal_SHA256':sha(thermal),'unchanged_arrays':unchanged,'all_four_electric_theta_u_and_potentials_byte_equal':True,'all_d855_thermal_arrays_equal_true_Frank_control':True,'original22_frozen_inputs_reverified':inputcheck,'scope':'Actualopticalrun41or40dependencyreceiptmustbecheckedatitsowner;thisverifiesthese22sourceinputsandactualbundlearrays,notanunseenfutureMaxwellrun.'},'scope':'Same19layerphysicalledgerandoneanalyticbowcheck,notanewopticalsolveorallprocesscertificate.'}
    (a.out/'results.json').write_text(json.dumps(result,indent=2),encoding='utf-8');(a.out/'source.py').write_bytes(Path(__file__).read_bytes());print(json.dumps({'envelope_um':z,'clearance':result['clearance'],'bow':bow,'unchanged_arrays':len(unchanged),'frozen_inputs':len(inputcheck)},indent=2))
if __name__=='__main__':main()
