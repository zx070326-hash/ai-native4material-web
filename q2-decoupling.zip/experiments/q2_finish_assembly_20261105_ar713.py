"""Frozen-input six-shard713 spectrum for the fixed external19-layer candidate.

This orchestrates the existing external_ar optical entrypoint with no physics
changes. Manifest preparation precedes every shard; each shard checks it again.
"""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import argparse,hashlib,json,runpy,sys,time
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
ENTRY='experiments/q2_finish_decouple_20261105_external_ar.py'
FIELDS='runs/20261105-q2-finish-external-director64-support32-01'
GRID='data/q2_close_materials_full713.npz'
OUT='runs/20261105-q2-finish-assembly-AR19-713-{shard}-01'


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,d):Path(p).write_text(json.dumps(d,indent=2),encoding='utf-8')
def checked(manifest):
    m=json.loads((manifest/'manifest.json').read_text())
    for path,h in m['SHA256'].items():
        if sha(ROOT/path)!=h:raise ValueError('Frozen input changed: '+path)
    return m


def prepare(a):
    from experiments import q2_finish_decouple_20261105_external_ar as ar
    assert abs(ar.thickness-.08302889342260214)<1e-15
    snapshot=Path(a.manifest);snapshot.mkdir(parents=True,exist_ok=False)
    source_paths=[]
    for module in list(sys.modules.values()):
        fn=getattr(module,'__file__',None)
        if not fn:continue
        p=Path(fn).resolve()
        if p.suffix=='.py' and p.is_relative_to(ROOT) and '.venv'not in p.parts:
            source_paths.append(p)
    source_paths.append(Path(__file__).resolve())
    data_paths=[ROOT/p for p in [FIELDS+'/fields.npz',FIELDS+'/results.json','runs/20261105-q2-package-A-director64-d1p45-02/fields.npz',GRID,'data/nk/Al2O3_Franta.csv','data/q2_current/Li2005_E7_Cauchy.csv','data/q2_finish_material_20261105/SiNx_spectrum/DLC_4keV_vector_digitized.csv','data/q2_package_A_20261105/ZnO2022_Fig5d_passive_digitized.csv','data/q2_parallel_loss_20261105/Wu2002_E7_graph_alpha_k.csv','data/constraints_upgrade_sources/C_Hagemann.csv','runs/20261105-q2-package-device-kernels-01/inner600/gram.npz','runs/20261105-q2-package-device-kernels-01/inner700/gram.npz','data/q2_current/solid_gram.npz']]
    paths=sorted(set(source_paths+data_paths));hashes={str(p.relative_to(ROOT)):sha(p)for p in paths}
    for p in paths:
        target=snapshot/'frozen'/p.relative_to(ROOT);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
    grid=np.load(ROOT/GRID)['wavelength_um'];assert len(grid)==713 and len(np.unique(grid))==713
    launches={str(i):[ENTRY,'optics','--d','2.5','--bias','12.235','--fields',FIELDS,'--grid',GRID,'--order','4','--slices','32','--shards','6','--shard',str(i),'--out',OUT.format(shard=i)]for i in range(6)}
    result={'prepared_time_unix':time.time(),'SHA256':hashes,'launches':launches,'source_field_SHA256':sha(ROOT/FIELDS/'fields.npz'),'AR_each_um':ar.thickness,'fixed_external_V_RMS':[0,12.235],'main_layers_including_screen_excluding_ambient':19,'source_grid':{'nodes':713,'minmax_um':[float(grid.min()),float(grid.max())],'half_even_nodes':len(grid[::2]),'boundary078_in_even_subset':bool(np.any(abs(grid[::2]-.78)<1e-12))},'geometry':'FiveAl8um supports,3LCd2.5/2.5/8.353152um,6SiNx20nm,2ZnO99.8nm outerelectrodes,2AR83.028893nm outsideelectrodes,2um coherentambientgap,10mmoutputscreen','scope':'No new V, material or thickness search;713 actual solves, sixshards. Does not establish uniform spectral convergence, manufacturing or fullproblem closure.'}
    save(snapshot/'manifest.json',result);(snapshot/'source.py').write_bytes(Path(__file__).read_bytes());print(json.dumps({'manifest':str(snapshot.relative_to(ROOT)),'dependencies':len(hashes),'grid':result['source_grid'],'fields_SHA':result['source_field_SHA256'],'AR_um':ar.thickness}),flush=True)


def solve(a):
    m=checked(a.manifest);argv=m['launches'][str(a.shard)];out=ROOT/OUT.format(shard=a.shard)
    if out.exists():raise ValueError('Refusing existing shard directory '+str(out))
    save(a.manifest/f'preflight-shard{a.shard}.json',{'time_unix':time.time(),'shard':a.shard,'argv':argv,'manifest_SHA256':sha(a.manifest/'manifest.json'),'all_inputs_match':True})
    sys.argv=argv;runpy.run_path(str(ROOT/ENTRY),run_name='__main__')
    checked(a.manifest)
    save(out/'frozen_manifest_receipt.json',{'manifest':str(a.manifest.relative_to(ROOT)),'manifest_SHA256':sha(a.manifest/'manifest.json'),'all_inputs_before_and_after_match':True,'shard':a.shard,'fields_SHA256':m['source_field_SHA256'],'source_fields':FIELDS,'grid':GRID,'solver_thread_limits':{k:os.environ[k]for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']}})


def readout(a):
    from experiments.q2_gap_vector_review import load_runs
    from experiments.q2_package_A_20261105 import readout as existing
    from experiments.lead_balance_compact_port import summarize
    from experiments.q2_upgrade_output import spectral_cross
    m=checked(a.manifest);paths=[ROOT/OUT.format(shard=i)for i in range(6)]
    for i,p in enumerate(paths):
        receipt=json.loads((p/'frozen_manifest_receipt.json').read_text());assert receipt['all_inputs_before_and_after_match']and receipt['shard']==i
        launch=json.loads((p/'launch.json').read_text());assert launch['argv']==m['launches'][str(i)]
    z=load_runs(paths);w=z['wavelength_um'];assert len(w)==713 and len(np.unique(w))==713 and np.array_equal(w,np.load(ROOT/GRID)['wavelength_um'])
    a.out.mkdir(parents=True,exist_ok=False);summary={}
    for inner in [600,700]:
        dest=a.out/f'inner{inner}';dest.mkdir();hole=ROOT/f'runs/20261105-q2-package-device-kernels-01/inner{inner}/gram.npz'
        existing(argparse.Namespace(runs=paths,hole=hole,out=dest))
        r=json.loads((dest/'results.json').read_text());s=np.load(dest/'spectra.npz');T=s['total_T'];ix=np.arange(0,len(w),2);assert len(ix)==357 and np.any(abs(w[ix]-.78)<1e-12)
        half=summarize(w[ix],T[:,:,ix]);cross=spectral_cross(w[ix],T[:,:,ix])[0]
        diag={'nodes':len(ix),'indices':'0,2,...,712; includes.4/.78/2.5','main':half,'cross':cross,'main_change_vs713_pp':{'VIS':half['VIS_conditional_lower_pp']-r['main']['VIS_conditional_lower_pp'],'NIR':half['NIR_model_pp']-r['main']['NIR_model_pp']},'scope':'Subset integration of saved713 actual fields. Not new intermediate source solve, not an allband error bound.'}
        r['identity']={'AR_external_layers':19,'fixed_external_V':[0,12.235],'source':FIELDS,'source_SHA256':m['source_field_SHA256'],'six_shards':True,'source_manifest':str(a.manifest.relative_to(ROOT)),'source_manifest_SHA256':sha(a.manifest/'manifest.json'),'scope':'Actual external electrode fiveboard/AR19-layer fourstate; no internal16layer substitution.'};r['half357_diagnostic']=diag
        save(dest/'results.json',r);summary[str(inner)]={'main':r['main'],'cross':r['cross'],'half357':diag,'signed_exterior_residual_range':r['exterior_residual_range'],'spectral_nodes':713}
    result={'manifest':str(a.manifest.relative_to(ROOT)),'shards':[str(p.relative_to(ROOT))for p in paths],'source_SHA256':{str((p/f).relative_to(ROOT)):sha(p/f)for p in paths for f in ['results.json','scattered_fields.npz']},'records':summary,'scope':'Same19layer/source/V/AR/device fields, fixed600and700 masks separately across allfourstates.713 numerical sampling and357 subset diagnostics, not full-domain error bound.','normalization':'fullGaussian power denominator; hard150um/waist75 truncation not renormalized','manufacturing':'opticsonlyAR,externalZnOcontacts/standofflanduncoated;19mainlayersandperipheralretainedinventoryseparate'}
    save(a.out/'results.json',result);(a.out/'source.py').write_bytes(Path(__file__).read_bytes());print(json.dumps({k:{'main':[v['main']['VIS_conditional_lower_pp'],v['main']['NIR_model_pp']],'half357change':v['half357']['main_change_vs713_pp']}for k,v in summary.items()}),flush=True)


def main():
    p=argparse.ArgumentParser();p.add_argument('action',choices=['prepare','solve','readout']);p.add_argument('--manifest',type=Path,required=True);p.add_argument('--shard',type=int,choices=range(6));p.add_argument('--out',type=Path);a=p.parse_args();a.manifest=a.manifest.resolve();a.out=a.out.resolve()if a.out else None;globals()[a.action](a)


if __name__=='__main__':main()
