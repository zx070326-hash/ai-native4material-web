"""Fetch only primary E7 constitutive sources requested for the mechanism."""
from pathlib import Path
import argparse,json,hashlib,time,concurrent.futures
import requests

TARGETS={
 'E7hCNT2025.xml':'https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12029598/fullTextXML',
 'E7hCNT2025.pdf':'https://mdpi-res.com/d_attachment/micromachines/micromachines-16-00457/article_deploy/micromachines-16-00457.pdf',
 'E7hCNT2025_OA.xml':'https://pmc.ncbi.nlm.nih.gov/utils/oa/oa.fcgi?id=PMC12029598',
 'Hakemi1983_attempt.pdf':'https://www.tandfonline.com/doi/pdf/10.1080/00268948308083080',
}
def main():
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False)
 def fetch(item):
  name,url=item
  try:
   r=requests.get(url,timeout=40);body=r.content;kind='pdf'if body.startswith(b'%PDF')else('xml'if(b'<article' in body[:4000]or b'<OA>'in body[:4000])else'other')
   saved=name if(kind=='pdf'and name.endswith('.pdf'))or(kind=='xml'and name.endswith('.xml'))else name+'.response.txt'
   (a.out/saved).write_bytes(body)
   return {'target':name,'url':url,'final_url':r.url,'status':r.status_code,'content_type':r.headers.get('Content-Type'),'detected':kind,'saved':saved,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}
  except Exception as e:return {'target':name,'url':url,'error':str(e)}
 with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:rows=list(pool.map(fetch,TARGETS.items()))
 (a.out/'source_manifest.json').write_text(json.dumps({'rows':rows,'time_unix':time.time(),'scope':'PublicprimaryauthoredE7constitutivesources;request/accessfailuresnotabsenceofdata'},indent=2));(a.out/'source.py').write_bytes(Path(__file__).read_bytes());print(json.dumps(rows,indent=2))
if __name__=='__main__':main()
