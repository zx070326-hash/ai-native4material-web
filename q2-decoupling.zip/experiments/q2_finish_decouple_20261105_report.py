"""Compact reproducible readout/point controls, no new physical simulation."""
from pathlib import Path
import argparse,json,sys,hashlib
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))

def points(a):
 base=np.load(ROOT/'runs/20261105-q2-finish-decouple-SiNx-readout-d2p5-127-01/spectra.npz');w=base['wavelength_um'];T=base['total_T'];rows=[]
 ids=np.load(ROOT/'runs/20261105-q2-finish-decouple-pointgrid-01/grid.npz')['wavelength_um'];Tb=T[:,:,np.searchsorted(w,ids)]
 for name in ['1p5nominal','4Vcontrol','V1p48','V1p52']:
  Q=Tb if name=='1p5nominal'else np.load(ROOT/f'runs/20261105-q2-finish-decouple-SiNx-readout-{name}-points-01/spectra.npz')['total_T']
  rows.append({'name':name,'wavelength_um':ids.tolist(),'thermal_byV_pp':(100*(Q[:,1]-Q[:,0])).tolist(),'electric_byT_pp':(100*(Q[1]-Q[0])).tolist(),'max_single_state_change_from1p5_pp':float(100*np.max(abs(Q-Tb))),'T':Q.tolist()})
 result={'scope':'Six fixed exact127-grid actual-wavelength pointwise comparisons, not sparse-bandintegrals','rows':rows,'limits':['fixedV at eachT, same16layers/material/finite700holes','4V hot director reached2800iterationcap withgrad2.26e-6, retained finite source control not a convergedsolutioncertificate','voltages1.48/1.5/1.52 all independently2Drelaxed']}
 (a.out/'results.json').write_text(json.dumps(result,indent=2));print(json.dumps([{k:v for k,v in r.items()if k!='T'}for r in rows],indent=2))

def overview(a):
 import matplotlib;matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 paths=[('DLC4um1.65V','20261105-q2-finish-decouple-readout-d4-127-01'),('DLC2.5um1.5V','20261105-q2-finish-decouple-readout-d2p5-127-01'),('SiNx2.5um1.5V','20261105-q2-finish-decouple-SiNx-readout-d2p5-127-01')]
 rows=[];hashes={}
 for name,d in paths:
  p=ROOT/'runs'/d;r=json.loads((p/'results.json').read_text());row={'name':name,'main_pp':[r['main']['VIS_conditional_lower_pp'],r['main']['NIR_model_pp']],'thermal_VIS_meanabs_peak_pp':[max(r['cross']['VIS'][k])for k in ['absolute_spectral_cross_band_means_pp','max_absolute_spectral_cross_pp']],'voltage_NIR_meanabs_peak_pp':[max(r['cross']['NIR'][k])for k in ['absolute_spectral_cross_band_means_pp','max_absolute_spectral_cross_pp']],'path':str(p.relative_to(ROOT))};rows.append(row)
  for f in ['results.json','spectra.npz']:hashes[str((p/f).relative_to(ROOT))]=hashlib.sha256((p/f).read_bytes()).hexdigest()
 z=np.load(ROOT/'runs'/paths[-1][1]/'spectra.npz');w=z['wavelength_um'];T=z['total_T'];fig,ax=plt.subplots(2,2,figsize=(12,8),constrained_layout=True)
 for vi in [0,1]:
  for ti in [0,1]:ax[0,0].plot(w,100*T[vi,ti],lw=1,label=f'{[0,1.5][vi]:g} V / {[15,50][ti]} C')
 ax[0,0].set(title='Same-device four states: SiNx three cells',ylabel='Finite-port T (%)');ax[0,0].legend(fontsize=8)
 for vi in [0,1]:ax[0,1].plot(w,100*(T[vi,1]-T[vi,0]),lw=1,label=f'{[0,1.5][vi]:g} V')
 ax[0,1].set(xlim=(.4,.78),title='Thermal cross response in VIS',ylabel='Hot - cold (pp)');ax[0,1].legend(fontsize=8)
 for ti in [0,1]:ax[1,0].plot(w,100*(T[1,ti]-T[0,ti]),lw=1,label=f'{[15,50][ti]} C')
 ax[1,0].set(xlim=(.78,2.5),title='Electrical cross response in NIR',ylabel='1.5 V - 0 V (pp)');ax[1,0].legend(fontsize=8)
 x=np.arange(len(rows));ax[1,1].bar(x-.15,[r['main_pp'][0]for r in rows],.3,label='VIS passivity lower');ax[1,1].bar(x+.15,[r['main_pp'][1]for r in rows],.3,label='NIR');ax[1,1].axhline(30,color='C0',ls=':',lw=.8);ax[1,1].axhline(20,color='C1',ls=':',lw=.8);ax[1,1].set_xticks(x,['DLC 4um','DLC 2.5um','SiNx 2.5um']);ax[1,1].set(title='Fixed physical mechanism / loss control',ylabel='Main modulation (pp)');ax[1,1].legend(fontsize=8)
 for aa in ax.ravel():aa.grid(alpha=.2)
 for aa in [ax[0,0],ax[0,1],ax[1,0]]:aa.set_xlabel('Wavelength (um)')
 fig.suptitle('Conditional three-cell pilot: 127 wavelengths, 32x17 electric source, +/-4 Fourier / 32 slices',fontsize=11)
 for suffix in ['png','svg']:fig.savefig(a.out/f'compensation_summary.{suffix}',dpi=150)
 plt.close(fig)
 (a.out/'results.json').write_text(json.dumps({'rows':rows,'hashes':hashes,'full_problem_solved':False,'scope':'actual four-state pilot readback; no crosstalk cutoff, no A/manufacturing closure; 64source/713 refinement separate'},indent=2));print(json.dumps(rows,indent=2))

def dense(a):
 import matplotlib;matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 p=(a.readout or ROOT/'runs/20261105-q2-finish-decouple-SiNx-readout64-713-600-01').resolve();z=np.load(p/'spectra.npz');w=z['wavelength_um'];T=z['total_T'];r=json.loads((p/'results.json').read_text());coarse=np.unique(np.r_[np.arange(0,len(w),2),np.argmin(abs(w-.78)),len(w)-1])
 def mean(x,y,lo,hi):
  ix=(x>=lo)&(x<=hi);return np.trapezoid(y[...,ix],x[ix],axis=-1)/(hi-lo)
 def stats(x,y):
  v=mean(x,y,.4,.78);n=mean(x,y,.78,2.5)
  return {'main_pp':[float(100*(.95*np.min(abs(v[1]-v[0]))-.05)),float(100*np.min(abs(n[:,1]-n[:,0])))],'VIS_thermal_meanabs_pp':(100*mean(x,abs(y[:,1]-y[:,0]),.4,.78)).tolist(),'NIR_electric_meanabs_pp':(100*mean(x,abs(y[1]-y[0]),.78,2.5)).tolist()}
 fine=stats(w,T);half=stats(w[coarse],T[:,:,coarse]);assert np.max(abs(np.array(fine['main_pp'])-np.array([r['main']['VIS_conditional_lower_pp'],r['main']['NIR_model_pp']])))<1e-10
 fig,axs=plt.subplots(2,2,figsize=(12,8),constrained_layout=True)
 for vi in [0,1]:
  for ti in [0,1]:
   label=f'{[0,1.5][vi]:g} V / {[15,50][ti]} C'
   for aa in axs[0]:aa.plot(w,100*T[vi,ti],lw=.85,label=label)
 axs[0,0].set(xlim=(.4,.78),title='VIS same-device four states',ylabel='Port T (%)');axs[0,1].set(xlim=(.78,2.5),title='NIR same-device four states',ylabel='Port T (%)')
 for vi in [0,1]:axs[1,0].plot(w,100*(T[vi,1]-T[vi,0]),lw=.8,label=f'{[0,1.5][vi]:g} V')
 axs[1,0].set(xlim=(.4,.78),title='VIS thermal cross response',ylabel='Hot - cold (pp)')
 for ti in [0,1]:axs[1,1].plot(w,100*(T[1,ti]-T[0,ti]),lw=.8,label=f'{[15,50][ti]} C')
 axs[1,1].set(xlim=(.78,2.5),title='NIR electrical cross response',ylabel='1.5 V - 0 V (pp)')
 # Autoscaling must use the displayed band; out-of-window main switching
 # otherwise gives a large empty y range and obscures actual crosstalk.
 for ax,values,mask in [(axs[1,0],100*(T[:,1]-T[:,0]),w<=.78),(axs[1,1],100*(T[1]-T[0]),w>=.78)]:
  lo=float(values[:,mask].min());hi=float(values[:,mask].max());pad=.07*(hi-lo);ax.set_ylim(lo-pad,hi+pad)
 for aa in axs.ravel():aa.set_xlabel('Wavelength (um)');aa.grid(alpha=.2);aa.legend(fontsize=8)
 fig.suptitle(f'Internal-electrode 16-layer conditional model: 64x33 source / {len(w)} actual wavelengths / fixed600um holes',fontsize=11)
 for ext in ['png','svg']:fig.savefig(a.out/f'four_state_dense.{ext}',dpi=150)
 plt.close(fig)
 result={'source':str(p.relative_to(ROOT)),'fine_independent':fine,'half_grid_same_fields':half,'main_coarse_minus_fine_pp':(np.array(half['main_pp'])-np.array(fine['main_pp'])).tolist(),'cross':r['cross'],'periodic_numerics':r['periodic_numerics'],'limits':['independentreintegration agreeswithstoredmain','halfgriddiagnostic isnotuniformspectral/source/materialerrorbound','internal16layerconditionalmodelisnotexternal17/19layerassembly','noacceptedcrosstalkcutoffadded']};(a.out/'results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))

def main():
 p=argparse.ArgumentParser();p.add_argument('action',choices=['points','overview','dense']);p.add_argument('--out',type=Path,required=True);p.add_argument('--readout',type=Path);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False);globals()[a.action](a);(a.out/'source.py').write_bytes(Path(__file__).read_bytes())
if __name__=='__main__':main()
