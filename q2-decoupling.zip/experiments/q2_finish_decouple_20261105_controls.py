"""Seed and finite-direction curvature checks for selected fixed-bias points."""
import os
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import argparse,json,sys,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments import q2_finish_decouple_20261105 as b
from experiments.q2_manufacturing_lc_director2d import problem
from autograd import value_and_grad
from scipy.optimize import minimize

def main():
 p=argparse.ArgumentParser();p.add_argument('--fields',type=Path,required=True);p.add_argument('--d',type=float,required=True);p.add_argument('--bias',type=float,required=True);p.add_argument('--sinx',action='store_true');p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False);tic=time.perf_counter()
 D=b.direct_electric()
 if a.sinx:
  from experiments.q2_finish_decouple_20261105_sinx import sinx_electric
  D=sinx_electric()
 data=np.load(a.fields/'fields.npz');rows=[];arr={};nx,nz=data['electric_T15_V0__theta_rad'].shape
 X,Z=np.meshgrid(2*np.pi*np.arange(nx)/nx,np.linspace(0,1,nz),indexing='ij')
 directions=[]
 for t,u in [(np.sin(np.pi*Z),Z*0),(np.cos(X)*np.sin(np.pi*Z),Z*0),(np.sin(X)*np.sin(np.pi*Z),Z*0),(np.cos(2*X)*np.sin(np.pi*Z),Z*0),(Z*0,np.sin(X)),(Z*0,np.sin(2*X))]:
  q=np.r_[t.ravel(),u.ravel()];directions.append(q/np.linalg.norm(q))
 for T in [15,50]:
  for V in [a.bias,0.]:
   key=f'electric_T{T}_V{V:g}';K=np.array([11.1,6.5,17.1])*b.scale(T);f,_,meta=problem(a.d,12,K,nx,nz,Wp=2e-4,Wa=1.14e-4,pattern='8step');fvg=value_and_grad(f);ev=D(a.d,12,K[0],nx,nz,V)
   def fg(q):
    fr,gr=fvg(q);gs,psi,ck=ev.solve(q);_,eg=ev.evg(q,gs);return float(fr-ck['positive_electric_dimensionless']),gr+eg
   orig=np.r_[data[key+'__theta_rad'].ravel(),data[key+'__phi_correction_rad'].ravel()];seed=np.r_[(.02*np.sin(np.pi*Z)).ravel(),data[f'electric_T{T}_V0__phi_correction_rad'].ravel()]
   sol=minimize(fg,seed,jac=True,method='L-BFGS-B',bounds=[(-np.pi/2+1e-5,np.pi/2-1e-5)]*(nx*nz)+[(None,None)]*(nx*nz),options={'maxiter':2800,'maxcor':40,'maxls':40,'ftol':1e-13,'gtol':2e-8})
   e0=fg(orig)[0];ee=fg(sol.x)[0];curves=[]
   for h in [1e-3,5e-4]:curves.append([(fg(orig+h*v)[0]+fg(orig-h*v)[0]-2*e0)/h**2 for v in directions])
   def unit(q):
    th=q[:nx*nz].reshape(nx,nz);ph=q[nx*nz:].reshape(nx,nz)+X
    return np.stack([np.cos(th)*np.cos(ph),np.cos(th)*np.sin(ph),np.sin(th)],-1)
   axis=np.rad2deg(np.arccos(np.clip(abs(np.sum(unit(orig)*unit(sol.x),axis=-1)),0,1)))
   row={'key':key,'original_energy_dimensionless':e0,'lowtilt_energy_dimensionless':ee,'low_minus_original_J_m2':(ee-e0)*meta['energy_unit_J_m2'],'lowseed_success':bool(sol.success),'lowseed_nit':int(sol.nit),'lowseed_gradient_inf':float(abs(sol.jac).max()),'headtail_axis_difference_max_deg':float(axis.max()),'directional_second_derivatives':curves,'direction_order':['uniform_sinz_theta','cosx_sinz_theta','sinx_sinz_theta','cos2x_sinz_theta','sinx_phi','sin2x_phi'],'elapsed_s':time.perf_counter()-tic};rows.append(row)
   arr[key+'__theta_rad']=sol.x[:nx*nz].reshape(nx,nz);arr[key+'__phi_correction_rad']=sol.x[nx*nz:].reshape(nx,nz);print(json.dumps(row),flush=True)
   np.savez_compressed(a.out/'lowseed_fields.npz',**arr);(a.out/'results.json').write_text(json.dumps({'rows':rows,'scope':'Two independent tilt seeds and six finite directions at two step sizes; fixed-winding local evidence, not Hessian minimum/global/3D stability proof'},indent=2))
 vertical=[]
 for T in [15,50]:
  low=.02*np.sin(np.linspace(0,np.pi,65));high=1.4*np.sin(np.linspace(0,np.pi,65))+.02
  th0,c0=b.vertical(a.d,a.bias,T,low);th1,c1=b.vertical(a.d,a.bias,T,high);vertical.append({'T':T,'low_seed':c0,'high_seed':c1,'axis_difference_max_deg':float(np.rad2deg(abs(th0-th1)).max()),'scope':'1Dreducedmodel;SiNxfilmnotpartofthisdiagnostic'})
 r=json.loads((a.out/'results.json').read_text());r['oneD_seed_checks']=vertical;(a.out/'results.json').write_text(json.dumps(r,indent=2));(a.out/'source.py').write_bytes(Path(__file__).read_bytes())
if __name__=='__main__':main()
