"""Independent actual-input n, layer and feature audit; no field/Maxwell solve."""
import os
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
from pathlib import Path
import sys,json,hashlib,shutil
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments import q2_finish_decouple_20261105_source25_phase855 as actual
OUT=ROOT/'runs/20261105-q2-finish-material-final-constraints-01';OUT.mkdir(parents=True,exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths={'ZnO':ROOT/'runs/20261105-q2-finish-material-ZnO-hires-input-01/ZnO2022_Fig5d_hires_exactnodes_tail_linear_scenario.csv','SiNx':ROOT/'data/q2_finish_material_20261105/SiNx_spectrum/DLC_4keV_vector_digitized.csv','Al2O3':ROOT/'data/nk/Al2O3_Franta.csv','C_screen':ROOT/'data/constraints_upgrade_sources/C_Hagemann.csv','E7_real':ROOT/'data/q2_current/Li2005_E7_Cauchy.csv','E7_loss':ROOT/'data/q2_parallel_loss_20261105/Wu2002_E7_graph_alpha_k.csv'}
source=actual.source
for name in ('ZnO','SiNx'):
 assert str(paths[name].relative_to(ROOT)).replace('\\','/')in source
assert '[25,50]'in source and 'd=8.55 if kind=='in source and "old.index('Al2O3_Franta'"in source
assert 'ne+=1j*k;no+=1j*k'in source
rows=[]
for name in ('ZnO','SiNx','Al2O3','C_screen'):
 a=np.loadtxt(paths[name],delimiter=',',skiprows=1);w=np.unique(np.r_[.38,2.5,a[(a[:,0]>.38)&(a[:,0]<2.5),0]])
 if name=='Al2O3':
  from experiments.q2_closure_coupling import model
  values=model.old.index('Al2O3_Franta',w).real
 else:values=np.interp(w,a[:,0],a[:,1])
 n550=float(np.interp(.55,a[:,0],a[:,1]));r={'material':name,'working_temperatures_C':[25,50],'model_temperature_policy':'same source complex spectrum at bothT','loaded_table_range_um':[float(a[0,0]),float(a[-1,0])],'target_um':[.38,2.5],'Re_n_min':float(values.min()),'Re_n_max':float(values.max()),'min_at_um':float(w[values.argmin()]),'max_at_um':float(w[values.argmax()]),'A_model_pointwise_range_pass':bool(np.all((values>=1.5)&(values<=3))),'B_reference_550nm_25C_Re_n':n550,'B_reference_model_pass':bool(1.5<=n550<=3),'method':'Piecewise-linear table: exact extrema over each linearsegment occur at nodes/endpoints, not a dense sample certificate.'};rows.append(r)
for T in (25,50):
 # The actual positive-coefficient Cauchy functions are monotonically decreasing
 # over this positive wavelength interval, so endpoints give exact model extrema.
 ne,no=actual.base.indices(T,np.array([.38,2.5]));ne550,no550=actual.base.indices(T,.55)
 for axis,values,ref in (('ne',ne,ne550),('no',no,no550)):
  rows.append({'material':'E7_'+axis,'working_temperature_C':T,'target_um':[.38,2.5],'Re_n_min':float(min(values)),'Re_n_max':float(max(values)),'min_at_um':2.5,'max_at_um':.38,'A_model_pointwise_range_pass':bool(min(values)>=1.5 and max(values)<=3),'B_reference_550nm_25C_Re_n':float(ref)if T==25 else None,'B_reference_model_pass':bool(1.5<=ref<=3)if T==25 else None,'n550_at_this_temperature':float(ref),'method':'Actual positive-coefficient Cauchy A+B/lambda^2+C/lambda^4; analytic monotonic endpoint extrema; wavelength inum.'})
coverage={
 'ZnO':{'source':'doi10.1021/acsaelm.1c01026 originalFig5d1254x747; undoped reference99.8nm','original_measured_domain_um':[.35,2.5],'visible_blue_n_reaches_target_end':True,'last_visible_green_k_um':2.4448051948051948,'table_operations':'335nodeunion,colorcolumnmedian;linearinterpolation;rawnegativekfloor0;terminalgreenblankto2.5explicitlinearcontinuation,k2.5=.041801115572','transfers':'samegraphboth25/50; substrate/process/temperature transfer;noindependentDCtransportcertificate'},
 'SiNx':{'source':'Amato arxiv2409.07147 sample23028 nativevectorFig4; plot190-2500nm','loaded_graph_domain_um':[.38,2.5],'operations':'Linearinterpolationofretainedcomplexfit; k>560nmbelowinstrumentsensitivityisnotmeasuredzero','transfers':'IBS50-500nmfamilyopticalsource→20nmalignmentlayer;PECVD/ionalignmentnotidenticalfilm;both25/50sameopticalfit;Wa,Wp,epsilon7.5scenarios'},
 'Al2O3':{'source':'Franta2015,doi10.1117/12.2190104,authornumericaldataset','tabulated_domain_um':[.114114,125.124],'operations':'Actualmodel.old.indexboundcheckedlinearcomplexinterpolation;no380-400nmendhold','transfers':'Roomtemperature121.5nmebeam/cSisource→8umsupports and83.028893nmAR;notmatchedsubstrate/stress/release/25-50spectrum'},
 'E7_real':{'source':'Li2005,doi10.1063/1.1877815,TableI;localoriginalsourceJSON','source_temperature_points_C':[15,20,25,30,35,40,45,50],'measured_wavelengths_um':[.450,.486,.546,.589,.633,.656,1.55,10.6],'operations':'Cauchyfitfromsixvisiblelines;380-450nmandNIRcontinuoususeareextrapolation;discrete1.55/10.6checksnotcontinuous380-2500measuredn','transfers':'E7batch/surface/temperatureopticalvsdielectricsourcescombined;noindependentactualanisotropicfinite-Tcomplexspectrum'},
 'E7_loss':{'source':'Wu2002authorisotropic~70Calphagraph','raw_source_lower_um':.4,'operations':'Actualnp.interpholdsfirstalphaover380-400nmthenk=alpha*lambda*1e-4/(4pi);graphnodeinterpolationthereafter','transfers':'Isotropic70Calphatransferredtoboth25/50andbothaxes;380-400sampledmodelknotmeasuredsourceclosure'},
 'C_screen':{'source':'Hagemann1975doi10.1364/JOSA.65.000742 / DESY1974 dataset','operations':'Broadtabulatedcomplexn,klinearlyinterpolated,sourcecovers380-2500withoutwavelengthextension','transfers':'Datasetmaterial/film→5umfreecarbonscreen and3.75/5/6.25umconservativefinite-screencontrol;25/50opticsheldfixed,notfoilprocesscertificate'}}
ledger=json.loads((ROOT/'runs/20261105-q2-finish-assembly-d8p55-ledger-01/results.json').read_text());layers=ledger['axial_main_sequence'];solids=[x for x in layers if x['material_role']!='ambient_air'];thickness=[x['thickness_um']*1000 for x in solids]+[5000.]
size={'main_solid_layers_from_actual_sequence_including_screen':len(solids)+1,'ambient_gap_um':2.,'main_if_ambient_counted_as_layer':len(layers)+1,'main_layer_10_to_10000nm_all_pass':bool(all(10<=d<=10000 for d in thickness)),'solid_main_thicknesses_nm':thickness,'physical_support_count':5,'AR_each_nm':actual.pilot.ar.thickness*1000,'driver_comp_thermal_nm':[2500,2500,8550],'ZnO_each_nm':99.8,'SiNx_each_nm':20,'carbon_nominal_nm':5000,'carbon_control_nm':[3750,5000,6250],'min_easy_axis_band_um':1.5,'strict_feature_gt_1um_model_pass':True,'periphery_named_inventory':25,'scope':'Mainaxialinputcount/thicknessandeasy-axiswidthonly;peripheralgenuineobjectsnotdiscarded;notmanufacturing/process/packagingcertificate.'}
inputs={str(p.relative_to(ROOT)):sha(p)for p in [Path(__file__),Path(actual.__file__),ROOT/'experiments/q2_finish_decouple_20261105.py',ROOT/'runs/20261105-q2-finish-assembly-d8p55-ledger-01/results.json',*paths.values()]}
result={'candidate':'actuald8.55/source25/AR19/fixed9.235V/correctedZnO335','rows':rows,'coverage_and_migration':coverage,'size_check':size,'all_finite_solid_materials_A_model_range_pass':all(r['A_model_pointwise_range_pass']for r in rows),'all_finite_solid_materials_B_reference_pass':all(r['B_reference_model_pass']for r in rows if r['B_reference_model_pass']is not None),'A_evidence_closed':False,'B_reference_is_not_A':True,'ambient_if_n_constraint_applied':{'n':1.,'A_pass':False,'B_pass':False,'scope':'Ambientenvironmentexclusionisexplicitconvention;countingairas20thlayerdoesnotmakeitsn1satisfy1.5.'},'conditions':['Modelrangechecksareaboutactualloaders,notproofcontinuousmeasuredsourcecoverage.','380-400nmE7nCauchyextrapolationandWu-alphaendholdremain;noMaxwellsolvebelow400wasadded.','AandBseparatelyreported;Breference550nm25Cisexplicitchosenreferencecondition.','Finiteopticalsourcecoveragedoesnotverifytemperature/thickness/anchoring/processmigration.'],'inputs_sha256':inputs,'source_effective_sha256':hashlib.sha256(source.encode()).hexdigest(),'full_problem_solved':False}
(OUT/'results.json').write_text(json.dumps(result,indent=2));shutil.copy2(__file__,OUT/'source.py');print(json.dumps({'rows':rows,'sizes':size,'A_model':result['all_finite_solid_materials_A_model_range_pass'],'B_reference':result['all_finite_solid_materials_B_reference_pass']},indent=2))
