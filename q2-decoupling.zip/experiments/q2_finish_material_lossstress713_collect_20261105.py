"""Collect fixed union grid; separate source refinement from spectral refinement.

No optical field is recomputed. Requested713, original127, and nestedhalf grid
are selected from the same837 genuinely solved64-source wavelengths. Reports
are physical finite-carbon-port readouts of the retained complex fields.
"""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import sys,json,hashlib,argparse,contextlib,io
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments.q2_gap_vector_review import load_runs
from experiments.q2_package_A_20261105 import readout
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,default=ROOT/'runs/20261105-q2-finish-material-lossstress64-collected-01');a=ap.parse_args()
    runs=[ROOT/f'runs/20261105-q2-finish-material-lossstress64-union-optical-{i}'for i in range(3)]
    # Fail before any output if a still-running optical shard has no final data.
    originals=[json.loads((p/'results.json').read_text())for p in runs]
    for r in originals:
        assert all(r['input_hashes_unchanged_after_run'].values()),'Input drift reported by optical worker'
    z=load_runs(runs);w=z['wavelength_um'];assert len(w)==837 and np.all(np.diff(w)>0)
    a.out.mkdir(parents=True,exist_ok=False);(a.out/'launched_source.py').write_bytes(Path(__file__).read_bytes())
    launch=ROOT/'runs/20261105-q2-finish-material-lossstress-launch64-713-01';g713=np.load(launch/'grid713.npz')['wavelength_um'];g127=np.load(launch/'grid127.npz')['wavelength_um']
    half=np.unique(np.r_[np.arange(0,len(g713),2),np.argmin(abs(g713-.78)),len(g713)-1]);grids={'127':g127,'713':g713,'half713':g713[half]};results={};field_sources={}
    for key,target in grids.items():
        idx=np.array([np.argmin(abs(w-x))for x in target]);assert np.max(abs(w[idx]-target))<1e-10
        p=a.out/f'fields{key}';p.mkdir();sub={k:(z[k] if k=='harmonics' else z[k][idx])for k in z}
        np.savez_compressed(p/'scattered_fields.npz',**sub);(p/'selection.json').write_text(json.dumps({'source_runs':[str(q)for q in runs],'full_waves':837,'selected_waves':len(idx),'max_requested_difference_um':float(np.max(abs(w[idx]-target))),'method':'Exactselectionoftheactuallysolvedcomplexfields,nointerpolationorrecomputation'}))
        field_sources[key]=str(p)
        for aperture in [600,700]:
            out=a.out/f'readout{key}-inner{aperture}';out.mkdir();args=argparse.Namespace(out=out,runs=[p],hole=ROOT/f'runs/20261105-q2-package-device-kernels-01/inner{aperture}/gram.npz')
            with contextlib.redirect_stdout(io.StringIO()):readout(args)
            r=json.loads((out/'results.json').read_text());r['actual_alignment_material']='SiNx';r['LC_loss_pressure']='k=max(Wu2002graphtransfer,.001) forall3LC;notmeasuredstatelossbound';r['limits']=[s.replace('DLCoptical/electrical/anchoring','SiNxoptical/dielectric/assignedanchoring')for s in r['limits']];(out/'results.json').write_text(json.dumps(r,indent=2));results[key,aperture]=r
            print(json.dumps({'grid':key,'aperture':aperture,'main_pp':[r['main']['VIS_conditional_lower_pp'],r['main']['NIR_model_pp']]}),flush=True)
    comparisons=[]
    def main(r):return np.array([r['main']['VIS_conditional_lower_pp'],r['main']['NIR_model_pp']])
    for aperture in [600,700]:
        prev=json.loads((ROOT/f'runs/20261105-q2-finish-material-lossstress-readout{aperture}-01/results.json').read_text());m127=main(results['127',aperture]);m713=main(results['713',aperture]);mh=main(results['half713',aperture]);old=main(prev)
        nominal_path=ROOT/f'runs/20261105-q2-finish-decouple-SiNx-readout64-713-{aperture}-01/results.json';nominal=json.loads(nominal_path.read_text());mn=main(nominal)
        comparisons.append({'inner_edge_um':aperture,'main32source_127_pp':old.tolist(),'main64source_127_pp':m127.tolist(),'main64source_713_pp':m713.tolist(),'main64source_half713_pp':mh.tolist(),'source32to64_same127_change_pp':(m127-old).tolist(),'grid127to713_same64_change_pp':(m713-m127).tolist(),'nested713_minus_half_change_pp':(m713-mh).tolist(),'713_margin_pp':(m713-[30,20]).tolist(),'same64source_713_nominal_main_pp':mn.tolist(),'lossstress_minus_nominal_same64_713_pp':(m713-mn).tolist(),'nominal_readout_path':str(nominal_path),'nominal_sha256':sha(nominal_path),'cross713':results['713',aperture]['cross']})
    rows=[s for r in originals for d in r['diagnostics']for s in d['states']]
    diag={'actual_union_waves':len(w),'actual_states':len(rows),'R_minmax':[min(s['R']for s in rows),max(s['R']for s in rows)],'T_minmax':[min(s['T']for s in rows),max(s['T']for s in rows)],'A_minmax':[min(s['A']for s in rows),max(s['A']for s in rows)],'max_cascade_residual':max(s['cascade_residual']for s in rows),'max_transfer_condition':max(s['maxcondition']for s in rows),'scope':'Actualunmaskedperiodicstates; finitecarbonportreadoutseparate; nofiniteedgeMaxwellerrorbound'}
    deps=[Path(__file__),ROOT/'experiments/q2_package_A_20261105.py',ROOT/'data/q2_current/solid_gram.npz',ROOT/'data/constraints_upgrade_sources/C_Hagemann.csv',*[ROOT/f'runs/20261105-q2-package-device-kernels-01/inner{n}/gram.npz'for n in [600,700]],*[p/'results.json'for p in runs],*[p/'scattered_fields.npz'for p in runs]]
    summary={'comparisons':comparisons,'source_grid_separation':'32source127 ->64source127 isolatesdirectorchange;64source127 ->64source713 isolatesquadraturegridchange. Nestedhalfgridisdiagnosticnotuniformerrorbound.','half_grid_nodes':len(half),'grid_folders':field_sources,'RTA':diag,'input_guards':{str(p):all(r['input_hashes_unchanged_after_run'].values())for p,r in zip(runs,originals)},'source_sha256':{str(q):sha(q)for q in deps},'full_problem_solved':False,'all_requested_calculations_collected':True,'limits':['kfloor.001is specifiedpressure,notmeasuredtwotemperatureanisotropicloss or confidencebound.','64directorand713spectrumdo notcertifyallFourierorders/axiallayers/finitescreens/continuousjointmanufacturingerror.','SiNxIBSoptical50–500nmto20nm/PECVDanchoringandtemperaturetransfersremainconditions.','No usercrosstalkacceptancecutoffadded.']};(a.out/'results.json').write_text(json.dumps(summary,indent=2));print(json.dumps({'comparisons':comparisons,'RTA':diag},indent=2),flush=True)
