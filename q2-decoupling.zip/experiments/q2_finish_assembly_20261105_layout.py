"""One explicit five-board external-electrode proposal; no optical solve."""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,hashlib,argparse
from pathlib import Path
import numpy as np
from scipy.optimize import root
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments.q2_finish_assembly_20261105 import plate,state


def separated_mechanics(th,d):
 m=plate(a=150e-6);h=np.array([d,d,8.353152083061113])*1e-6;hc=h+2*th*1e-6
 Q=np.array([[2.,0.,0.],[0.,2.,-1.],[0.,-1.,2.]])
 area=np.pi*m['a']**2;Cp=m['Cv']*Q;Vg0=area*h;pc=2*.03*(1/hc+1/20e-6);pl0=-pc
 Vlc=area*h+20000e-12*hc+Cp@pl0;rows=[]
 for T,q in [(288.15,0),(323.15,.04)]:
  def eq(pg):
   pl=pg-101325-pc;vg=Vg0-q*Vlc+Cp@(pl-pl0)
   return (pg*vg-101325*Vg0*T/288.15)/(101325*Vg0)
  sol=root(eq,np.ones(3)*101325*T/288.15,tol=1e-11);assert max(abs(eq(sol.x)))<1e-10
  pl=sol.x-101325-pc;center=m['C0']*(Q@pl);cold=m['C0']*(Q@pl0)
  rows.append({'temperature_C':T-273.15,'qexp_scenario':q,'gas_ratio':1,'gas_abs_pressure_Pa':sol.x.tolist(),'liquid_gauge_pressure_Pa':pl.tolist(),
               'center_LC_thickness_um':((h+center)*1e6).tolist(),'center_gap_change_from_flat_nm':(center*1e9).tolist(),
               'center_change_from_cold_nm':((center-cold)*1e9).tolist(),'bare_ring_height_um':(hc*1e6).tolist(),'relative_residual':float(max(abs(eq(sol.x))))})
 return {'C0_m_per_Pa':m['C0'],'Cv_m3_per_Pa':m['Cv'],'pressure_matrix':Q.tolist(),'states':rows,
         'scope':'Five boards: independent two-board driver and separate shared three-board passive/thermal. a150um, E170GPa, nu.22,8um plates, zero prestress, gas1atm initially, gamma.03/cos1; Maxwell stress and support thermal expansion omitted.'}


def main():
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--electric-d',type=float,default=4);p.add_argument('--lc-voltage',type=float,default=1.65);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False);d=a.electric_d
 stacks={}
 for coating,th in [('DLC',.01),('SiNx_scenario',.02)]:
  z=0.;rows=[]
  seq=[('ZnO',.0998,'external driver electrode1'),('Al2O3',8,'board1'),(coating,th,'driver lower alignment'),('E7',d,'driver LC'),(coating,th,'driver upper alignment'),('Al2O3',8,'board2'),('ZnO',.0998,'external driver electrode2'),('environment_air',2,'separation between independent driver and passive pair'),('Al2O3',8,'board3'),(coating,th,'passive lower alignment'),('E7',d,'passive compensation LC'),(coating,th,'passive upper alignment'),('Al2O3',8,'board4'),(coating,th,'thermal lower alignment'),('E7',8.353152083061113,'thermal LC'),(coating,th,'thermal upper alignment'),('Al2O3',8,'board5')]
  for mat,layer_d,role in seq:rows.append({'material':mat,'role':role,'z_start_um':z,'z_end_um':z+layer_d,'thickness_um':layer_d});z+=layer_d
  solids=[r for r in rows if r['material']!='environment_air']
  stacks[coating]={'axial_sequence':rows,'package_envelope_um':z,'main_before_screen_count':len(solids),'screen_conservative_max_add':1,'main_plus_screen_conservative_max':len(solids)+1,
                  'bare_LC_ring_heights_um':[d+2*th,d+2*th,8.353152083061113+2*th],
                  'solid_layer_thickness_check':all(.01<=r['thickness_um']<=10 for r in solids)}
 # No voltage or source/complex-index validation is inferred here.
 external=[]
 for epsLC in [5.2,19.]:
  for epsAl in [8.,9.,10.]:
   for coat,th,eps in [('DLC_effectively_conducting',.01,None),('SiNx',.02,4.),('SiNx',.02,8.)]:
    extra=0 if eps is None else 2*th/eps
    V=a.lc_voltage*(d/epsLC+16/epsAl+extra)/(d/epsLC)
    external.append({'LC_target_V':a.lc_voltage,'d_LC_um':d,'epsLC_scenario':epsLC,'epsAl_scenario':epsAl,'coating':coat,'eps_alignment_scenario':eps,'outer_voltage_series_scale':V})
 result={'status':'single concrete lab assembly proposal; source migration and final liquid/gas closure remain conditional',
  'stacks':stacks,'transverse_regions':{
   'beam_square_um':[-75,75],'alignment_and_LC_texture_square_um':[-105,105],
   'LC_cavity_inner_circle_radius_um':150,'liquid_seal_ring_outer_radius_um':170,
   'alignment_corner_to_seal_clearance_um':150-105*(2**.5),
   'intermodule_Al2O3_standoff_ring_radius_um':[180,200],'intermodule_standoff_height_um':2.,
   'carbon_electrode_contact_patches_um':{'x':[210,230],'y':[-10,10],'thickness':5},
   'fill_ports_in_separate_ring_extensions':{'driver_center_um':[250,300],'passive_center_um':[250,400],'thermal_center_um':[250,500],'square_size_um':20,'cap_thickness_um':8,'cap_side_um':40,
       'through_upper_board':'driver:board2; passive:board4; thermal:board5',
       'cap_clearance_notches':'80um square centered250,300 removed from boards3,4,5; 80um square centered250,400 removed from board5; these local tabs/notches avoid8um caps colliding with2um intermodule gap or upper liquid cell. ZnO excludes20um port holes on outer driver board.'},
   'buffer_channels':{'width_um':20,'rib_width_um':20,'gas_ratio':1,'no_shared_liquid_connection_between_cells':True},
   'board_footprint_proposal_um':{'x':[-250,900],'y':[-250,600]},
   'caution':'Ports/buffers occupy separate lateral branches outside all active squares; exact electrode fanout and branch mask still requires a fabrication drawing. Features are proposals, not achieved fabrication.'},
  'retained_layer_paths_conservative':[
   {'path':'active optical square','items':{'boards':5,'alignment':6,'LC':3,'ZnO':2,'screen_max':1},'maximum':17},
   {'path':'common liquid sealing rings r150to170','items':{'boards':5,'LC_spacer_rings':3,'external_ZnO':2,'screen_max':1},'maximum':11},
   {'path':'intermodule standoff r180to200','items':{'boards':5,'intermodule_Al2O3_standoff':1,'external_ZnO':2,'screen_max':1},'maximum':9},
   {'path':'one external fill-port cap on separate lateral extension','items':{'boards':5,'LC_spacer_rings_upper_conservative':3,'external_ZnO':2,'single_cap':1,'screen_max':1},'maximum':12},
   {'path':'carbon contact patch separate from all fill caps and main aperture','items':{'boards':5,'LC_spacer_rings_upper_conservative':3,'external_ZnO':2,'two_carbon_contacts_max':2,'screen_max':1},'maximum':13}],
  'whole_named_record_inventory':{'main_plus_screen':17,'LC_spacer_rings':3,'Al2O3_fill_caps':3,'carbon_contacts':2,'intermodule_standoff':1,'total':26,'scope':'Inventory records are not mutually co-located layers; layer-count definition must be stated. Do not silently equate26records with26stacked layers or omit them and report only17.'},
  'electrical_LC_thickness_um':d,'target_LC_voltage':a.lc_voltage,
  'series_voltage_scenarios':external,'five_board_mechanics':{coat:separated_mechanics(th,d) for coat,th in [('DLC',.01),('SiNx_scenario',.02)]},
  'five_board_optics_and_Gauss_not_yet_solved':True,
  'remaining_port_interface':'Close liquid/gas fill ports after E7 filling while preserving chosen gas pressure, final n/thickness and DLC/SiNx chemistry. Vacuum SAB before filling cannot by itself solve this post-fill interface.',
  'remaining_material_process_evidence':['Dense8um membrane release and carrier removal','SAB transfer from6nm ALD source to>=10nm or existing amorphous8um surface, protected alignment region','Real anchoring and complex optical spectrum after patterning; SiNx is a candidate from sibling line, no source approval here.'],
  'full_problem_solved':False}
 for r in result['retained_layer_paths_conservative']:assert sum(r['items'].values())==r['maximum'] and r['maximum']<=20
 assert result['transverse_regions']['alignment_corner_to_seal_clearance_um']>1
 (a.out/'results.json').write_text(json.dumps(result,indent=2));(a.out/'source.py').write_bytes(Path(__file__).read_bytes())
 print(json.dumps({'stacks':stacks,'paths':result['retained_layer_paths_conservative'],'remaining':result['remaining_port_interface']}))

if __name__=='__main__':main()
