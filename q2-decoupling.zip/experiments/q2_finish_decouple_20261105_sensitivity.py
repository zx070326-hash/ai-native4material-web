"""Mechanism-level derivatives; not a finite-device tolerance certificate."""
import os
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import sys,json,argparse
import numpy as np
import autograd.numpy as anp
from autograd import value_and_grad
from scipy.optimize import minimize
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments.q2_finish_decouple_20261105 import indices,scale

def solve(d,V,T,Wp,nz=65):
 K=np.array([11.1,6.5,17.1])*1e-12*scale(T);dx=1/(nz-1);dm=d*1e-6
 def f(t):
  m=(t[:-1]+t[1:])/2;kp=K[0]*anp.cos(m)**2+K[2]*anp.sin(m)**2
  elastic=anp.sum(.5*kp*((t[1:]-t[:-1])/dx)**2)*dx/dm
  surf=.5*Wp*(anp.sin(t[0])**2+anp.sin(t[-1])**2)
  inverse=dm*anp.sum(1/(5.2+13.8*anp.sin(m)**2))*dx+2*.02e-6/7.5
  return (elastic+surf-.5*8.8541878128e-12*V*V/inverse)/(K[0]/dm)
 sols=[]
 for amp in [.02,1.4]:
  seed=amp*np.sin(np.linspace(0,np.pi,nz))+.005
  sol=minimize(value_and_grad(f),seed,jac=True,method='L-BFGS-B',bounds=[(-np.pi/2+1e-6,np.pi/2-1e-6)]*nz,options={'maxiter':1400,'maxcor':30,'ftol':1e-13,'gtol':1e-8});sols.append(sol)
 return min(sols,key=lambda s:s.fun).x,{'energies_dimensionless':[float(s.fun)for s in sols],'seed_axis_difference_deg':float(np.rad2deg(abs(sols[0].x-sols[1].x)).max())}

def main():
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False);w=np.r_[np.linspace(.4,.78,121),np.linspace(.8,2.5,100)];cache={}
 def R(d,V,T,Wp):
  key=(d,V,T,Wp)
  if key in cache:return cache[key]
  th,ck=solve(d,V,T,Wp);ne,no=indices(T,w);n=ne*no/np.sqrt(ne**2*np.sin(th[:,None])**2+no**2*np.cos(th[:,None])**2);rr=d*np.trapezoid(n-no,dx=1/(len(th)-1),axis=0);cache[key]=(rr,ck);return rr,ck
 cases=[('nominal',1.5,2.5,2.5,2e-4,2e-4),('V_minus20mV',1.48,2.5,2.5,2e-4,2e-4),('V_plus20mV',1.52,2.5,2.5,2e-4,2e-4),('driver_hot_plus5p517nm',1.5,2.5,2.505517,2e-4,2e-4),('driver_all_plus10nm',1.5,2.51,2.51,2e-4,2e-4),('Wp_both_half',1.5,2.5,2.5,1e-4,1e-4),('Wp_both_double',1.5,2.5,2.5,4e-4,4e-4),('Wp_driver_half_only',1.5,2.5,2.5,1e-4,2e-4)]
 rows=[];arrays={}
 for name,V,dc,dh,Wd,Wc in cases:
  conv=np.zeros((2,2,len(w)));phase=np.zeros_like(conv);checks=[]
  for ti,T in enumerate([15,50]):
   comp,c=R(2.5,0,T,Wc);checks.append(c)
   for vi,v in enumerate([0,V]):
    dr,c=R([dc,dh][ti],v,T,Wd);checks.append(c);phase[vi,ti]=dr-comp;conv[vi,ti]=np.sin(np.pi*phase[vi,ti]/w)**2
  ix=w<=.78;main=abs(np.mean(conv[1,:,ix]-conv[0,:,ix],axis=0));cross=np.mean(abs(conv[:,1,ix]-conv[:,0,ix]),axis=0)
  row={'name':name,'fixed_bias_V':V,'driver_d_cold_hot_um':[dc,dh],'Wp_driver_compensator':[Wd,Wc],'min_VIS_conversion_delta_pp':float(100*np.min(main)),'max_VIS_thermal_conversion_mean_abs_pp':float(100*np.max(cross)),'phase550_driven_cold_hot_um':[float(np.interp(.55,w,phase[1,ti]))for ti in range(2)],'seed_checks':checks};rows.append(row);arrays[name+'__conversion']=conv;arrays[name+'__phase_um']=phase
 (a.out/'results.json').write_text(json.dumps({'scope':'1DselfconsistentFrankGauss with20nmSiNxeps7.5, same fixedbias bothT; predictive sensitivities only, not finite device T or actual tolerance','rows':rows,'limits':['usesK(T)dn² and transferredWp, no azimuthalWa sensitivity in1D','5.517nm is assembly4umcase differential shift used only as diagnostic at2.5um, not re-solved2.5umgeometry','allwavelength mean estimates are simple mechanism indicators, no blue-passivity/port/source-loss correction']},indent=2));np.savez_compressed(a.out/'spectra.npz',wavelength_um=w,**arrays);(a.out/'source.py').write_bytes(Path(__file__).read_bytes());print(json.dumps(rows,indent=2))
if __name__=='__main__':main()
