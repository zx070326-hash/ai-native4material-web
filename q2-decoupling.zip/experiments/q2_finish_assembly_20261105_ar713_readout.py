"""Read out all six frozen AR19 shards, normalizing only runpy's argv[0].

runpy records an absolute script path; the frozen launch template uses a
workspace-relative path. Verify resolved identity, leaving every physics and
all other argument comparisons exact. Do not edit the running frozen guard.
"""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import argparse,ast,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments import q2_finish_assembly_20261105_ar713 as frozen_guard


def main():
    p=argparse.ArgumentParser();p.add_argument('--manifest',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.manifest=a.manifest.resolve();a.out=a.out.resolve()
    frozen_guard.checked(a.manifest)
    f=a.manifest/'frozen/experiments/q2_finish_assembly_20261105_ar713.py'
    text=f.read_text();tree=ast.parse(text);fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='readout');source=ast.get_source_segment(text,fn)
    old="assert launch['argv']==m['launches'][str(i)]"
    new="got=launch['argv'];expected=m['launches'][str(i)];assert Path(got[0]).resolve()==(ROOT/expected[0]).resolve() and got[1:]==expected[1:]"
    assert source.count(old)==1
    source=source.replace(old,new);namespace=dict(frozen_guard.__dict__);exec(source,namespace);namespace['readout'](a)
    paths=[ROOT/frozen_guard.OUT.format(shard=i)for i in range(6)];states=[s for p in paths for row in json.loads((p/'results.json').read_text())['diagnostics']for s in row['states']]
    result=json.loads((a.out/'results.json').read_text());result['periodic_numerics']={'state_count':len(states),'T_range':[min(s['T']for s in states),max(s['T']for s in states)],'R_range':[min(s['R']for s in states),max(s['R']for s in states)],'A_range':[min(s['A']for s in states),max(s['A']for s in states)],'maximum_cell_transfer_condition':max(s['maxcondition']for s in states),'maximum_cascade_residual':max(s['cascade_residual']for s in states)};result['launch_identity_check']='Onlyargv0resolvedpathnormalization;allotherargumentsandfrozenSHAexact';frozen_guard.checked(a.manifest);result['all_frozen_optical_inputs_unchanged_after_readout']=True
    result['full_problem_solved']=False
    result['limits']=['AR19atFourier±4/32LCslices;theinternal16layer6pointordercontrolisnotanAR19certificate.','713actualwavelengthsolvesand357subsetintegrationarenotuniformspectralerrorbounds.','Ambientaircounting,indexA/B,source-temperatureandanchoringtransfersremainexplicit.','The8umsupportrelease,patternedSiNx/ARprocessandperipheralinterfacesarenotcertifiedbyoptics.']
    for inner in [600,700]:
        dest=a.out/f'inner{inner}/results.json';rr=json.loads(dest.read_text());rr['actual_material_identity']='Six20nmSiNxsample23028sourcefilms;legacyDLCfilename/limitlabelsarenotDLCretainedlayers.TwofixedAl2O3ARoutsideZnO.';frozen_guard.save(dest,rr)
    frozen_guard.save(a.out/'results.json',result);(a.out/'post_entry.py').write_bytes(Path(__file__).read_bytes());(a.out/'executed_readout.py').write_text(source,encoding='utf-8')
    print(json.dumps(result['periodic_numerics']),flush=True)


if __name__=='__main__':main()
