"""Material-specific readout adapter; numerical projection remains unchanged.

The original helper's numeric output is retained verbatim. Explicit SiNx and
geometry conditions replace inherited DLC wording only in the new receipt.
"""
from pathlib import Path
import argparse,json,sys,hashlib
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments.q2_package_A_20261105 import readout

def main():
 p=argparse.ArgumentParser();p.add_argument('--runs',nargs='+',type=Path,required=True);p.add_argument('--hole',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False)
 inputs=[json.loads((q/'results.json').read_text())for q in a.runs]
 allw=np.concatenate([np.load(q/'scattered_fields.npz')['wavelength_um']for q in a.runs]);assert len(np.unique(allw))==len(allw),'Duplicateactualwavelengthsbetweeninputs'
 for key in ['main_layer_count','physical_supports','d_electric_um','bias_V']:assert len({x.get(key)for x in inputs})==1,('Mixedphysicalgeometry',key)
 readout(a);numeric=(a.out/'results.json').read_bytes();(a.out/'inherited_numeric_results.json').write_bytes(numeric);r=json.loads(numeric)
 first=inputs[0];geometry=first.get('physical_override',{})
 r['identity']={'coating':'six20nmSiNx, IBS sample23028 Amato2024 fittedvectorcomplexspectrum; NOT DLC','main_path_layer_count':first.get('main_layer_count',geometry.get('main_path_layers',16)),'drive_d_um':first.get('d_electric_um'),'fixed_drive_V':first.get('bias_V'),'physical_support_count':first.get('physical_supports',4),'geometry_override':geometry,'source_paths':[str(q)for q in a.runs],'source_hashes':{str(q/'scattered_fields.npz'):hashlib.sha256((q/'scattered_fields.npz').read_bytes()).hexdigest()for q in a.runs},'hole_path':str(a.hole),'hole_sha256':hashlib.sha256(a.hole.read_bytes()).hexdigest(),'numeric_helper_receipt_sha256':hashlib.sha256(numeric).hexdigest()}
 r['limits']=['Same four-state numerical projection retained; spectral/order/director grids are identified in input receipts, not a universal error certificate.','SixSiNx20nm films use native-vector n,k from Amato2024sample23028 50-500nmIBSfilm family;20nm is thickness migration; nonzero fittedk retained, including below instrument sensitivity.','SiNxepsilon7.5, Wa1.14e-4 and Wp2e-4 are transferred scenarios, not same-film measurements;1.5um8direction patterning is not source-certified.','E7Li2005realn(T), Wu2002isotropic70Calpha transferred to both15/50C axes; continuous same-T anisotropic loss is not measured here.','ZnO optical graph/parameter normalization and actual electrical transport remain conditional; all nonLCfilm spectra are transferred to both working temperatures.','Al2O3Franta121.5nmoptical source transferred to8um supports; carbonHagemann response transferred to5um foil. Complete release/seal/assembly not certified.','Four/five physical supports, real fixed voltage and optional AR are identified by actual optical source receipt; internal16layer results do not establish external17/19layer results.','Finite hardGaussian/tilted-hole propagation is the same physical-optics envelope approximation, not finite-edge fullMaxwell.','Ambient air is external environment under retained convention; full retained peripheral inventory and A/B manufacturing conditions remain.','No user crosstalk acceptance cutoff and no fullA/manufacturing/strict-decoupling closure inferred.']
 r['actual_complete_device_pass']=False;r['readout_identity_note']='Material identities above supersede inherited DLC wording; numeric projection and spectra unchanged. Original helper receipt retained verbatim in inherited_numeric_results.json.'
 states=[s for q in inputs for d in q.get('diagnostics',[])for s in d['states']]
 if states:r['periodic_numerics']={'actual_unique_wavelengths':len(allw),'actual_state_count':len(states),'T_range':[min(s['T']for s in states),max(s['T']for s in states)],'R_range':[min(s['R']for s in states),max(s['R']for s in states)],'A_range':[min(s['A']for s in states),max(s['A']for s in states)],'max_cascade_residual':max(s['cascade_residual']for s in states),'max_transfer_condition':max(s['maxcondition']for s in states),'scope':'ActualcomputedperiodicRTA/cascadechecks; not material or completefinite-boundarycertificate'}
 (a.out/'results.json').write_text(json.dumps(r,indent=2));(a.out/'source.py').write_bytes(Path(__file__).read_bytes());print(json.dumps({'identity':r['identity'],'main':[r['main']['VIS_conditional_lower_pp'],r['main']['NIR_model_pp']]}))
if __name__=='__main__':main()
