"""Source-supported25/50C dielectric values, fixed-V one-dimensional diagnostic.

Only dielectricanisotropy is new source data. K(T), epsilon_perp(T), anchoring,
and coating permittivity remain explicitly identified scenarios.
"""
import os
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import sys,json,argparse,time,hashlib
import numpy as np
import autograd.numpy as anp
from autograd import value_and_grad
from scipy.optimize import minimize,brentq
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments.q2_finish_decouple_20261105 import indices

def solve(T,V,support,de,epsp,nz=65,p=2):
 e,o=indices(T,.589);e25,o25=indices(25,.589);rt=float((e-o)/(e25-o25));K=np.array([11.1,6.5,17.1])*1e-12*rt**p
 d=2.5e-6;dz=1/(nz-1);extra=2*.02e-6/7.5+(2*8e-6/9 if support else 0.)
 def f(th):
  m=(th[:-1]+th[1:])/2;kp=K[0]*anp.cos(m)**2+K[2]*anp.sin(m)**2
  return (.5*anp.sum(kp*((th[1:]-th[:-1])/dz)**2)*dz/d+1e-4*(anp.sin(th[0])**2+anp.sin(th[-1])**2)-.5*8.8541878128e-12*V**2/(d*anp.sum(1/(epsp+de*anp.sin(m)**2))*dz+extra))/(K[0]/d)
 ss=[]
 for amp in [.025,1.3]:
  seed=amp*np.sin(np.linspace(0,np.pi,nz))+.005
  s=minimize(value_and_grad(f),seed,jac=True,method='L-BFGS-B',bounds=[(-np.pi/2+1e-6,np.pi/2-1e-6)]*nz,options={'maxiter':1800,'maxcor':30,'ftol':1e-13,'gtol':1e-8});ss.append(s)
 s=min(ss,key=lambda x:x.fun);m=(s.x[:-1]+s.x[1:])/2;inv=d*np.sum(1/(epsp+de*np.sin(m)**2))*dz
 return s.x,{'T_C':T,'terminal_V':V,'K_pN':(K*1e12).tolist(),'delta_epsilon':de,'epsilon_perp':epsp,'meanLC_V':V*inv/(inv+extra),'theta_max_deg':float(np.rad2deg(abs(s.x)).max()),'success':bool(s.success),'gradient_inf':float(abs(s.jac).max()),'seed_delta_max_deg':float(np.rad2deg(abs(ss[0].x-ss[1].x)).max()),'seed_energies':[float(x.fun)for x in ss]}

def main():
 pa=argparse.ArgumentParser();pa.add_argument('--out',type=Path,required=True);a=pa.parse_args();a.out.mkdir(parents=True,exist_ok=False);tic=time.perf_counter()
 sourcepath=ROOT/'runs/20261105-q2-finish-decouple-E7-constitutive-digitized-01/results.json';ds=json.loads(sourcepath.read_text())['dielectric_source'];deps=[ds['delta_epsilon25'],ds['delta_epsilon50']];epsp=ds['epsilon_perp25_lowV_approx'];w=np.linspace(.4,.78,381);cache={};arrays={}
 def evaluate(mode,V):
  key=(mode,round(float(V),8))
  if key in cache:return cache[key]
  retard=[];checks=[]
  for T,de in zip([25,50],deps):
   th,ck=solve(T,V,mode=='external',de,epsp);checks.append(ck);ne,no=indices(T,w);neff=ne*no/np.sqrt(ne**2*np.sin(th[:,None])**2+no**2*np.cos(th[:,None])**2);retard.append(2.5*(np.trapezoid(neff-no,dx=1/(len(th)-1),axis=0)-(ne-no)))
  R=np.array(retard);C=np.sin(np.pi*R/w)**2;cross=C[1]-C[0]
  row={'mode':mode,'fixed_terminal_V':float(V),'VIS_conversion_byT_pp':(100*np.trapezoid(C,w,axis=1)/.38).tolist(),'VIS_thermal_meanabs_pp':float(100*np.trapezoid(abs(cross),w)/.38),'VIS_thermal_peak_pp':float(100*abs(cross).max()),'retardance550_um':[float(np.interp(.55,w,r))for r in R],'retardance550_difference_hot_minus_cold_um':float(np.interp(.55,w,R[1]-R[0])),'source_checks':checks};cache[key]=row;arrays[f'{mode}_V{V:.8f}__retardance_um']=R;arrays[f'{mode}_V{V:.8f}__conversion']=C;print(json.dumps({k:v for k,v in row.items()if k!='source_checks'}),flush=True);return row
 brackets={'internal':[1.2,1.35,1.5,1.65,1.8,2.0],'external':[8.,9.,10.,11.,12.235]};selected=[]
 for mode,vs in brackets.items():
  rows=[evaluate(mode,V)for V in vs]
  roots=[]
  for lo,hi,rlo,rhi in zip(vs[:-1],vs[1:],rows[:-1],rows[1:]):
   if rlo['retardance550_difference_hot_minus_cold_um']*rhi['retardance550_difference_hot_minus_cold_um']<0:
    root=brentq(lambda V:evaluate(mode,V)['retardance550_difference_hot_minus_cold_um'],lo,hi,xtol=2e-5);rr=evaluate(mode,root)
    if min(rr['VIS_conversion_byT_pp'])>20:roots.append(rr)
  selected.append({'mode':mode,'nontrivial550_roots':roots,'baseline_fixed':evaluate(mode,1.5 if mode=='internal' else 12.235)})
 result={'scope':'25/50C source-supporteddeltaepsilon,1DsamefixedVretardanceprediction; nofinite3cellopticalresult','parameters':{'temperatures_C':[25,50],'d_each_electric_comp_um':2.5,'K25_pN':[11.1,6.5,17.1],'K_exponent_p':2,'K_T_status':'MODEL retained; HuangonlyK11/K22and25-40Cpretilt-specific, noK33/50C','delta_epsilon':deps,'epsilon_perp_fixed':epsp,'epsilon_perp_status':'Fig4a25Conly; heldconstantat50 as model','Wp_J_m2':2e-4,'SiNx_each_um':.02,'SiNx_epsilon_scenario':7.5,'external_Al2O3_each_um':8,'external_Al2O3_epsilon_scenario':9,'selection_rule':'bracketnonzero550nmdelaymatchthenreportbroadband;singlefixedvoltageatbothT;notperTtuning'},'selected':selected,'all_evaluated':list(cache.values()),'source':ds,'elapsed_s':time.perf_counter()-tic,'input_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()for p in [sourcepath,Path(__file__),ROOT/'data/q2_current/Li2005_E7_Cauchy.csv']},'limits':['DielectricandopticaldatafromdifferentE7batches/processes.','K(T)/epsilonperp(T)/anchoringremainmodels, notnewlymeasuredsame-deviceinputs.','No patterned2DGauss,finitehole,absorption,ARor9.8umthermalcellcomputationclaimed.']};(a.out/'results.json').write_text(json.dumps(result,indent=2));np.savez_compressed(a.out/'spectra.npz',wavelength_um=w,**arrays);(a.out/'source.py').write_bytes(Path(__file__).read_bytes())
if __name__=='__main__':main()
