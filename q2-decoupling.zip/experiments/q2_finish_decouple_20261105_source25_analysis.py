"""Reintegrate source25 controls, exact causal differences, band parts and LP.

Virtual mixed-module temperatures and single-pass fields are diagnostics only.
LP is a discrete bound for common scalar attenuation, not general filter optics.
"""
from pathlib import Path
import sys,json,argparse,hashlib
import numpy as np
from scipy.optimize import linprog
ROOT=Path(__file__).resolve().parents[1]

def avg(w,y,lo,hi):
 m=(w>=lo-1e-12)&(w<=hi+1e-12);return np.trapezoid(y[...,m],w[m],axis=-1)/(hi-lo)
def crossstats(w,y,lo,hi):
 m=(w>=lo-1e-12)&(w<=hi+1e-12)
 return {'signed_mean_pp':(100*avg(w,y,lo,hi)).tolist(),'absolute_spectral_mean_pp':(100*avg(w,abs(y),lo,hi)).tolist(),'absolute_spectral_peak_pp':(100*np.max(abs(y[...,m]),axis=-1)).tolist()}

def main():
 pa=argparse.ArgumentParser();pa.add_argument('--out',type=Path,required=True);a=pa.parse_args();a.out.mkdir(exist_ok=False,parents=True);inputs={};data={}
 for c in ['reference','freezeThermal','freezeDC','singlePass']:
  p=ROOT/('runs/20261105-q2-finish-decouple-source25-AR19-readout64-127-600-01'if c=='reference'else f'runs/20261105-q2-finish-decouple-source25-control-{c}-readout600-01');z=np.load(p/'spectra.npz');w=z['wavelength_um'];data[c]=z['total_T'];inputs[c]=str(p.relative_to(ROOT))
 T=data['reference'];dc=data['freezeThermal'];th=data['freezeDC'];sp=data['singlePass'];assert np.array_equal(T[:,0],dc[:,0])and np.array_equal(T[:,0],th[:,0])
 effects={'full':T[:,1]-T[:,0],'DCmodule_at_coldThermal':dc[:,1]-dc[:,0],'thermal_at_coldDCmodule':th[:,1]-th[:,0]}
 effects['interaction']=effects['full']-effects['DCmodule_at_coldThermal']-effects['thermal_at_coldDCmodule'];effects['singlePass']=sp[:,1]-sp[:,0];effects['intermodule_return_contribution']=effects['full']-effects['singlePass']
 factor={name:{'VIS':crossstats(w,y,.4,.78),'NIR':crossstats(w,y,.78,2.5)}for name,y in effects.items()};assert np.max(abs(effects['full']-effects['DCmodule_at_coldThermal']-effects['thermal_at_coldDCmodule']-effects['interaction']))<1e-14
 parts=[]
 for lo,hi in zip([.78,1.,1.2,1.4,1.6,2.],[1.,1.2,1.4,1.6,2.,2.5]):parts.append({'band_um':[lo,hi],'local_mean_coldminus_hot_pp':(-100*avg(w,effects['full'],lo,hi)).tolist(),'contribution_to_full_NIR_pp':(-100*avg(w,effects['full'],lo,hi)*(hi-lo)/1.72).tolist()})
 m=w>=.78;x=w[m];d=-effects['full'][:,m];weights=np.zeros(len(x));weights[:-1]+=np.diff(x)/2;weights[1:]+=np.diff(x)/2;weights/=1.72
 lp=linprog(np.r_[np.zeros(len(x)),-1.],A_ub=np.column_stack([-d*weights,np.ones(2)]),b_ub=np.zeros(2),bounds=[(0,1)]*len(x)+[(None,None)],method='highs');assert lp.success
 filt={'max_min_NIR_signed_coldminus_hot_pp':100*lp.x[-1],'scope':'Discrete87NIRwavelengthcommonf(lambda)in[0,1] withbothVconstraints; ignoresphysicalmaterial/layer/smoothnessimplementation, not generalcoherentfilter bound','blocked_actual_wavelengths_um':x[lp.x[:-1]<.01].tolist(),'not_a_constructed_filter':True}
 # Exact periodic power: ky/y is the first Fourier-array axis.
 zs=[np.load(ROOT/f'runs/20261105-q2-finish-decouple-source25-AR19-optics64-127-{i}/scattered_fields.npz')for i in [0,1]];ww=np.concatenate([z['wavelength_um']for z in zs]);order=np.argsort(ww);assert np.array_equal(ww[order],w);modes=zs[0]['harmonics'];P=np.zeros((2,2,len(w),len(modes),len(modes)))
 for vi in range(2):
  for ti in range(2):
   E=np.concatenate([z[f'V{vi}T{ti}__E']for z in zs])[order];G=np.concatenate([z[f'V{vi}T{ti}__G']for z in zs])[order];P[vi,ti]=np.real(np.sum(E.conj()*G,axis=(-2,-1)))/2
 modeparts=[]
 for lo,hi in [(.78,1.2),(1.2,1.6),(1.6,2.),(2.,2.5)]:
  q=100*avg(w,P[:,0].sum(axis=-1).transpose(0,2,1)-P[:,1].sum(axis=-1).transpose(0,2,1),lo,hi);modeparts.append({'band_um':[lo,hi],'harmonics_ky':modes.tolist(),'periodic_coldminus_hot_byV_ky_pp':q.tolist(),'scope':'periodicmodalpower, not finite-mask integral'})
 # Actual stationary centers for the dominant thermal +/-2 order, including tilt.
 centers=[]
 for lam in [1.2,1.4,1.6,2.,2.5]:
  positions=[]
  for h in [-2,2]:
   slope=lam*h/48;positions.append(float(slope*10000/(1-slope*np.tan(np.deg2rad(25)))))
  centers.append({'lambda_um':lam,'h_minus2_plus2_center_y_um':positions})
 r={'scope':'Actualsource25/50AR19fixed9.235V127/64source diagnostic, notnewcandidatepass','source_paths':inputs,'factorization':factor,'NIR_bandparts':parts,'common_scalar_attenuation_LP':filt,'periodic_modeparts':modeparts,'propagation_mapping':{'equation':'a=lambda*h/(2P); y=a*z0/(1-a*tanbeta), P24um,z010000um,beta25deg','dominant_thermal_orders':[-2,2],'centers':centers,'single_geometry_test':'yhalfw750um, projected clear half739 after11um shadow; samex600 three slots; notscan','rejected_mapping':'1.3-1.4mm halfwidth wouldcollectlong2-2.5um orders too; do not use2lambda/Pfactor'},'limits':['freezeThermalandfreezeDCarevirtualmixedmoduletemperaturecontrols,notuniformdeviceproposals.','SinglePassdisablesinter-cellreturnsonly,keepsintracellmultilayerresponse; missingpowernotabsorption.','Absolutecomponentaveragesdonotadd; pointwisesignedfactorialidentitydoes.','1DdelayrootdoesnotcontrolmultilayerreflectionorindividualmoduleVISresponse.','CurrentZnOtablehasnewlydiscoveredpixelcalibrationerror; materiallinecorrected127controlseparate.'],'input_sha256':{str((ROOT/p/'spectra.npz').relative_to(ROOT)):hashlib.sha256((ROOT/p/'spectra.npz').read_bytes()).hexdigest()for p in inputs.values()}}
 (a.out/'results.json').write_text(json.dumps(r,indent=2));np.savez_compressed(a.out/'factorized_spectra.npz',wavelength_um=w,**effects);np.savez_compressed(a.out/'ideal_common_filter.npz',wavelength_um=x,f=lp.x[:-1]);(a.out/'source.py').write_bytes(Path(__file__).read_bytes())
 import matplotlib;matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 fig,ax=plt.subplots(2,2,figsize=(12,8),constrained_layout=True)
 for vi in range(2):
  for ti in range(2):
   for aa in ax[0]:aa.plot(w,100*T[vi,ti],lw=1,label=f'{[0,9.235][vi]:g} V / {[25,50][ti]} C')
 ax[0,0].set(xlim=(.4,.78),title='Actual VIS four states',ylabel='Port T (%)');ax[0,1].set(xlim=(.78,2.5),title='Actual NIR: main modulation below 20 pp',ylabel='Port T (%)')
 labels={'full':'Full device','DCmodule_at_coldThermal':'Driven + compensator warmed','thermal_at_coldDCmodule':'Thermal cell warmed','interaction':'Interaction','singlePass':'No intercell returns'}
 for name in ['full','DCmodule_at_coldThermal','thermal_at_coldDCmodule','interaction','singlePass']:
  ax[1,0].plot(w,100*effects[name][0],lw=.9,label=labels[name])
 ax[1,0].set(xlim=(.4,.78),title='0 V thermal components (virtual controls)',ylabel='Hot - cold (pp)')
 for vi in range(2):ax[1,1].plot(w,-100*effects['full'][vi],label=f'{[0,9.235][vi]:g} V')
 ax[1,1].set(xlim=(.78,2.5),title='Actual NIR sign cancellation',ylabel='Cold - hot (pp)')
 for aa in ax.ravel():aa.grid(alpha=.2);aa.set_xlabel('Wavelength (um)');aa.legend(fontsize=7)
 for aa in ax[0]:aa.set_ylim(0,100)
 vv=np.concatenate([100*effects[k][0,w<=.78]for k in ['full','DCmodule_at_coldThermal','thermal_at_coldDCmodule','interaction','singlePass']]);ax[1,0].set_ylim(vv.min()-3,vv.max()+3);vv=-100*effects['full'][:,w>=.78];ax[1,1].set_ylim(vv.min()-3,vv.max()+3)
 fig.suptitle('Dielectric data at 25/50 C; K(T), epsilon_perp(T), anchoring still model conditions',fontsize=11)
 for ext in ['png','svg']:fig.savefig(a.out/f'four_state_diagnosis.{ext}',dpi=150)
 plt.close(fig);print(json.dumps({'factorization':factor,'LP':filt,'mapping':centers},indent=2))
if __name__=='__main__':main()
