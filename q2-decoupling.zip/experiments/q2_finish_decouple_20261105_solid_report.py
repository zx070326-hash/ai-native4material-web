"""Independent matched127 all-solid versus air result comparison, no scans."""
from pathlib import Path
import json,hashlib,sys,argparse
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments.q2_finish_decouple_20261105_phase855_dense import stats
COUNTS={'physical_retained_entities_including_carbon':19,'merged_optical_material_layers_including_carbon':18,'unmerged_pre_screen_computational_material_segments':20,'unmerged_computational_material_segments_including_carbon':21,'note':'LC slice subdivisions and zero-thickness air-basis algebraic cuts are not independent material entities. Launch computational_retained_segments20 refers to pre-screen segments only.'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out=a.out.resolve();a.out.mkdir(parents=True,exist_ok=False);rows=[];views={}
 for hole in [600,700]:
  solid=ROOT/f'runs/20261105-q2-finish-decouple-solid-interface-readout64-127-{hole}-01';air=ROOT/f'runs/20261105-q2-finish-decouple-source25-phase855-readout64-127-{hole}-01'
  sr=json.loads((solid/'results.json').read_text());ar=json.loads((air/'results.json').read_text());sz=np.load(solid/'spectra.npz');az=np.load(air/'spectra.npz');w=sz['wavelength_um'];assert np.array_equal(w,az['wavelength_um'])and len(w)==127
  # Correct identity only on these NEW readout receipts; preserve inherited numeric
  # helper bytes, all physical optics launches, and all old air receipts unchanged.
  sr['identity']['layer_count_identity']=COUNTS
  sr['identity']['solid_interface_note']='No internal air2um. Driver AR83.028893nm is directly bonded to physical passive entranceAl9.8um, continuous same-sourceAl9.883028893um. Screen10mm after FINAL thermalAl exit. Ideal bond, constitutive and process migrations remain conditions.'
  (solid/'results.json').write_text(json.dumps(sr,indent=2))
  assert sr['identity']['hole_sha256']==ar['identity']['hole_sha256'];assert sr['identity']['geometry_override']['internal_air_gap_um']==0
  st=stats(w,sz['total_T']);at=stats(w,az['total_T']);assert np.max(abs(np.array(st['main_pp'])-[sr['main']['VIS_conditional_lower_pp'],sr['main']['NIR_model_pp']]))<1e-10
  row={'hole_inner_um':hole,'actual_wavelength_count':127,'solid':st,'matched_air127':at,'solid_minus_matched_air127':{k:(np.array(st[k])-np.array(at[k])).tolist()for k in st},'periodic_numerics':sr['periodic_numerics'],'solid_readout':str(solid.relative_to(ROOT)),'matched_air_readout':str(air.relative_to(ROOT)),'solid_spectra_sha256':sha(solid/'spectra.npz'),'air_spectra_sha256':sha(air/'spectra.npz'),'same_screen_sha256':sr['identity']['hole_sha256']}
  peaks={}
  for band,arr,mask in [('VIS_thermal',sz['total_T'][:,1]-sz['total_T'][:,0],w<=.78),('NIR_electric',sz['total_T'][1]-sz['total_T'][0],w>=.78)]:
   ids=np.flatnonzero(mask);peaks[band]=[]
   for i,y in enumerate(arr):
    peak_index=ids[int(np.argmax(abs(y[mask])))];peaks[band].append({'branch':i,'wavelength_um':float(w[peak_index]),'absolute_peak_pp':float(100*np.max(abs(y[mask])))})
  row['sampled_peaks']=peaks;rows.append(row);views[hole]=(w,sz['total_T'],az['total_T'])
 result={'scope':'ONE solid-interface counterpart, exactly matched127 actual wavelengths; no spectral interpolation, parameter/window scan, or density convergence claim.','interface':'Driver exit AR0.08302889342260214um + Al1.8um + passive entranceAl8um = contiguous9.883028893422603um; physical9.8um plate directly oxide-bonded to AR, no retained internal air or glue.','layer_count_identity':{'physical_retained_entities_including_carbon':19,'merged_optical_material_layers_including_carbon':18,'unmerged_pre_screen_computational_material_segments':20,'unmerged_computational_material_segments_including_carbon':21,'explanation':'Driver9 + spacer1 + compensator5 + thermal5=20 pre-screen; merge AR+Al1.8+Al8 removes2 segments and sharedAl4+Al4 removes1; addcarbon gives18 optical layers. Each32sliceLC counted as one physical LC layer here; algebraic cuts are not material entities. Launch computational_retained_segments20 means pre-screen only.'},'screen_reference':'10mm from FINAL thermal-moduleAl exit; original600/700 screen kernels unchanged.','rows':rows,'limitations':['Same source25/50C, external0/9.235Vrms,64x33 fields, driven/passive2.5um and thermal8.55um, correctedZnO335 and all other materials frozen.','This replaces only the intermodule air2um; external incident/final-exit environment remains air.','Strict pointwise n caseA and reference-n caseB need independent material assessment; no use of internaln=1 exemption.','K(T),epsilon_perp50,anchoring,optical-state/process migration and ideal zero-void bonding remain conditions.','Old five8um support mechanical results do not certify changed9.8um passive entrance plate.','127-point pilot is not dense spectral convergence, and signed-band cancellation does not certify decoupling; no user crosstalk threshold supplied.','No full finite-edge Maxwell, global elastic stability, or complete manufacturing certificate.'],'provenance':{'source_sha256':sha(Path(__file__)),'independent_stats_source_sha256':sha(ROOT/'experiments/q2_finish_decouple_20261105_phase855_dense.py'),'numeric_readout_source_sha256':sha(ROOT/'experiments/q2_finish_decouple_20261105_readout.py'),'carbon_data_sha256':sha(ROOT/'data/constraints_upgrade_sources/C_Hagemann.csv'),'solid_kernel_sha256':sha(ROOT/'data/q2_current/solid_gram.npz')}}
 (a.out/'results.json').write_text(json.dumps(result,indent=2));(a.out/'source.py').write_bytes(Path(__file__).read_bytes())
 import matplotlib;matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 w,Ts,Ta=views[600];fig,axs=plt.subplots(2,2,figsize=(12,8),constrained_layout=True)
 for vi in range(2):
  for ti in range(2):
   for ax in axs[0]:ax.plot(w,100*Ts[vi,ti],lw=.8,label=f'{[0,9.235][vi]:g}V / {[25,50][ti]}C')
 for ax,lim,title in [(axs[0,0],(.4,.78),'All-solid four states: VIS'),(axs[0,1],(.78,2.5),'All-solid four states: NIR')]:ax.set(xlim=lim,title=title,ylabel='Port T (%)')
 for vi in range(2):
  axs[1,0].plot(w,100*(Ts[vi,1]-Ts[vi,0]),label=f'Solid / {vi and 9.235 or 0:g}V',lw=.9)
  axs[1,0].plot(w,100*(Ta[vi,1]-Ta[vi,0]),ls='--',label=f'Air / {vi and 9.235 or 0:g}V',lw=.65)
 for ti in range(2):
  axs[1,1].plot(w,100*(Ts[1,ti]-Ts[0,ti]),label=f'Solid / {[25,50][ti]}C',lw=.9)
  axs[1,1].plot(w,100*(Ta[1,ti]-Ta[0,ti]),ls='--',label=f'Air / {[25,50][ti]}C',lw=.65)
 axs[1,0].set(xlim=(.4,.78),title='VIS thermal cross response',ylabel='Hot - cold (pp)');axs[1,1].set(xlim=(.78,2.5),title='NIR electrical cross response',ylabel='9.235V - 0V (pp)')
 for ax,ys,mask in [(axs[1,0],np.r_[100*(Ts[:,1]-Ts[:,0]),100*(Ta[:,1]-Ta[:,0])],w<=.78),(axs[1,1],np.r_[100*(Ts[1]-Ts[0]),100*(Ta[1]-Ta[0])],w>=.78)]:
  lo=float(ys[:,mask].min());hi=float(ys[:,mask].max());pad=.06*(hi-lo);ax.set_ylim(lo-pad,hi+pad)
 for ax in axs.ravel():ax.set_xlabel('Wavelength (um)');ax.grid(alpha=.2);ax.legend(fontsize=7)
 fig.suptitle('ONE fixed solid-interface control / 127 actual wavelengths / original600 screen',fontsize=11)
 for ext in ['png','svg']:fig.savefig(a.out/f'solid_interface_127.{ext}',dpi=150)
 plt.close(fig);print(json.dumps({'rows':rows},indent=2))
if __name__=='__main__':main()
