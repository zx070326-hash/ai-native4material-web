"""Exact same three-cell mechanism with source-spectrum SiNx alignment.

The reference entrypoint is frozen as a dependency; transformations below are
deliberately explicit, isolated to this process, and preserve shared kernels.
20nm layers with epsilon7.5 are included in freshly solved Gauss boundaries.
Anchoring is only the original A scenario, not measured on this SiNx film.
"""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import sys,inspect,json,hashlib,time
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments import q2_finish_decouple_20261105 as base
from experiments.q2_gap_director import Electric

def sinx_electric():
 source=inspect.getsource(Electric).replace('class Electric:','class SiNxElectric:').replace('-.015/d','-.02/d').replace('1+.015/d','1+.02/d')
 ns=dict(Electric.__init__.__globals__);exec(source,ns);cl=ns['SiNxElectric']
 return lambda *args:cl(*args,epsa=7.5)

base.direct_electric=sinx_electric
source=inspect.getsource(base.optics)
old="ROOT/'runs/20261105-q2-package-A-DLC-spectrum-01/DLC_4keV_vector_digitized.csv'"
new="ROOT/'data/q2_finish_material_20261105/SiNx_spectrum/DLC_4keV_vector_digitized.csv'"
assert old in source and source.count('(iso(dn),.01)')==2
source=source.replace(old,new).replace('(iso(dn),.01)','(iso(dn),.02)')
exec(source,base.__dict__)

if __name__=='__main__':
 args=sys.argv;out=Path(args[args.index('--out')+1]);base_source=Path(base.__file__).read_bytes();own_source=Path(__file__).read_bytes()
 launch={'started_time_unix':time.time(),'argv':args,'base_source_sha256':hashlib.sha256(base_source).hexdigest(),'entry_source_sha256':hashlib.sha256(own_source).hexdigest(),'SiNx_source_csv':'data/q2_finish_material_20261105/SiNx_spectrum/DLC_4keV_vector_digitized.csv','SiNx_source_sha256':hashlib.sha256((ROOT/'data/q2_finish_material_20261105/SiNx_spectrum/DLC_4keV_vector_digitized.csv').read_bytes()).hexdigest(),'film_um':.02,'epsilon_r_scenario':7.5,'anchoring_Wa_Wp_scenarios':[1.14e-4,2e-4],'conditions':['six20nmSiNx films with finite source-fit n,k','eps7.5 and anchoring are explicit transferred scenarios, not same-film measurement','native-vector sample23028 n,k from Amato2024; beyond560nm k fitted below measurement sensitivity, not exact measured absorption','thermal source unchanged because same assigned anchoring and noV; electric source freshly solves two20nm dielectrics']}
 base.main()
 (out/'source.py').write_bytes(own_source);(out/'base_source.py').write_bytes(base_source);(out/'launch.json').write_text(json.dumps(launch,indent=2),encoding='utf-8')
 result=json.loads((out/'results.json').read_text());result['alignment_override']=launch;result['scope']='SiNx20nm explicit-dielectric fixed-voltage three-cell compensation; transferred anchoring; no full-device closure';(out/'results.json').write_text(json.dumps(result,indent=2))
