"""One mechanism-selected screen control: yhalf750, xinner600 unchanged.

Exact same177wavelength geometry nodes and5umquadrature, actual tiltedplane.
No parameter sweep and no new Maxwell solve. Existing carbon screen unchanged.
"""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import argparse,hashlib,inspect,json,sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,d):Path(p).write_text(json.dumps(d,indent=2),encoding='utf-8')
def kernel(a):
    from experiments import q2_package_device_20261105 as old
    reference=ROOT/'runs/20261105-q2-package-device-kernels-01/inner600/gram.npz';w=np.load(reference)['wavelength_um'];assert len(w)==177
    text=inspect.getsource(old.gram);needle='pts(-589,589,step)';assert text.count(needle)==1;text=text.replace(needle,'pts(-739,739,step)');ns=dict(old.__dict__);exec(text,ns)
    (a.out/'kernel_function.py').write_text(text,encoding='utf-8');(a.out/'factory_source.py').write_bytes(Path(old.__file__).read_bytes())
    setup={'nominal_y_half_um':750,'shadow_um':11,'effective_y_half_um':739,'nominal_x_intervals_um':[[-2500,-600],[-200,200],[600,2500]],'effective_x_intervals_um':[[-2489,-611],[-189,189],[611,2489]],'center_distance_from_final_exit_um':10000,'tilt_deg':25,'geometry_nodes':177,'plane_step_um':5,'source_reference_kernel_SHA256':sha(reference),'original_factory_SHA256':sha(old.__file__),'new_kernel_function_SHA256':sha(a.out/'kernel_function.py'),'mode_mapping':'qx=mx/24,qy=my/48;my=±2firstthermalordersgiveqy=±1/24,not±2/24','selection':'Exactlyone750umhalfwidthchosenfromtrue1.6umfirstthermalordersandfinitebeamwidth, noheightsearch.','screen':'samecarbon5um,20x15mm exterior','normalization':'originalfullGaussianpowerdenominator;hard150um/waist75notrenormalized'}
    save(a.out/'launch.json',setup);g=ns['gram'](600,w,5,True);np.savez_compressed(a.out/'gram.npz',**g)
    setup['kernel_SHA256']=sha(a.out/'gram.npz');setup['scope']='177node5umactualtiltedFresnelkernel;finiteexit-envelopeapproximation,notfiniteedgeMaxwelloroptimum';save(a.out/'results.json',setup)


def readout(a):
    from experiments.q2_package_A_20261105 import readout as existing
    from experiments.q2_gap_vector_review import load_runs
    existing(argparse.Namespace(out=a.out,runs=a.runs,hole=a.kernel/'gram.npz'))
    r=json.loads((a.out/'results.json').read_text());s=np.load(a.out/'spectra.npz');w=s['wavelength_um'];T=s['total_T'];old=np.load(a.baseline/'spectra.npz');assert np.array_equal(w,old['wavelength_um']);base=old['total_T'];part=[]
    def integral(q,lo,hi):
        ww=np.r_[lo,w[(w>lo)&(w<hi)],hi];flat=q.reshape(-1,q.shape[-1]);vals=np.array([np.interp(ww,w,v)for v in flat]).reshape(q.shape[:-1]+(len(ww),));return np.trapezoid(vals,ww,axis=-1)
    for lo,hi in [(.78,1.2),(1.2,1.6),(1.6,2.),(2.,2.5)]:
        part.append({'range_um':[lo,hi],'contribution_to_wholeNIR_delta_pp_byV_old600':(100*integral(base[:,0]-base[:,1],lo,hi)/1.72).tolist(),'contribution_to_wholeNIR_delta_pp_byV_new750':(100*integral(T[:,0]-T[:,1],lo,hi)/1.72).tolist()})
    centers=[]
    for lam in [1.2,1.6,2.,2.5]:
        hits=[]
        for sign in [-1,1]:
            q=sign*lam/24;slope=q/np.sqrt(1-q*q);hits.append(10000*slope/(1-np.tan(np.deg2rad(25))*slope))
        centers.append({'wavelength_um':lam,'thermal_my_plusminus2_centers_y_um':hits})
    r['mask_control']={'kernel':str(a.kernel.relative_to(ROOT)),'kernel_SHA256':sha(a.kernel/'gram.npz'),'baseline':str(a.baseline.relative_to(ROOT)),'only_geometry_change':'yhalf600to750um;shadow11inner600xslotsandexteriorscreenunchanged','actual_mode_mapping_centers':centers,'source_paths':[str(p.relative_to(ROOT))for p in a.runs],'source_SHA256':{str((p/'scattered_fields.npz').relative_to(ROOT)):sha(p/'scattered_fields.npz')for p in a.runs},'new_field_solve':False,'physical_main_layers_unchanged':19,'minimal_new_feature_um':min(378,1478),'spectrum_partition':part,'scope':'Onefixedmaskallfourstatesandwavelengths;notoptimalityorfullspectral/fieldcertificate.FinitebeamandordersoverlapareactuallyretainedinGramprojection.'};r['actual_material_identity']='Source25/50AR19,drived2.5thermal9.8P24fixedexternal9.235.Allmaterial/epsilonK/anchoringconditionsretained;ZnOtableidentityfromsourcefiles.'
    r['full_problem_solved']=False;save(a.out/'results.json',r)
    print(json.dumps({'main':[r['main']['VIS_conditional_lower_pp'],r['main']['NIR_model_pp']],'cross':r['cross'],'partition':part},indent=2),flush=True)


def main():
    p=argparse.ArgumentParser();p.add_argument('action',choices=['kernel','readout']);p.add_argument('--out',type=Path,required=True);p.add_argument('--kernel',type=Path);p.add_argument('--runs',nargs='+',type=Path);p.add_argument('--baseline',type=Path);a=p.parse_args()
    for k in ['out','kernel','baseline']:
        if getattr(a,k,None)is not None:setattr(a,k,getattr(a,k).resolve())
    if a.runs:a.runs=[x.resolve()for x in a.runs]
    a.out.mkdir(parents=True,exist_ok=False);(a.out/'source.py').write_bytes(Path(__file__).read_bytes());{'kernel':kernel,'readout':readout}[a.action](a)


if __name__=='__main__':main()
