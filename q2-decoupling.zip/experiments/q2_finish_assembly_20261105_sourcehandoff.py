"""Compare independently relaxed32/17 and64/33 external-Gauss directors."""
import os
for key in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'):
    os.environ[key] = '1'
from pathlib import Path
import argparse, hashlib, json
import numpy as np
from scipy.interpolate import RegularGridInterpolator
ROOT=Path(__file__).resolve().parents[1]


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--coarse',type=Path,default=ROOT/'runs/20261105-q2-finish-external-director32-support32-01')
    p.add_argument('--fine',type=Path,default=ROOT/'runs/20261105-q2-finish-external-director64-support32-01')
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False)
    co=np.load(a.coarse/'fields.npz');fi=np.load(a.fine/'fields.npz')
    cr=json.loads((a.coarse/'results.json').read_text());fr=json.loads((a.fine/'results.json').read_text())
    rows=[]
    def it(q,X,Z):
        return RegularGridInterpolator((np.linspace(0,1,len(q)+1),np.linspace(0,1,q.shape[1])),np.r_[q,q[:1]])(np.stack([X,Z],-1))
    for rr in fr['rows']:
        key=rr['key'];old=next(x for x in cr['rows'] if x['key']==key)
        th=fi[key+'__theta_rad'];u=fi[key+'__phi_correction_rad']
        differences={}
        for label,nx,nz in [('fine_native_nodes',64,33),('common128x65_probe',128,65)]:
            X,Z=np.meshgrid(np.arange(nx)/nx,np.linspace(0,1,nz),indexing='ij')
            def nd(dic):
                t=it(dic[key+'__theta_rad'],X,Z);pp=2*np.pi*X+it(dic[key+'__phi_correction_rad'],X,Z)
                return np.stack([np.cos(t)*np.cos(pp),np.cos(t)*np.sin(pp),np.sin(t)],-1)
            nc,nf=nd(co),nd(fi);dot=abs(np.sum(nc*nf,-1));ang=np.degrees(np.arccos(np.clip(dot,0,1)))
            mi=np.unravel_index(np.argmax(ang),ang.shape)
            core=(Z[0]>=.125)&(Z[0]<=.875)
            differences[label]={'headless_axis_max_deg':float(np.max(ang)),'headless_axis_RMS_deg':float(np.sqrt(np.mean(ang**2))),'nematic_tensor_absmax':float(np.max(abs(nc[...,None]*nc[...,None,:]-nf[...,None]*nf[...,None,:]))),'argmax_x_z_um':[float(24*X[mi]),float(2.5*Z[mi])],'bulk_z_fraction_1over8_to7over8_max_deg':float(np.max(ang[:,core])),'midplane_max_deg':float(np.max(ang[:,nz//2])),'surface_max_deg':float(np.max(ang[:,[0,-1]]))}
        rows.append({'key':key,'coarse_nx_nz':[old['nx'],old['nz']],'fine_nx_nz':[rr['nx'],rr['nz']],'independently_relaxed':True,'support_cells_each_side':rr['support_cells_per_side'],'fine_optimization_success':rr['success'],'fine_optimization_message':rr['message'],'fine_nit':rr['nit'],'fine_gradient_inf':rr['gradient_inf'],'axis_comparisons':differences,'LC_voltage_mean_coarse_fine_V':[old['Gauss']['LC_terminal_voltage_mean_minmax_V'][0],rr['Gauss']['LC_terminal_voltage_mean_minmax_V'][0]],'Gauss_free_residual_inf':rr['Gauss']['Gauss_free_residual_inf'],'charge_balance_abs':rr['Gauss']['charge_balance_abs'],'energy_J_m2_coarse_fine':[old['energy_J_m2'],rr['energy_J_m2']],'fixed_fine_director_support_refinement':rr['fixed_director_support_refinement']})
    result={'fixed_external_V_RMS':fr['fixed_external_V_RMS'],'geometry':'outerZnO / Al8eps9 / SiNx20nmeps7.5 / E7d2.5P12 / SiNx20nm / Al8 / outerZnO','coarse_source':str(a.coarse.relative_to(ROOT)),'fine_source':str(a.fine.relative_to(ROOT)),'source_SHA256':{str((q/'fields.npz').relative_to(ROOT)):hashlib.sha256((q/'fields.npz').read_bytes()).hexdigest() for q in [a.coarse,a.fine]},'fine_source_shapes':{k:list(fi[k].shape) for k in fi.files},'states':rows,'scope':'Fresh Gauss/Frank reoptimization64x33 warmed by32x17, fixed support32 elements. Axis refinement is not a device optical tolerance or global branch/defect stability certificate.','conditions':fr['conditions'],'optical_handoff':'Use unchanged electric_T{15,50}_V{0,12.235} theta/phi keys. No LC-voltage-ratio rescaling; actual outer voltage remains12.235 for both temperatures.'}
    (a.out/'results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    (a.out/'source.py').write_bytes(Path(__file__).read_bytes())
    print(json.dumps({'fine':result['fine_source'],'sha':result['source_SHA256'],'states':[{'key':r['key'],'axis':r['axis_comparisons']['common128x65_probe'],'LC_voltage':r['LC_voltage_mean_coarse_fine_V'],'gradient':r['fine_gradient_inf']} for r in rows]},indent=2))


if __name__=='__main__':main()
