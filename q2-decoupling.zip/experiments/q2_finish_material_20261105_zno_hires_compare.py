"""Separate legacy calibration from resolution and report pixel sensitivities."""
from pathlib import Path
import json,hashlib,shutil
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'runs/20261105-q2-finish-material-ZnO-hires-calibration-01'
OUT=ROOT/'runs/20261105-q2-finish-material-ZnO-hires-comparison-01'
OUT.mkdir(parents=True,exist_ok=False)
r=json.loads((SRC/'results.json').read_text());c=r['calibration']
out={'identity':'Coordinate-remapping diagnostic, not a new material spectrum or statistical error interval','bands':{},'edge_half_pixel_x_sensitivity':[]}
for name in ('n','k'):
 new=np.loadtxt(SRC/f'ZnO2022_Fig5d_hires_{name}_raw.csv',delimiter=',',skiprows=1)
 old=np.loadtxt(ROOT/f'data/q2_package_A_20261105/ZnO2022_Fig5d_{name}_raw.csv',delimiter=',',skiprows=1)
 x=418+(old[:,0]-.5)*78
 y=319-(old[:,1]-1.6)*135/.8 if name=='n' else 319-old[:,1]*272
 corrected=np.c_[np.polyval(c['x_to_lambda_um'],2*x),np.polyval(c['y_to_'+name],2*y)]
 np.savetxt(OUT/f'legacy_pixel_centers_with_hires_axes_{name}.csv',corrected,delimiter=',',header=f'lambda_um,{name}',comments='')
 out['bands'][name]={}
 for lo,hi in ((.38,.42),(.42,.78),(.78,2.42)):
  w=np.linspace(lo,hi,2001);a=np.interp(w,*new[:,:2].T);b=np.interp(w,*old.T);d=np.interp(w,*corrected.T)
  out['bands'][name][f'{lo:g}-{hi:g}']={'new_minus_original_rms':float(np.sqrt(np.mean((a-b)**2))),'new_minus_recalibrated_old_rms':float(np.sqrt(np.mean((a-d)**2))),'recalibration_only_rms':float(np.sqrt(np.mean((d-b)**2)))}
 for wave in (.38,.4,.42,.5,1,2.5):
  dw=abs(c['x_to_lambda_um'][0])*.5
  values=[float(np.interp(wave+d,*new[:,:2].T))for d in (-dw,0,dw)]
  out['edge_half_pixel_x_sensitivity'].append({'kind':name,'lambda_um':wave,'x_half_pixel_lambda_um':dw,'values_at_minus_nominal_plus':values,'not_source_errorbar':True})
out['assumption']='Diagnostic maps legacy column/row center coordinates to2x positions; downsample resampling-center convention may add subpixel offsets. Do not treat as exact registration of compressed images.'
out['entry_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();shutil.copy2(__file__,OUT/'source.py');(OUT/'results.json').write_text(json.dumps(out,indent=2));print(json.dumps(out['bands'],indent=2))
