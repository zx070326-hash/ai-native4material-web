"""Matched Drude convention diagnostic on the recalibrated figure, no optics."""
from pathlib import Path
import hashlib,json,inspect,shutil,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments import q2_finish_material_20261105 as original
OUT=ROOT/'runs/20261105-q2-finish-material-ZnO-hires-drude-01';OUT.mkdir(parents=True,exist_ok=False)
TABLE=ROOT/'runs/20261105-q2-finish-material-ZnO-hires-input-01/ZnO2022_Fig5d_hires_exactnodes_tail_linear_scenario.csv'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=[Path(__file__),Path(original.__file__),TABLE];before={str(p.relative_to(ROOT)):sha(p)for p in files}
source=inspect.getsource(original.drude)
old="p=ROOT/'data/q2_package_A_20261105/ZnO2022_Fig5d_passive_digitized.csv'"
assert source.count(old)==1
source=source.replace(old,f"p=ROOT/{str(TABLE.relative_to(ROOT)).replace(chr(92),'/')!r}")
(OUT/'effective_drude.py').write_text(source);shutil.copy2(__file__,OUT/'source.py');(OUT/'launch.json').write_text(json.dumps({'argv':sys.argv,'input_sha256':before,'fit_domain_um':[.5,2.4],'scope':'Only graphdata changed from legacy matcheddiagnostic; no last55nm tailisusedinfit','weights':'legacyfixed0.01185n/0.00735k scales; numerical weighting, not errors/likelihood'},indent=2))
exec(source,original.__dict__);original.drude(OUT)
r=json.loads((OUT/'results.json').read_text());r['identity']='Highresolution original Figure5d actualtickcalibration; sameTLparametersandfitweightsaslegacydiagnostic';r['printed_equation_status']='OriginalPDFEq5 numeratorADwithoutGamma confirmedindependentlybylead; noauthorsorrectionhasbeenmade';r['postflight_all_sha_match']=all(sha(ROOT/p)==v for p,v in before.items());assert r['postflight_all_sha_match'];(OUT/'results.json').write_text(json.dumps(r,indent=2))
