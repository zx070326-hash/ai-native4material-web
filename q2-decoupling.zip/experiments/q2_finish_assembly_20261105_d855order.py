"""Selected-point order/slice control of actual d8.55 externalAR19 optics.

Executes the completed127run's final effective function. No shared source edit,
no old internal16-layer control reuse, no full169-mode aperture claim.
"""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import argparse,ast,hashlib,inspect,json,sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
REF=ROOT/'runs/20261105-q2-finish-decouple-source25-phase855-optics64-127-0'
READ=ROOT/'runs/20261105-q2-finish-decouple-source25-phase855-readout64-127-600-01'
FIELD=ROOT/'runs/20261105-q2-finish-assembly-phase25-d8p55-source64-01/fields.npz'
ZN=ROOT/'runs/20261105-q2-finish-material-ZnO-hires-input-01/ZnO2022_Fig5d_hires_exactnodes_tail_linear_scenario.csv'


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x):Path(p).write_text(json.dumps(x,indent=2),encoding='utf-8')
def checked(folder):
    m=json.loads((folder/'results.json').read_text())
    for p,h in m['frozen_inputs_SHA256'].items():assert sha(ROOT/p)==h,p
    assert sha(folder/'effective_optics_source.py')==m['effective_source_SHA256']
    return m
def namespace():
    from experiments import q2_finish_decouple_20261105 as base
    return dict(base.__dict__)


def audit_layers(source):
    tree=ast.parse(source);fn=tree.body[0];cell=next(q for q in fn.body if isinstance(q,ast.FunctionDef)and q.name=='cell');cut=next(i for i,q in enumerate(cell.body)if isinstance(q,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='S'for t in q.targets));cell.body=cell.body[:cut]+ast.parse('return layers').body
    fn.body=fn.body[:fn.body.index(cell)+1]+ast.parse("return {k:cell(k,0,0,.55)for k in ['driven','compensator','thermal']}").body;fn.name='audit';ast.fix_missing_locations(tree);ns=namespace();exec(compile(tree,'<actuald855layeraudit>','exec'),ns)
    layers=ns['audit'](argparse.Namespace(fields=FIELD.parent,d=2.5,slices=32,order=4))
    from experiments.q2_closure_coupling import model
    old=model.old;ar=complex(old.index('Al2O3_Franta',np.array([.55]))[0]);sn=np.loadtxt(ROOT/'data/q2_finish_material_20261105/SiNx_spectrum/DLC_4keV_vector_digitized.csv',delimiter=',',skiprows=1);zn=np.loadtxt(ZN,delimiter=',',skiprows=1)
    names={n:complex(np.interp(.55,t[:,0],t[:,1]),np.interp(.55,t[:,0],t[:,2]))for n,t in [('SiNx',sn),('ZnO',zn)]};names['Al2O3']=ar
    def identify(ep,d):
        for label,n in names.items():
            ref=old.dielectric(n,n,np.zeros(128),np.zeros(128))
            if abs(ep-ref).max()<1e-12:return 'AR_Al2O3'if label=='Al2O3'and d<1 else label
        return 'E7'
    out={}
    for name,ll in layers.items():
        seq=[]
        for ep,d in ll:
            label=identify(ep,d)
            if seq and seq[-1]['material']==label:seq[-1]['thickness_um']+=float(d)
            else:seq.append({'material':label,'thickness_um':float(d)})
        out[name]=seq
    assert [r['material']for r in out['driven']]==['AR_Al2O3','ZnO','Al2O3','SiNx','E7','SiNx','Al2O3','ZnO','AR_Al2O3']
    merged=[]
    for q in out['driven']+[{'material':'ambient_air','thickness_um':2.}]+out['compensator']+out['thermal']:
        if merged and merged[-1]['material']==q['material']:merged[-1]['thickness_um']+=q['thickness_um']
        else:merged.append(dict(q))
    assert [r['thickness_um']for r in merged if r['material']=='Al2O3']==[8.]*5
    assert len([r for r in merged if r['material']!='ambient_air'])+1==19
    assert abs(sum(r['thickness_um']for r in out['thermal']if r['material']=='E7')-8.55)<1e-12
    from experiments import q2_package_device_20261105 as device
    assert 'dist=10000+y*'in inspect.getsource(device.gram)
    assert 'forward=S[2]@incident'in source and source.count('coupled.uniform_layer(1.,2.')==1
    return {'actual_cell_layers':out,'merged_main_sequence':merged,'physical_support_total_um':40,'main_including_external_screen':19,'electrode_positions':'bothouterZnOfacesofdrivermodule,ARoutsidethem','terminal_source':'actual25/50electricandthermal8.55six-state64source','screen_reference':'S[2]afterfinalthermalAl8;existinginner600Gramdistance10000umfromthisfinalexit','air_reference':'2umfromouterARtofrontpassiveAl8,bareZnOstandoff2.083028893um','scope':'Actualeffectivefunctionlayerprefixaudit;nophysicalwording-only19layermetadataassumption.'}


def select(a):
    source=(REF/'effective_optics_source.py').read_text();launch=json.loads((REF/'launch.json').read_text());assert json.loads((REF/'optical_postflight.json').read_text())['all_used_script_and_input_hashes_still_match']
    assert sha(FIELD)=='d281beb19c1504927f336eaac1dd74231ccd7d711903fb167ee0195d4e587e7e'and sha(ZN)=='2504682932f858210bcb30b01d8d7d2b27208af0df143cb2adbcca9899c0b18e'
    assert '[25,50]'in source and 'd=8.55 if kind=='in source and str(ZN.relative_to(ROOT)).replace('\\','/')in source
    layeraudit=audit_layers(source);z=np.load(READ/'spectra.npz');w=z['wavelength_um'];T=z['total_T'];peaks=[]
    for kind,q,lo,hi in [('VIS_thermal',abs(T[:,1]-T[:,0]),.4,.78),('NIR_electric',abs(T[1]-T[0]),.78,2.5)]:
        ix=np.flatnonzero((w>=lo)&(w<=hi))
        for state in range(2):
            j=ix[np.argmax(q[state,ix])];peaks.append({'kind':kind,'fixed_state':state,'wavelength_um':float(w[j]),'absolute_cross_pp':float(100*q[state,j])})
    vv=max([q for q in peaks if q['kind']=='VIS_thermal'],key=lambda q:q['absolute_cross_pp']);nn=sorted([q for q in peaks if q['kind']=='NIR_electric'],key=lambda q:q['absolute_cross_pp'],reverse=True);selected=np.unique([.4,.78,2.5,vv['wavelength_um']]+[q['wavelength_um']for q in nn]);assert len(selected)<=6
    np.savez_compressed(a.out/'grid.npz',wavelength_um=selected);(a.out/'effective_optics_source.py').write_text(source,encoding='utf-8');(a.out/'original_launch.json').write_bytes((REF/'launch.json').read_bytes())
    files=[Path(__file__).resolve(),FIELD,FIELD.parent/'results.json',ZN,ROOT/'data/nk/Al2O3_Franta.csv',ROOT/'data/q2_current/Li2005_E7_Cauchy.csv',ROOT/'data/q2_finish_material_20261105/SiNx_spectrum/DLC_4keV_vector_digitized.csv',ROOT/'data/q2_parallel_loss_20261105/Wu2002_E7_graph_alpha_k.csv']
    for module in list(sys.modules.values()):
        name=getattr(module,'__file__',None)
        if name:
            p=Path(name).resolve()
            if p.suffix=='.py'and p.is_relative_to(ROOT)and '.venv'not in p.parts:files.append(p)
    files=sorted(set(files))
    for p in files:
        dest=a.out/'frozen'/p.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes())
    result={'fields':str(FIELD.parent.relative_to(ROOT)),'fields_SHA256':sha(FIELD),'ZnO_table':str(ZN.relative_to(ROOT)),'ZnO_SHA256':sha(ZN),'frozen_inputs_SHA256':{str(p.relative_to(ROOT)):sha(p)for p in files},'effective_source_SHA256':sha(a.out/'effective_optics_source.py'),'selection':'ThreebandboundariesplusglobalVISthermalpeakandbothNIRtemperatureconditionelectricpeaks;max6actual127points','all_four_actual_peaks':peaks,'wavelength_um':selected.tolist(),'hole_kernel':'runs/20261105-q2-package-device-kernels-01/inner600/gram.npz','layer_audit':layeraudit,'reference127':str(REF.relative_to(ROOT)),'reference127_field_SHA256':sha(REF/'scattered_fields.npz'),'reference_readout_spectra_SHA256':sha(READ/'spectra.npz'),'physics_identity':{'main_layers':19,'temperatures_C':[25,50],'fixed_external_bias_V':9.235,'driver_comp_thermal_d_um':[2.5,2.5,8.55],'AR_each_um':.08302889342260214,'support_um':[8]*5,'ambient_gap_after_AR_um':2,'mask':'originalxinner600/yhalf600with11umshadow','source_nx_nz':[64,33]}}
    save(a.out/'results.json',result);print(json.dumps({'waves':selected.tolist(),'peaks':peaks,'audit':layeraudit},indent=2),flush=True)


def solve(a):
    m=checked(a.selection);source=(a.selection/'effective_optics_source.py').read_text();old="[('E',forward),('G',Y@forward)]";assert source.count(old)==1;source=source.replace(old,"[('E',forward),('G',Y@forward),('RE',back),('RG',Y@back)]");ns=namespace();exec(source,ns)
    (a.out/'executed_optics.py').write_text(source,encoding='utf-8');save(a.out/'launch.json',{'argv':sys.argv,'order':a.order,'slices':a.slices,'source_selection':str(a.selection.relative_to(ROOT)),'selected_physics':m['physics_identity'],'fields_SHA256':m['fields_SHA256'],'ZnO_SHA256':m['ZnO_SHA256'],'only_code_difference':'savebackfieldRE/RG;nomodificationoflayer/source/physics'});ns['optics'](argparse.Namespace(out=a.out,fields=ROOT/m['fields'],grid=a.selection/'grid.npz',d=2.5,bias=9.235,order=a.order,slices=a.slices,shard=0,shards=1,dense=False));checked(a.selection);save(a.out/'postflight.json',{'frozen_inputs_match':True})


def compare(a):
    from experiments import q2_finish_order_control_20261105 as common
    text=inspect.getsource(common.compare);old="original_runs=[ROOT/f'runs/20261105-q2-finish-decouple-SiNx-optics64-713-{j}'for j in range(3)]";new="original_runs=[ROOT/f'runs/20261105-q2-finish-decouple-source25-phase855-optics64-127-{j}'for j in range(2)]";assert text.count(old)==1;text=text.replace(old,new).replace('original713','original127').replace('Original713','Original127');ns=dict(common.__dict__);exec(text,ns);ns['compare'](a)
    r=json.loads((a.out/'results.json').read_text());r['actual_candidate']='ExternalAR19,d8.55/source25/9.235V/corrected335nodeZnO;notinternal16layercontrol';r['readback_frozen_inputs_match']=bool(checked(a.selection));save(a.out/'results.json',r);(a.out/'executed_compare.py').write_text(text,encoding='utf-8')


def main():
    p=argparse.ArgumentParser();p.add_argument('action',choices=['select','solve','compare']);p.add_argument('--out',type=Path,required=True);p.add_argument('--selection',type=Path);p.add_argument('--order',type=int);p.add_argument('--slices',type=int);p.add_argument('--low',type=Path);p.add_argument('--high',type=Path);a=p.parse_args()
    for k in ['out','selection','low','high']:
        if getattr(a,k,None)is not None:setattr(a,k,getattr(a,k).resolve())
    a.out.mkdir(parents=True,exist_ok=False);(a.out/'source.py').write_bytes(Path(__file__).read_bytes());{'select':select,'solve':solve,'compare':compare}[a.action](a)
if __name__=='__main__':main()
