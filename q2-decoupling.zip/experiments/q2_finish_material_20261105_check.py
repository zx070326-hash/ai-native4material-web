"""Independent local Gauss-gradient check for two 20nm SiNx dielectric films."""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import sys,json,inspect,hashlib
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments.q2_gap_director import Electric,initial
out=ROOT/'runs/20261105-q2-finish-material-SiNx-Gauss-check-01';out.mkdir(exist_ok=False)
(out/'launched_source.py').write_bytes(Path(__file__).read_bytes())
src=inspect.getsource(Electric).replace('class Electric:','class SiNxElectric:').replace('-.015/d','-.020/d').replace('1+.015/d','1+.020/d')
ns=dict(Electric.__init__.__globals__);exec(src,ns);ev=ns['SiNxElectric'](1.45,12,11.1,16,9,4,epsa=7.5)
v=initial(16,9,'perturbed');gr,p,c=ev.solve(v);val,g=ev.evg(v,gr)
rng=np.random.default_rng(20261105);direction=rng.normal(size=len(v));direction/=np.linalg.norm(direction)
def energy(q):return -ev.solve(q)[2]['positive_electric_dimensionless']
h=1e-5;fd=(energy(v+h*direction)-energy(v-h*direction))/(2*h)
r={'film_thickness_um':.020,'film_epsilon_scenario':7.5,'mesh':[16,9],'freshGauss_directional_difference':float(fd),'envelope_directional_gradient':float(g@direction),'absolute_difference':float(abs(fd-g@direction)),'Gauss':c,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Onlynumericalfunctionalcheck; noSiNxmaterialorfullspectrumcertificate'}
(out/'results.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
