"""Same-field passive bound beyond the digitized ZnO extinction trajectory.

No new Maxwell solve. A failed sufficient bound is not a material counterexample.
The nominal graphical endpoint continuation remains a separate scenario.
"""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import argparse,hashlib,json
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('--readout',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False)
    raw=ROOT/'data/q2_package_A_20261105/ZnO2022_Fig5d_k_raw.csv';last=float(np.loadtxt(raw,delimiter=',',skiprows=1)[-1,0]);rows=[];inputs=[raw]
    for inner in [600,700]:
        folder=a.readout/f'inner{inner}';f=folder/'spectra.npz';inputs.append(f);z=np.load(f);w=z['wavelength_um'];T=z['total_T'];assert T.min()>=-1e-9 and T.max()<=1+1e-9
        use=(w>=.78)&(w<=last);b=float(w[use][-1]);delta=T[:,0]-T[:,1];known=np.trapezoid(delta[:,use],w[use],axis=-1);tail=2.5-b;lower=100*np.maximum(0,abs(known)-tail)/(2.5-.78);nom=json.loads((folder/'results.json').read_text())['main']['NIR_model_pp']
        rows.append({'inner_um':inner,'digitized_ZnO_k_last_um':last,'last_actual_known713_node_um':b,'arbitrary_tail_width_um':tail,'known_signed_delta_integral_um_by_voltage':known.tolist(),'NIR_passive_lower_pp_by_voltage':lower.tolist(),'NIR_min_passive_lower_pp':float(lower.min()),'lower_reaches20pp':bool(lower.min()>=20),'nominal_endpoint_continuation_NIR_main_pp':nom,'spectra':str(f.resolve().relative_to(ROOT))})
    sources=[ROOT/'experiments/q2_package_A_controls_20261105.py',ROOT/'data/q2_package_A_20261105/ZnO2022_fig5.jpg',ROOT/'data/q2_package_A_20261105/ZnO_Zr_ALD2022.xml',ROOT/'runs/20261105-q2-finish-material-lossstress-ZnO-tail-01/results.json']
    inputs+=sources;result={'formula':'100*max(0,abs(trapz_.78_to_b(Tcold-Thot))-(2.5-b))/1.72','source_DOI':'10.1021/acsaelm.1c01026','source_graph':'Figure5d undoped99.8nmZnO;originalextractionq2_package_A_controls_20261105.py:zno','rows':rows,'SHA256':{str(f.resolve().relative_to(ROOT)):sha(f)for f in inputs},'scope':'Conditional same713-field integration only. Unknown tail transmittance independently ranges0to1foreachstate;commonmaterialfourstatecorrelationisnotexploited.','limits':['Digitizedktrajectoryendsbeforedeclared2500nmmeasurement;thisbounddoesnotasserttheauthorhasnodata.','bisthelastcomputed713nodeinsideknownsupport;theuncomputedgapfrombtothedigitizedendpointisconservativelyincludedintheunknowntail.','Knownregionalsoremainsconditionalontherecordedmaterialsource/temperature/anchoringtransfers.','FailureofthissufficientboundisnotanactualcommonZnOcounterexampleandnotaproofofproblemimpossibility.','Nominalendpointextensionandfullyunknowntailarenotthesameassumption.']}
    (a.out/'results.json').write_text(json.dumps(result,indent=2),encoding='utf-8');(a.out/'source.py').write_bytes(Path(__file__).read_bytes());print(json.dumps(rows,indent=2),flush=True)


if __name__=='__main__':main()
