"""Frozen one-factor optical-loss pressure for the same SiNx three-cell device.

All three LC cells use k=max(Wu2002 graph-transferred k(lambda),.001). This is
a pressure scenario, never measured low-temperature anisotropic absorption or
a certified source uncertainty bound. The actual Frank/Gauss fields, geometry,
fixed bias and complex spectra of all retained non-LC materials are unchanged.
"""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import sys,argparse,json,hashlib,time
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments import q2_finish_decouple_20261105_sinx as adapter
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('action',choices=['optics','readout']);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--shard',type=int,default=0);ap.add_argument('--shards',type=int,default=2);ap.add_argument('--runs',type=Path,nargs='+');ap.add_argument('--hole',type=Path,default=ROOT/'runs/20261105-q2-package-device-kernels-01/inner600/gram.npz');a=ap.parse_args();a.out.mkdir(parents=True,exist_ok=False)
    deps=[Path(__file__),Path(adapter.__file__),Path(adapter.base.__file__),ROOT/'data/q2_finish_material_20261105/SiNx_spectrum/DLC_4keV_vector_digitized.csv',ROOT/'data/q2_parallel_loss_20261105/Wu2002_E7_graph_alpha_k.csv',ROOT/'runs/20261105-q2-finish-decouple-SiNx-director32-d2p5-01/fields.npz',ROOT/'runs/20261105-q2-package-A-director64-d1p45-02/fields.npz']
    hashes={str(p.resolve().relative_to(ROOT)):sha(p) for p in deps}
    for i,p in enumerate(deps):
        (a.out/f'launch_input_{i:02d}_{p.name}').write_bytes(p.read_bytes())
    old='ne+=1j*k;no+=1j*k';new='k=max(k,.001);ne+=1j*k;no+=1j*k';assert adapter.source.count(old)==1
    source=adapter.source.replace(old,new);(a.out/'executed_optics_source.py').write_text(source,encoding='utf8');exec(source,adapter.base.__dict__)
    launch={'argv':sys.argv,'started_time_unix':time.time(),'input_sha256':hashes,'executed_optics_sha256':hashlib.sha256(source.encode()).hexdigest(),'only_change':'AllthreeLCk=max(Wu2002graphtransferredk(lambda),.001),sameforbothaxesandtemperatures','not_a_measured_or_confidence_bound':True,'geometry':'SiNx20nmthreecell,d2.5um,Va0/Vb1.5Vfixedboth15/50C;actual32electricand64thermalfields unchanged','fields':'runs/20261105-q2-finish-decouple-SiNx-director32-d2p5-01','thermal':'runs/20261105-q2-package-A-director64-d1p45-02','grid':'same127originalgrid'};(a.out/'launch.json').write_text(json.dumps(launch,indent=2))
    a.d=2.5;a.bias=1.5;a.fields=ROOT/'runs/20261105-q2-finish-decouple-SiNx-director32-d2p5-01';a.slices=32;a.order=4;a.dense=True;a.grid=None
    if a.action=='optics':adapter.base.optics(a)
    else:adapter.base.readout(a)
    p=a.out/'results.json';r=json.loads(p.read_text());r['lossstress_launch']=launch;r['input_hashes_unchanged_after_run']={str(q.resolve().relative_to(ROOT)):sha(q)==hashes[str(q.resolve().relative_to(ROOT))]for q in deps};r['actual_alignment_material']='SiNx';r['LC_loss_pressure']='max(Wu2002graphtransferredk(lambda),.001) forallthreeLCs; notmeasured bound';p.write_text(json.dumps(r,indent=2),encoding='utf8')
