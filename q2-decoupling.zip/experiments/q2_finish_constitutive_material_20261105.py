"""Independently digitize Huang2010 Fig4; compare apparent K(T) to Li2005 dn.

One local single-thread calculation. Data exist only25/30/35/40C, K11/K22,
and pretilts plotted in this25um rubbed-PVA/DLS sample. No15/50C or K33 is
manufactured. beta<1deg immeasurable is never replaced by K=0.
"""
import os
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import sys,argparse,json,hashlib,itertools
import numpy as np
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
SRC=ROOT/'runs/20261105-q2-finish-decouple-E7-constitutive-source-01'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main(a):
    a.out.mkdir(parents=True,exist_ok=False);(a.out/'source.py').write_bytes(Path(__file__).read_bytes())
    image=Image.open(SRC/'Huang2010_native_2.png').convert('RGB');gray=np.asarray(image.convert('L'));xs=np.array([111.,218.,315.,383.,422.,491.,523.,576.]);Ts=[25,30,35,40]
    # Manual branch windows identify temperatures/markers only; reported y is
    # extracted independently from nearby connecting curves outside all symbols.
    seed1=np.array([[229,159,108,82,80,78,78,77],[250,175,139,121,119,118,118,117],[285,235,203,175,173,172,171,171],[320,272,232,208,206,205,204,203]],float)
    seed2=np.array([[541,510,487,468,463,462,462,462],[559,528,509,491,489,487,487,485],[582,549,530,516,515,513,513,512],[600,562,547,532,530,530,529,528]],float)
    xcal=np.polyfit([1,3,5,7],[104,257,410,563],1);beta=(xs-xcal[1])/xcal[0]
    ticks={'K11':[(12.,11.5),(9.5,174.),(7.,319.5)],'K22':[(12.,358.5),(9.,511.5),(6.,674.5)]}
    raw={};unc={};branches=[]
    for mode,seeds in [('K11',seed1),('K22',seed2)]:
        yy=np.zeros_like(seeds);ee=np.zeros_like(seeds)
        for ti,T in enumerate(Ts):
            for j,x in enumerate(xs):
                candidates=[];details=[]
                for side in [-1,1]:
                    columns=np.arange(int(max(124,x-46)if side<0 else x+17),int(x-16 if side<0 else min(625,x+47)))
                    pts=[]
                    for col in columns:
                        if np.min(abs(xs-col))<=16:continue
                        pred=np.interp(col,xs,seeds[ti]);ys=np.arange(max(2,int(pred-7)),min(gray.shape[0]-2,int(pred+8)))
                        dark=ys[gray[ys,col]<100]
                        if len(dark):pts.append((col,float(np.median(dark))))
                    if len(pts)>=6:
                        pts=np.asarray(pts);fit=np.polyfit(pts[:,0]-x,pts[:,1],1);candidates.append(float(fit[1]));details.append({'side':side,'points':len(pts),'slope':float(fit[0]),'at_marker_y':float(fit[1]),'residual_rms_px':float(np.sqrt(np.mean((pts[:,1]-np.polyval(fit,pts[:,0]-x))**2)))})
                if not candidates:raise ValueError((mode,T,j,'No independently isolated curve'))
                yy[ti,j]=np.mean(candidates);ee[ti,j]=max(2.,np.ptp(candidates)/2 if len(candidates)>1 else 2.)
                branches.append({'mode':mode,'T_C':T,'x_pixel':x,'beta_from_axis_deg':float(beta[j]),'marker_y_pixel':float(yy[ti,j]),'marker_sensitivity_px':float(ee[ti,j]),'branches':details})
        raw[mode]=yy;unc[mode]=ee
    calibration={};values={};rows=[]
    for mode in ticks:
        anchors=np.array(ticks[mode]);fit=np.polyfit(anchors[:,0],anchors[:,1],1);calibration[mode]={'y_equals_slope_times_KpN_plus_offset':fit.tolist(),'manual_label_anchors_KpN_ypixel':anchors.tolist(),'label_noncollinearity_rms_px':float(np.sqrt(np.mean((np.polyval(fit,anchors[:,0])-anchors[:,1])**2))),'warning':'Ticklabelcentersaremanualimagecalibration;pairwiseanchorand2pxchangespropagatedassensitivity,notstatisticalconfidence.'};values[mode]=(raw[mode]-fit[1])/fit[0]
    for j,b in enumerate(beta):
        for ti,T in enumerate(Ts):rows.append([b,T,values['K11'][ti,j],values['K22'][ti,j],raw['K11'][ti,j],raw['K22'][ti,j]])
    np.savetxt(a.out/'Huang2010_Fig4_independent_curves.csv',rows,delimiter=',',header='pretilt_deg_from_axis,T_C,K11_pN_apparent,K22_pN_apparent,K11_y_pixel,K22_y_pixel',comments='')
    tab=np.loadtxt(ROOT/'data/q2_current/Li2005_E7_Cauchy.csv',delimiter=',',skiprows=1)
    def optics(w):
        q=tab[np.isin(tab[:,0],Ts)];ne=q[:,1]+q[:,2]/w**2+q[:,3]/w**4;no=q[:,4]+q[:,5]/w**2+q[:,6]/w**4;return ne,no
    ne,no=optics(.589);dn=ne-no;x=np.log(dn/dn[0]);den=float(x@x)
    def exponent(k):return float(x@np.log(k/k[0])/den)
    comparisons=[]
    for mode in ticks:
        for group,idx in [('low_pretilt_first',[0]),('second_actual_plotted_pretilt',[1]),('plateau_beta_ge5',[4,5,6,7])]:
            k=values[mode][:,idx].mean(axis=1);y=raw[mode][:,idx].mean(axis=1);e=unc[mode][:,idx].max(axis=1);p=exponent(k);pred=k[0]*(dn/dn[0])**2;sens=[]
            # Allthreepairs and +/-2px calibration, plus independently directed
            # marker errors. These are image sensitivity extrema, not CIs.
            anchors=ticks[mode]
            for pair in itertools.combinations(anchors,2):
                for tickerr in itertools.product([-2,2],repeat=2):
                    cf=np.polyfit([pair[0][0],pair[1][0]],[pair[0][1]+tickerr[0],pair[1][1]+tickerr[1]],1)
                    for errors in itertools.product([-1,1],repeat=4):
                        kk=(y+np.array(errors)*e-cf[1])/cf[0]
                        if np.all(kk>0):sens.append(exponent(kk))
            comparisons.append({'mode':mode,'group':group,'pretilts_deg':[float(beta[i])for i in idx],'T_C':Ts,'K_pN_apparent':k.tolist(),'ratio_over25':(k/k[0]).tolist(),'p_effective_fit25to40_vs_Li589':p,'p_image_sensitivity_range':[min(sens),max(sens)],'Li_dn2_ratio':((dn/dn[0])**2).tolist(),'p2_predicted_K_pN_at_same25anchor':pred.tolist(),'measured_apparent_minus_p2_pN':(k-pred).tolist(),'normalized_p2_rms':float(np.sqrt(np.mean((k/k[0]-(dn/dn[0])**2)**2))),'scope':'Onlythispretilt/sample/DLSmethodover25to40C;no15/50/K33/zeropretiltextrapolation'})
    im=image.copy();draw=ImageDraw.Draw(im);colors=['red','blue','green','orange']
    for mode in raw:
        for ti in range(4):
            for j,xx in enumerate(xs):
                yy=raw[mode][ti,j];draw.ellipse((xx-3,yy-3,xx+3,yy+3),outline=colors[ti],width=2)
    im.save(a.out/'Huang2010_independent_selected_centers.png')
    n514,o514=optics(.514);qopt=n514*n514-o514*o514
    cross={};other=ROOT/'runs/20261105-q2-finish-decouple-E7-constitutive-digitized-01/Huang2010_Fig4_pretilt_specific_K.csv'
    if other.exists():
        q=np.loadtxt(other,delimiter=',',skiprows=1);diff=[]
        for j,pre in [(0,1.1),(1,2.5),(7,7.2)]:
            for ti,T in enumerate(Ts):
                v=q[(abs(q[:,0]-pre)<1e-8)&(q[:,1]==T)][0];diff.append([pre,T,values['K11'][ti,j]-v[2],values['K22'][ti,j]-v[3]])
        cross={'reference_file':str(other),'difference_own_minus_decouple_rows':diff,'warning':'ReferenceCSVreadonlyafterindependentcalibrationandcurvebranchmethodspecified;notusedasinputcoordinates.'}
    result={'source_sha256':{str(p.relative_to(ROOT)):sha(p)for p in [SRC/'Huang2010_K_dependence.pdf',SRC/'Huang2010_native_2.png',ROOT/'data/q2_current/Li2005_E7_Cauchy.csv',Path(__file__)]},'doi':'10.1016/j.cap.2009.07.022','native_image_pixels':image.size,'source_temperatures_C':Ts,'native_x_calibration':{'tick_pretilt':[1,3,5,7],'tick_x_pixel':[104,257,410,563],'fit_slope_offset':xcal.tolist(),'actual_marker_pretilts_deg':beta.tolist(),'second_low_marker':'about2.5deg;sourcebody2.1isnotthisplottedmarker. No2.1datafabricated.'},'calibration':calibration,'curve_digitization':branches,'comparisons':comparisons,'plateau_K22_over_K11_by_T':(values['K22'][:,[4,5,6,7]].mean(axis=1)/values['K11'][:,[4,5,6,7]].mean(axis=1)).tolist(),'current_model_K22overK11_at25':6.5/11.1,'Li514_optical_check':{'T_C':Ts,'n_e':n514.tolist(),'n_o':o514.tolist(),'delta_n':(n514-o514).tolist(),'optical_delta_epsilon':qopt.tolist(),'Huang_reported_ne_no':[1.720,1.521],'Huang_reported_optical_delta_epsilon':.6450,'caution':'Sourcegivesfixedne/no valueswithoutT-dependenttabulation;notprovedtheyheldconstantinallinversion. Batch/opticalcalibrationdiffersfromLi2005. NoowncorrectionofreportedKisinvented.'},'independent_crosscheck':cross,'limits':['SampleSlichemE7;25umrubbedPVAcell;discussioncallspolyimide,soidentitynotfullyconsistent.','Pretiltmeasuredat23C;quoted1.1etcarenotdemonstratedconstantwithtemperature.','Paperbeta<1degunmeasurablemeansmissingmeasurement,nouniversalK=0orabsenceofnematicelasticity.','Figure25/30/35/40Conly;text11.25pNat20Ccannotcalibrate25Ctraceandisnotshown20Cfigurepoint.','Apparentpretilt/methoddependenceisnotuniversalintrinsicFrankconstitutiveK(beta).','NoK33measurements,15/50Cdata,0degreeplanarproof,combinedsamebatchdn/K/epsilon/anchoringcertificate.','p1/p2/p3of9scenariosaremodelpressures,notconfidenceboundsfromthispaper;mode-dependentfitscannotjustifyonecommonexponentforallthreeK.']}
    (a.out/'results.json').write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps({'comparisons':comparisons,'plateau_K22_K11':result['plateau_K22_over_K11_by_T'],'calibration':calibration},indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);main(p.parse_args())
