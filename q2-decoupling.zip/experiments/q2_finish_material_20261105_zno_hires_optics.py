"""Only ZnO graph calibration changes in two existing external AR19 devices."""
import os
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[key]='1'
from pathlib import Path
import sys,json,hashlib,shutil,argparse,time,importlib
from types import SimpleNamespace
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
LAUNCH=ROOT/'runs/20261105-q2-finish-material-ZnO-hires-optics-launch-01'
TABLE=ROOT/'runs/20261105-q2-finish-material-ZnO-hires-input-01/ZnO2022_Fig5d_hires_exactnodes_tail_linear_scenario.csv'
VARIANTS={
 'old15':{'module':'experiments.q2_finish_decouple_20261105_external_ar','fields':'runs/20261105-q2-finish-external-director64-support32-01','bias':12.235,'temperatures':[15,50],'baseline':'runs/20261105-q2-finish-decouple-external_ar-optics64-127-0'},
 'new25':{'module':'experiments.q2_finish_decouple_20261105_external_ar_source25','fields':'runs/20261105-q2-finish-source25-combined64-01','bias':9.235,'temperatures':[25,50],'baseline':'runs/20261105-q2-finish-decouple-source25-AR19-optics64-127-0'}}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def prepare():
 LAUNCH.mkdir(parents=True,exist_ok=False)
 original=json.loads((ROOT/'runs/20261105-q2-finish-assembly-AR19-713-launch-01/manifest.json').read_text())
 files={ROOT/p for p in original['SHA256'] if not p.endswith('q2_close_materials_full713.npz')}
 files|={Path(__file__),TABLE,ROOT/'experiments/q2_finish_decouple_20261105_external_ar_source25.py',ROOT/'experiments/q2_finish_decouple_20261105_readout.py',ROOT/'runs/20261105-q2-finish-source25-config-01/config.json'}
 for v in VARIANTS.values():files|={ROOT/v['fields']/'fields.npz',ROOT/v['fields']/'results.json',ROOT/v['baseline']/'results.json'}
 checks={str(p.relative_to(ROOT)):sha(p) for p in sorted(files)}
 for p in files:
  q=LAUNCH/'frozen'/p.relative_to(ROOT);q.parent.mkdir(exist_ok=True,parents=True);shutil.copy2(p,q)
 waves=np.unique(np.r_[np.linspace(.4,.78,41),np.linspace(.78,2.5,87)])
 np.savez(LAUNCH/'grid127.npz',wavelength_um=waves)
 receipt={'prepared_time_unix':time.time(),'argv':sys.argv,'SHA256':checks,'variants':VARIANTS,'ZnO_actual_table':str(TABLE.relative_to(ROOT)),'ZnO_actual_table_sha256':sha(TABLE),'spectral_grid':'127 existing dense nodes .4-.78:41 and .78-2.5:87, duplicate .78 removed','wavelengths_um':waves.tolist(),'single_change':'Recalibrated1254x747 original Figure5d n/k, explicitpassiveprojection and2444.805-2500nm continuouslineargraph-tail scenario','source_scope':'not an uncertainty upper bound; electrical Gauss and constitutive sources unchanged','legacy_ZnO_in_manifest':'retained provenance comparison ONLY; actual opticaltable replaced in effective source'}
 (LAUNCH/'manifest.json').write_text(json.dumps(receipt,indent=2));print(json.dumps({'manifest':str(LAUNCH),'sha256':sha(LAUNCH/'manifest.json'),'table_sha256':sha(TABLE),'dependencies':len(checks),'wavelengths':len(waves)}))

def solve(variant,shard):
 manifest=json.loads((LAUNCH/'manifest.json').read_text());v=manifest['variants'][variant]
 before={p:sha(ROOT/p)==h for p,h in manifest['SHA256'].items()};assert all(before.values()),before
 out=ROOT/f'runs/20261105-q2-finish-material-ZnO-hires-{variant}-optics127-{shard}-01';out.mkdir(parents=True,exist_ok=False)
 module=importlib.import_module(v['module']);base=module.base;source=module.source
 old="zn=np.loadtxt(ROOT/'data/q2_package_A_20261105/ZnO2022_Fig5d_passive_digitized.csv',delimiter=',',skiprows=1)"
 new=f"zn=np.loadtxt(ROOT/{str(TABLE.relative_to(ROOT)).replace(chr(92),'/')!r},delimiter=',',skiprows=1)"
 assert source.count(old)==1;source=source.replace(old,new)
 assert source.count(new)==1
 (out/'effective_optics_source.py').write_text(source)
 shutil.copy2(__file__,out/'source.py');shutil.copy2(LAUNCH/'manifest.json',out/'launch_manifest.json')
 (out/'preflight.json').write_text(json.dumps({'argv':sys.argv,'variant':v,'checks':before,'manifest_sha256':sha(LAUNCH/'manifest.json'),'effective_source_sha256':sha(out/'effective_optics_source.py')},indent=2))
 exec(source,base.__dict__)
 a=SimpleNamespace(out=out,fields=ROOT/v['fields'],bias=v['bias'],d=2.5,slices=32,order=4,grid=None,dense=True,shards=2,shard=shard)
 base.optics(a)
 r=json.loads((out/'results.json').read_text());baseline=json.loads((ROOT/v['baseline']/'results.json').read_text())
 config=baseline.get('physical_override',{}).copy();config.update({'ZnO_source_override':'1254x747 original Fig5d recalibrated independent graph table','ZnO_actual_optical_table':str(TABLE.relative_to(ROOT)),'ZnO_actual_optical_table_SHA256':sha(TABLE),'ZnO_tail':'continuous linear slope of last300nm colored pixels, anchored at last2444.805nm greenpixel; k2500=.041801115572','ZnO_uncertainty_status':'graphical scenario only; not measured endpoint, not temperaturedependent or measuredupperbound','actual_source_fields':v['fields'],'temperatures_C':v['temperatures'],'fixed_terminal_voltage_V':v['bias'],'only_optical_input_change':'ZnO n/k; all geometry, all actual LCfields and other materials identical to paired baseline'})
 r.update({'physical_override':config,'temperatures_C':v['temperatures'],'scope':'Matchedreal4state externalAR19 samegeometry fixedV; onlyoriginalZnOgraphrecalibrationchanged','limits':baseline.get('limits',[])+['High-resolutiongraphcalibration supersedes oldhalf-resolution table inthisrunonly; final55.195nm ofkusesdeclaredcontinuationmodel; pixelandtailchoicesarenotmeasuredconfidenceintervals.']})
 (out/'results.json').write_text(json.dumps(r,indent=2))
 after={p:sha(ROOT/p)==h for p,h in manifest['SHA256'].items()};(out/'postflight.json').write_text(json.dumps({'all_sha_match':all(after.values()),'checks':after,'wavelengths':len(r['diagnostics'])},indent=2));assert all(after.values())

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('action',choices=['prepare','solve']);p.add_argument('--variant',choices=VARIANTS);p.add_argument('--shard',type=int,choices=[0,1]);a=p.parse_args()
 if a.action=='prepare':prepare()
 else:solve(a.variant,a.shard)
