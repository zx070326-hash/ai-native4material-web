"""One authorized exact dense VIS peak append to frozen solid six-point audit."""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import argparse,inspect,json,sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments import q2_finish_assembly_20261106_solidorder as audit
BASE=ROOT/'runs/20261106-q2-finish-assembly-solid-order-selection-01'
SIX=ROOT/'runs/20261106-q2-finish-assembly-solid-order-comparison-01/results.json'
DENSE=ROOT/'runs/20261105-q2-finish-decouple-solid-interface-readout64-837-600-01/spectra.npz'
def select(a):
    m=audit.checked(BASE);z=np.load(DENSE);w=z['wavelength_um'];T=z['total_T'];ix=np.flatnonzero((w>=.4)&(w<=.78));dd=abs(T[:,1]-T[:,0]);at=np.unravel_index(np.argmax(dd[:,ix]),dd[:,ix].shape);j=ix[at[1]];lam=float(w[j]);assert abs(lam-.5230125523012551)<1e-13
    np.savez_compressed(a.out/'grid.npz',wavelength_um=np.array([lam]));(a.out/'effective_optics_source.py').write_bytes((BASE/'effective_optics_source.py').read_bytes());m['original_six_wavelength_um']=m['wavelength_um'];m['wavelength_um']=[lam];m['selection']='One exact actual837 saved600 VIS thermal global peak; authorized append only';m['dense_peak']={'wavelength_um':lam,'Vindex':int(at[0]),'absolute_cross_pp':float(dd[at[0],j]*100),'dense_spectra':str(DENSE.relative_to(ROOT)),'dense_spectra_SHA256':audit.sha(DENSE)};m['original_frozen_snapshot']=str(BASE.relative_to(ROOT));m['frozen_inputs_SHA256'][str(Path(__file__).resolve().relative_to(ROOT))]=audit.sha(__file__);m['frozen_inputs_SHA256'][str(DENSE.relative_to(ROOT))]=audit.sha(DENSE);audit.save(a.out/'results.json',m);print(json.dumps(m['dense_peak']),flush=True)
def compare(a):
    from experiments import q2_finish_order_control_20261105 as common
    source=inspect.getsource(common.compare);old="original_runs=[ROOT/f'runs/20261105-q2-finish-decouple-SiNx-optics64-713-{j}'for j in range(3)]";new="original_runs=[ROOT/f'runs/20261105-q2-finish-decouple-solid-interface-optics64-missing713-{j}-01'for j in range(4)]";assert source.count(old)==1
    source=source.replace(old,new).replace('original713','original_dense713');ns=dict(common.__dict__);exec(source,ns);ns['compare'](a)
    r=json.loads((a.out/'results.json').read_text());r['actual_candidate']='Frozen all-solid source25 d8.55 / corrected ZnO / fixed9.235V';r['single_authorized_dense_peak_append']=True;r['all_frozen_inputs_match']=bool(audit.checked(a.selection));audit.save(a.out/'results.json',r);(a.out/'executed_compare.py').write_text(source,encoding='utf-8')
    six=json.loads(SIX.read_text());rows=six['wavelengths']+r['wavelengths'];states=[s for q in rows for s in q['states']]
    summary={'wavelength_um':sorted(q['wavelength_um']for q in rows),'point_count':7,'state_count':len(states),'RTA_max_absolute_change_pp':{k:max(abs(s['RTA_change_pp'][k])for s in states)for k in ['R','T','A']},'common81_hole_projection_max_change_pp':max(abs(s['common81_hole_projection_change_pp'])for s in states),'common81_field_absolute_max':{k:max(s['field_differences'][k]['common81_absolute_max']for s in states)for k in ['E','G','RE','RG']},'new_tail88_forward_power_max':max(s['new_tail88_forward_power_fraction_of_incident']for s in states),'new_tail88_reflected_power_max':max(s['new_tail88_reflected_power_fraction_of_incident']for s in states),'high_all_passive':all(min(s['RTA_high'].values())>=-1e-10 for s in states),'high_cascade_residual_max':max(s['high_cascade_residual']for s in states),'modal_power_identity_max_abs':max(max(abs(s['high_forward_modal_power_sum_minus_T']),abs(s['high_reflected_modal_power_sum_minus_R']))for s in states)}
    audit.save(a.out/'seven_point_summary.json',{'summary':summary,'original_six_results':str(SIX.relative_to(ROOT)),'original_six_SHA256':audit.sha(SIX),'single_peak_results':str((a.out/'results.json').relative_to(ROOT)),'single_peak_SHA256':audit.sha(a.out/'results.json'),'dense_peak':r['selection']['dense_peak'],'scope':'Seven selected actual-solid wavelengths, common81 original600 projection only; excluded88-mode coherent aperture interference; no full-band or manufacturing certificate. Original six outputs unchanged.','wavelengths':rows});print(json.dumps(summary,indent=2),flush=True)
def main():
    p=argparse.ArgumentParser();p.add_argument('action',choices=['select','solve','compare']);p.add_argument('--out',type=Path,required=True);p.add_argument('--selection',type=Path);p.add_argument('--order',type=int);p.add_argument('--slices',type=int);p.add_argument('--low',type=Path);p.add_argument('--high',type=Path);a=p.parse_args()
    for k in ['out','selection','low','high']:
        if getattr(a,k,None)is not None:setattr(a,k,getattr(a,k).resolve())
    a.out.mkdir(parents=True,exist_ok=False);(a.out/'source.py').write_bytes(Path(__file__).read_bytes());{'select':select,'solve':audit.solve,'compare':compare}[a.action](a)
if __name__=='__main__':main()
