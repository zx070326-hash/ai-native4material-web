"""Five-support external-electrode variant, separate from the16-layer result.

Requires a freshly relaxed external-support-Gauss LC director source. This
entrypoint never approximates external voltage by a scalar LC-voltage ratio.
"""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import sys,json,hashlib,time
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments import q2_finish_decouple_20261105_sinx as adapter
base=adapter.base
source=adapter.source
old="layers=[(iso(support),front)]+electrode+[(iso(dn),.02)]+[(old.dielectric(ne,no,th[:,j],ph[:,j]),d/a.slices)for j in range(a.slices)]+[(iso(dn),.02)]+electrode+[(iso(support),back)]"
new="body=[(iso(dn),.02)]+[(old.dielectric(ne,no,th[:,j],ph[:,j]),d/a.slices)for j in range(a.slices)]+[(iso(dn),.02)]\n  if kind=='driven':layers=electrode+[(iso(support),8.)]+body+[(iso(support),8.)]+electrode\n  else:layers=[(iso(support),8. if kind=='compensator' else 4.)]+body+[(iso(support),back)]"
assert old in source
source=source.replace(old,new)
old="after,err=coupled.cascade(c,t)"
new="after,err=coupled.cascade(c,t);gap=coupled.uniform_layer(1.,2.,float(lam),lam*qx,lam*qy);after,er_gap=coupled.cascade(gap,after);err=max(err,er_gap)"
assert old in source
source=source.replace(old,new).replace("'main_layer_count':16","'main_layer_count':17").replace("'physical_supports':4","'physical_supports':5")
exec(source,base.__dict__)

if __name__=='__main__':
 if len(sys.argv)<2 or sys.argv[1]!='optics':raise SystemExit('This separate entrypoint only accepts optics and requires external-Gauss --fields and --bias.')
 if '--fields'not in sys.argv or '--bias'not in sys.argv:raise SystemExit('Explicit externally solved director --fields and fixed --bias are required.')
 out=Path(sys.argv[sys.argv.index('--out')+1]);files=[Path(__file__),Path(adapter.__file__),Path(base.__file__)];frozen={p.name:p.read_bytes()for p in files}
 config={'time_unix':time.time(),'argv':sys.argv,'source_sha256':{p.name:hashlib.sha256(frozen[p.name]).hexdigest()for p in files},'main_path_layers':17,'supports_um':[8.,8.,8.,8.,8.],'drive_LC_um':2.5,'passive_LC_um':2.5,'thermal_LC_um':8.353152083061113,'coating_um':.02,'electrodes':'two99.8nmZnOonouterfacesofisolateddrivermodule','environment_gap_um':2.,'conditions':['External-supportGauss source is required; noVLCratio approximation','full periodic triple-cell vector scattering with2umairreturncoupling','fourA/source/anchoring/temperaturetransferconditionscarryover','five-boardassemblyscenarioisnotmanufacturingcertificate','peripheralinventoryandnA/Bconditionsremainexplicit']}
 base.main()
 for name,payload in frozen.items():(out/('dependency_'+name)).write_bytes(payload)
 (out/'source.py').write_bytes(frozen[Path(__file__).name]);(out/'launch.json').write_text(json.dumps(config,indent=2))
 r=json.loads((out/'results.json').read_text());r['physical_override']=config;r['scope']='Fiveboard17-layer external-electrode SiNx three-cell same-fixed-externalV four-state optics';(out/'results.json').write_text(json.dumps(r,indent=2))
