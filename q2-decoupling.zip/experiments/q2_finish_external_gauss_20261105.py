"""Explicit external-electrode multilayer Gauss + Frank source, no optical solve.

Electrodes lie outside8umAl2O3/20nmSiNx/LC/20nmSiNx/8umAl2O3.
Supports are separately meshed isotropic dielectrics. LC anisotropic tensor and
stationary-potential envelope derivative follow the existing Q1 functional.
"""
import os
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
import argparse,json,sys,time,hashlib
from pathlib import Path
import numpy as np
import autograd.numpy as anp
from autograd import value_and_grad
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve
from scipy.optimize import minimize,minimize_scalar
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments.q2_gap_director import Electric
from experiments.q2_manufacturing_lc_director2d import problem,initial
from experiments.q2_finish_decouple_20261105 import scale,indices
EPS0=8.8541878128e-12


class ExternalElectric(Electric):
 def __init__(self,d,period,K,nx,nz,V,support_cells=16):
  self.nx,self.nz,self.V=nx,nz,V;self.A=2*period/d;self.dx=self.A/nx;self.K=K*1e-12
  self.ep,self.de,self.epsa=5.2,13.8,7.5;self.d=d;self.ns=support_cells
  self.z=np.r_[np.linspace(-8.02,-.02,support_cells+1),0.,np.linspace(0,d,nz)[1:],d+.02,np.linspace(d+.02,d+8.02,support_cells+1)[1:]]/d
  self.dz=np.diff(self.z);self.x=np.arange(nx)[:,None];self.np=len(self.z)
  self.lc=slice(support_cells+1,support_cells+nz)
  node=np.arange(nx*self.np).reshape(nx,self.np)
  self.conn=np.stack([node[:,:-1],np.roll(node,-1,axis=0)[:,:-1],node[:,1:],np.roll(node,-1,axis=0)[:,1:]],-1)
  self.ii=np.broadcast_to(self.conn[...,None],(*self.conn.shape,4)).ravel()
  self.jj=np.broadcast_to(self.conn[...,None,:],(*self.conn.shape,4)).ravel()
  self.free=node[:,1:-1].ravel();self.bound=node[:,[0,-1]].ravel();self.val=np.tile([0,V],nx)
  self.g=[.5-.5/np.sqrt(3),.5+.5/np.sqrt(3)];self.basis=[]
  for a in self.g:
   for b in self.g:
    bx=np.array([-(1-b),1-b,-b,b])/self.dx
    bz=np.array([-(1-a),-a,1-a,a])[None,:]/self.dz[:,None]
    self.basis.append((a,b,bx,bz))
  self.evg=value_and_grad(self.negative_at_fixed_potential)

 def all_eps(self,v,a,b):
  ex,ec,ez=self.eps(v,a,b);iso=np.full((self.nx,self.np-1),9.)
  iso[:,self.ns]=7.5;iso[:,self.ns+self.nz]=7.5
  exall=iso.copy();ezall=iso.copy();ecall=np.zeros_like(iso)
  exall[:,self.lc]=ex;ezall[:,self.lc]=ez;ecall[:,self.lc]=ec
  return exall,ecall,ezall

 def solve(self,v):
  ke=np.zeros((self.nx,self.np-1,4,4));tensors=[]
  for a,b,bx,bz in self.basis:
   ex,ec,ez=self.all_eps(v,a,b);tensors.append((ex,ec,ez))
   ke+=(ex[...,None,None]*bx[None,None,:,None]*bx[None,None,None,:]+ec[...,None,None]*(bx[None,None,:,None]*bz[None,:,None,:]+bz[None,:,:,None]*bx[None,None,None,:])+ez[...,None,None]*bz[None,:,:,None]*bz[None,:,None,:])*(self.dx*self.dz[None,:,None,None]/4)
  mat=coo_matrix((ke.ravel(),(self.ii,self.jj)),shape=(self.nx*self.np,)*2).tocsr()
  psi=np.zeros(self.nx*self.np);psi[self.bound]=self.val;rhs=-(mat[self.free][:,self.bound]@self.val)
  psi[self.free]=spsolve(mat[self.free][:,self.free],rhs);p=psi[self.conn];grads=[];integral=0.;energies=np.zeros(self.np-1)
  for (_,_,bx,bz),(ex,ec,ez)in zip(self.basis,tensors):
   gx=np.sum(p*bx,axis=-1);gz=np.sum(p*bz[None],axis=-1);grads.append((gx[:,self.lc],gz[:,self.lc]))
   density=(ex*gx*gx+2*ec*gx*gz+ez*gz*gz)*self.dx*self.dz[None,:]/4
   integral+=np.sum(density);energies+=np.sum(density,axis=0)
  residual=mat@psi;lc_nodes=psi.reshape(self.nx,self.np)[:,self.ns+1:self.ns+1+self.nz]
  ck={'Gauss_free_residual_inf':float(abs(residual[self.free]).max()),'charge_balance_abs':float(abs(residual[self.bound].sum())),
      'positive_electric_dimensionless':float(EPS0/self.K/(2*self.A)*integral),'terminal_energy_identity_error':float(abs(integral-psi@residual)),
      'LC_terminal_voltage_mean_minmax_V':[float(np.mean(lc_nodes[:,-1]-lc_nodes[:,0])),float(np.min(lc_nodes[:,-1]-lc_nodes[:,0])),float(np.max(lc_nodes[:,-1]-lc_nodes[:,0]))],
      'LC_Ex_rms_V_um':float(np.sqrt(sum(np.mean(q[0]**2)for q in grads)/4)/self.d),
      'LC_Ez_rms_V_um':float(np.sqrt(sum(np.mean(q[1]**2)for q in grads)/4)/self.d),
      'energy_by_z_element_dimensionless':(EPS0/self.K/(2*self.A)*energies).tolist()}
  return grads,psi.reshape(self.nx,self.np),ck


def vertical(d,V,T,external,nz=65):
 K=np.array([11.1,6.5,17.1])*1e-12*scale(T);h=1/(nz-1);series=2*.02/(7.5*d)+(2*8/(9*d)if external else 0.)
 def f(t):
  mid=(t[:-1]+t[1:])/2;kp=K[0]*anp.cos(mid)**2+K[2]*anp.sin(mid)**2
  en=anp.sum(.5*kp*((t[1:]-t[:-1])/h)**2)*h/(d*1e-6)+.5*2e-4*(anp.sin(t[0])**2+anp.sin(t[-1])**2)
  inverse=anp.mean(1/(5.2+13.8*anp.sin(mid)**2))+series
  return (en-.5*EPS0*V*V/(d*1e-6*inverse))/(K[0]/(d*1e-6))
 u=np.linspace(0,1,nz);sols=[]
 for amp in [0.05,1.4]:
  ss=minimize(value_and_grad(f),amp*np.sin(np.pi*u)+.01,jac=True,method='L-BFGS-B',bounds=[(-np.pi/2+1e-6,np.pi/2-1e-6)]*nz,options={'maxiter':1800,'ftol':1e-13,'gtol':1e-8,'maxcor':30});sols.append(ss)
 sol=min(sols,key=lambda q:q.fun);w=np.linspace(.4,.78,121);ne,no=indices(T,w)
 nn=ne[None,:]*no[None,:]/np.sqrt(ne[None,:]**2*np.sin(sol.x[:,None])**2+no[None,:]**2*np.cos(sol.x[:,None])**2)
 ret=d*np.trapezoid(nn-no[None,:],u,axis=0)
 return ret,sol.x,{'V':V,'T_C':T,'external':external,'energy_dimensionless':float(sol.fun),'gradient_inf':float(max(abs(sol.jac))),'success':bool(sol.success),'theta_max_deg':float(np.degrees(max(abs(sol.x))))}


def select(a):
 cache={};d=2.5;targets={};arr={};base={};rows=[]
 for T in [15,50]:
  r0,t0,ck=vertical(d,0,T,False);r1,t1,ck1=vertical(d,1.5,T,False);targets[T]=r0-r1;base[T]=r0
  arr[f'internal_T{T}_V0']=t0;arr[f'internal_T{T}_V1.5']=t1;rows.extend([ck,ck1])
 def objective(V):
  errors=[];cs=[]
  for T in [15,50]:
   r,t,ck=vertical(d,float(V),T,True);dr=base[T]-r;errors.append(dr-targets[T]);cs.append((r,t,ck))
  value=float(np.mean(np.array(errors)**2));cache[float(V)]=(cs,value)
  print(json.dumps({'fixed_V_trial':float(V),'two_temperature_retardance_MSE_um2':value}),flush=True);return value
 opt=minimize_scalar(objective,bounds=(5,24),method='bounded',options={'xatol':.003,'maxiter':24});V=float(round(opt.x,3));objective(V)
 chosen=cache[V][0];report=[]
 for T,(r,t,ck)in zip([15,50],chosen):
  arr[f'external_T{T}_V{V:g}']=t;dr=base[T]-r;report.append({'T_C':T,'internal_difference_550_um':float(np.interp(.55,np.linspace(.4,.78,121),targets[T])),'external_difference_550_um':float(np.interp(.55,np.linspace(.4,.78,121),dr)),'retardance_spectral_absmax_mismatch_um':float(max(abs(dr-targets[T]))),**ck})
 result={'fixed_external_V_RMS':V,'d_um':d,'internal_reference_V_RMS':1.5,'selection':'one fixed V minimizes equal-temperature, equal-visible-wavelength mean square difference in1D retardance changes; not separate V(T)','temperature_cases':report,'internal_checks':rows,'geometry':'ZnO / Al2O3 8um eps9 / SiNx20nm eps7.5 / LC2.5um / SiNx20nm eps7.5 / Al2O3 8um eps9 / ZnO','limitations':['Restricted1D theta(z), no lateral winding or azimuthal relaxation; actual2Dnext.','Wp2e-4, K(T)dn² and eps5.2/19 are assigned transfers.'],'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
 np.savez_compressed(a.out/'vertical_fields.npz',**arr);(a.out/'results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)


def validation(a):
 tests=[];nx,nz=16,9;V=12.;K=11.1;d=2.5
 for ns in [8,16,32,64]:
  ev=ExternalElectric(d,12,K,nx,nz,V,ns);v=initial(nx,nz,'linear_phi');gr,p,ck=ev.solve(v)
  exact=EPS0/(K*1e-12)*V*V/(2*(1/5.2+2*.02/(7.5*d)+16/(9*d)))
  tests.append({'kind':'uniform_series','support_cells':ns,'energy_relative_error':abs(ck['positive_electric_dimensionless']/exact-1),'potential_V':float(p.max()),**ck})
 v=initial(nx,nz,'perturbed');v[:nx*nz]+=.8*np.sin(np.linspace(0,np.pi,nz))[None,:].repeat(nx,axis=0).ravel()
 rng=np.random.default_rng(11052026);direction=rng.normal(size=len(v));direction/=np.linalg.norm(direction)
 fields={}
 for ns in [8,16,32,64]:
  ev=ExternalElectric(d,12,K,nx,nz,V,ns);gr,p,ck=ev.solve(v);en,gg=ev.evg(v,gr);h=1e-5
  fd=(-ev.solve(v+h*direction)[2]['positive_electric_dimensionless']+ev.solve(v-h*direction)[2]['positive_electric_dimensionless'])/(2*h)
  fields[ns]=(gr,p,ck);tests.append({'kind':'fresh_Gauss_envelope_gradient','support_cells':ns,'fd':float(fd),'autodiff':float(gg@direction),'absolute_error':float(abs(fd-gg@direction)),**ck})
 ref=fields[64];conv=[]
 for ns in [8,16,32]:
  gr,p,ck=fields[ns];conv.append({'support_cells':ns,'energy_relative_vs64':abs(ck['positive_electric_dimensionless']/ref[2]['positive_electric_dimensionless']-1),'LC_gradient_rms_relative_vs64':float(np.sqrt(sum(np.sum((x-y)**2)for qs,rs in zip(gr,ref[0])for x,y in zip(qs,rs))/sum(np.sum(y*y)for rs in ref[0]for y in rs)))})
 out={'checks':tests,'support_refinement':conv,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'uniform LC series analytic, variable director freshGauss envelope, support mesh refinement; not source director convergence'}
 (a.out/'results.json').write_text(json.dumps(out,indent=2));print(json.dumps({'support_refinement':conv,'max_uniform_error':max(q['energy_relative_error']for q in tests if q['kind']=='uniform_series'),'max_gradient_error':max(q['absolute_error']for q in tests if q['kind'].startswith('fresh'))}),flush=True)


def director(a):
 from scipy.interpolate import RegularGridInterpolator
 if a.V is None:a.V=json.loads((a.selection/'results.json').read_text())['fixed_external_V_RMS']
 nx,nz=a.nx,a.nz;arr={};rows=[];tic=time.perf_counter();warm=np.load(a.warm/'fields.npz')if a.warm else None
 for T in [15,50]:
  for V in [0,a.V]:
   key=f'electric_T{T}_V{V:g}';X,Z=np.meshgrid(np.arange(nx)/nx,np.linspace(0,1,nz),indexing='ij');pts=np.stack([X,Z],-1)
   if warm is not None:
    pre=f'electric_T{T}_V{a.warm_on if V else 0:g}'
    def it(q):return RegularGridInterpolator((np.linspace(0,1,len(q)+1),np.linspace(0,1,q.shape[1])),np.r_[q,q[:1]])(pts)
    v=np.r_[it(warm[pre+'__theta_rad']).ravel(),it(warm[pre+'__phi_correction_rad']).ravel()]
   else:
    v=initial(nx,nz,'perturbed');v[:nx*nz]+=(1.2 if V else .04)*np.sin(np.pi*Z).ravel()
   K=np.array([11.1,6.5,17.1])*scale(T);f,_,meta=problem(2.5,12,K.tolist(),nx,nz,Wp=2e-4,Wa=1.14e-4,pattern='8step');fvg=value_and_grad(f);ev=ExternalElectric(2.5,12,K[0],nx,nz,V,a.support_cells)
   def fg(q):
    fr,gg=fvg(q)
    if V:
     gr,psi,ck=ev.solve(q);_,ge=ev.evg(q,gr);return float(fr-ck['positive_electric_dimensionless']),gg+ge
    return float(fr),gg
   counter=[0]
   def cb(q):
    counter[0]+=1
    if counter[0]%100==0:print(json.dumps({'key':key,'iter':counter[0],'elapsed_s':time.perf_counter()-tic}),flush=True)
   sol=minimize(fg,v,jac=True,method='L-BFGS-B',bounds=[(-np.pi/2+1e-5,np.pi/2-1e-5)]*(nx*nz)+[(None,None)]*(nx*nz),callback=cb,options={'maxiter':a.maxiter,'maxcor':40,'maxls':40,'ftol':1e-13,'gtol':2e-8})
   th=sol.x[:nx*nz].reshape(nx,nz);u=sol.x[nx*nz:].reshape(nx,nz);gr,psi,ck=ev.solve(sol.x)
   for suf,q in [('theta_rad',th),('phi_correction_rad',u),('potential_V',psi),('LC_potential_V',psi[:,ev.ns+1:ev.ns+1+nz])]:arr[key+'__'+suf]=q
   arr['electric_z_over_LC_d']=ev.z
   refined=[]
   for ns in [32,64]:
    ee=ExternalElectric(2.5,12,K[0],nx,nz,V,ns);gg,pp,cc=ee.solve(sol.x);refined.append({'support_cells':ns,'energy_relative_to_source':abs(cc['positive_electric_dimensionless']/ck['positive_electric_dimensionless']-1)if V else 0.,'LC_voltage_mean_V':cc['LC_terminal_voltage_mean_minmax_V'][0],'Gauss_free_residual_inf':cc['Gauss_free_residual_inf']})
   row={'key':key,'T_C':T,'V_external_RMS':V,**meta,'support_cells_per_side':a.support_cells,'success':bool(sol.success),'message':str(sol.message),'nit':int(sol.nit),'gradient_inf':float(max(abs(sol.jac))),'energy_J_m2':float(sol.fun*meta['energy_unit_J_m2']),'theta_max_deg':float(np.degrees(max(abs(th.ravel())))),'Gauss':ck,'fixed_director_support_refinement':refined,'elapsed_s':time.perf_counter()-tic};rows.append(row)
   np.savez_compressed(a.out/'fields.npz',**arr);(a.out/'results.json').write_text(json.dumps({'fixed_external_V_RMS':a.V,'rows':rows,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':__doc__,'conditions':['SamefixedexternalV15/50C','Supports8umeps9 separatelymeshed, SiNx20nmeps7.5','Smooth2periodwinding sector, no defect/global/dynamic stability','LCeps5.2/19 and K(T)dn², Wa/Wp1.14e-4/2e-4 transfers','RMS1kHz equilibrium,no ions/conduction/leadfringe or mechanics'],'complete_device_pass':False},indent=2));print(json.dumps(row),flush=True)


def main():
 p=argparse.ArgumentParser();p.add_argument('action',choices=['select','validation','director']);p.add_argument('--out',type=Path,required=True);p.add_argument('--selection',type=Path);p.add_argument('--V',type=float);p.add_argument('--warm',type=Path);p.add_argument('--warm-on',type=float,default=1.5);p.add_argument('--nx',type=int,default=32);p.add_argument('--nz',type=int,default=17);p.add_argument('--support-cells',type=int,default=16);p.add_argument('--maxiter',type=int,default=3000);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False);globals()[a.action](a);(a.out/'source.py').write_bytes(Path(__file__).read_bytes())

if __name__=='__main__':main()
