"""Fixed same-source alumina quarter-wave coatings: matched19-layer control.

The two extra films lie OUTSIDE the two ZnO electrodes, hence do not change
the solved through-support capacitor boundary. Contact/land openings and the
pre-fill deposition sequence are separate assembly conditions.
"""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import sys,json,hashlib,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments import q2_finish_decouple_20261105_external as ext
from experiments.q2_closure_coupling import model
base=ext.base;source=ext.source;n550=float(model.old.index('Al2O3_Franta',np.array([.55]))[0].real);thickness=.55/(4*n550)
old="if kind=='driven':layers=electrode+[(iso(support),8.)]+body+[(iso(support),8.)]+electrode"
new=f"if kind=='driven':layers=[(iso(support),{thickness:.17g})]+electrode+[(iso(support),8.)]+body+[(iso(support),8.)]+electrode+[(iso(support),{thickness:.17g})]"
assert old in source
source=source.replace(old,new).replace("'main_layer_count':17","'main_layer_count':19")
exec(source,base.__dict__)

if __name__=='__main__':
 if len(sys.argv)<2 or sys.argv[1]!='optics' or '--fields'not in sys.argv or '--bias'not in sys.argv:raise SystemExit('Only optics with explicit external-source --fields and fixed --bias is supported.')
 out=Path(sys.argv[sys.argv.index('--out')+1]);files=[Path(__file__),Path(ext.__file__),Path(ext.adapter.__file__),Path(base.__file__)];frozen={p.name:p.read_bytes()for p in files}
 config={'time_unix':time.time(),'argv':sys.argv,'source_sha256':{n:hashlib.sha256(x).hexdigest()for n,x in frozen.items()},'main_path_layers':19,'AR_material':'Al2O3_Franta, samecomplexspectrum','AR_design_wavelength_um':.55,'AR_n_design':n550,'AR_each_um':thickness,'AR_location':'eachZnOexteriorsurfaceofisolateddrivermodule, twofilms; contact/landopeningsnotonbeam','scope':'Fixedquarterwavelength1parameterpredesign; nofreek/nfit or thicknessscan','conditions':['opticalregioncoatingonly, leaveexternalZnOcontactexposed','depositbeforeLCfillingwithoutchangingfinishedinneralignment; assemblysequencependingreview','ARoutsideelectrodes, doesnotreplaceexplicitexternalGaussdirector','same17layercontrol geometry, source, V and losses retained']}
 base.main()
 for name,payload in frozen.items():(out/('dependency_'+name)).write_bytes(payload)
 (out/'source.py').write_bytes(frozen[Path(__file__).name]);(out/'launch.json').write_text(json.dumps(config,indent=2))
 r=json.loads((out/'results.json').read_text());r['physical_override']=config;r['scope']='Matched19layerfixedAl2O3quarterwaveARexternal-electrodeSiNxthree-cellfour-stateoptics';(out/'results.json').write_text(json.dumps(r,indent=2))
