"""Frozen SiNx alternative: native-vector spectrum, explicit dielectric Gauss.

The SiNx spectrum is from IBS film23028, not the PECVD alignment film. Wa/Wp
remain sensitivity inputs, never measurements for this optical film. The
baseline carbon/source and all previous runs are preserved unchanged.
"""
import os
for _k in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']:
    os.environ[_k]='1'
from pathlib import Path
import sys,argparse,json,hashlib,inspect,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
DATA=ROOT/'data/q2_finish_material_20261105'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def extract(a):
    import fitz
    p=DATA/'SiNx_Amato2025.pdf';doc=fitz.open(p);ds=doc[14].get_drawings();arr=[]
    x0,x1=170.53616333007812,403.20782470703125
    for idx,col in [(23,'n'),(27,'k')]:
        pts=np.array([[q.x,q.y] for it in ds[idx]['items'] if it[0]=='l' for q in it[1:]])
        pts=pts[np.argsort(pts[:,0])];xx=np.unique(pts[:,0]);yy=np.array([np.median(pts[pts[:,0]==z,1]) for z in xx]);w=(190+(xx-x0)/(x1-x0)*2310)/1000
        v=2+(466.645263671875-yy)/(2*(535.6799926757812-466.645263671875)) if col=='n' else (563.2938842773438-yy)*.1/(563.2938842773438-531.0787963867188)
        np.savetxt(a.out/f'{col}_vector.csv',np.c_[w,v],delimiter=',',header=f'wavelength_um,{col}',comments='');arr.append((w,v))
    w=np.unique(np.r_[arr[0][0],arr[1][0],.38,.4,.5,.55,.56,.78,2.5]);w=w[(w>=.38)&(w<=2.5)];z=np.c_[w,np.interp(w,*arr[0]),np.interp(w,*arr[1])]
    np.savetxt(a.out/'SiNx23028_vector.csv',z,delimiter=',',header='wavelength_um,n,k',comments='')
    # This adapter basename is required by the unmodified A optical kernel.
    np.savetxt(a.out/'DLC_4keV_vector_digitized.csv',z,delimiter=',',header='wavelength_um,n,k',comments='')
    r={'actual_material':'IBS SiNx sample23028','source':'arXiv2409.07147v1 Figure4 native vector paths23/27','source_sha256':sha(p),'support_um':z[[0,-1],0].tolist(),'n_range':[float(z[:,1].min()),float(z[:,1].max())],'k_range':[float(z[:,2].min()),float(z[:,2].max())],'A_interpolant_pass':bool(np.all((z[:,1]>=1.5)&(z[:,1]<=3))),'method':'x=190..2500nm; native y-axis ticks n1.5/2 andk0/.1; piecewise linear','limits':['k beyond560nm is belowinstrument sensitivity accordingtoauthor; plottedpositivefit is a model,not measuredtinyk.','No matchedPECVDalignment/IBSopticalfilm;Wa/Wp and lowfrequency epsilon must remain explicit assumptions.','The file namedDLC is an APIadapter only;actual material remainsSiNx.']}
    (a.out/'results.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))

def director(a):
    from experiments.q2_manufacturing_lc_director2d import problem
    from experiments.q2_gap_director import Electric
    from scipy.optimize import minimize
    from autograd import value_and_grad
    old=np.load(a.warm/'fields.npz');arr={k:old[k].copy() for k in old.files};nx,nz=arr['electric_T15_V4__theta_rad'].shape
    # Explicit two dielectric films replace the literal old SD15nm geometry.
    src=inspect.getsource(Electric).replace('class Electric:','class SiNxElectric:').replace('-.015/d','-FILM/d').replace('1+.015/d','1+FILM/d')
    ns=dict(Electric.__init__.__globals__);ns['FILM']=a.film;exec(src,ns);E=ns['SiNxElectric'];rows=[];tic=time.perf_counter()
    tab=np.loadtxt(ROOT/'data/q2_current/Li2005_E7_Cauchy.csv',delimiter=',',skiprows=1)
    def dn(T):
        r=tab[tab[:,0]==T][0,1:];w=.589;return r[0]-r[3]+(r[1]-r[4])/w**2+(r[2]-r[5])/w**4
    for T in [15,50]:
        pre=f'electric_T{T}_V4';v=np.r_[arr[pre+'__theta_rad'].ravel(),arr[pre+'__phi_correction_rad'].ravel()];K=np.array([11.1,6.5,17.1])*(dn(T)/dn(25))**2
        f,parts,meta=problem(1.45,12,K.tolist(),nx,nz,Wp=2e-4,Wa=1.14e-4,pattern='8step');vg=value_and_grad(f);ev=E(1.45,12,K[0],nx,nz,4,epsa=a.epsa)
        def fg(v):
            fr,g=vg(v);gr,p,c=ev.solve(v);_,eg=ev.evg(v,gr);return float(fr-c['positive_electric_dimensionless']),g+eg
        sol=minimize(fg,v,jac=True,method='L-BFGS-B',bounds=[(-np.pi/2+1e-5,np.pi/2-1e-5)]*(nx*nz)+[(None,None)]*(nx*nz),options={'maxiter':3500,'maxcor':40,'maxls':40,'ftol':1e-13,'gtol':2e-8})
        t=sol.x[:nx*nz].reshape(nx,nz);u=sol.x[nx*nz:].reshape(nx,nz);gr,p,c=ev.solve(sol.x)
        for suf,val in [('theta_rad',t),('phi_correction_rad',u),('potential_V',p)]:arr[pre+'__'+suf]=val
        def axis(t,u):
            ph=2*np.pi*np.arange(nx)[:,None]/nx+u;return np.stack([np.cos(t)*np.cos(ph),np.cos(t)*np.sin(ph),np.sin(t)],-1)
        n1=axis(t,u);n0=axis(v[:nx*nz].reshape(nx,nz),v[nx*nz:].reshape(nx,nz));diff=np.degrees(np.arccos(np.clip(abs(np.sum(n1*n0,-1)),0,1)))
        row={'T_C':T,'V_terminal_rms':4,'iterations':int(sol.nit),'optimizer_success':bool(sol.success),'message':str(sol.message),'gradient_inf':float(abs(sol.jac).max()),'axis_change_max_deg':float(diff.max()),'axis_change_rms_deg':float(np.sqrt(np.mean(diff*diff))),'LC_voltage_drop_V_minmax':[float((p[:,-2]-p[:,1]).min()),float((p[:,-2]-p[:,1]).max())],'gauss':c,'elapsed_s':time.perf_counter()-tic};rows.append(row);print(json.dumps(row),flush=True)
        np.savez_compressed(a.out/'fields.npz',**arr)
    # Independent uniform director series-capacitor test and envelope derivative.
    ev=E(1.45,12,11.1,16,9,4,epsa=a.epsa);vv=np.zeros(16*9*2);gr,p,c=ev.solve(vv);exact=8.8541878128e-12/11.1e-12*16/(2*(1/5.2+2*a.film/1.45/a.epsa))
    r={'actual_alignment_material':'SiNx','alignment_thickness_um':a.film,'alignment_epsilon_lowfrequency_scenario':a.epsa,'Wa_J_m2_scenario':1.14e-4,'Wp_J_m2_scenario':2e-4,'pretilt_deg_scenario':0,'mesh':[nx,nz],'rows':rows,'uniform_capacitor_energy_error':float(abs(exact-c['positive_electric_dimensionless'])),'warm_sha256':sha(a.warm/'fields.npz'),'zero_field_policy':'Originalthermal0V andelectric0V fields retained because sameassignedWa/Wp andnogeometric/elasticchange; dielectriccoatingchanges nozeroVtorque.','limits':['Wa/Wp are assignedcarbonbaselinecomparison,not measuredSiNxsurface values.','epsa7.5 is adielectricscenario,not opticaln squared andnot measured forsample23028.','Allfieldsremainfixedwindingsector; noglobaldefectcertificate.']}
    (a.out/'results.json').write_text(json.dumps(r,indent=2))

def optics(a):
    from experiments.q2_package_A_20261105 import optics as go
    opt=argparse.Namespace(out=a.out,fields=a.fields,dlc=a.spectrum,zno=True,support=8.,shared=True,dlc_thickness=a.film,zno_k_add=0.,dlc_k_add=0.,slices=32,order=4,electric_d=1.45,thermal_d=8.353152083061113,grid=a.grid,shard=0,shards=1)
    go(opt)
    p=a.out/'results.json';r=json.loads(p.read_text());r.update({'scope':'SiNx optical-substitution control; actualSiNx23028complexspectrum andexplicitSiNxdielectricGauss; assignedWa/Wp remainconditional.','actual_alignment_material':'SiNx','SiNx_um':a.film,'SiNx_spectrum':str(a.spectrum),'DLC_um':None,'DLC_source':None,'DLC_terminal_k_policy':None,'alignment_conditions':'Wa1.14e-4,Wp2e-4,pretilt0 transferredscenario; notSiNxmeasurement; lowfrequencyepsilon7.5scenario.'});p.write_text(json.dumps(r,indent=2))

def readout(a):
    from experiments.q2_package_A_20261105 import readout as go
    go(argparse.Namespace(out=a.out,runs=a.runs,hole=ROOT/'data/q2_current/hole_shadow11_gram.npz'))
    p=a.out/'results.json';r=json.loads(p.read_text());r['actual_alignment_material']='SiNx';r['limits']=[x.replace('DLCoptical/electrical/anchoring','SiNxoptical/dielectric/assignedanchoring') for x in r['limits']];p.write_text(json.dumps(r,indent=2))

def mask(a):
    rows=[]
    for t,g,alpha,delta,err in [(.1,.05,60,1,.05),(.2,.1,60,1,.05),(1.,.05,60,1,.05)]:
        rad=np.pi/180;shadow=t*np.tan(alpha*rad);blur=2*g/(np.cos(alpha*rad)**2)*delta*rad;core=1.5-shadow-blur-2*err
        rows.append({'mask_um':t,'standoff_um':g,'incidence_fromnormal_deg':alpha,'divergence_halfangle_deg':delta,'registration_eachside_um':err,'uncompensated_sidewall_shadow_um':float(shadow),'gap_divergence_width_um':float(blur),'guaranteed_central_full_dose_width_um_model':float(core),'core_greater1um':bool(core>1)})
    r={'scope':'Geometricstencilnecessaryconditions only; notfabricationtolerancecertificate orsourceanchoring proof','rows':rows,'limits':['SiNx/stencilorMo100nm mask compositionis temporary; mustbecompletelyremoved beforefinalretainedlayeraudit.','No experimentreported these1.5umeightdirections onsourceopticalfilm.','Do notcountanunintentionaldosetransitionas anintentional independentnanopattern; explicitlymodelitseffectonsurfaceanchor.','A1umthickmask is rejected bythis60deggeometriccontrol.']};(a.out/'results.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('action',choices=['extract','director','optics','readout','mask']);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--warm',type=Path,default=ROOT/'runs/20261105-q2-package-A-director64-d1p45-02');ap.add_argument('--fields',type=Path);ap.add_argument('--spectrum',type=Path,default=ROOT/'data/q2_finish_material_20261105/SiNx_spectrum');ap.add_argument('--film',type=float,default=.020);ap.add_argument('--epsa',type=float,default=7.5);ap.add_argument('--grid',type=Path);ap.add_argument('--runs',type=Path,nargs='+');a=ap.parse_args();a.out.mkdir(parents=True,exist_ok=False)
    (a.out/'launched_source.py').write_bytes(Path(__file__).read_bytes());(a.out/'launch.json').write_text(json.dumps({'argv':sys.argv,'source_sha256':sha(__file__),'shared_optics_sha256':sha(ROOT/'experiments/q2_package_A_20261105.py')},indent=2));globals()[a.action](a)
