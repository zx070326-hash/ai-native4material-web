"""Read-only cross-line audit of the external-electrode optical entrypoint.

No device spectrum or director re-solve. Actual transformed optics code is
parsed, and only its layer-building/texture prefix is executed. Small uniform
slabs independently test cascade order and coherent air propagation.
"""
import os
for key in ('OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'OMP_NUM_THREADS'):
    os.environ[key] = '1'
import argparse, ast, hashlib, inspect, json, sys
from pathlib import Path
import numpy as np
from scipy.linalg import expm
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    a = parser.parse_args()
    a.out.mkdir(parents=True, exist_ok=False)
    paths = [ROOT/'experiments'/p for p in (
        'q2_finish_decouple_20261105_external.py',
        'q2_finish_decouple_20261105_sinx.py',
        'q2_finish_decouple_20261105.py',
        'q2_closure_coupling.py', 'q2_package_A_20261105.py',
        'q2_package_device_20261105.py', 'q2_output_screen.py')]
    before = {str(p.relative_to(ROOT)): sha(p) for p in paths}
    from experiments import q2_finish_decouple_20261105_external as external
    from experiments import q2_closure_coupling as coupled
    source = external.source
    tree = ast.parse(source)
    optics = tree.body[0]
    cell = next(n for n in optics.body if isinstance(n, ast.FunctionDef) and n.name == 'cell')
    cut = next(i for i,n in enumerate(cell.body) if isinstance(n, ast.Assign)
               and any(isinstance(t,ast.Name) and t.id == 'S' for t in n.targets))
    cell.body = cell.body[:cut] + [ast.parse('return layers').body[0]]
    # Keep actual imports, input tables, texture and cell builders; discard the
    # expensive wavelength loop, then return actual layer arrays for audit.
    optics.body = optics.body[:optics.body.index(cell)+1] + ast.parse(
        "return {kind:cell(kind,0,0,.55) for kind in ['driven','compensator','thermal']}").body
    optics.name = 'audit_layers'
    ast.fix_missing_locations(tree)
    namespace = dict(external.base.__dict__)
    exec(compile(tree, '<read-only transformed optical layer prefix>', 'exec'), namespace)
    fields = ROOT/'runs/20261105-q2-finish-external-director32-support32-01'
    args = argparse.Namespace(fields=fields, d=2.5, slices=32, order=4)
    layers = namespace['audit_layers'](args)
    old = coupled.model.old
    al = complex(old.index('Al2O3_Franta',np.array([.55]))[0])
    sn = np.loadtxt(ROOT/'data/q2_finish_material_20261105/SiNx_spectrum/DLC_4keV_vector_digitized.csv',delimiter=',',skiprows=1)
    zn = np.loadtxt(ROOT/'data/q2_package_A_20261105/ZnO2022_Fig5d_passive_digitized.csv',delimiter=',',skiprows=1)
    snn = complex(np.interp(.55,sn[:,0],sn[:,1]),np.interp(.55,sn[:,0],sn[:,2]))
    znn = complex(np.interp(.55,zn[:,0],zn[:,1]),np.interp(.55,zn[:,0],zn[:,2]))
    def identify(ep):
        for name,n in [('Al2O3',al),('SiNx',snn),('ZnO',znn)]:
            ref = old.dielectric(n,n,np.zeros(128),np.zeros(128))
            if np.max(abs(ep-ref)) < 1e-12:
                return name
        return 'E7'
    actual = {}
    for kind,ll in layers.items():
        rr = []
        for ep,d in ll:
            name = identify(ep)
            if rr and rr[-1]['material'] == name:
                rr[-1]['thickness_um'] += float(d)
            else:
                rr.append({'material':name,'thickness_um':float(d)})
        actual[kind] = rr
    concatenated = actual['driven'] + [{'material':'ambient_air','thickness_um':2.}] + actual['compensator'] + actual['thermal']
    merged = []
    for r in concatenated:
        if merged and merged[-1]['material'] == r['material']:
            merged[-1]['thickness_um'] += r['thickness_um']
        else:
            merged.append(dict(r))
    supports = [r['thickness_um'] for r in merged if r['material']=='Al2O3']
    assert supports == [8.]*5
    assert len([r for r in merged if r['material']!='ambient_air']) == 16
    assert [r['material'] for r in actual['driven']] == ['ZnO','Al2O3','SiNx','E7','SiNx','Al2O3','ZnO']
    # Exact air phase and direct full-transfer composition use arbitrary simple
    # slabs, not a claim about the entire patterned device.
    lam = .55
    qx, qy = np.array([0.,.14,-.18]), np.array([0.,-.08,.06])
    gap = coupled.uniform_layer(1.,2.,lam,qx,qy)
    qz = np.sqrt(1-qx*qx-qy*qy)
    expected = np.diag(np.tile(np.exp(2j*np.pi/lam*2*qz),2))
    air = {'reflection_max':float(max(np.max(abs(gap[0])),np.max(abs(gap[1])))),
           'forward_phase_max_error':float(np.max(abs(gap[2]-expected))),
           'backward_phase_max_error':float(np.max(abs(gap[3]-expected)))}
    q = np.array([0.])
    aa = coupled.uniform_layer(1.8+.002j,.21,lam,q,q)
    gg = coupled.uniform_layer(1.,2.,lam,q,q)
    bb = coupled.uniform_layer(1.6+.001j,.32,lam,q,q)
    ag,r1 = coupled.cascade(aa,gg)
    got,r2 = coupled.cascade(ag,bb)
    transfers = []
    for n,d in [(1.8+.002j,.21),(1.,2.),(1.6+.001j,.32)]:
        ep = old.dielectric(n,n,np.zeros(1),np.zeros(1))
        gen = old.generator(ep,np.zeros((1,1)),np.zeros((1,1)),np.array([0]))
        transfers.append(expm(2j*np.pi/lam*d*gen))
    direct = old.to_scattering(transfers[2]@transfers[1]@transfers[0],old.admittance(q,q))
    full_error = float(max(np.max(abs(x-y)) for x,y in zip(got,direct)))
    no_return = bb[2]@gg[2]@aa[2]
    air['three_slab_full_transfer_error'] = full_error
    air['three_slab_cascade_residual'] = max(r1,r2)
    air['deliberately_omit_return_forward_error'] = float(np.max(abs(got[2]-no_return)))
    assert full_error < 1e-12
    assert air['deliberately_omit_return_forward_error'] > 1e-4
    # The exterior cache carries only arrays. Recompute four selected entries
    # with the original declared15um quadrature at10mm and deliberate20mm.
    from experiments.q2_package_device_20261105 import field, pts
    solid = np.load(ROOT/'data/q2_current/solid_gram.npz')
    wi = int(np.argmin(abs(solid['wavelength_um']-.55)))
    wavelength = float(solid['wavelength_um'][wi])
    modes = np.asarray(solid['modes'])
    selected_modes = [(0,0),(4,0),(0,4),(4,4)]
    ids = [int(np.flatnonzero(np.all(modes==q,axis=1))[0]) for q in selected_modes]
    cached = solid['Gram'][wi][np.ix_(ids,ids)]
    ox,dx = pts(-10000,10000,15.)
    oy,dy = pts(-7500,7500,15.)
    selected_h = np.array([0,4]); xi=np.array([0,1,0,1]); yi=np.array([0,0,1,1])
    exterior_check = {'wavelength_um':wavelength,'four_modes':selected_modes,'quadrature_um':15.}
    for distance in [10000.,20000.]:
        G = np.zeros((4,4),complex)
        for yy in oy:
            zz = distance + yy*np.tan(np.deg2rad(25))
            vx = field(wavelength,zz,ox,12.,selected_h)
            gx = vx@vx.conj().T*dx/(np.sqrt(np.pi/2)*75)
            vy = field(wavelength,zz,[yy],24.,selected_h)[:,0]
            gy = np.outer(vy,vy.conj())*dy/(np.sqrt(np.pi/2)*75)
            G += gx[xi[:,None],xi[None,:]]*gy[yi[:,None],yi[None,:]]
        exterior_check[str(int(distance))+'um_max_cache_error'] = float(np.max(abs(G-cached)))
    assert exterior_check['10000um_max_cache_error'] < 1e-11
    # Physical axis identity: compensator is a lateral shift, thermal is a
    # joint spatial/vector 90-degree rotation; evaluate nematic tensors.
    f = np.load(fields/'fields.npz')
    th = f['electric_T15_V0__theta_rad']
    u = f['electric_T15_V0__phi_correction_rad']
    def director(t,p):
        return np.stack([np.cos(t)*np.cos(p),np.cos(t)*np.sin(p),np.sin(t)],axis=-1)
    x = np.arange(th.shape[0])/th.shape[0]
    j = np.arange(len(x)); shift = len(x)//4
    source_at_shift = director(np.roll(th,-shift,axis=0),2*np.pi*((x+.25)%1)[:,None]+np.roll(u,-shift,axis=0))
    comp = director(np.roll(th,-shift,axis=0),2*np.pi*x[:,None]+np.pi/2+np.roll(u,-shift,axis=0))
    axis_error = float(np.max(abs(source_at_shift[...,None]*source_at_shift[...,None,:]-comp[...,None]*comp[...,None,:])))
    # Periods and feature sizes are physical nematic periods P; optical field
    # winding is 2P. Six micrometers is a half-P registration for P12.
    pilot = ROOT/'runs/20261105-q2-finish-decouple-external-optics-pilot-01/launch.json'
    launch = json.loads(pilot.read_text()) if pilot.exists() else None
    source_meta = json.loads((fields/'results.json').read_text())
    result = {
        'scope':'Read-only source/geometry audit plus small uniform-slab coherent controls; no new device spectrum, manufacturability, finite-edge Maxwell or full-problem certificate.',
        'actual_layer_stacks_at_550nm':actual,'merged_axial_sequence':merged,
        'support_thicknesses_um':supports,'support_total_um':sum(supports),
        'counting':{'main_solid_layers_before_external_screen':16,'main_plus_external_carbon_screen':17,'ambient_air_intervals':1,'if_ambient_air_were_counted_as_retained_layer':18,'old_internal_four_board_including_screen':16,'proposed_two_AR_films_including_screen':19},
        'dielectric_director_source':{'path':str(fields.relative_to(ROOT)/'fields.npz'),'sha256':sha(fields/'fields.npz'),'four_keys':[r['key'] for r in source_meta['rows']],'fixed_external_voltage_RMS':source_meta['fixed_external_V_RMS'],'support_elements_each_side':32,'SiNx_each_um':.020,'epsilon_Al2O3':9,'epsilon_SiNx':7.5,'electrodes':'at two outer faces of driven8um supports;20nmSiNx is inside the electrodes','thermal_source':'runs/20261105-q2-package-A-director64-d1p45-02/fields.npz; thermal0V/anchoring assigned scenario unchanged; dielectric epsilon irrelevant at0V'},
        'coherent_air_tests':air,
        'cached_exterior_distance_control':exterior_check,
        'texture_registration':{'compensator_tensor_shift_identity_max':axis_error,'compensator':'X=(x+.25)%1, phi=2pi*x+u(X)+pi/2 equals source phi(X); physical lateral6um registration, not an independent extra rotation after translation','thermal':'X=(y-.25)%1, phi=2pi*y+u(X) equals Rz(pi/2)*source_axis(X); Fourier blocks swapped to y','nematic_periods_um':[12,24],'optical_domains_um':[24,48],'eight_step_widths_um':[1.5,3.0],'pattern_square_um':[-105,105],'illumination_square_um':[-75,75],'finite_pattern_side_edges':'not explicitly scattered; periodic texture multiplied by exit envelope'},
        'reference_planes':{'optical_input':'air-side plane immediately before first outer ZnO','optical_output':'air-side plane immediately after final thermal8umAl2O3','screen_plane_um_relative_to_output':'z=10000+y*tan(25deg)','screen_center_distance_from_final_output_um':10000,'kernel':'runs/20261105-q2-package-device-kernels-01/inner700/gram.npz','kernel_sha256':sha(ROOT/'runs/20261105-q2-package-device-kernels-01/inner700/gram.npz'),'solid_kernel':'data/q2_current/solid_gram.npz','solid_kernel_sha256':sha(ROOT/'data/q2_current/solid_gram.npz'),'old20mm_generator':'q2_output_screen.tilted_gram is not called by this package readout','finite_beam_boundary':'periodic normal-incidence plane-wave optical solve followed by150um hard Gaussian exit-envelope projection; not a finite beam solved through all55.672752um of the stack','distance_interpretation':'new assembly places the screen10mm after its new final exit. No claim that a screen fixed relative to an old exit retains the same10mm separation.'},
        'actual_pilot_launch':launch,
        'AR_process_interface':{'main_count_if_added':19,'coating_positions':'air/AR/ZnO/driverAl8/.../driverAl8/ZnO/AR/air2/passive pair','footprint':'limited to illumination/pattern optical region; leave outer ZnO contacts andr180-200umstandoff ring bare','order':'outerZnO -> limited-area outerAR on carrier -> innerSiNx/developed alignment pattern -> dry peripheral assembly -> liquid fill/vented capillary branch','conditions':'Same opticalAl2O3 source; no claim that a150C source film is identical to a cooler deposition. Do not expose completed inner anchoring or E7 to an unaccounted AR deposition/plasma/heat step. AR outside ideal ZnO electrodes does not alter the already solved LC/support Gauss voltage boundary.'},
        'review_outcome':'No layer order/period/gap/cascade/reference-plane mismatch found in inspected source. Frozen127launch must be checked when its receipt is written; wrapper saves launch only after optics completes.',
        'limits':['16 support source pilot is not final32 support source; retain separate hashes and receipts.','No use of old internal1.5V optical result for external12.235V.','Constant plane layers do not include a150um aperture bow or stand-off wedge.','Source-temperature/anchoring/process transfers and strictA/B material conditions remain.','The17 count includes an external carbon screen absent from the periodic transfer stack; it is applied in finite-screen readout.']}
    after = {str(p.relative_to(ROOT)):sha(p) for p in paths}
    assert before == after
    result['audited_source_sha256'] = before
    result['read_only_source_hashes_unchanged'] = True
    (a.out/'results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    (a.out/'source.py').write_bytes(Path(__file__).read_bytes())
    print(json.dumps({'support_um':supports,'counts':result['counting'],'air':air,'axis_shift_error':axis_error,'source_unchanged':True}),flush=True)


if __name__ == '__main__':
    main()
