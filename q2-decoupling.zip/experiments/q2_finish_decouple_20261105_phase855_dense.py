"""Exact713 versus127-union837 source selection and independent reintegration."""
from pathlib import Path
import sys,argparse,json,hashlib
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
RUNS=[ROOT/f'runs/20261105-q2-finish-decouple-source25-phase855-optics64-127-{i}'for i in [0,1]]+[ROOT/f'runs/20261105-q2-finish-decouple-source25-phase855-optics64-missing713-{i}'for i in range(4)]

def stats(w,T):
 def mean(y,lo,hi):
  m=(w>=lo)&(w<=hi);return np.trapezoid(y[...,m],w[m],axis=-1)/(hi-lo)
 v=mean(T,.4,.78);n=mean(T,.78,2.5);vc=T[:,1]-T[:,0];nc=T[1]-T[0]
 return {'main_pp':[float(100*(.95*np.min(abs(v[1]-v[0]))-.05)),float(100*np.min(abs(n[:,1]-n[:,0])))],'VIS_thermal_signed_pp':(100*mean(vc,.4,.78)).tolist(),'VIS_thermal_meanabs_pp':(100*mean(abs(vc),.4,.78)).tolist(),'NIR_electric_signed_pp':(100*mean(nc,.78,2.5)).tolist(),'NIR_electric_meanabs_pp':(100*mean(abs(nc),.78,2.5)).tolist(),'VIS_thermal_peaks_pp':(100*np.max(abs(vc[:,w<=.78]),axis=-1)).tolist(),'NIR_electric_peaks_pp':(100*np.max(abs(nc[:,w>=.78]),axis=-1)).tolist()}

def select(a):
 zs=[np.load(p/'scattered_fields.npz')for p in RUNS];meta=[json.loads((p/'results.json').read_text())for p in RUNS];w=np.concatenate([z['wavelength_um']for z in zs]);order=np.argsort(w);w=w[order];assert len(w)==837 and len(np.unique(w))==837
 for key in ['d_electric_um','bias_V','main_layer_count','physical_supports','temperatures_C','thermal_LC_um']:
  assert all(m[key]==meta[0][key]for m in meta),(key,[m[key]for m in meta])
 assert meta[0]['temperatures_C']==[25,50]and meta[0]['thermal_LC_um']==8.55
 arrays={k:np.concatenate([z[k]for z in zs])[order]for k in zs[0].files if k not in ['wavelength_um','harmonics']};h=zs[0]['harmonics'];assert all(np.array_equal(z['harmonics'],h)for z in zs)
 diagnostics={d['wavelength_um']:d for m in meta for d in m['diagnostics']};assert len(diagnostics)==837
 standard=np.load(ROOT/'runs/20261105-q2-finish-decouple-source25-phase855-dense-launch-01/standard713.npz')['wavelength_um'];receipt={}
 for name,grid in [('standard713',standard),('union837',w)]:
  ids=np.searchsorted(w,grid);assert np.array_equal(w[ids],grid);out=a.out/name;out.mkdir(exist_ok=False);np.savez_compressed(out/'scattered_fields.npz',wavelength_um=w[ids],harmonics=h,**{k:v[ids]for k,v in arrays.items()})
  r=dict(meta[0]);r['diagnostics']=[diagnostics[float(x)]for x in grid];r['scope']=f'Exact{name}actualcomputedwavelengthselection; samephysicalphase855sourceandfields';r['spectral_selection']={'name':name,'count':len(grid),'source_runs':[str(p.relative_to(ROOT))for p in RUNS],'all_source_field_sha256':{str((p/'scattered_fields.npz').relative_to(ROOT)):hashlib.sha256((p/'scattered_fields.npz').read_bytes()).hexdigest()for p in RUNS},'eachwavelengthcomputed_once_noInterpolation':True};(out/'results.json').write_text(json.dumps(r,indent=2));receipt[name]=r['spectral_selection']
 (a.out/'results.json').write_text(json.dumps(receipt,indent=2));print(json.dumps({k:v['count']for k,v in receipt.items()}))

def summarize(a):
 rows=[];views={}
 for grid in ['713','837']:
  for hole in [600,700]:
   p=ROOT/f'runs/20261105-q2-finish-decouple-source25-phase855-readout64-{grid}-{hole}-01';z=np.load(p/'spectra.npz');w=z['wavelength_um'];T=z['total_T'];r=json.loads((p/'results.json').read_text());q=stats(w,T);assert max(abs(np.array(q['main_pp'])-[r['main']['VIS_conditional_lower_pp'],r['main']['NIR_model_pp']]))<1e-10
   half=np.unique(np.r_[np.arange(0,len(w),2),np.argmin(abs(w-.78)),len(w)-1]);qh=stats(w[half],T[:,:,half]);old=json.loads((ROOT/f'runs/20261105-q2-finish-decouple-source25-phase855-readout64-127-{hole}-01/results.json').read_text());row={'grid':grid,'actual_wavelengths':len(w),'hole_inner_um':hole,'independent':q,'half_actual_count':len(half),'half_samefields':qh,'half_minus_full_main_pp':(np.array(qh['main_pp'])-q['main_pp']).tolist(),'full_minus127_main_pp':(np.array(q['main_pp'])-[old['main']['VIS_conditional_lower_pp'],old['main']['NIR_model_pp']]).tolist(),'periodic_numerics':r['periodic_numerics'],'readout':str(p.relative_to(ROOT)),'spectra_sha256':hashlib.sha256((p/'spectra.npz').read_bytes()).hexdigest()};rows.append(row);views[grid,hole]=(w,T)
 # Grids are different quadratures over the SAME saved source, not713 arithmetic mislabeled837.
 delta={str(h):{k:(np.array(next(r for r in rows if r['grid']=='837'and r['hole_inner_um']==h)['independent'][k])-np.array(next(r for r in rows if r['grid']=='713'and r['hole_inner_um']==h)['independent'][k])).tolist()for k in ['main_pp','VIS_thermal_meanabs_pp','NIR_electric_meanabs_pp']}for h in [600,700]}
 (a.out/'results.json').write_text(json.dumps({'rows':rows,'union837_minus_standard713':delta,'conditions':['Same25/50Cfixed9.235V,19layers,dthermal8.55,correctedZnO335table,64sources,unchangedphysicalmask.','K(T),epsilonperp50,anchoring,optical/state/processmigrationremainconditions.','Gridagreementisnotmaterial/crosstalk/manufacturing/globalMaxwellcertificate.','Noadditionalvoltage/thicknessscanorusercrosstalkcutoff.']},indent=2))
 import matplotlib;matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 w,T=views['837',600];fig,axs=plt.subplots(2,2,figsize=(12,8),constrained_layout=True)
 for vi in range(2):
  for ti in range(2):
   for ax in axs[0]:ax.plot(w,100*T[vi,ti],lw=.8,label=f'{[0,9.235][vi]:g} V / {[25,50][ti]} C')
 axs[0,0].set(xlim=(.4,.78),title='VIS: same-device four states',ylabel='Port T (%)');axs[0,1].set(xlim=(.78,2.5),title='NIR: same-device four states',ylabel='Port T (%)')
 for vi in range(2):axs[1,0].plot(w,100*(T[vi,1]-T[vi,0]),lw=.8,label=f'{[0,9.235][vi]:g} V')
 for ti in range(2):axs[1,1].plot(w,100*(T[1,ti]-T[0,ti]),lw=.8,label=f'{[25,50][ti]} C')
 axs[1,0].set(xlim=(.4,.78),title='VIS thermal cross response',ylabel='Hot - cold (pp)');axs[1,1].set(xlim=(.78,2.5),title='NIR electrical cross response',ylabel='9.235 V - 0 V (pp)')
 for ax,vals,mask in [(axs[1,0],100*(T[:,1]-T[:,0]),w<=.78),(axs[1,1],100*(T[1]-T[0]),w>=.78)]:
  lo=float(vals[:,mask].min());hi=float(vals[:,mask].max());pad=.06*(hi-lo);ax.set_ylim(lo-pad,hi+pad)
 for ax in axs.ravel():ax.set_xlabel('Wavelength (um)');ax.grid(alpha=.2);ax.legend(fontsize=8)
 fig.suptitle('Conditional19-layer phase branch:25/50 C, thermal8.55um, correctedZnO,837 actual wavelengths',fontsize=11)
 for ext in ['png','svg']:fig.savefig(a.out/f'four_state_phase855_837.{ext}',dpi=150)
 plt.close(fig);print(json.dumps({'rows':rows,'delta837minus713':delta},indent=2))

def main():
 p=argparse.ArgumentParser();p.add_argument('action',choices=['select','summarize']);p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False);globals()[a.action](a);(a.out/'source.py').write_bytes(Path(__file__).read_bytes())
if __name__=='__main__':main()
