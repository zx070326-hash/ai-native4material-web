"""Frozen-source six-point Fourier/slice control for the internal16-layer cell.

No new material/source/voltage selection. High-order finite apertures are NOT
computed: cached81-mode Grams are used only after an explicit common-mode cut.
"""
import os
for k in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'):os.environ[k]='1'
import argparse,ast,hashlib,json,sys,time
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
READOUT=ROOT/'runs/20261105-q2-finish-decouple-SiNx-readout64-713-600-01'
REFERENCE=ROOT/'runs/20261105-q2-finish-decouple-SiNx-optics64-713-0'
FIELDS=ROOT/'runs/20261105-q2-finish-decouple-SiNx-director64-d2p5-01'


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,d):Path(p).write_text(json.dumps(d,indent=2),encoding='utf-8')


def select(a):
    s=np.load(READOUT/'spectra.npz');w=s['wavelength_um'];T=s['total_T'];peaks=[]
    for band,lo,hi,delta in [('VIS_thermal',.4,.78,abs(T[:,1]-T[:,0])),('NIR_electric',.78,2.5,abs(T[1]-T[0]))]:
        ix=np.flatnonzero((w>=lo)&(w<=hi));ind=np.unravel_index(np.argmax(delta[:,ix]),delta[:,ix].shape);j=ix[ind[1]]
        peaks.append({'kind':band,'wavelength_um':float(w[j]),'fixed_state_index':int(ind[0]),'absolute_cross_pp':float(100*delta[ind[0],j])})
    ww=np.unique([.4,.55,.78,2.5]+[r['wavelength_um']for r in peaks]);assert len(ww)<=6
    np.savez_compressed(a.out/'grid.npz',wavelength_um=ww)
    launch=json.loads((REFERENCE/'launch.json').read_text())
    assert launch['base_source_sha256']==sha(REFERENCE/'base_source.py')
    assert launch['entry_source_sha256']==sha(REFERENCE/'source.py')
    frozen={'frozen_base.py':REFERENCE/'base_source.py','frozen_sinx.py':REFERENCE/'source.py'}
    for name,p in frozen.items():(a.out/name).write_bytes(p.read_bytes())
    manifest={'selection':'Fourfixedwavelengthsplusactual600mask713spectrumVIS/NIRcrosstalkabsolutepeaks; at most6points','wavelength_um':ww.tolist(),'peaks':peaks,'readout':str(READOUT.relative_to(ROOT)),'readout_SHA256':sha(READOUT/'spectra.npz'),'reference_launch':launch,'fields':str(FIELDS.relative_to(ROOT)),'fields_SHA256':sha(FIELDS/'fields.npz'),'thermal_fields':'runs/20261105-q2-package-A-director64-d1p45-02/fields.npz','frozen_SHA256':{name:sha(p)for name,p in frozen.items()},'hole_kernel':json.loads((READOUT/'results.json').read_text())['hole'],'scope':'Sixwavelengthpointcontrol,newthreecellinternalSiNx16layerd2.5/bias1.5/64source,notoldAcontrolreuse'}
    save(a.out/'results.json',manifest);print(json.dumps({'wavelength_um':ww.tolist(),'peaks':peaks}),flush=True)


def solve(a):
    m=json.loads((a.selection/'results.json').read_text())
    for name,h in m['frozen_SHA256'].items():assert sha(a.selection/name)==h
    assert sha(ROOT/m['fields']/'fields.npz')==m['fields_SHA256']
    # Import only the ordinary namespace. Execute the optics function extracted
    # from the completed713run's frozen source, not a mutable current wrapper.
    from experiments import q2_finish_decouple_20261105 as base
    frozen=(a.selection/'frozen_base.py').read_text();tree=ast.parse(frozen)
    func=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='optics')
    source=ast.get_source_segment(frozen,func)
    old="ROOT/'runs/20261105-q2-package-A-DLC-spectrum-01/DLC_4keV_vector_digitized.csv'"
    new="ROOT/'data/q2_finish_material_20261105/SiNx_spectrum/DLC_4keV_vector_digitized.csv'"
    assert old in source and source.count('(iso(dn),.01)')==2
    source=source.replace(old,new).replace('(iso(dn),.01)','(iso(dn),.02)')
    original="[('E',forward),('G',Y@forward)]"
    assert source.count(original)==1
    source=source.replace(original,"[('E',forward),('G',Y@forward),('RE',back),('RG',Y@back)]")
    ns=dict(base.__dict__);exec(source,ns)
    args=argparse.Namespace(out=a.out,fields=ROOT/m['fields'],grid=a.selection/'grid.npz',d=2.5,bias=1.5,slices=a.slices,order=a.order,shard=0,shards=1,dense=False)
    for name in ['frozen_base.py','frozen_sinx.py']:(a.out/name).write_bytes((a.selection/name).read_bytes())
    (a.out/'executed_optics.py').write_text(source,encoding='utf-8')
    save(a.out/'launch.json',{'argv':sys.argv,'order':a.order,'slices':a.slices,'source_selection':str(a.selection.relative_to(ROOT)),'source_manifest':m,'executed_optics_SHA256':sha(a.out/'executed_optics.py'),'differences_from_frozen_function':'SiNxadapterliteralreplacementandadditionalbackfieldsaveonly','timestamp_unix':time.time()})
    ns['optics'](args)


def compare(a):
    from experiments.q2_output_screen import tilted_project
    from experiments.q2_gap_vector_review import load_runs
    lo=np.load(a.low/'scattered_fields.npz');hi=np.load(a.high/'scattered_fields.npz')
    lr=json.loads((a.low/'results.json').read_text());hr=json.loads((a.high/'results.json').read_text())
    assert lr['order']==4 and lr['slices']==32 and hr['order']==6 and hr['slices']==64
    assert np.array_equal(lo['wavelength_um'],hi['wavelength_um'])
    select=json.loads((a.selection/'results.json').read_text());gh=dict(np.load(ROOT/select['hole_kernel']))
    original_runs=[ROOT/f'runs/20261105-q2-finish-decouple-SiNx-optics64-713-{j}'for j in range(3)]
    original=load_runs(original_runs);identity=[]
    for j,lam in enumerate(lo['wavelength_um']):
        k=int(np.argmin(abs(original['wavelength_um']-lam)))
        if abs(original['wavelength_um'][k]-lam)>1e-12:continue
        err=max(float(abs(lo[f'V{v}T{t}__{q}'][j]-original[f'V{v}T{t}__{q}'][k]).max())for v in range(2)for t in range(2)for q in ['E','G'])
        identity.append({'wavelength_um':float(lam),'low_recomputed_vs_original713_EG_absolute_max':err})
    assert max(r['low_recomputed_vs_original713_EG_absolute_max']for r in identity)<1e-12
    common={k:(v if k=='wavelength_um'else np.arange(-4,5)if k=='harmonics'else v[:,2:-2,2:-2]) for k,v in hi.items()}
    lp=tilted_project(dict(lo),gh,25,periods=(12.,24.));hp=tilted_project(common,gh,25,periods=(12.,24.))
    m=hi['harmonics'];xx,yy=np.meshgrid(m,m,indexing='xy');tail=(abs(xx)>4)|(abs(yy)>4)
    rows=[]
    for j,lam in enumerate(lo['wavelength_um']):
        states=[]
        for v in range(2):
            for t in range(2):
                p=f'V{v}T{t}__';ld=next(r for r in lr['diagnostics'][j]['states']if r['vi']==v and r['Tindex']==t);hd=next(r for r in hr['diagnostics'][j]['states']if r['vi']==v and r['Tindex']==t)
                fields={}
                for suffix in ['E','G','RE','RG']:
                    l=lo[p+suffix][j];h=hi[p+suffix][j];co=h[2:-2,2:-2];d=co-l
                    fields[suffix]={'common81_absolute_max':float(abs(d).max()),'common81_relative_Frobenius':float(np.linalg.norm(d)/max(np.linalg.norm(l),1e-300)),'tail88_Frobenius':float(np.linalg.norm(h[tail])),'tail88_relative_full_Frobenius':float(np.linalg.norm(h[tail])/max(np.linalg.norm(h),1e-300))}
                E,G,RE,RG=[hi[p+suffix][j]for suffix in ['E','G','RE','RG']]
                tf=.5*np.real(np.sum(E.conj()*G,axis=(-1,-2)));rf=.5*np.real(np.sum(RE.conj()*RG,axis=(-1,-2)))
                states.append({'V_index':v,'T_index':t,'RTA_low':{k:ld[k]for k in ['R','T','A']},'RTA_high':{k:hd[k]for k in ['R','T','A']},'RTA_change_pp':{k:100*(hd[k]-ld[k])for k in ['R','T','A']},'high_forward_modal_power_sum_minus_T':float(tf.sum()-hd['T']),'high_reflected_modal_power_sum_minus_R':float(rf.sum()-hd['R']),'new_tail88_forward_power_fraction_of_incident':float(tf[tail].sum()),'new_tail88_reflected_power_fraction_of_incident':float(rf[tail].sum()),'new_tail88_forward_fraction_of_transmitted':float(tf[tail].sum()/max(hd['T'],1e-300)),'field_differences':fields,'common81_hole_projection_low_high':[float(lp[v,t,j]),float(hp[v,t,j])],'common81_hole_projection_change_pp':float(100*(hp[v,t,j]-lp[v,t,j])),'high_cascade_residual':hd['cascade_residual'],'high_cell_transfer_condition_max':hd['maxcondition']})
        rows.append({'wavelength_um':float(lam),'states':states,'common81_hole_thermal_cross_low_pp':(100*(lp[:,1,j]-lp[:,0,j])).tolist(),'common81_hole_thermal_cross_high_pp':(100*(hp[:,1,j]-hp[:,0,j])).tolist(),'common81_hole_electric_cross_low_pp':(100*(lp[1,:,j]-lp[0,:,j])).tolist(),'common81_hole_electric_cross_high_pp':(100*(hp[1,:,j]-hp[0,:,j])).tolist()})
    ss=[s for r in rows for s in r['states']]
    summary={'RTA_max_absolute_change_pp':{k:max(abs(s['RTA_change_pp'][k])for s in ss)for k in ['R','T','A']},'common81_E_absolute_max':max(s['field_differences']['E']['common81_absolute_max']for s in ss),'common81_G_absolute_max':max(s['field_differences']['G']['common81_absolute_max']for s in ss),'new_tail88_forward_power_max':max(s['new_tail88_forward_power_fraction_of_incident']for s in ss),'new_tail88_reflected_power_max':max(s['new_tail88_reflected_power_fraction_of_incident']for s in ss),'common81_hole_projection_max_change_pp':max(abs(s['common81_hole_projection_change_pp'])for s in ss),'RTA_all_passive_at_sampled_points':all(min(s['RTA_high'].values())>=-1e-10 for s in ss),'modal_power_identity_max_abs':max(max(abs(s['high_forward_modal_power_sum_minus_T']),abs(s['high_reflected_modal_power_sum_minus_R']))for s in ss),'high_cascade_residual_max':max(s['high_cascade_residual']for s in ss)}
    result={'selection':select,'low_run':str(a.low.relative_to(ROOT)),'high_run':str(a.high.relative_to(ROOT)),'source_SHA256':{str((p/f).relative_to(ROOT)):sha(p/f)for p in [a.low,a.high]for f in ['scattered_fields.npz','results.json','executed_optics.py']},'low_recomputation_identity_to_original713':identity,'summary':summary,'wavelengths':rows,'projection_scope':'Onlythecommon81modesuseexistinginner600Gram;omitted88modecoherentfieldandcrossinterferencearenotprojected.No169modefinite-apertureclaim,nofullhighordercarbon/exteriorscreenreadout.','normalization':'PeriodicsolverT/Rfullincidentplanewave;finiteholecommon81usesoriginalfullGaussianpowerdenominator,notrenormalizedhardtruncation.','limits':['JointFourier/slicerefine±4/32to±6/64doesnotseparatethetwodiscretizationerrors.','Same128xFouriermaterialsamplingremains;Gauss/Frank64sourceunchanged.','Sixwavelengthcontrolisnotfullbanduniformerrorboundorcertificate.','Common81projectioncannotboundthefull169modeaperturecrossinterference.','Sourcefilm/anchoring/temperature/processA/Bconditionsunchanged.']}
    np.savez_compressed(a.out/'common81_hole_projection.npz',wavelength_um=lo['wavelength_um'],low=lp,high_common81=hp)
    save(a.out/'results.json',result);print(json.dumps(summary,indent=2),flush=True)


def main():
    p=argparse.ArgumentParser();p.add_argument('action',choices=['select','solve','compare']);p.add_argument('--out',type=Path,required=True);p.add_argument('--selection',type=Path);p.add_argument('--order',type=int);p.add_argument('--slices',type=int);p.add_argument('--low',type=Path);p.add_argument('--high',type=Path);a=p.parse_args()
    for k in ['out','selection','low','high']:
        if getattr(a,k,None)is not None:setattr(a,k,getattr(a,k).resolve())
    a.out.mkdir(parents=True,exist_ok=False);(a.out/'source.py').write_bytes(Path(__file__).read_bytes());globals()[a.action](a)


if __name__=='__main__':main()
