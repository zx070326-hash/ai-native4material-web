"""Material-interface controls; shared candidate kernels are read-only imports.

`optics` and `readout` pass their arguments to q2_package_A_20261105.
`drude` reconstructs three printed-parameter conventions and fits the graph.
No fitted graph is called author-corrected or matched-film electrical data.
"""
import os
for _k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[_k]='1'
from pathlib import Path
import sys,json,argparse,hashlib
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

def drude(out):
    from scipy.integrate import quad
    from scipy.optimize import least_squares
    p=ROOT/'data/q2_package_A_20261105/ZnO2022_Fig5d_passive_digitized.csv'
    z=np.loadtxt(p,delimiter=',',skiprows=1)
    w=np.linspace(.5,2.4,160);E=1.239841984332/w
    target=np.interp(w,z[:,0],z[:,1])+1j*np.interp(w,z[:,0],z[:,2])
    def e2(x):
        return 42*3.44*.172*(x-2.95)**2/(((x*x-3.44**2)**2+.172**2*x*x)*x) if x>2.95 else 0.
    tl=np.array([3.6+2/np.pi*quad(lambda x:x*e2(x)/(x*x-e*e),2.95,np.inf,epsabs=1e-10)[0] for e in E])
    def nk(B,G,shift=0):return np.sqrt(tl+shift-B/(E*E+1j*G*E))
    eps0=8.8541878128e-12;hb=6.582119569e-16
    cases=[]
    for name,B,G,shift in [('printed_eq5_AD',5.87,.0541,0),('AD_times_Gamma_hypothesis',5.87*.0541,.0541,0),('AD_squared_hypothesis',5.87**2,.0541,0)]:
        v=nk(B,G,shift)
        cases.append({'case':name,'B_eV2':B,'Gamma_eV':G,'epsilon_inf_shift':shift,'rms_n':float(np.sqrt(np.mean((v.real-target.real)**2))),'rms_k':float(np.sqrt(np.mean((v.imag-target.imag)**2))),'nk_at2400':[float(v[-1].real),float(v[-1].imag)],'sigma_DC_S_m':eps0*B/(hb*G),'rho_ohm_cm':100*hb*G/(eps0*B)})
    def resid(x):
        v=nk(*x);return np.r_[(v.real-target.real)/.01185,(v.imag-target.imag)/.00735]
    fit=least_squares(resid,[.32,.0541,0],bounds=([.001,.001,-.5],[2,1,.5]),xtol=1e-13,ftol=1e-13,gtol=1e-13)
    B,G,shift=fit.x;v=nk(*fit.x)
    cases.append({'case':'graph_fit_B_Gamma_and_epsilon_inf','B_eV2':B,'Gamma_eV':G,'epsilon_inf_shift':shift,'rms_n':float(np.sqrt(np.mean((v.real-target.real)**2))),'rms_k':float(np.sqrt(np.mean((v.imag-target.imag)**2))),'nk_at2400':[float(v[-1].real),float(v[-1].imag)],'sigma_DC_S_m':eps0*B/(hb*G),'rho_ohm_cm':100*hb*G/(eps0*B),'warning':'Graph inverse fit, not author-confirmed erratum or independent DC measurement; fixed TL parameter subset. Pixel scales are sensitivities, not statistical error bars.'})
    np.savetxt(out/'ZnO_graphfit_nk.csv',np.c_[w,v.real,v.imag,target.real,target.imag],delimiter=',',header='wavelength_um,n_fit,k_fit,n_graph,k_graph',comments='')
    result={'source':'Bohorquez2022 doi10.1021/acsaelm.1c01026 Figure5d and Table2','model':'epsilon_TL - B/(E^2+i Gamma E); SI sigma0=epsilon0 B/(hbar_eVs Gamma)','cases':cases,'fit_scope_um':[.5,2.4],'source_rho_ohm_cm':.0017,'same_source_graph_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'full_problem_solved':False}
    (out/'results.json').write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps(result,indent=2))

if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='drude':
        ap=argparse.ArgumentParser();ap.add_argument('action');ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();a.out.mkdir(parents=True,exist_ok=False);drude(a.out)
    else:
        from experiments.q2_package_A_20261105 import main
        main()
