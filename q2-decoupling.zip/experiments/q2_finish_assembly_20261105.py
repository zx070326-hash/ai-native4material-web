"""Conditional assembly mechanics, no optical/manufacturing certificate.

Two gas reservoirs and liquid cells share three clamped circular plates.
Lengths SI internally. Pressure positive expands each cavity. Gas law is
solved jointly with plate-volume compliance and liquid thermal expansion.
The modeled meniscus lies in a stiff narrow reservoir channel, not the aperture.
"""
import os
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[key]='1'
import argparse, json, hashlib
from pathlib import Path
import numpy as np
from scipy.optimize import root
from scipy.special import iv
from numpy.polynomial import Polynomial as P


def plate(E=170e9,nu=.22,t=8e-6,a=120e-6,sigma=0,n=6):
    # Rayleigh-Ritz, clamped radial basis (1-x²)² x^(2i), x=r/a.
    x,q=np.polynomial.legendre.leggauss(96); x=(x+1)/2;q=q/2
    base=P([1,0,-2,0,1]); pol=[base*P([0]*(2*i)+[1]) for i in range(n)]
    f=np.array([p(x) for p in pol]); fp=np.array([p.deriv()(x) for p in pol]); fpp=np.array([p.deriv(2)(x) for p in pol])
    D=E*t**3/(12*(1-nu**2));N=sigma*t
    K=2*np.pi*D/a**2*np.einsum('ik,jk,k->ij',fpp,fpp,q*x)
    K+=2*np.pi*D/a**2*np.einsum('ik,jk,k->ij',fp,fp,q/x)
    K+=2*np.pi*D/a**2*nu*(np.einsum('ik,jk,k->ij',fpp,fp,q)+np.einsum('ik,jk,k->ij',fp,fpp,q))
    K+=2*np.pi*N*np.einsum('ik,jk,k->ij',fp,fp,q*x)
    b=2*np.pi*a*a*(f@(q*x));coef=np.linalg.solve(K,b)
    shape=sum((float(c)*p for c,p in zip(coef,pol)),P([0]))
    # w per Pa; Cvolume = integral w dA per Pa.
    C0=float(shape(0));Cv=float(b@coef)
    if sigma==0: analytic=a**4/(64*D)
    elif sigma>0:
        k=np.sqrt(N/D);z=k*a
        analytic=a*a/(4*N)+a/(2*N*k*iv(1,z))*(1-iv(0,z))
    else: analytic=None
    return dict(C0=C0,Cv=Cv,D=D,shape=shape,analytic_C0=analytic,eigmin=float(np.linalg.eigvalsh(K)[0]),E=E,nu=nu,t=t,a=a,sigma=sigma)


def state(model,T,qexp,gamma,gas_ratio=10,theta_deg=0,p0=101325.,T0=288.15,
          gamma0=.03,channel_width=20e-6,liquid_extra_area=20000e-12,heights_um=None):
    # gas_ratio means initial gas volume / aperture liquid volume for each cavity.
    a=model['a'];area=np.pi*a*a
    h=np.array([1.45,8.353152083061113] if heights_um is None else heights_um)*1e-6
    # The channel and bond lands are uncoated Al2O3: add both LC-face coating
    # thicknesses to get bare substrate separation, using two ZnO only in cell0.
    channel_h=h+20e-9;channel_h[0]+=199.6e-9
    Vg0=gas_ratio*area*h
    nc=len(h);Q=2*np.eye(nc)-np.eye(nc,k=1)-np.eye(nc,k=-1)
    Cp=model['Cv']*Q
    ct=np.cos(np.deg2rad(theta_deg))
    pc0=2*gamma0*ct*(1/channel_h+1/channel_width)
    pc=2*gamma*ct*(1/channel_h+1/channel_width)
    pl0=-pc0
    Vlc=area*h+liquid_extra_area*channel_h+Cp@pl0
    # At cold fill/seal gas pressure is p0 and liquid is at p0-pc0.
    # Increase in total cavity volume equals decrease in liquid occupancy,
    # plus plate bow increase; narrow supported gas channel volume is fixed.
    def f(pg):
        pl=pg-p0-pc
        Vg=Vg0-qexp*Vlc+Cp@(pl-pl0)
        return (pg*Vg-p0*Vg0*T/T0)/(p0*Vg0)
    sol=root(f,np.ones(nc)*p0*T/T0,tol=1e-11)
    if not sol.success and np.max(np.abs(f(sol.x)))>1e-9:raise RuntimeError(sol.message)
    pg=sol.x;pl=pg-p0-pc;Vg=Vg0-qexp*Vlc+Cp@(pl-pl0)
    center=model['C0']*(Q@pl)
    cold=model['C0']*(Q@pl0)
    rr=np.linspace(0,a,241);delta=(Q@pl)[:,None]*model['shape'](rr/a)
    # external uniform pressure on plate stack; signed bottom/middle/top loads.
    loads=np.r_[-pl[0],pl[:-1]-pl[1:],pl[-1]]
    return {'temperature_C':T-273.15,'qexp_scenario':qexp,'gamma_N_m_scenario':gamma,
            'cos_theta_scenario':ct,'gas_ratio':gas_ratio,'gas_pressure_abs_Pa':pg.tolist(),
            'liquid_pressure_gauge_Pa':pl.tolist(),'capillary_pressure_Pa':pc.tolist(),
            'gas_volume_nL':(Vg*1e12).tolist(),
            'bare_channel_height_um':(channel_h*1e6).tolist(),
            'expansion_only_meniscus_shift_um':(qexp*Vlc/(channel_width*channel_h)*1e6).tolist(),
            'net_meniscus_shift_um':((Vg0-Vg)/(channel_width*channel_h)*1e6).tolist(),
            'plate_loads_bottom_middle_top_Pa':loads.tolist(),
            'center_gap_change_from_flat_nm':(center*1e9).tolist(),
            'center_gap_change_from_cold_nm':((center-cold)*1e9).tolist(),
            'center_LC_thickness_um':((h+center)*1e6).tolist(),
            'min_LC_thickness_um':((h+delta.min(axis=1))*1e6).tolist(),
            'max_LC_thickness_um':((h+delta.max(axis=1))*1e6).tolist(),
            'gas_equation_residual_relative':float(np.max(np.abs(f(pg)))),
            'LC_aperture_volume_nL':(area*h*1e12).tolist(),
            'gas_initial_volume_nL':(Vg0*1e12).tolist()}


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);args=ap.parse_args()
    args.out.mkdir(parents=True,exist_ok=False)
    checks=[]
    for stress in [0,200e6]:
        for n in [3,5,7]:
            m=plate(sigma=stress,n=n)
            checks.append({'sigma_MPa':stress/1e6,'basis':n,'C0_m_per_Pa':m['C0'],'closed_form_C0':m['analytic_C0'],
                           'relative_center_difference':abs(m['C0']/m['analytic_C0']-1)})
    scenarios=[]
    for E in [100e9,170e9,300e9]:
        for a in [112e-6,120e-6,150e-6]:
            for stress in [0,200e6]:
                m=plate(E=E,a=a,sigma=stress)
                for ratio in [1,10]:
                    for q in [.008,.02,.04]:
                        for gam in [.025,.03,.035]:
                            z=state(m,323.15,q,gam,gas_ratio=ratio)
                            z.update({'E_GPa_scenario':E/1e9,'radius_um':a*1e6,'stress_MPa_scenario':stress/1e6})
                            scenarios.append(z)
    m=plate();nominal={'cold':state(m,288.15,0,.03),'hot_q04':state(m,323.15,.04,.03)}
    triple={'cold':state(m,288.15,0,.03,heights_um=[4,4,8.353152083061113]),
            'hot_q04':state(m,323.15,.04,.03,heights_um=[4,4,8.353152083061113])}
    xx=np.linspace(-75,75,151);X,Y=np.meshgrid(xx,xx);R=np.sqrt(X*X+Y*Y)*1e-6
    maps={'x_um':xx,'y_um':xx,'radius_um':R*1e6}
    Q=np.array([[2.,-1.],[-1.,2.]])
    for name,s in nominal.items():
        shapes=(Q@np.array(s['liquid_pressure_gauge_Pa']))[:,None,None]*m['shape'](R[None,:,:]/m['a'])
        maps[name+'_LC_thickness_um']=(np.array([1.45,8.353152083061113])[:,None,None]+shapes*1e6)
    np.savez(args.out/'nominal_LC_thickness_maps.npz',**maps)
    np.savez(args.out/'nominal_bow.npz',radius_um=np.linspace(0,120,241),
             center_response_m_per_Pa=m['shape'](np.linspace(0,1,241)))
    # Isolated circular interface blister mechanical energy release rate:
    # compliant two-plate load. This does not bound edge defects, shear, or leakage.
    bond=[]
    for p in [13000.,50000.,100000.]:
        bond.append({'pressure_Pa':p,'G_J_m2_two_clamped_plate_blister':p*p*m['a']**4/(64*m['D'])})
    # Scalar phase diagnostic for the B wedge; no intensity average is used.
    # Beam width150um; posts300um apart; delta post height -> wedge PV/2.
    wedge=[]
    for dh in [30,80]:
        pv_nm=dh*150/300
        for lam in [400,550,780,1550,2500]:
            x=np.linspace(-.5,.5,100001);phase=4*np.pi/lam*pv_nm*x
            amp=np.trapezoid(np.exp(1j*phase),x)
            wedge.append({'post_height_difference_nm':dh,'gap_PV_nm':pv_nm,'lambda_nm':lam,
                          'roundtrip_phase_PV_rad':float(4*np.pi/lam*pv_nm),
                          'coherent_uniform_angular_mode_roundtrip_amplitude_real_imag':[float(amp.real),float(amp.imag)],
                          'roundtrip_mode_power':float(abs(amp)**2),
                          'scope':'phase-only aperture average of one roundtrip, NOT the B device multi-scattering response'})
    residual=[];biax=m['E']/(1-m['nu'])
    for stress in [100e6,200e6,500e6]:
        residual.append({'stress_MPa_scenario':stress/1e6,
                         'stored_inplane_energy_J_m2_one_plate':stress*stress*m['t']/biax,
                         'fully_relaxed_free_strain':stress/biax,
                         'scope':'Equibiaxial strain energy on rigid carrier; not the released-plate prestress or an actual interface energy-release rate.'})
    curvature=[]
    for force in [1,10,50]:
        kap=6*force/(biax*m['t']**2)
        curvature.append({'one_sided_film_stress_times_thickness_N_m':force,'free_curvature_per_m':kap,
                          'free_center_edge_sag_nm':kap*m['a']**2/2*1e9,
                          'scope':'Stoney thin-coating scale on free8um plate; ideal edge clamp suppresses this shape but stores moments.'})
    bonding_pressure=9.8e4/(np.pi*(.1016/2)**2)
    eps0=8.8541878128e-12
    result={'model':'3 isotropic clamped circular 8um plates, two separately sealed ideal-gas buffers, fixed capillary contact angle, narrow stiff buffer channels',
            'nominal_scenarios':nominal,'mechanical_checks':checks,'sensitivity_scenarios':scenarios,
            'four_plate_three_LC_scenarios':triple,
            'residual_stress_energy_scales':residual,'coating_gradient_curvature_scales':curvature,
            'SAB_source_load_scale':{'nominal_pressure_Pa':bonding_pressure,
                 'if_pressure_were_applied_over_aperture_single_plate_bow_um':bonding_pressure*m['C0']*1e6,
                 'annular_land_120to140um_force_N':bonding_pressure*np.pi*((140e-6)**2-(120e-6)**2),
                 'scope':'Source blanket rigid-wafer load cannot be applied blindly to unsupported cavities; need land-only annular stamps or fully removable cavity scaffold.'},
            'finite_source_LC_thickness_maps':'nominal_LC_thickness_maps.npz, two geometry states, no self-consistent director/Maxwell recomputation',
            'electrostatic_normal_stress_scales':[
                {'V_LC':V,'d_LC_um':h,'eps_scenario':19,'pressure_Pa':eps0*19*(V/(h*1e-6))**2/2,
                 'scope':'uniform-field upper permittivity scale, not actual patterned Maxwell stress field'}
                for V,h in [(4,1.45),(1.65,4)]],
            'reservoir_geometry':{'channel_width_um':20,
                 'gas_path_length_um_for_ratio10':(10*np.pi*120**2*np.array([1.45,8.353152083061113])/np.array(nominal['cold']['bare_channel_height_um'])/20).tolist(),
                 'with20um_separating_rib_min_raster_footprint_mm2':(10*np.pi*120**2*np.array([1.45,8.353152083061113])/np.array(nominal['cold']['bare_channel_height_um'])*2/1e6).tolist(),
                 'liquid_feed_area_um2_scenario':20000,'required_net_interface_travel_nominal_hot_um':nominal['hot_q04']['net_meniscus_shift_um'],
                 'extra_straight_free_travel_proposal_um':300,'caution':'No 600um unsupported reservoir roof: use20umwide channels separated by20um alumina ribs, all at cell-height. Gas starts after liquid feed. Exact source-mask/coating pattern and final closure remain conditional.'},
            'blister_energy_scales':bond,'B_wedge_phase_only_diagnostic':wedge,
            'pressure_volume_relation':'delta_V = Cv * [[2,-1],[-1,2]] @ delta_p_liquid',
            'center_gap_relation':'delta_h_center = C0 * [[2,-1],[-1,2]] @ p_liquid',
            'nominal_assumptions':{'E_GPa':170,'nu':.22,'radius_um':120,'support_um':8,'gas_to_aperture_liquid_volume_ratio':10,'theta_deg':0,'channel_width_um':20,'extra_liquid_area_um2':20000,'gas_T_initial_K':288.15,'T_hot_K':323.15},
            'claims_excluded':['E7 expansion, surface tension, wetting and actual 8um modulus/stress are not measured intervals.',
                'Cold nominal optical thickness is not automatically obtained after capillary filling.',
                'Reservoir and bond geometry has not been optically or process-validated.',
                'Initial1atm gas sealing has no proven final closure path under vacuum SAB; gas-reservoir calculation is an explicit assembly scenario.',
                'Ring expansion, external pressure changes, permeation, evaporation and fluid compressibility are omitted.',
                'Coherent phase diagnostic is not wedge-coupled full B optical solve.',
                'Mechanical checks are conditional implementation checks, not strict A or fabrication pass.'],
            'full_problem_solved':False}
    (args.out/'results.json').write_text(json.dumps(result,indent=2),encoding='utf8')
    (args.out/'source.py').write_bytes(Path(__file__).read_bytes())
    print(json.dumps({'nominal':nominal,'triple':triple,'checks':checks,'blister_energy_scales':bond,'SAB':result['SAB_source_load_scale'],'residual':residual,'curvature':curvature}))

if __name__=='__main__':main()
