"""Six fixed all-solid actual-device order/slice controls, common81 aperture only."""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'): os.environ[k]='1'
import argparse,hashlib,inspect,json,sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
REF=ROOT/'runs/20261105-q2-finish-decouple-solid-interface-optics64-127-0-01'
READ=ROOT/'runs/20261105-q2-finish-decouple-solid-interface-readout64-127-600-01'
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x): Path(p).write_text(json.dumps(x,indent=2),encoding='utf-8')
def checked(folder):
    m=json.loads((folder/'results.json').read_text())
    for p,h in m['frozen_inputs_SHA256'].items(): assert sha(ROOT/p)==h,p
    assert sha(folder/'effective_optics_source.py')==m['effective_source_SHA256']
    return m
def select(a):
    from experiments import q2_finish_decouple_20261105_solid_interface as solid
    config,deps,data=solid.provenance();launch=json.loads((REF/'launch.json').read_text())
    assert config['effective_source_sha256']==launch['effective_source_sha256']
    assert config['input_sha256']==launch['input_sha256'] and config['source_sha256']==launch['source_sha256']
    assert all(json.loads((REF/'optical_postflight.json').read_text()).values())
    source=(REF/'effective_optics_source.py').read_text();assert hashlib.sha256(source.encode()).hexdigest()==config['effective_source_sha256']
    assert source.count(solid.SOLID)==1 and solid.AIR not in source
    z=np.load(READ/'spectra.npz');w=z['wavelength_um'];T=z['total_T'];peaks=[]
    for kind,q,lo,hi in [('VIS_thermal',abs(T[:,1]-T[:,0]),.4,.78),('NIR_electric',abs(T[1]-T[0]),.78,2.5)]:
        ix=np.flatnonzero((w>=lo)&(w<=hi))
        for state in range(2):
            j=ix[np.argmax(q[state,ix])];peaks.append({'kind':kind,'fixed_state':state,'wavelength_um':float(w[j]),'absolute_cross_pp':float(100*q[state,j])})
    vp=max((p for p in peaks if p['kind']=='VIS_thermal'),key=lambda p:p['absolute_cross_pp'])
    npk=max((p for p in peaks if p['kind']=='NIR_electric'),key=lambda p:p['absolute_cross_pp'])
    selected=np.unique([.4,.78,2.5,1.1,vp['wavelength_um'],npk['wavelength_um']]);assert len(selected)==6
    np.savez_compressed(a.out/'grid.npz',wavelength_um=selected)
    (a.out/'effective_optics_source.py').write_text(source,encoding='utf-8')
    (a.out/'original_launch.json').write_bytes((REF/'launch.json').read_bytes())
    files=sorted(set(deps+data+[Path(__file__).resolve(),READ/'spectra.npz']))
    for p in files:
        dest=a.out/'frozen'/p.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes())
    m={'fields':str(solid.FIELDS.relative_to(ROOT)),'fields_SHA256':solid.FIELD_SHA,'ZnO_table':str(solid.ZN.relative_to(ROOT)),'ZnO_SHA256':solid.ZN_SHA,'frozen_inputs_SHA256':{str(p.relative_to(ROOT)):sha(p)for p in files},'effective_source_SHA256':sha(a.out/'effective_optics_source.py'),'wavelength_um':selected.tolist(),'all_four_actual600_peaks':peaks,'selection':'Fixed .4/.78/2.5 boundaries, 1.1 diagnostic, actual600 VIS thermal and NIR electric global pilot peaks. No 700 peak .82 control.','hole_kernel':'runs/20261105-q2-package-device-kernels-01/inner600/gram.npz','physics_identity':config,'reference127':str(REF.relative_to(ROOT)),'reference_readout_spectra_SHA256':sha(READ/'spectra.npz'),'scope':'Actual all-solid 19 retained entities / 18 merged optical layers including carbon; 20 pre-screen computational segments / 21 including carbon. No air-result reuse.'}
    save(a.out/'results.json',m);print(json.dumps({'waves':selected.tolist(),'peaks':peaks}),flush=True)
def solve(a):
    m=checked(a.selection);source=(a.selection/'effective_optics_source.py').read_text();old="[('E',forward),('G',Y@forward)]";assert source.count(old)==1
    source=source.replace(old,"[('E',forward),('G',Y@forward),('RE',back),('RG',Y@back)]")
    from experiments import q2_finish_assembly_20261105_d855order as aircontrol
    ns=aircontrol.namespace();exec(source,ns)
    (a.out/'executed_optics.py').write_text(source,encoding='utf-8');save(a.out/'launch.json',{'argv':sys.argv,'order':a.order,'slices':a.slices,'source_selection':str(a.selection.relative_to(ROOT)),'fields_SHA256':m['fields_SHA256'],'ZnO_SHA256':m['ZnO_SHA256'],'only_code_difference':'save reflected RE/RG; exact frozen all-solid source otherwise'})
    ns['optics'](argparse.Namespace(out=a.out,fields=ROOT/m['fields'],grid=a.selection/'grid.npz',d=2.5,bias=9.235,order=a.order,slices=a.slices,shard=0,shards=1,dense=False))
    checked(a.selection);save(a.out/'postflight.json',{'frozen_inputs_match':True})
def compare(a):
    from experiments import q2_finish_order_control_20261105 as common
    source=inspect.getsource(common.compare);old="original_runs=[ROOT/f'runs/20261105-q2-finish-decouple-SiNx-optics64-713-{j}'for j in range(3)]";new="original_runs=[ROOT/f'runs/20261105-q2-finish-decouple-solid-interface-optics64-127-{j}-01'for j in range(2)]";assert source.count(old)==1
    source=source.replace(old,new).replace('original713','original127').replace('Original713','Original127');ns=dict(common.__dict__);exec(source,ns);ns['compare'](a)
    result=json.loads((a.out/'results.json').read_text());result['actual_candidate']='Frozen actual all-solid source25 d8.55, corrected335node ZnO, external9.235V, 19 entities / 18 merged optical layers including carbon';result['readback_frozen_inputs_match']=bool(checked(a.selection));save(a.out/'results.json',result);(a.out/'executed_compare.py').write_text(source,encoding='utf-8')
def main():
    p=argparse.ArgumentParser();p.add_argument('action',choices=['select','solve','compare']);p.add_argument('--out',type=Path,required=True);p.add_argument('--selection',type=Path);p.add_argument('--order',type=int);p.add_argument('--slices',type=int);p.add_argument('--low',type=Path);p.add_argument('--high',type=Path);a=p.parse_args()
    for k in ['out','selection','low','high']:
        if getattr(a,k,None)is not None:setattr(a,k,getattr(a,k).resolve())
    a.out.mkdir(parents=True,exist_ok=False);(a.out/'source.py').write_bytes(Path(__file__).read_bytes());globals()[a.action](a)
if __name__=='__main__':main()
