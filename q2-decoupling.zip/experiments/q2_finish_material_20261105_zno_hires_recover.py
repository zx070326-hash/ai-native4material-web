"""Reconcile completed optics after a changed, unused future reader dependency."""
import os
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[key]='1'
from pathlib import Path
import json,hashlib,shutil,sys,difflib,argparse
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
OUT=ROOT/'runs/20261105-q2-finish-material-ZnO-hires-recovery-01'
LAUNCH=ROOT/'runs/20261105-q2-finish-material-ZnO-hires-optics-launch-01'
READER=ROOT/'experiments/q2_finish_decouple_20261105_readout.py'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def prepare():
 OUT.mkdir(parents=True,exist_ok=False);m=json.loads((LAUNCH/'manifest.json').read_text());oldreader=LAUNCH/'frozen'/READER.relative_to(ROOT)
 shutil.copy2(oldreader,OUT/'reader_before_optics.py');shutil.copy2(READER,OUT/'reader_after_optics_frozen.py');shutil.copy2(__file__,OUT/'source.py')
 diff=''.join(difflib.unified_diff(oldreader.read_text().splitlines(True),READER.read_text().splitlines(True),fromfile='frozen_before_optics',tofile='reader_after_optics'))
 (OUT/'reader_change.diff').write_text(diff)
 runs={}
 for variant in ('old15','new25'):
  allwaves=[];states=[];paths=[]
  for shard in (0,1):
   p=ROOT/f'runs/20261105-q2-finish-material-ZnO-hires-{variant}-optics127-{shard}-01';post=json.loads((p/'postflight.json').read_text());before=json.loads((p/'preflight.json').read_text());changed=[k for k,v in post['checks'].items()if not v]
   assert changed==[str(READER.relative_to(ROOT))],changed
   assert all(before['checks'].values())
   field=np.load(p/'scattered_fields.npz');w=field['wavelength_um'];allwaves.extend(w);r=json.loads((p/'results.json').read_text());assert len(w)==len(r['diagnostics'])
   assert all(np.isfinite(field[k]).all()for k in field.files)
   assert set(field.files)=={'wavelength_um','harmonics'}|{f'V{vi}T{ti}__{label}'for vi in (0,1)for ti in (0,1)for label in ('E','G')}
   states.extend(s for point in r['diagnostics']for s in point['states']);paths.append({'directory':str(p.relative_to(ROOT)),'fields_sha256':sha(p/'scattered_fields.npz'),'result_sha256':sha(p/'results.json'),'nodes':len(w),'original_guard_status':'failed_postflight_only_unused_readout_changed','40_other_dependencies_unchanged':all(v for k,v in post['checks'].items()if k!=str(READER.relative_to(ROOT)))})
  waves=np.sort(allwaves);assert len(waves)==len(np.unique(waves))==127
  assert np.array_equal(waves,np.array(m['wavelengths_um']))
  for s in states:assert min(s['T'],s['R'],s['A'])>=-1e-10 and max(s['T'],s['R'],s['A'])<=1+1e-10
  runs[variant]={'inputs':paths,'unique_nodes':len(waves),'state_count':len(states),'R_range':[min(s['R']for s in states),max(s['R']for s in states)],'T_range':[min(s['T']for s in states),max(s['T']for s in states)],'A_range':[min(s['A']for s in states),max(s['A']for s in states)],'max_cascade_residual':max(s['cascade_residual']for s in states),'max_transfer_condition':max(s['maxcondition']for s in states)}
 files=[Path(__file__),OUT/'reader_after_optics_frozen.py',ROOT/'experiments/q2_package_A_20261105.py',ROOT/'runs/20261105-q2-package-device-kernels-01/inner600/gram.npz',ROOT/'runs/20261105-q2-package-device-kernels-01/inner700/gram.npz']
 receipt={'recovery':'No optics rerun; reconcile completedfields from four initial jobs whose only postflight failure was changed unused readout dependency. All41preflightchecks passed and40actualopticaldependencies remain unchanged.','changed_file':str(READER.relative_to(ROOT)),'old_reader_sha256':sha(oldreader),'new_frozen_reader_sha256':sha(OUT/'reader_after_optics_frozen.py'),'diff_file':'reader_change.diff','reader_change_scope':'three lines add diagnostic_control receipt handling, no numeric change; no diagnostic_control exists in these newphysical inputs','runs':runs,'postprocess_SHA256':{str(p.relative_to(ROOT)):sha(p)for p in files},'legacy_baselines':{'old15':[f'runs/20261105-q2-finish-decouple-external_ar-optics64-127-{i}'for i in (0,1)],'new25':[f'runs/20261105-q2-finish-decouple-source25-AR19-optics64-127-{i}'for i in (0,1)]}}
 (OUT/'manifest.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2))

def read(variant,hole,legacy):
 m=json.loads((OUT/'manifest.json').read_text());assert all(sha(ROOT/p)==v for p,v in m['postprocess_SHA256'].items())
 paths=m['legacy_baselines'][variant] if legacy else [x['directory']for x in m['runs'][variant]['inputs']]
 output=ROOT/f'runs/20261105-q2-finish-material-ZnO-hires-{variant}-{"baseline"if legacy else"readout"}127-{hole}-01'
 ns={'__file__':str(READER),'__name__':'independent_frozen_reader'};exec((OUT/'reader_after_optics_frozen.py').read_text(),ns)
 sys.argv=[str(Path(__file__)),'--runs',*paths,'--hole',f'runs/20261105-q2-package-device-kernels-01/inner{hole}/gram.npz','--out',str(output)]
 ns['main']()
 r=json.loads((output/'results.json').read_text());r['independent_postprocess']={'recovery_manifest':str(OUT.relative_to(ROOT)),'recovery_manifest_sha256':sha(OUT/'manifest.json'),'actual_reader_SHA256':sha(OUT/'reader_after_optics_frozen.py'),'legacy_comparison':legacy,'scope':'127truewave nodes, same actual LCsource/samegeometry/onlyZnOopticsdifferent; originalfailedguardpreservedandreconciled'};(output/'results.json').write_text(json.dumps(r,indent=2))
 assert all(sha(ROOT/p)==v for p,v in m['postprocess_SHA256'].items())

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('action',choices=['prepare','read']);p.add_argument('--variant',choices=['old15','new25']);p.add_argument('--hole',type=int,choices=[600,700]);p.add_argument('--legacy',action='store_true');a=p.parse_args()
 if a.action=='prepare':prepare()
 else:read(a.variant,a.hole,a.legacy)
