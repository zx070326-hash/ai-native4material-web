"""Independent saved-spectrum audit and matched A-aperture control.

This does not solve new Maxwell fields or certify source/process uncertainty.
"""
import os
for _k in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[_k] = '1'
from pathlib import Path
import argparse
import hashlib
import json
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def metrics(w, t):
    if t.shape != (2, 2, len(w)) or not np.all(np.isfinite(t)):
        raise ValueError('Expected finite voltage x temperature x wavelength T')
    if not np.all(np.diff(w) > 0):
        raise ValueError('Duplicated or unordered wavelength')
    means, cross = {}, {}
    for name, lo, hi in [('VIS', .4, .78), ('NIR', .78, 2.5)]:
        mask = (w >= lo) & (w <= hi)
        assert abs(w[mask][0]-lo) < 1e-12 and abs(w[mask][-1]-hi) < 1e-12
        def avg(x):
            return np.trapezoid(x[..., mask], w[mask], axis=-1)/(hi-lo)
        means[name] = avg(t)
        d = t[:, 1]-t[:, 0] if name == 'VIS' else t[1]-t[0]
        cross[name] = {
            'signed_band_pp': (100*avg(d)).tolist(),
            'mean_absolute_spectral_pp': (100*avg(abs(d))).tolist(),
            'sampled_peak_absolute_pp': (100*abs(d[..., mask]).max(axis=-1)).tolist(),
        }
    return {
        'main_pp': [max(0., .95*min(abs(means['VIS'][1]-means['VIS'][0]))-.05)*100,
                    min(abs(means['NIR'][:, 1]-means['NIR'][:, 0]))*100],
        'band_T': {k: v.tolist() for k, v in means.items()},
        'cross': cross,
        'T_range': [float(t.min()), float(t.max())],
        'nodes': len(w),
    }


def audit(out):
    rows = []
    aroot = ROOT/'runs/20261105-q2-package-A-readout-rotationfix-64-1425-01'
    z = np.load(aroot/'spectra.npz')
    q = metrics(z['wavelength_um'], z['total_T'])
    ref = json.loads((aroot/'results.json').read_text())['main']
    err = max(abs(np.asarray(q['main_pp'])-np.array([ref['VIS_conditional_lower_pp'], ref['NIR_model_pp']])))
    rows.append({'case': 'A_rotationfix', **q, 'main_arithmetic_max_error_pp': float(err)})
    bsum = json.loads((ROOT/'runs/20261105-q2-package-source-summary-02/results.json').read_text())
    for r in bsum['rows']:
        folder = ROOT/r['readout']['readout_path']
        zz = np.load(folder/'spectra.npz')
        v = metrics(zz['wavelength_um'], zz[str(r['inner_um'])+'__total_T'])
        err = float(max(abs(np.asarray(v['main_pp'])-r['main_pp'])))
        rows.append({'case': r['case'], 'inner_um': r['inner_um'], **v,
                     'main_arithmetic_max_error_pp': err})
    assert max(r['main_arithmetic_max_error_pp'] for r in rows) < 1e-10
    hand = json.loads((ROOT/'runs/20261105-q2-package-A-handoff-01/results.json').read_text())
    hashes = [{'path': p, 'match': sha(ROOT/p) == expected}
              for p, expected in hand['input_sha256'].items()]
    # Entry scripts can change after a run. A mismatch is evidence to inspect,
    # never grounds to silently replace a reference hash.
    result = {'rows': rows, 'A_handoff_hash_checks': hashes,
              'source_sha256': sha(__file__), 'full_problem_solved': False,
              'scope': 'Independent saved-spectrum integration only; no field/material/process certification.'}
    (out/'results.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps({'rows': len(rows), 'main_error_pp': max(r['main_arithmetic_max_error_pp'] for r in rows),
                      'hash_matches': sum(r['match'] for r in hashes), 'hash_count': len(hashes)}), flush=True)


def aperture(out):
    runs = sorted((ROOT/'runs').glob('20261105-q2-package-A-optical-rotationfix-*/scattered_fields.npz'))
    assert len(runs) == 12
    return aperture_fields(out, runs, 'Original A64/1425 fields')


def compensated_aperture(out):
    runs = sorted((ROOT/'runs').glob('20261105-q2-finish-decouple-SiNx-optics-d2p5-127-*/scattered_fields.npz'))
    assert len(runs) == 2
    return aperture_fields(out, runs, 'SiNx compensated three-cell32/127 fields; assigned anchoring and dielectric constant')


def external_aperture(out):
    runs = [ROOT/'runs/20261105-q2-finish-decouple-external-optics-127-01/scattered_fields.npz']
    assert all(p.exists() for p in runs)
    return aperture_fields(out, runs, 'Five-board17-layer SiNx external-electrode32/support32/127 fields at fixed12.235V')


def ar_aperture(out):
    runs = sorted((ROOT/'runs').glob('20261105-q2-finish-decouple-external_ar-optics64-127-*/scattered_fields.npz'))
    assert len(runs) == 2
    return aperture_fields(out, runs, 'Five-board19-layer SiNx external-electrode64/support32/127 fields at fixed12.235V; two83.028893nmAl2O3AR films')


def aperture_fields(out, runs, scope):
    from types import SimpleNamespace
    from experiments.q2_package_A_20261105 import readout
    rows = []
    for inner in (700, 650, 600):
        hole = (ROOT/f'runs/20261105-q2-package-device-kernels-01/inner{inner}/gram.npz'
                if inner != 650 else ROOT/'runs/20261105-q2-parallel-crosstalk-xcut-refined-01/gram_inner650_177step5.npz')
        dest = out/f'inner{inner}'
        dest.mkdir()
        readout(SimpleNamespace(runs=[p.parent for p in runs], hole=hole, out=dest))
        receipt=json.loads((dest/'results.json').read_text())
        receipt['explicit_source_scope']=scope
        receipt['inherited_adapter_notice']='Numeric helper uses historical DLC naming. Source identity is specified above; no new film was silently added. Full source and manufacturing conditions remain.'
        (dest/'results.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
        z = np.load(dest/'spectra.npz')
        q = metrics(z['wavelength_um'], z['total_T'])
        rows.append({'inner_um': inner, **q, 'kernel_sha256': sha(hole),
                     'kernel_precision': '177 wavelengths / 5um plane quadrature',
                     'spectra_sha256': sha(dest/'spectra.npz')})
    result = {'rows': rows, 'source_fields_sha256': {str(p.relative_to(ROOT)): sha(p) for p in runs},
              'scope': 'Matched fixed masks, '+scope+'; carbon leakage retained. Aperture control cannot repair material or temperature-differential phase.',
              'full_problem_solved': False}
    (out/'results.json').write_text(json.dumps(result, indent=2), encoding='utf-8')


def passive_filter(out):
    """Generous spectral-filter relaxation, not a realizable added component."""
    from scipy.optimize import linprog
    sources = [
        ('A', ROOT/'runs/20261105-q2-package-A-readout-rotationfix-64-1425-01/spectra.npz', 'total_T'),
        ('B600', ROOT/'runs/20261105-q2-package-device-graph2p0-02/spectra.npz', '600__total_T'),
    ]
    rows = []
    arrays = {}
    for label, path, key in sources:
        saved = np.load(path)
        w, t = saved['wavelength_um'], saved[key]
        for band, lo, hi, main_floor in [('VIS', .4, .78, (.30+.05)/.95), ('NIR', .78, 2.5, .20)]:
            use = (w >= lo) & (w <= hi)
            ww = w[use]
            tt = t[..., use]
            weights = np.r_[ww[1]-ww[0], ww[2:]-ww[:-2], ww[-1]-ww[-2]]/2/(hi-lo)
            main = tt[1]-tt[0] if band == 'VIS' else tt[:, 0]-tt[:, 1]
            cross = tt[:, 1]-tt[:, 0] if band == 'VIS' else tt[1]-tt[0]
            # Positive main band signs are fixed to the source candidate.
            n = len(ww)
            for objective in ('worst_mean_absolute', 'worst_sampled_peak'):
                main_constraints = np.c_[-main*weights, np.zeros(2)]
                if objective == 'worst_mean_absolute':
                    cross_constraints = np.c_[abs(cross)*weights, -np.ones(2)]
                else:
                    cross_constraints = np.zeros((2*n, n+1))
                    for setting in range(2):
                        cross_constraints[setting*n+np.arange(n), np.arange(n)] = abs(cross[setting])
                    cross_constraints[:, -1] = -1
                aub = np.r_[main_constraints, cross_constraints]
                bub = np.r_[np.full(2, -main_floor), np.zeros(len(cross_constraints))]
                opt = linprog(np.r_[np.zeros(n), 1.], A_ub=aub, b_ub=bub,
                              bounds=[(0., 1.)]*n+[(0., None)], method='highs')
                if not opt.success:
                    rows.append({'source': label, 'band': band, 'objective': objective,
                                 'status': opt.message})
                    continue
                f = opt.x[:-1]
                dual = float(bub@opt.ineqlin.marginals + opt.upper.marginals[:-1].sum())
                stationarity = np.r_[np.zeros(n), 1.] - aub.T@opt.ineqlin.marginals - opt.lower.marginals - opt.upper.marginals
                main_after = (main*weights)@f
                means_after = (abs(cross)*weights)@f
                peaks_after = abs(cross*f).max(axis=-1)
                arrays[f'{label}_{band}_{objective}__wavelength_um'] = ww
                arrays[f'{label}_{band}_{objective}__filter_T'] = f
                rows.append({'source': label, 'band': band, 'objective': objective,
                             'baseline_main_known_pp': (100*(main*weights).sum(axis=-1)).tolist(),
                             'main_floor_known_pp': 100*main_floor,
                             'main_after_known_pp': (100*main_after).tolist(),
                             'cross_mean_after_pp': (100*means_after).tolist(),
                             'cross_sampled_peak_after_pp': (100*peaks_after).tolist(),
                             'objective_lower_bound_pp': float(100*opt.fun),
                             'max_constraint_residual': float(np.maximum(aub@opt.x-bub, 0).max()),
                             'dual_objective_pp': 100*dual,
                             'primal_dual_gap_pp': float(100*(opt.fun-dual)),
                             'max_dual_stationarity_residual': float(abs(stationarity).max())})
    np.savez_compressed(out/'relaxation_filters.npz', **arrays)
    (out/'results.json').write_text(json.dumps({
        'rows': rows, 'scope': 'Arbitrary common passive scalar spectral attenuation on saved four-state intensities, separately relaxed in each band. No material, phase, reflection or layer-count constraints. Source candidates and main band signs fixed. This is a generous mathematical bound for this attenuation-only model, not a fabricated filter or a general decoupling no-go.',
        'full_problem_solved': False}, indent=2), encoding='utf-8')
    print(json.dumps(rows), flush=True)


def assembly_audit(out):
    path = ROOT/'runs/20261105-q2-finish-assembly-gasplate-final-01/results.json'
    data = json.loads(path.read_text())
    a = data['nominal_assumptions']
    radius, thick, modulus = a['radius_um']*1e-6, a['support_um']*1e-6, a['E_GPa']*1e9
    area = np.pi*radius**2
    bend = modulus*thick**3/(12*(1-a['nu']**2))
    c0 = radius**4/(64*bend)
    cv = np.pi*radius**6/(192*bend)
    coupling = np.array([[2., -1.], [-1., 2.]])
    h = np.array([1.45, 8.353152083061113])*1e-6
    cold = data['nominal_scenarios']['cold']
    pc0 = np.array(cold['capillary_pressure_Pa'])
    channel_h = np.array(cold['bare_channel_height_um'])*1e-6
    extra_area = a['extra_liquid_area_um2']*1e-12
    vlc0 = area*h + extra_area*channel_h - cv*coupling@pc0
    vg0 = a['gas_to_aperture_liquid_volume_ratio']*area*h
    rows = []
    for label, saved in data['nominal_scenarios'].items():
        pg = np.array(saved['gas_pressure_abs_Pa'])
        pl = pg-101325-np.array(saved['capillary_pressure_Pa'])
        vg = vg0-saved['qexp_scenario']*vlc0+cv*coupling@(pl+pc0)
        ideal = 101325*vg0*(saved['temperature_C']+273.15)/a['gas_T_initial_K']
        center = c0*coupling@pl*1e9
        rows.append({'case': label,
                     'center_nm': center.tolist(),
                     'center_saved_max_difference_nm': float(max(abs(center-saved['center_gap_change_from_flat_nm']))),
                     'gaslaw_relative_residual': float(max(abs(pg*vg-ideal)/ideal)),
                     'gasvolume_saved_max_difference_nL': float(max(abs(vg*1e12-saved['gas_volume_nL'])))})
    assert max(r['center_saved_max_difference_nm'] for r in rows) < 1e-8
    assert max(r['gaslaw_relative_residual'] for r in rows) < 1e-10
    result = {'rows': rows, 'analytic_center_compliance_m_Pa': c0,
              'analytic_volume_compliance_m3_Pa': cv,
              'input_sha256': sha(path),
              'scope': 'Independent analytic zero-prestress clamped-plate and ideal-gas algebra. No verification of actual membrane modulus, wetting, thermal expansion, seal or coupled optical response.',
              'full_problem_solved': False}
    (out/'results.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result), flush=True)


def constitutive_audit(out):
    folder=ROOT/'runs/20261105-q2-finish-decouple-constitutive9-01'
    info=json.loads((folder/'results.json').read_text())
    z=np.load(folder/'fields_spectra.npz');w=z['wavelength_um'];mask=(w>=.4)&(w<=.78)
    rows=[]
    for r in info['rows']:
        prefix=f"{r['mode']}_p{r['p_K']}_q{r['q_de']}"
        retardance=z[prefix+'__delta_retardance_um']
        conversion=np.sin(np.pi*retardance/w[None,:])**2
        saved=z[prefix+'__conversion']
        avg=lambda y:np.sum((y[...,1:]+y[...,:-1])*np.diff(w[mask])/2,axis=-1)/(.78-.4)
        signed=conversion[1,mask]-conversion[0,mask]
        mean=float(avg(abs(signed))*100);main=float(min(avg(conversion[:,mask]))*100)
        err=max(abs(mean-r['VIS_thermal_meanabs_pp']),abs(main-r['min_VIS_conversion_pp']))
        rows.append({'mode':r['mode'],'p':r['p_K'],'q':r['q_de'],
                     'main_conversion_pp':main,'thermal_meanabs_pp':mean,
                     'max_formula_array_error':float(abs(conversion-saved).max()),
                     'max_statistic_error_pp':err})
    assert max(r['max_statistic_error_pp'] for r in rows)<1e-9
    assert max(r['max_formula_array_error'] for r in rows)<1e-12
    result={'rows':rows,'scope':'Independent retardance-to-conversion and wavelength-axis statistics only. One-dimensional conversion is not whole-device transmission or measured constitutive data.',
            'input_sha256':{n:sha(folder/n) for n in ['results.json','fields_spectra.npz']},'full_problem_solved':False}
    (out/'results.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('action', choices=['audit', 'aperture', 'compensated_aperture', 'external_aperture', 'ar_aperture', 'passive_filter', 'assembly_audit', 'constitutive_audit'])
    p.add_argument('--out', type=Path, required=True)
    a = p.parse_args()
    a.out.mkdir(parents=True, exist_ok=False)
    globals()[a.action](a.out)
    (a.out/'source.py').write_bytes(Path(__file__).read_bytes())
