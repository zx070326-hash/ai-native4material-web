"""Fixed-bias, same-E7 crossed-electrical-cell compensation screening.

This starts with a vertical Frank/Gauss variational reduction to reject or
select a physical mechanism, then uses independently relaxed 2D directors.
No temperature-dependent voltage selection or arbitrary n(T) is permitted.
"""
import os
for name in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[name]='1'
from pathlib import Path
import sys,json,argparse,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from scipy.optimize import minimize
from autograd import value_and_grad
import autograd.numpy as anp

TAB=np.loadtxt(ROOT/'data/q2_current/Li2005_E7_Cauchy.csv',delimiter=',',skiprows=1)
def indices(T,w):
 r=TAB[TAB[:,0]==T][0,1:]
 return tuple(v[0]+v[1]/w**2+v[2]/w**4 for v in [r[:3],r[3:]])
def scale(T):
 e,o=indices(T,.589);e0,o0=indices(25,.589);return ((e-o)/(e0-o0))**2
def vertical(d,V,T,seed,nz=65):
 K=np.array([11.1,6.5,17.1])*1e-12*scale(T);dx=1/(nz-1);Wp=2e-4;eps0=8.8541878128e-12
 def f(t):
  a=(t[:-1]+t[1:])/2;kp=K[0]*anp.cos(a)**2+K[2]*anp.sin(a)**2
  elastic=anp.sum(.5*kp*((t[1:]-t[:-1])/dx)**2)*dx/(d*1e-6)
  surf=.5*Wp*(anp.sin(t[0])**2+anp.sin(t[-1])**2)
  inverse=anp.sum(1/(5.2+13.8*anp.sin(a)**2))*dx
  return (elastic+surf-.5*eps0*V*V/(d*1e-6*inverse))/(K[0]/(d*1e-6))
 sol=minimize(value_and_grad(f),seed,jac=True,method='L-BFGS-B',bounds=[(-np.pi/2+1e-6,np.pi/2-1e-6)]*nz,options={'maxiter':1200,'ftol':2e-13,'gtol':1e-8,'maxcor':30})
 return sol.x,{'success':bool(sol.success),'nit':int(sol.nit),'grad':float(abs(sol.jac).max()),'energy':float(sol.fun)}
def screen(a):
 volts=np.r_[np.arange(0,3.01,.15),4.,5.,6.];w=np.linspace(.4,.78,121);rows=[];ret={};arr={};nz=65
 for d in [1.45,2.5,4.]:
  for T in [15,50]:
   last=1.4*np.sin(np.linspace(0,np.pi,nz))+.02
   for V in volts[::-1]:
    t,ck=vertical(d,float(V),T,last);last=t
    ne,no=indices(T,w);nn=ne[None,:]*no[None,:]/np.sqrt(ne[None,:]**2*np.sin(t[:,None])**2+no[None,:]**2*np.cos(t[:,None])**2)
    r=d*np.trapezoid(nn-no[None,:],dx=1/(nz-1),axis=0)
    key=f'd{d}_T{T}_V{V:.3f}';arr[key]=t;ret[d,T,float(V)]=r;rows.append({'key':key,**ck,'retardance550_um':float(np.interp(.55,w,r))})
 candidates=[]
 for d in [1.45,2.5,4.]:
  for va in volts:
   for vb in volts:
    if vb<=va:continue
    r0=ret[d,15,float(va)]-ret[d,15,float(vb)];r1=ret[d,50,float(va)]-ret[d,50,float(vb)]
    conv=np.array([np.sin(np.pi*r/w)**2 for r in [r0,r1]])
    cross=np.abs(conv[1]-conv[0]);amp=np.min(np.mean(conv,axis=1))
    candidates.append({'d_um':d,'Va':float(va),'Vb':float(vb),'min_VIS_conversion':float(amp),'VIS_mean_abs_thermal_conversion':float(cross.mean()),'VIS_max_abs_thermal_conversion':float(cross.max()),'retardance550_cold_hot':[float(np.interp(.55,w,r))for r in [r0,r1]]})
 best=sorted(candidates,key=lambda q:q['VIS_mean_abs_thermal_conversion']+3*max(.5-q['min_VIS_conversion'],0))[:20]
 (a.out/'results.json').write_text(json.dumps({'scope':'1DvariationalFrankGauss preliminary mechanism test, no finite-device result','rows':rows,'best':best,'conditions':['identical crossed electric E7 cells each d; state0 equal drives0V0V cancellation, state1 fixedVa,Vb at both temperatures','E7Li2005n;K(T)dn²;eps5.2/13.8 bothT;Wp2e-4 transferred scenario','LCd<=4um individual; lateral8stepP12 must be re-solved2D; exact compensation in1D is not optical proof','Four sharedAl2O3supports+6DLC+4ZnO+3LC+screen=18 main path layers; retained peripheral inventory not closed']},indent=2))
 np.savez_compressed(a.out/'screen_fields.npz',**arr);print(json.dumps(best,indent=2),flush=True)
def direct_electric():
 import inspect
 from experiments.q2_gap_director import Electric
 src=inspect.getsource(Electric).replace('class Electric:','class DirectElectric:').replace('self.z=np.r_[-.015/d,np.linspace(0,1,nz),1+.015/d]','self.z=np.linspace(0,1,nz)').replace('self.np=nz+2','self.np=nz').replace('nx*(nz+2)).reshape(nx,nz+2)','nx*nz).reshape(nx,nz)').replace('self.nz+1,4,4','self.nz-1,4,4').replace('ex=np.pad(ex,((0,0),(1,1)),constant_values=self.epsa);ez=np.pad(ez,((0,0),(1,1)),constant_values=self.epsa);ec=np.pad(ec,((0,0),(1,1)))','ex=ex;ez=ez;ec=ec').replace('gx[:,1:-1],gz[:,1:-1]','gx,gz')
 ns=dict(Electric.__init__.__globals__);exec(src,ns);return ns['DirectElectric']
def director(a):
 from experiments.q2_manufacturing_lc_director2d import problem,initial
 from scipy.interpolate import RegularGridInterpolator
 Direct=direct_electric();nx,nz=a.nx,a.nz;rows=[];arr={};tic=time.perf_counter()
 old=np.load(ROOT/'runs/20261105-q2-package-A-director64-d1p45-02/fields.npz')
 for T in [15,50]:
  for V in [a.bias,0.]:
   key=f'electric_T{T}_V{V:g}';qkey=f'electric_T{T}_V{4 if V else 0}'
   X,Z=np.meshgrid(np.arange(nx)/nx,np.linspace(0,1,nz),indexing='ij');pts=np.stack([X,Z],-1)
   def it(q):return RegularGridInterpolator((np.linspace(0,1,len(q)+1),np.linspace(0,1,q.shape[1])),np.r_[q,q[:1]])(pts)
   v=np.r_[it(old[qkey+'__theta_rad']).ravel(),it(old[qkey+'__phi_correction_rad']).ravel()]
   if not V:v[:nx*nz]+=.04*np.sin(np.pi*Z).ravel()
   K=np.array([11.1,6.5,17.1])*scale(T);f,_,meta=problem(a.d,12,K,nx,nz,Wp=2e-4,Wa=1.14e-4,pattern='8step');fg=value_and_grad(f);ev=Direct(a.d,12,K[0],nx,nz,V)
   def fun(v):
    e,g=fg(v);gr,psi,ck=ev.solve(v);_,ge=ev.evg(v,gr)
    return float(e-ck['positive_electric_dimensionless']),g+ge
   sol=minimize(fun,v,jac=True,method='L-BFGS-B',bounds=[(-np.pi/2+1e-5,np.pi/2-1e-5)]*(nx*nz)+[(None,None)]*(nx*nz),options={'maxiter':a.maxiter,'maxcor':40,'maxls':40,'ftol':1e-13,'gtol':2e-8})
   th=sol.x[:nx*nz].reshape(nx,nz);u=sol.x[nx*nz:].reshape(nx,nz);gr,psi,ck=ev.solve(sol.x)
   for suf,q in [('theta_rad',th),('phi_correction_rad',u),('potential_V',psi)]:arr[key+'__'+suf]=q
   row={'key':key,'d_um':a.d,'V':V,'T':T,'nx':nx,'nz':nz,'success':bool(sol.success),'nit':int(sol.nit),'gradient_inf':float(abs(sol.jac).max()),'theta_max_deg':float(np.rad2deg(abs(th).max())),'energy_J_m2':float(sol.fun*meta['energy_unit_J_m2']),'Gauss':ck,'elapsed_s':time.perf_counter()-tic};rows.append(row)
   np.savez_compressed(a.out/'fields.npz',**arr);(a.out/'results.json').write_text(json.dumps({'rows':rows,'scope':'actual2DFrankGauss at identical two temperatures and fixed bias, transferredA anchoring'},indent=2));print(json.dumps(row),flush=True)
def optics(a):
 from scipy.linalg import expm
 from scipy.interpolate import RegularGridInterpolator
 from experiments import q2_closure_coupling as coupled
 old=coupled.model.old;src=np.load(a.fields/'fields.npz');thermal=np.load(ROOT/'runs/20261105-q2-package-A-director64-d1p45-02/fields.npz')
 dlc=np.loadtxt(ROOT/'runs/20261105-q2-package-A-DLC-spectrum-01/DLC_4keV_vector_digitized.csv',delimiter=',',skiprows=1)
 zn=np.loadtxt(ROOT/'data/q2_package_A_20261105/ZnO2022_Fig5d_passive_digitized.csv',delimiter=',',skiprows=1)
 loss=np.loadtxt(ROOT/'data/q2_parallel_loss_20261105/Wu2002_E7_graph_alpha_k.csv',delimiter=',',skiprows=1)
 nx=128;xx=(np.arange(nx)+.5)/nx;zz=(np.arange(a.slices)+.5)/a.slices;cache={};m=np.arange(-a.order,a.order+1);N=len(m);count=N*N
 def texture(kind,V,ti):
  key=(kind,V,ti)
  if key in cache:return cache[key]
  dat=thermal if kind=='thermal'else src;pre=f'{"thermal"if kind=="thermal"else"electric"}_T{[15,50][ti]}_V{V:g}'
  shift=-.25 if kind=='thermal' else (.25 if kind=='compensator' else 0.)
  X,Z=np.meshgrid((xx+shift)%1,zz,indexing='ij');pts=np.stack([X,Z],-1)
  def it(q):return RegularGridInterpolator((np.linspace(0,1,len(q)+1),np.linspace(0,1,q.shape[1])),np.r_[q,q[:1]])(pts)
  t=it(dat[pre+'__theta_rad']);u=it(dat[pre+'__phi_correction_rad']);p=2*np.pi*xx[:,None]+u+(np.pi/2 if kind=='compensator' else 0.)
  cache[key]=t,p;return t,p
 def cell(kind,V,ti,lam):
  th,ph=texture(kind,V,ti);ne,no=indices([15,50][ti],lam);k=float(np.interp(lam,loss[:,0],loss[:,1]))*lam*1e-4/(4*np.pi);ne+=1j*k;no+=1j*k
  support=complex(old.index('Al2O3_Franta',np.array([lam]))[0]);dn=complex(np.interp(lam,dlc[:,0],dlc[:,1]),np.interp(lam,dlc[:,0],dlc[:,2]));znn=complex(np.interp(lam,zn[:,0],zn[:,1]),np.interp(lam,zn[:,0],zn[:,2]));iso=lambda n:old.dielectric(n,n,np.zeros(nx),np.zeros(nx))
  electrode=[(iso(znn),.0998)]if kind=='driven'else[]
  front=8. if kind=='driven' else 4.;back=8. if kind=='thermal' else 4.;d=8.353152083061113 if kind=='thermal' else a.d
  layers=[(iso(support),front)]+electrode+[(iso(dn),.01)]+[(old.dielectric(ne,no,th[:,j],ph[:,j]),d/a.slices)for j in range(a.slices)]+[(iso(dn),.01)]+electrode+[(iso(support),back)]
  S=[np.zeros((2*count,2*count),complex)for _ in range(4)];cond=0.
  for fixed,mf in enumerate(m):
   if kind!='thermal':qx,qy=lam*m/24,np.full(N,lam*mf/48);idx=np.arange(N)+fixed*N
   else:qx,qy=np.full(N,lam*mf/24),lam*m/48;idx=np.arange(N)*N+fixed
   M=np.eye(4*N,dtype=complex)
   for ep,dd in layers:M=expm(2j*np.pi/lam*dd*old.generator(ep,np.diag(qx),np.diag(qy),m))@M
   local=old.to_scattering(M,old.admittance(qx,qy));ii=np.r_[idx,idx+count]
   for b,c in zip(S,local):b[np.ix_(ii,ii)]=c
   cond=max(cond,float(np.linalg.cond(M)))
  return S,cond
 waves=np.load(a.grid)['wavelength_um'] if a.grid else (np.unique(np.r_[np.linspace(.4,.78,41),np.linspace(.78,2.5,87)]) if a.dense else np.array([.4,.45,.55,.65,.78,1.,1.25,1.6,2.,2.5]));waves=waves[a.shard::a.shards];vals={};di=[];tic=time.perf_counter()
 mx,my=np.meshgrid(m,m,indexing='xy');qx,qy=mx.ravel()/24,my.ravel()/48;incident=np.zeros((2*count,2));incident[a.order*N+a.order,0]=1;incident[count+a.order*N+a.order,1]=1
 for lam in waves:
  Y=old.admittance(lam*qx,lam*qy);diagn=[]
  for ti in range(2):
   c,cc=cell('compensator',0,ti,lam);t,ct=cell('thermal',0,ti,lam);after,err=coupled.cascade(c,t)
   for vi,V in enumerate([0.,a.bias]):
    e,ce=cell('driven',V,ti,lam);S,er=coupled.cascade(e,after);forward=S[2]@incident;back=S[0]@incident;T=float(np.real(np.sum(forward.conj()*(Y@forward)))/2);R=float(np.real(np.sum(back.conj()*(Y@back)))/2)
    for label,field in [('E',forward),('G',Y@forward)]:vals.setdefault(f'V{vi}T{ti}__{label}',[]).append(np.stack([field[:count],field[count:]],axis=1).reshape(N,N,2,2))
    diagn.append({'vi':vi,'Tindex':ti,'T':T,'R':R,'A':1-T-R,'maxcondition':max(cc,ct,ce),'cascade_residual':max(err,er)})
  di.append({'wavelength_um':float(lam),'states':diagn});print(json.dumps({'done':len(di),'total':len(waves),'elapsed_s':time.perf_counter()-tic}),flush=True)
 np.savez_compressed(a.out/'scattered_fields.npz',wavelength_um=waves,harmonics=m,**{k:np.array(v)for k,v in vals.items()})
 (a.out/'results.json').write_text(json.dumps({'scope':'same-device fixed0/bias V crossed passiveE7 compensation, same15/50C, full vector three-cell cascading','d_electric_um':a.d,'bias_V':a.bias,'main_layer_count':16,'physical_supports':4,'order':a.order,'slices':a.slices,'diagnostics':di,'limits':['1D screening is separate; this usesactual2Drelaxedfields','compensator has no electrode; quarter-domain lateral registration shifts same8step physical texture bypi/2','thermal field usesproper spatial/axis90deg rotation','periodic full vector scattering; finite aperture separate envelope projection','same A film optical/electrical/anchoring transfers remain; peripheral inventory unclosed']},indent=2))
def readout(a):
 from experiments.q2_package_A_20261105 import readout as run
 run(a)
def main():
 p=argparse.ArgumentParser();p.add_argument('action',choices=['screen','director','optics','readout']);p.add_argument('--out',type=Path,required=True);p.add_argument('--nx',type=int,default=32);p.add_argument('--nz',type=int,default=17);p.add_argument('--d',type=float,default=4.);p.add_argument('--bias',type=float,default=1.65);p.add_argument('--maxiter',type=int,default=2800);p.add_argument('--fields',type=Path,default=ROOT/'runs/20261105-q2-finish-decouple-director32-d4-01');p.add_argument('--slices',type=int,default=32);p.add_argument('--order',type=int,default=4);p.add_argument('--grid',type=Path);p.add_argument('--dense',action='store_true');p.add_argument('--shards',type=int,default=1);p.add_argument('--shard',type=int,default=0);p.add_argument('--runs',type=Path,nargs='+');p.add_argument('--hole',type=Path,default=ROOT/'runs/20261105-q2-package-device-kernels-01/inner700/gram.npz');a=p.parse_args();a.out.mkdir(exist_ok=False,parents=True);globals()[a.action](a);(a.out/'source.py').write_bytes(Path(__file__).read_bytes())
if __name__=='__main__':main()
