"""Single authorized denseVISpeak append to the completed six-point audit."""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import argparse,inspect,json,sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments import q2_finish_assembly_20261105_d855order as audit
BASE=ROOT/'runs/20261105-q2-finish-assembly-d855-order-selection-02'
DENSE=ROOT/'runs/20261105-q2-finish-decouple-source25-phase855-readout64-837-600-01/spectra.npz'


def select(a):
    m=audit.checked(BASE);z=np.load(DENSE);w=z['wavelength_um'];T=z['total_T'];ix=np.flatnonzero((w>=.4)&(w<=.78));dd=abs(T[:,1]-T[:,0]);at=np.unravel_index(np.argmax(dd[:,ix]),dd[:,ix].shape);j=ix[at[1]];lam=float(w[j]);assert abs(lam-.4227257355427798)<1e-13
    np.savez_compressed(a.out/'grid.npz',wavelength_um=np.array([lam]));(a.out/'effective_optics_source.py').write_bytes((BASE/'effective_optics_source.py').read_bytes());m['original_six_wavelength_um']=m['wavelength_um'];m['wavelength_um']=[lam];m['selection']='Singleauthorizedexactactual837savedVISthermalglobalpeak;appendonlynotrescan';m['dense_peak']={'wavelength_um':lam,'Vindex':int(at[0]),'absolute_cross_pp':float(dd[at[0],j]*100),'dense_spectra':str(DENSE.relative_to(ROOT)),'dense_spectra_SHA256':audit.sha(DENSE)};m['original_frozen_snapshot']=str(BASE.relative_to(ROOT));m['frozen_inputs_SHA256'][str(Path(__file__).resolve().relative_to(ROOT))]=audit.sha(__file__);m['frozen_inputs_SHA256'][str(DENSE.relative_to(ROOT))]=audit.sha(DENSE);audit.save(a.out/'results.json',m);print(json.dumps(m['dense_peak']),flush=True)


def compare(a):
    from experiments import q2_finish_order_control_20261105 as common
    text=inspect.getsource(common.compare);old="original_runs=[ROOT/f'runs/20261105-q2-finish-decouple-SiNx-optics64-713-{j}'for j in range(3)]";new="original_runs=[ROOT/f'runs/20261105-q2-finish-decouple-source25-phase855-optics64-missing713-{j}'for j in range(4)]";assert text.count(old)==1;text=text.replace(old,new).replace('original713','original_dense713');ns=dict(common.__dict__);exec(text,ns);ns['compare'](a)
    r=json.loads((a.out/'results.json').read_text());r['actual_candidate']='ExternalAR19/d8.55/25-50/9.235V/d281source/250468ZnO';r['single_authorized_dense_peak_append']=True;r['all_frozen_inputs_match']=bool(audit.checked(a.selection));audit.save(a.out/'results.json',r);(a.out/'executed_compare.py').write_text(text,encoding='utf-8')


def main():
    p=argparse.ArgumentParser();p.add_argument('action',choices=['select','solve','compare']);p.add_argument('--out',type=Path,required=True);p.add_argument('--selection',type=Path);p.add_argument('--order',type=int);p.add_argument('--slices',type=int);p.add_argument('--low',type=Path);p.add_argument('--high',type=Path);a=p.parse_args()
    for k in ['out','selection','low','high']:
        if getattr(a,k,None)is not None:setattr(a,k,getattr(a,k).resolve())
    a.out.mkdir(parents=True,exist_ok=False);(a.out/'source.py').write_bytes(Path(__file__).read_bytes());{'select':select,'solve':audit.solve,'compare':compare}[a.action](a)
if __name__=='__main__':main()
