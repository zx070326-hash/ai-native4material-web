"""Nine constitutive-power scenarios at fixed physical voltage and thickness.

This is a new1DFrank/Gauss mechanism calculation, not measured material data,
not the saved2Ddirectors, and not a finite-device uncertainty guarantee.
"""
import os
for name in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[name]='1'
from pathlib import Path
import sys,argparse,json,hashlib,time
import numpy as np
import autograd.numpy as anp
from autograd import value_and_grad
from scipy.optimize import minimize
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments.q2_finish_decouple_20261105 import indices

def ratio(T):
 e,o=indices(T,.589);e25,o25=indices(25,.589);return float((e-o)/(e25-o25))

def solve(T,p,q,voltage,support,nz):
 d=2.5e-6;dz=1/(nz-1);Wp=2e-4;rt=ratio(T);K=np.array([11.1,6.5,17.1])*1e-12*rt**p;de=13.8*rt**q;epsp=5.2;extra=2*.02e-6/7.5+(2*8e-6/9 if support else 0.)
 def energies(th):
  mid=.5*(th[:-1]+th[1:]);kp=K[0]*anp.cos(mid)**2+K[2]*anp.sin(mid)**2
  elastic=.5*anp.sum(kp*((th[1:]-th[:-1])/dz)**2)*dz/d
  anchoring=.5*Wp*(anp.sin(th[0])**2+anp.sin(th[-1])**2)
  lc_inverse=d*anp.sum(1/(epsp+de*anp.sin(mid)**2))*dz
  electro=-.5*8.8541878128e-12*voltage**2/(lc_inverse+extra)
  return (elastic+anchoring+electro)/(K[0]/d)
 sols=[]
 for amp in [.025,1.3]:
  seed=amp*np.sin(np.linspace(0,np.pi,nz))+.005
  sol=minimize(value_and_grad(energies),seed,jac=True,method='L-BFGS-B',bounds=[(-np.pi/2+1e-6,np.pi/2-1e-6)]*nz,options={'maxiter':1800,'maxcor':30,'ftol':1e-13,'gtol':1e-8});sols.append(sol)
 sol=min(sols,key=lambda r:r.fun);th=sol.x;mid=.5*(th[:-1]+th[1:]);lc_inv=d*np.sum(1/(epsp+de*np.sin(mid)**2))*dz
 return th,{'T_C':T,'ratio_dn589_over_dn25':rt,'K_pN':(K*1e12).tolist(),'delta_epsilon':de,'epsilon_perp':epsp,'voltage_terminal':voltage,'mean_LC_voltage_1D':float(voltage*lc_inv/(lc_inv+extra)),'theta_max_deg':float(np.rad2deg(abs(th).max())),'energies_dimensionless':[float(r.fun)for r in sols],'seed_headtail_axis_diff_max_deg':float(np.rad2deg(abs(sols[0].x-sols[1].x)).max()),'selected_gradient_inf':float(abs(sol.jac).max()),'selected_success':bool(sol.success),'seed_success':[bool(r.success)for r in sols]}

def main():
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--nz',type=int,default=65);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False)
 w=np.unique(np.r_[np.linspace(.4,.78,381),np.linspace(.78,2.5,345)]);vis=(w<=.78);rows=[];arrays={};tic=time.perf_counter()
 for mode,V,support in [('internal',1.5,False),('external',12.235,True)]:
  for pp in [1,2,3]:
   for qq in [0,1,2]:
    conversions=[];phases=[];checks=[]
    for T in [15,50]:
     th,ck=solve(T,pp,qq,V,support,a.nz);checks.append(ck);ne,no=indices(T,w);neff=ne*no/np.sqrt(ne**2*np.sin(th[:,None])**2+no**2*np.cos(th[:,None])**2)
     active=2.5*np.trapezoid(neff-no,dx=1/(a.nz-1),axis=0);passive=2.5*(ne-no)
     delta=active-passive;phases.append(delta);conversions.append(np.sin(np.pi*delta/w)**2)
     arrays[f'{mode}_p{pp}_q{qq}_T{T}__theta_rad']=th
    C=np.array(conversions);cross=abs(C[1]-C[0]);means=np.trapezoid(C[:,vis],w[vis],axis=-1)/.38
    row={'mode':mode,'p_K':pp,'q_de':qq,'fixed_terminal_voltage_V':V,'d_both_um':2.5,'VIS_conversion_byT_pp':(100*means).tolist(),'min_VIS_conversion_pp':float(100*min(means)),'VIS_thermal_signed_mean_pp':float(100*np.trapezoid((C[1]-C[0])[vis],w[vis])/.38),'VIS_thermal_meanabs_pp':float(100*np.trapezoid(cross[vis],w[vis])/.38),'VIS_thermal_peak_pp':float(100*cross[vis].max()),'retardance550_driven_minus_compensator_um':[float(np.interp(.55,w,r))for r in phases],'source_checks':checks};rows.append(row)
    arrays[f'{mode}_p{pp}_q{qq}__conversion']=C;arrays[f'{mode}_p{pp}_q{qq}__delta_retardance_um']=np.array(phases);print(json.dumps({k:v for k,v in row.items()if k!='source_checks'}),flush=True)
    (a.out/'partial_results.json').write_text(json.dumps(rows,indent=2))
 result={'scope':'Only9physicalconstitutive(p,q)scenarios each fixedinternal/externalvoltage;1DselfconsistentFrank/Gauss+crossedpassiveE7retardance','parameters':{'T_C':[15,50],'dn_reference_um':.589,'d_each_um':2.5,'voltage_pair_internal':[0,1.5],'voltage_pair_external':[0,12.235],'Wp_J_m2':2e-4,'SiNx_each_um':.02,'SiNx_epsilon_scenario':7.5,'Al2O3_each_um_external':8.,'Al2O3_epsilon_scenario':9.,'K25_pN':[11.1,6.5,17.1],'epsilon_perp_fixed':5.2,'delta_epsilon25':13.8,'nz':a.nz},'rows':rows,'interpretation':['Threshold-balanceproxyhasVth²proportionalK11/de, so differentialexponentp-qisaprediction;finiteanchoringandseriesdielectricsbreakexactp-qequivalence.','AllstatesusefixedsamevoltageatbothT;noadaptivevoltageorreselectedthickness.','Zero-fieldpassive1Dcellhasanalyticplanarminimumtheta0, yieldingd(ne-no);thisdoesnotreplacepatterned2Dsource.','Noneofp/qrangeisameasureduncertaintyinterval;noactualdeviceT/bluepassivity/absorption/finitehole/NIRthermalmoduleisclaimed.','Surfaceazimuthalpattern/WaandlateralGaussarenotrepresentedinthe1Dmechanismreduction.'],'input_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()for p in [Path(__file__),ROOT/'data/q2_current/Li2005_E7_Cauchy.csv']},'elapsed_s':time.perf_counter()-tic}
 (a.out/'results.json').write_text(json.dumps(result,indent=2));np.savez_compressed(a.out/'fields_spectra.npz',wavelength_um=w,**arrays);(a.out/'source.py').write_bytes(Path(__file__).read_bytes())
if __name__=='__main__':main()
