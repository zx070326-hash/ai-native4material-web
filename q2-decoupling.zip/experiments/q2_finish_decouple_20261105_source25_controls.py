"""Exact same-source optical factorization controls, never new candidates.

FreezeThermal/freezeDC mix module temperatures solely for causal decomposition.
SinglePass omits inter-module returns while retaining each cell's full internal
multilayer S; its missing forward power is NOT interpreted as absorption.
"""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import sys,json,hashlib,argparse,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments import q2_finish_decouple_20261105_external_ar_source25 as pilot
base=pilot.base;source=pilot.source
start=source.index(' for lam in waves:')
source=source[:start]+'''
 controls=['reference','freezeThermal','freezeDC','singlePass']
 for lam in waves:
  Y=old.admittance(lam*qx,lam*qy);diagn=[];cs=[];ts=[];es={};conds={}
  gap=coupled.uniform_layer(1.,2.,float(lam),lam*qx,lam*qy)
  for ti in range(2):
   c,cc=cell('compensator',0,ti,lam);t,ct=cell('thermal',0,ti,lam);cs.append(c);ts.append(t);conds[ti]=[cc,ct]
   for vi,V in enumerate([0.,a.bias]):es[ti,vi]=cell('driven',V,ti,lam)
  for control in controls:
   for ti in range(2):
    dc_ti=0 if control=='freezeDC' else ti
    thermal_ti=0 if control=='freezeThermal' else ti
    c,t=cs[dc_ti],ts[thermal_ti]
    after,err=coupled.cascade(c,t);after,er_gap=coupled.cascade(gap,after);err=max(err,er_gap)
    for vi,V in enumerate([0.,a.bias]):
     e,ce=es[dc_ti,vi]
     if control=='singlePass':
      forward=t[2]@c[2]@gap[2]@e[2]@incident;back=np.zeros_like(forward);er=0.
     else:
      S,er=coupled.cascade(e,after);forward=S[2]@incident;back=S[0]@incident
     T=float(np.real(np.sum(forward.conj()*(Y@forward)))/2);R=float(np.real(np.sum(back.conj()*(Y@back)))/2)
     for label,field in [('E',forward),('G',Y@forward)]:vals.setdefault(f'{control}__V{vi}T{ti}__{label}',[]).append(np.stack([field[:count],field[count:]],axis=1).reshape(N,N,2,2))
     diagn.append({'control':control,'vi':vi,'Tindex':ti,'T':T,'R':R,'A':1-T-R,'maxcondition':max(conds[dc_ti][0],conds[thermal_ti][1],ce),'cascade_residual':max(err,er)})
  di.append({'wavelength_um':float(lam),'states':diagn});print(json.dumps({'done':len(di),'total':len(waves),'elapsed_s':time.perf_counter()-tic}),flush=True)
 for control in controls:
  out=a.out/control;out.mkdir(exist_ok=False)
  np.savez_compressed(out/'scattered_fields.npz',wavelength_um=waves,harmonics=m,**{k[len(control)+2:]:np.array(v)for k,v in vals.items()if k.startswith(control+'__')})
  diagnostics=[{'wavelength_um':d['wavelength_um'],'states':[s for s in d['states']if s['control']==control]}for d in di]
  result={'scope':'Causal optical diagnostic ONLY; frozen modules or removed intermodule returns are NOT physical sameuniformT candidates','diagnostic_control':control,'d_electric_um':a.d,'bias_V':a.bias,'temperatures_C':[25,50],'thermal_LC_um':9.8,'main_layer_count':19,'physical_supports':5,'order':a.order,'slices':a.slices,'diagnostics':diagnostics if control!='singlePass'else[],'limits':['Frozenmoduletemperaturecontrolsarenotnewuniformtemperaturedevices.','SinglePassretainsintracellreflectionbutomitscrosscellreturns;lostforwardpowerisNOTabsorption.','Allotherfield/material/geometry/finitescreenparametersunchanged.']}
  if control=='singlePass':result['single_pass_forward_checks']=[{'wavelength_um':d['wavelength_um'],'states':[{'vi':s['vi'],'Tindex':s['Tindex'],'forward_T':s['T'],'untracked_1minusT':1-s['T']}for s in d['states']if s['control']==control]}for d in di]
  (out/'results.json').write_text(json.dumps(result,indent=2))
 (a.out/'results.json').write_text(json.dumps({'scope':'Factorialsame-cell-Sopticaldiagnostic,notfournewcandidates','controls':controls,'actual_wavelengths':len(waves),'elapsed_s':time.perf_counter()-tic},indent=2))
'''
exec(source,base.__dict__)

def main():
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--fields',type=Path,required=True);p.add_argument('--shard',type=int,default=0);p.add_argument('--shards',type=int,default=2);a=p.parse_args();a.fields=a.fields.resolve();a.out=a.out.resolve();a.bias=9.235;a.d=2.5;a.order=4;a.slices=32;a.dense=True;a.grid=None
 fields=np.load(a.fields/'fields.npz');required=[f'{kind}_T{T}_V{V:g}__{s}'for kind,vs in [('electric',[0,9.235]),('thermal',[0])]for T in [25,50]for V in vs for s in ['theta_rad','phi_correction_rad']]
 assert all(k in fields and fields[k].shape==(64,33)for k in required)
 deps=[Path(__file__),Path(pilot.__file__),Path(pilot.ar.__file__),Path(pilot.ar.ext.__file__),Path(pilot.ar.ext.adapter.__file__),Path(base.__file__)];frozen={f.name:f.read_bytes()for f in deps};a.out.mkdir(parents=True,exist_ok=False)
 config={'argv':sys.argv,'time_unix':time.time(),'fields_sha256':hashlib.sha256((a.fields/'fields.npz').read_bytes()).hexdigest(),'source_sha256':{n:hashlib.sha256(v).hexdigest()for n,v in frozen.items()},'fixed_source_temperatures_C':[25,50],'fixed_bias_V':9.235,'controls':'reference, freezeThermal, freezeDC, singlePass; diagnosticsnotnewcandidates','interpretation':'CellScomputedonceperrealT/lambda; fourth-orderfactorialcausalcomparison, no material/source reoptimization'}
 (a.out/'launch.json').write_text(json.dumps(config,indent=2));(a.out/'effective_optics_source.py').write_text(source)
 for n,v in frozen.items():(a.out/('dependency_'+n)).write_bytes(v)
 (a.out/'source.py').write_bytes(frozen[Path(__file__).name]);base.optics(a)
 for control in ['reference','freezeThermal','freezeDC','singlePass']:
  r=json.loads((a.out/control/'results.json').read_text());r['diagnostic_launch']=config;(a.out/control/'results.json').write_text(json.dumps(r,indent=2))
if __name__=='__main__':main()
