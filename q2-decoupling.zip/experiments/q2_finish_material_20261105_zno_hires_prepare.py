"""Exact-node loadable scenarios and readback for the frozen high-res graph."""
from pathlib import Path
import json,hashlib,shutil
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'runs/20261105-q2-finish-material-ZnO-hires-calibration-01'
OUT=ROOT/'runs/20261105-q2-finish-material-ZnO-hires-input-01'
OUT.mkdir(parents=True,exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((SRC/'results.json').read_text())
n=np.loadtxt(SRC/'ZnO2022_Fig5d_hires_n_raw.csv',delimiter=',',skiprows=1)
k=np.loadtxt(SRC/'ZnO2022_Fig5d_hires_k_raw.csv',delimiter=',',skiprows=1)
old=np.loadtxt(ROOT/'data/q2_package_A_20261105/ZnO2022_Fig5d_passive_digitized.csv',delimiter=',',skiprows=1)
w=np.unique(np.r_[.38,.4,.5,.55,.78,1.,1.5,2.,2.5,n[(n[:,0]>.38)&(n[:,0]<2.5),0],k[(k[:,0]>.38)&(k[:,0]<2.5),0]])
nr=np.interp(w,*n[:,:2].T);kr=np.interp(w,*k[:,:2].T)
slope=r['tail_scenarios']['poly1_last0.3um']['coef_descending'][0]
klin=kr.copy();tail=w>k[-1,0];klin[tail]=k[-1,1]+slope*(w[tail]-k[-1,0])
tables={}
for name,ks in [('linear',klin),('hold',kr)]:
 p=OUT/f'ZnO2022_Fig5d_hires_exactnodes_tail_{name}_scenario.csv'
 np.savetxt(p,np.c_[w,nr,np.maximum(ks,0)],delimiter=',',header='lambda_um,n,k',comments='',fmt='%.14g')
 tables[name]={'path':str(p.relative_to(ROOT)),'sha256':sha(p),'rows':len(w),'domain_um':[float(w.min()),float(w.max())],'passive':True,'k_2p5':float(ks[-1])}
 assert np.isfinite(np.loadtxt(p,delimiter=',',skiprows=1)).all()
comparison={}
for lo,hi in ((.38,.42),(.42,.78),(.78,2.4230769230769234)):
 q=np.linspace(lo,hi,2001);dn=np.interp(q,*n[:,:2].T)-np.interp(q,old[:,0],old[:,1]);dk=np.maximum(np.interp(q,*k[:,:2].T),0)-np.interp(q,old[:,0],old[:,2]);comparison[f'{lo:g}-{hi:g}um']={'n_rms':float(np.sqrt(np.mean(dn**2))),'n_maxabs':float(abs(dn).max()),'k_rms':float(np.sqrt(np.mean(dk**2))),'k_maxabs':float(abs(dk).max())}
points=[]
for lam in (.38,.4,.5,.55,.78,1,1.5,2,2.4230769230769234,2.5):
 ki=float(np.interp(lam,*k[:,:2].T));ki=ki if lam<=k[-1,0]else float(k[-1,1]+slope*(lam-k[-1,0]))
 points.append({'lambda_um':lam,'n':float(np.interp(lam,*n[:,:2].T)),'k_raw_or_linear_tail':ki,'k_passive':max(ki,0),'tail_model':bool(lam>k[-1,0])})
out={'graph_calibration_source':str(SRC.relative_to(ROOT)),'tables':tables,'same_band_comparison_to_legacy_passive':comparison,'exact_selected_values':points,'raw_k_min':r['raw_k_min'],'raw_k_negative_points':r['raw_k_negative_point_count'],'notes':['Retains union of every colored-column n/k node in380-2500nm; no additional regular-grid resampling near UV edge.','The selected_values.k_linear_scenario field in calibration01 was interpolated from its713-point scenario table and can differ near the steep UV edge. Exact values here supersede that auxiliary field only; original raw n/k and axis calibration are unchanged.','Nonnegative projection is explicit, a graphical passivity repair below pixel sensitivity rather than evidence of true zero loss.','2444.805-2500nm linear tail is a declared graph-continuation model, not experimental confidence interval or measured endpoint.','No optical solver is invoked.'],'entrypoint_sha256':sha(Path(__file__))}
(OUT/'results.json').write_text(json.dumps(out,indent=2));shutil.copy2(__file__,OUT/'source.py')
print(json.dumps(out,indent=2))
