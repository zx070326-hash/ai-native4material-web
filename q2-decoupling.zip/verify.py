from pathlib import Path
import hashlib,json,numpy as np
r=Path(__file__).resolve().parent
m=json.loads((r/'MANIFEST.json').read_text())
for p,h in m.items(): assert hashlib.sha256((r/p).read_bytes()).hexdigest()==h,p
s=json.loads((r/'q2_finish_summary.json').read_text(encoding='utf-8'))
for rec in s['readouts']:
 z=np.load(r/rec['spectra']);w=z['wavelength_um'];t=z[rec['spectrum_key']]
 def avg(v,lo,hi):
  ix=(w>=lo)&(w<=hi);x=w[ix];y=v[...,ix]
  return np.sum((y[...,1:]+y[...,:-1])*np.diff(x)/2,axis=-1)/(hi-lo)
 v=avg(t,.4,.78);n=avg(t,.78,2.5)
 main=np.array([max(0,.95*min(abs(v[1]-v[0]))-.05)*100,min(abs(n[:,1]-n[:,0]))*100])
 assert max(abs(main-rec['main_pp']))<1e-9
 for name,lo,hi,d in [('VIS',.4,.78,t[:,1]-t[:,0]),('NIR',.78,2.5,t[1]-t[0])]:
  assert max(abs(100*avg(abs(d),lo,hi)-rec['cross'][name]['mean_absolute_spectral_pp']))<1e-9
 print(rec['label'],main.tolist(),rec['nodes'])
print('Verified manifest and saved spectra; no field or manufacturing certification.')
