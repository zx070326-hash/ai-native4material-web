from pathlib import Path
import json,numpy as np
r=Path(__file__).resolve().parent;j=json.loads((r/'data.json').read_text(encoding='utf8'));rows=[]
for q in j['rows']:
 folder=Path(q['spectra']).parent.name;z=np.load(r/'cases'/folder/'spectra.npz');w=z['wavelength_um'];T=z['total_T']
 def mean(x,lo,hi):
  mask=(w>=lo)&(w<=hi);return np.trapezoid(x[...,mask],w[mask],axis=-1)/(hi-lo)
 v,n=mean(T,.4,.78),mean(T,.78,2.5);m=[100*(.95*min(abs(v[1]-v[0]))-.05),100*min(abs(n[:,1]-n[:,0]))];error=float(max(abs(np.array(m)-q['main_pp'])));assert error<1e-10;rows.append({'case':q['label'],'error_pp':error})
print(json.dumps({'scope':'Saved-spectrum arithmetic only','cases':rows,'full_problem_solved':False}))
