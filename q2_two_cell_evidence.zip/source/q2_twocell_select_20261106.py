"""Assemble only genuinely solved nodes; keep exact713 and union837 separate."""
from pathlib import Path
import argparse,json,hashlib
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--runs',type=Path,nargs='+',required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--grid-root',type=Path,default=ROOT/'runs/20261106-q2-twocell-eight-dense-grid-01');a=p.parse_args();a.out=a.out.resolve();a.out.mkdir(parents=True,exist_ok=False);runs=[q.resolve()for q in a.runs];zs=[np.load(q/'scattered_fields.npz')for q in runs];rs=[json.loads((q/'results.json').read_text())for q in runs];waves=np.r_[tuple(z['wavelength_um']for z in zs)];assert len(np.unique(waves))==len(waves)==837
 first=rs[0];cfg=first['physical_override'];assert all(r['physical_override']==cfg for r in rs)
 assert all(all(v for v in json.loads((q/'postflight.json').read_text()).values())for q in runs)
 ordering=np.argsort(waves);waves=waves[ordering];values={k:np.concatenate([z[k]for z in zs])[ordering]for k in zs[0].files if k not in ['wavelength_um','harmonics']};diag={d['wavelength_um']:d for r in rs for d in r['diagnostics']};assert all(np.array_equal(z['harmonics'],zs[0]['harmonics'])for z in zs)
 for name in ['standard713','union837']:
  w=np.load(a.grid_root/f'{name}.npz')['wavelength_um'];idx=np.searchsorted(waves,w);assert np.array_equal(waves[idx],w);folder=a.out/name;folder.mkdir();np.savez_compressed(folder/'scattered_fields.npz',wavelength_um=w,harmonics=zs[0]['harmonics'],**{k:v[idx]for k,v in values.items()})
  r={**first,'diagnostics':[diag[x]for x in w],'sampling_scope':f'Exact actual{name}; no interpolation or synthetic midpoints','source_runs':[str(q.relative_to(ROOT))for q in runs]};(folder/'results.json').write_text(json.dumps(r,indent=2));(folder/'postflight.json').write_text(json.dumps({'exact_actual_nodes':True,'source_postflights_pass':True}))
 result={'waves':len(waves),'sampling':'713 exact subset and837union kept separate','inputs':{str(q.relative_to(ROOT)):sha(q/'scattered_fields.npz')for q in runs},'grid_inputs':{name:sha(a.grid_root/f'{name}.npz')for name in ['standard713','union837']},'selector_sha256':sha(__file__)};(a.out/'results.json').write_text(json.dumps(result,indent=2));(a.out/'source.py').write_bytes(Path(__file__).read_bytes());print(json.dumps(result))
if __name__=='__main__':main()
