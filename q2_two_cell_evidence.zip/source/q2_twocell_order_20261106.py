"""Actual dense12entity seven-point order/slice and full169-mode hole control."""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import argparse,inspect,json,hashlib,sys
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--case',choices=['eight','mixed'],default='eight');a=p.parse_args();a.out=a.out.resolve();a.out.mkdir(parents=True,exist_ok=False)
 from experiments import q2_finish_decouple_20261105_solid_interface as original
 from experiments import q2_package_device_20261105 as kernel
 from experiments.q2_output_screen import tilted_project
 fields=ROOT/('runs/20261106-q2-twocell-eight-source64-handoff-01'if a.case=='eight'else'runs/20261106-q2-twocell-mixed-source64-01');modal=ROOT/('runs/20261106-q2-twocell-eight-selected64-02/union837'if a.case=='eight'else'runs/20261106-q2-twocell-mixed-selected64-01/union837');readout=ROOT/('runs/20261106-q2-twocell-eight-readout64-union837-600-02'if a.case=='eight'else'runs/20261106-q2-twocell-mixed-readout64-union837-700-01');inner=600 if a.case=='eight'else 700
 z=np.load(modal/'scattered_fields.npz');s=np.load(readout/'spectra.npz');w=z['wavelength_um'];T=s['total_T'];assert np.array_equal(w,s['wavelength_um']);vt=abs(T[:,1]-T[:,0]);ve=abs(T[1]-T[0]);qv=np.where(w<=.78)[0];qn=np.where(w>=.78)[0];iv=qv[np.unravel_index(np.argmax(vt[:,qv]),vt[:,qv].shape)[1]];inn=qn[np.unravel_index(np.argmax(ve[:,qn]),ve[:,qn].shape)[1]];idx=np.unique([int(np.argmin(abs(w-lam)))for lam in [.4,.55,.78,1.4,2.5]]+[int(iv),int(inn)]);ww=w[idx];np.savez_compressed(a.out/'grid.npz',wavelength_um=ww)
 source=(ROOT/f'runs/20261106-q2-twocell-{a.case}-optics64-127-01/effective_optics_source.py').read_text();cfg=json.loads((fields/'results.json').read_text())['parameters'];frozen={str(q.relative_to(ROOT)):sha(q)for q in [fields/'fields.npz',modal/'scattered_fields.npz',readout/'spectra.npz',Path(__file__).resolve()]};(a.out/'launch.json').write_text(json.dumps({'selected_actual_wavelengths':ww.tolist(),'dense_VISthermal_peak':float(w[iv]),'dense_NIRvoltage_peak':float(w[inn]),'inputs':frozen,'source_sha256':hashlib.sha256(source.encode()).hexdigest()},indent=2));(a.out/'effective_optics_source.py').write_text(source)
 high=a.out/'high';high.mkdir();ns=original.base.__dict__;exec(source,ns);opt=argparse.Namespace(fields=fields,out=high,d=cfg['driver_d_um'],bias=4.,order=6,slices=64,dense=True,grid=a.out/'grid.npz',shard=0,shards=1);ns['optics'](opt);h=np.load(high/'scattered_fields.npz');hi={k:h[k]for k in h.files};low={k:(z[k]if k=='harmonics'else z[k][idx])for k in z.files}
 # Use the same analytic source integral and exact geometry, changing only h.
 src=inspect.getsource(kernel.gram);assert src.count('h=np.arange(-4,5)')==1;src=src.replace('h=np.arange(-4,5)','h=np.arange(-6,7)');kns=dict(kernel.gram.__globals__);exec(src,kns);g169=kns['gram'](inner,ww,5.,False);src_low=kernel.gram(inner,ww,5.,False);L=tilted_project(low,src_low,25.,periods=(12.,24.));H=tilted_project(hi,g169,25.,periods=(12.,24.));common={k:(v if k in ['wavelength_um','harmonics']else v[:,2:-2,2:-2])for k,v in hi.items()};common['harmonics']=np.arange(-4,5);HC=tilted_project(common,src_low,25.,periods=(12.,24.))
 new=np.ones((13,13),bool);new[2:-2,2:-2]=False;tails=[]
 for vi in range(2):
  for ti in range(2):tails.append(.5*np.real(np.sum(hi[f'V{vi}T{ti}__E'][:,new]*hi[f'V{vi}T{ti}__G'][:,new].conj(),axis=(1,2,3))))
 lowr=json.loads((modal/'results.json').read_text());lowmap={d['wavelength_um']:d for d in lowr['diagnostics']};highr=json.loads((high/'results.json').read_text());diffs=[]
 for d in highr['diagnostics']:
  baseline=lowmap[d['wavelength_um']]
  for x,y in zip(d['states'],baseline['states']):diffs.append([100*abs(x[k]-y[k])for k in ['R','T','A']])
 np.savez_compressed(a.out/'hole_comparison.npz',wavelength_um=ww,low81_hole=L,high169_hole=H,high_common81_hole=HC,added_mode_power=np.array(tails));result={'scope':'Actual12entity dense-selected seven-point joint order4/slices32->6/64; exact selected-lambda finite hole Gram, high includes all169 modes/cross terms','wavelengths_um':ww.tolist(),'max_periodic_RTA_difference_pp':np.max(diffs,axis=0).tolist(),'max_full169_hole_difference_pp':float(100*abs(H-L).max()),'max_common81_hole_difference_pp':float(100*abs(HC-L).max()),'max_added88_interference_effect_pp':float(100*abs(H-HC).max()),'max_added88_transmitted_power_pp':float(100*np.max(tails)),'limits':['Only selected points, joint order/slice changes not separated','Finite-hole flux includes169 coherent channels; finite-exterior and carbon transmission corrections are not rebuilt here','Not a whole-band or uniform finite-domain Maxwell error bound','Director remains actual64 source and material Fourier128 sampling'],'all_declared_inputs_still_match':all(sha(ROOT/k)==v for k,v in frozen.items())};assert result['all_declared_inputs_still_match'];(a.out/'results.json').write_text(json.dumps(result,indent=2));(a.out/'source.py').write_bytes(Path(__file__).read_bytes());print(json.dumps(result))
if __name__=='__main__':main()
