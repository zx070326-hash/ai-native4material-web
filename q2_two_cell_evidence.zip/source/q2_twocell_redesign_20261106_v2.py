"""Explicit source handoff repair and zero-winding thermal-axis rotation.

Original raw runs/snapshots stay unchanged. Eight-step source v1 copied thermal
arrays into memory after the last save; reconstruct exactly those arrays in a
new source directory, rather than declaring the incomplete archive usable.
"""
from pathlib import Path
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
import argparse,hashlib,json,sys
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments import q2_twocell_redesign_20261106 as v1
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def recover(folder,out):
 r=json.loads((folder/'results.json').read_text());assert r['complete'];z=np.load(folder/'fields.npz');arr={k:z[k]for k in z.files};added=[]
 if r['parameters']['pattern']=='eight':
  with np.load(v1.ORIGINAL/'fields.npz')as old:
   nx,nz=r['parameters']['nx_nz']
   for T in [25,50]:
    for suffix in ['theta_rad','phi_correction_rad']:
     k=f'thermal_T{T}_V0__{suffix}';expected=v1.interp(old[k],nx,nz)
     if k in arr:assert np.array_equal(arr[k],expected)
     else:arr[k]=expected;added.append(k)
 required=[f'electric_T{T}_V{V:g}__{s}'for T in [25,50]for V in [0,4]for s in ['theta_rad','phi_correction_rad']]+[f'thermal_T{T}_V0__{s}'for T in [25,50]for s in ['theta_rad','phi_correction_rad']]
 assert all(k in arr and arr[k].shape==tuple(r['parameters']['nx_nz'])and np.isfinite(arr[k]).all()for k in required)
 np.savez_compressed(out/'fields.npz',**arr);r['handoff_recovery']={'raw_source':str(folder.relative_to(ROOT)),'raw_source_fields_sha256':sha(folder/'fields.npz'),'added_exact_thermal_arrays':added,'explanation':'v1 source saved after each driven solve then copied thermal into memory without final resave. Added exact original8.55 source interpolation to NEW archive; no new physical state was inferred.','all_required_arrays_valid':True,'thermal_input_sha256':sha(v1.ORIGINAL/'fields.npz'),'wrapper_sha256':sha(__file__)};(out/'results.json').write_text(json.dumps(r,indent=2));(out/'postflight.json').write_text(json.dumps({'all_required_arrays_valid':True,'raw_postflight':json.loads((folder/'postflight.json').read_text())},indent=2))
def main():
 p=argparse.ArgumentParser();p.add_argument('action',choices=['recover','source','optics']);p.add_argument('--pattern',choices=['eight','binary'],required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--from-source',type=Path);p.add_argument('--fields',type=Path);p.add_argument('--warm',type=Path);p.add_argument('--nx',type=int,default=64);p.add_argument('--nz',type=int,default=33);p.add_argument('--maxiter',type=int,default=1800);p.add_argument('--grid',type=Path);a=p.parse_args()
 for name in ['out','from_source','fields','warm','grid']:
  if getattr(a,name):setattr(a,name,getattr(a,name).resolve())
 a.out.mkdir(parents=True,exist_ok=False);(a.out/'source.py').write_bytes(Path(__file__).read_bytes())
 if a.action=='recover':recover(a.from_source,a.out)
 elif a.action=='source':
  final=a.out;raw=final/'raw_source';raw.mkdir();a.out=raw;v1.source(a);a.out=final;recover(raw,final)
 else:
  from experiments import q2_finish_decouple_20261105_solid_interface as original
  if a.pattern=='binary':
   old="p=2*np.pi*xx[:,None]+u+(np.pi/2 if kind=='compensator' else 0.)";assert original.source.count(old)==1
   original.source=original.source.replace(old,"p=u+(np.pi/2 if kind=='thermal' else 0.)")
   # Eight-step winding's -.25 coordinate shift supplies -pi/2 canceled by
   # +pi/2 axis rotation. Binary phi has zero winding, so rotation stays explicit.
  v1.optics(a);p=a.out/'results.json';r=json.loads(p.read_text());r['handoff_wrapper_sha256']=sha(__file__);r['thermal_axis_policy']='binary: explicit+pi/2 andcoordinate-.25; eight: winding cancellation as original';p.write_text(json.dumps(r,indent=2))
if __name__=='__main__':main()
