"""Two-axis driver, proven eight-axis thermal texture, same12 physical entities."""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import argparse,json,hashlib,sys
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments import q2_twocell_redesign_20261106 as v1
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('action',choices=['source','optics']);p.add_argument('--out',type=Path,required=True);p.add_argument('--fields',type=Path,required=True);p.add_argument('--grid',type=Path);a=p.parse_args();a.out=a.out.resolve();a.fields=a.fields.resolve();a.out.mkdir(parents=True,exist_ok=False);(a.out/'source.py').write_bytes(Path(__file__).read_bytes())
 if a.action=='source':
  r=json.loads((a.fields/'results.json').read_text());assert r['complete']and r['parameters']['pattern']=='binary';z=np.load(a.fields/'fields.npz');arr={k:z[k]for k in z.files if k.startswith('electric_')};nx,nz=r['parameters']['nx_nz'];old=np.load(v1.ORIGINAL/'fields.npz')
  for T in [25,50]:
   for s in ['theta_rad','phi_correction_rad']:
    k=f'thermal_T{T}_V0__{s}';arr[k]=v1.interp(old[k],nx,nz)
  cfg=r['parameters'];cfg.update({'thermal_pattern':'eight','pattern_axes_by_face':[2,2,8,8],'easy_axis_width_driver_thermal_um':[6,3],'surface_direction_assignments':20,'mixing_scope':'New binary driver source and unchanged8.55 thermal8step source; same deviceT/no frozen mixed-temperature modules.'});r['parameters']=cfg;r['source_combination']={'driver':str(a.fields.relative_to(ROOT)),'driver_sha256':sha(a.fields/'fields.npz'),'thermal':str(v1.ORIGINAL.relative_to(ROOT)),'thermal_sha256':sha(v1.ORIGINAL/'fields.npz')};np.savez_compressed(a.out/'fields.npz',**arr);(a.out/'results.json').write_text(json.dumps(r,indent=2));(a.out/'postflight.json').write_text(json.dumps({'combined_actual_state_arrays':True}))
 else:
  from experiments import q2_finish_decouple_20261105_solid_interface as original
  old="p=2*np.pi*xx[:,None]+u+(np.pi/2 if kind=='compensator' else 0.)";assert original.source.count(old)==1
  original.source=original.source.replace(old,"p=(2*np.pi*xx[:,None]+u) if kind=='thermal' else u")
  a.pattern='binary';v1.optics(a);p=a.out/'results.json';j=json.loads(p.read_text());j['physical_override']['thermal_axis_policy']='Eightstep thermal usescoordinate-.25 with winding/pi2 cancellation; binary driver uses zero-winding actualphi.';j['mixed_adapter_sha256']=sha(__file__);p.write_text(json.dumps(j,indent=2))
if __name__=='__main__':main()
