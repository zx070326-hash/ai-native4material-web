"""Two real LC cells: phase-selected driver and inner electrodes, 12 entities.

Eight-step reference and zero-winding two-direction surface pattern are solved
as distinct physical states. New source fields are never renamed old fields.
"""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import argparse,hashlib,inspect,json,sys,time
import numpy as np
import autograd.numpy as anp
from autograd import value_and_grad
from scipy.optimize import minimize
from scipy.interpolate import RegularGridInterpolator
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from experiments import q2_manufacturing_lc_director2d as frank
from experiments.q2_gap_director import Electric,EPS0
from experiments.q2_finish_source25_20261105 import parameters,K_at
from experiments.q2_finish_decouple_20261105 import indices
ORIGINAL=ROOT/'runs/20261105-q2-finish-assembly-phase25-d8p55-source64-01'
D=.55/sum(indices(T,.55)[0]-indices(T,.55)[1]for T in [25,50])
BIAS=4.
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def models(pattern):
 src=inspect.getsource(Electric).replace('class Electric:','class InnerElectric:').replace('-.015/d','-.02/d').replace('1+.015/d','1+.02/d')
 if pattern=='binary':src=src.replace('ph=2*np.pi*(self.x+a)/self.nx+mid(u)','ph=mid(u)')
 ns=dict(Electric.__init__.__globals__);exec(src,ns);electric=ns['InnerElectric']
 source=inspect.getsource(frank.problem)
 if pattern=='binary':
  source=source.replace('q=np.pi*d_um/period_um','q=0.')
  source=source.replace('ph=2*np.pi*(x+a)/nx+uu','ph=uu')
  source=source.replace('ph=2*np.pi*(x[:,0]+a)/nx+(1-a)*us+a*anp.roll(us,-1)','ph=(1-a)*us+a*anp.roll(us,-1)')
  source=source.replace("return (anp.floor(ph/(np.pi/8))+.5)*np.pi/8 if pattern=='8step'else ph","return anp.where(anp.mod(2*(x[:,0]+a)/nx,1)<.5,0.,np.pi/2)")
 ns=dict(frank.problem.__globals__);exec(source,ns)
 return ns['problem'],electric,source,src
def config(a):
 cfg=parameters();cfg.update({'pattern':a.pattern,'driver_d_um':D,'thermal_d_um':8.55,'fixed_terminal_V_RMS':[0,BIAS],'electrode_position':'Inside driven LC cell; stack ZnO/SiNx20nm/LC/SiNx20nm/ZnO, noAl support between electrodes','entities':12,'supports':3,'alignment_faces':4,'LC_cells':2,'nx_nz':[a.nx,a.nz],'phase_selection':'d=.55/(delta_n25(.55)+delta_n50(.55)); mean cold/hot550nm optical retardation=.275um before tilt/texture relaxation; no spectral fit','easy_axis_width_driver_thermal_um':[6,12]if a.pattern=='binary'else[1.5,3],'pattern_axes':2 if a.pattern=='binary'else 8,'count_ledger':{'Al2O3_8um':3,'ZnO_99p8nm':2,'SiNx20nm':4,'E7_LC':2,'carbon5um':1}})
 for k in ['electric_comp_d_um','support_cells_each_side','support_um_each','support_epsilon','fixed_external_V_RMS']:cfg.pop(k,None)
 return cfg
def interp(q,nx,nz):
 X,Z=np.meshgrid(np.arange(nx)/nx,np.linspace(0,1,nz),indexing='ij');return RegularGridInterpolator((np.linspace(0,1,len(q)+1),np.linspace(0,1,q.shape[1])),np.r_[q,q[:1]])(np.stack([X,Z],-1))
def source(a):
 cfg=config(a);fn,E,fs,es=models(a.pattern);deps=[Path(__file__).resolve(),Path(frank.__file__),Path(inspect.getfile(Electric)),ROOT/'experiments/q2_finish_source25_20261105.py',ROOT/'data/q2_current/Li2005_E7_Cauchy.csv',ORIGINAL/'fields.npz',ORIGINAL/'results.json'];warm=np.load(a.warm/'fields.npz')if a.warm else np.load(ORIGINAL/'fields.npz')
 if a.warm:deps += [a.warm/'fields.npz',a.warm/'results.json']
 frozen={str(p.relative_to(ROOT)):sha(p)for p in deps};(a.out/'launch.json').write_text(json.dumps({'parameters':cfg,'inputs':frozen},indent=2));(a.out/'effective_frank.py').write_text(fs);(a.out/'effective_electric.py').write_text(es);arr={};rows=[];valid=[];tic=time.perf_counter()
 # Analytic capacitor and fresh-Gauss envelope derivative for actual geometry.
 for ti,T in enumerate([25,50]):
  K=K_at(T);ep=cfg['epsilon_perp_by_T'][ti];de=cfg['delta_epsilon_by_T'][ti];ev=E(D,12,K[0],16,9,BIAS,epsa=7.5,ep=ep,de=de);zero=np.zeros(16*9*2);_,_,ck=ev.solve(zero);exact=EPS0/(K[0]*1e-12)*BIAS**2/(2*(1/ep+2*.02/(D*7.5)));assert abs(ck['positive_electric_dimensionless']/exact-1)<1e-11
  q=frank.initial(16,9,'perturbed');q[:16*9]+=.5;gr,_,_=ev.solve(q);_,eg=ev.evg(q,gr);rng=np.random.default_rng(61106);vec=rng.normal(size=q.size);vec/=np.linalg.norm(vec);h=1e-5;fd=(-ev.solve(q+h*vec)[2]['positive_electric_dimensionless']+ev.solve(q-h*vec)[2]['positive_electric_dimensionless'])/(2*h)
  ff,_,_=fn(D,12,K.tolist(),16,9,Wp=2e-4,Wa=1.14e-4,pattern='8step');v,g=value_and_grad(ff)(q);ffd=(ff(q+h*vec)-ff(q-h*vec))/(2*h);assert abs(fd-eg@vec)<1e-6 and abs(ffd-g@vec)<1e-6
  valid.append({'T':T,'capacitor_relative_error':float(abs(ck['positive_electric_dimensionless']/exact-1)),'freshGauss_gradient_error':float(abs(fd-eg@vec)),'Frank_gradient_error':float(abs(ffd-g@vec))})
 for kind in ['electric','thermal']:
  if kind=='thermal'and a.pattern=='eight':
   with np.load(ORIGINAL/'fields.npz')as z:
    for T in [25,50]:
     for suffix in ['theta_rad','phi_correction_rad']:arr[f'thermal_T{T}_V0__{suffix}']=interp(z[f'thermal_T{T}_V0__{suffix}'],a.nx,a.nz)
   continue
  for ti,T in enumerate([25,50]):
   for V in ([BIAS,0.]if kind=='electric'else[0.]):
    d=D if kind=='electric' else 8.55;period=12 if kind=='electric' else 24;nx,nz=a.nx,a.nz;K=K_at(T)
    prefix=f'{kind}_T{T}_V{V:g}';oldkey=prefix if prefix+'__theta_rad'in warm else f'{kind}_T{T}_V{9.235 if V else 0:g}'
    if a.warm:
     theta=interp(warm[oldkey+'__theta_rad'],nx,nz);u=interp(warm[oldkey+'__phi_correction_rad'],nx,nz)
    elif a.pattern=='eight':
     theta=interp(warm[oldkey+'__theta_rad'],nx,nz);u=interp(warm[oldkey+'__phi_correction_rad'],nx,nz)
    else:
     x=np.arange(nx)[:,None]/nx;z=np.linspace(0,1,nz)[None,:];theta=(.9 if V else .04)*np.sin(np.pi*z)*np.ones((nx,1));u=np.broadcast_to(np.where((2*x)%1<.5,0.,np.pi/2),(nx,nz)).copy()
    if V and not a.warm:theta=np.maximum(theta,.9*np.sin(np.linspace(0,np.pi,nz))[None,:])
    v=np.r_[theta.ravel(),u.ravel()];f,parts,meta=fn(d,period,K.tolist(),nx,nz,Wp=2e-4,Wa=1.14e-4,pattern='8step');vg=value_and_grad(f);ev=E(d,period,K[0],nx,nz,V,epsa=7.5,ep=cfg['epsilon_perp_by_T'][ti],de=cfg['delta_epsilon_by_T'][ti])
    def fun(v):
     energy,g=vg(v)
     if not V:return float(energy),g
     gr,psi,ck=ev.solve(v);_,eg=ev.evg(v,gr);return float(energy-ck['positive_electric_dimensionless']),g+eg
    initial=float(fun(v)[0]);sol=minimize(fun,v,jac=True,method='L-BFGS-B',bounds=[(-np.pi/2+1e-5,np.pi/2-1e-5)]*(nx*nz)+[(None,None)]*(nx*nz),options={'maxiter':a.maxiter,'maxcor':40,'maxls':40,'ftol':1e-13,'gtol':2e-8});th=sol.x[:nx*nz].reshape(nx,nz);u=sol.x[nx*nz:].reshape(nx,nz);_,psi,ck=ev.solve(sol.x)
    for s,q in [('theta_rad',th),('phi_correction_rad',u),('potential_V',psi)]:arr[prefix+'__'+s]=q
    rows.append({'key':prefix,'iterations':int(sol.nit),'success':bool(sol.success),'message':str(sol.message),'gradient_inf':float(abs(sol.jac).max()),'initial_energy':initial,'final_energy':float(sol.fun),'theta_max_deg':float(np.degrees(abs(th).max())),'LC_voltage_range_V':[float((psi[:,-2]-psi[:,1]).min()),float((psi[:,-2]-psi[:,1]).max())],'gauss':ck,'elapsed_s':time.perf_counter()-tic});print(json.dumps(rows[-1]),flush=True)
    np.savez_compressed(a.out/'fields.npz',**arr);(a.out/'results.json').write_text(json.dumps({'parameters':cfg,'validation':valid,'rows':rows,'complete':False},indent=2))
 result={'parameters':cfg,'validation':valid,'rows':rows,'complete':True,'warm_is_initial_guess_only':True,'thermal8step_policy':'Original8.55 true64source, interpolated for pilot only; new binarythermal solved independently.','limits':['Frank/electric/material/anchoring migrations inherited','Fixed smooth sector and local minimum, no global defect stability','New electrode/SiNx contact process unverified','32pilot thermal interpolation is not high-resolution source convergence'],'inputs':frozen}
 (a.out/'results.json').write_text(json.dumps(result,indent=2));assert all(sha(ROOT/k)==v for k,v in frozen.items());(a.out/'postflight.json').write_text(json.dumps({'all_frozen_inputs_match':True}))
def optics(a):
 from experiments import q2_finish_decouple_20261105_solid_interface as original
 r=json.loads((a.fields/'results.json').read_text());cfg=r['parameters'];assert r['complete']and cfg['pattern']==a.pattern
 s=original.source;start=s.index("  if kind=='driven':layers=");end=s.index('\n  S=[',start)
 s=s[:start]+"  if kind=='driven':layers=[(iso(support),8.)]+electrode+body+electrode+[(iso(support),4.)]\n  else:layers=[(iso(support),4.)]+body+[(iso(support),8.)]"+s[end:]
 old="c,cc=cell('compensator',0,ti,lam);t,ct=cell('thermal',0,ti,lam);after,err=coupled.cascade(c,t);gap=coupled.uniform_layer(complex(old.index('Al2O3_Franta',np.array([lam]))[0]),1.8,float(lam),lam*qx,lam*qy);after,er_gap=coupled.cascade(gap,after);err=max(err,er_gap)";assert s.count(old)==1;s=s.replace(old,"after,ct=cell('thermal',0,ti,lam);cc=0.;err=0.")
 if a.pattern=='binary':
  s=s.replace("shift=-.25 if kind=='thermal' else (.25 if kind=='compensator' else 0.)","shift=-.25 if kind=='thermal' else 0.")
  s=s.replace("p=2*np.pi*xx[:,None]+u+(np.pi/2 if kind=='compensator' else 0.)","p=u")
 # Thermal spatial/axis rotation in existing separable generator remains unchanged.
 s=s.replace("'main_layer_count':19","'main_layer_count':12").replace("'physical_supports':5","'physical_supports':3")
 namespace=original.base.__dict__;exec(s,namespace);a.d=cfg['driver_d_um'];a.bias=BIAS;a.order=4;a.slices=32;a.dense=True;a.shard=0;a.shards=1
 deps=[Path(__file__).resolve(),a.fields/'fields.npz',a.fields/'results.json',ROOT/'runs/20261105-q2-finish-material-ZnO-hires-input-01/ZnO2022_Fig5d_hires_exactnodes_tail_linear_scenario.csv',ROOT/'data/q2_finish_material_20261105/SiNx_spectrum/DLC_4keV_vector_digitized.csv',ROOT/'data/nk/Al2O3_Franta.csv',ROOT/'data/q2_current/Li2005_E7_Cauchy.csv',ROOT/'data/q2_parallel_loss_20261105/Wu2002_E7_graph_alpha_k.csv'];frozen={str(p.relative_to(ROOT)):sha(p)for p in deps};(a.out/'launch.json').write_text(json.dumps({'parameters':cfg,'inputs':frozen},indent=2));(a.out/'effective_optics_source.py').write_text(s)
 namespace['optics'](a);j=json.loads((a.out/'results.json').read_text());j.update({'scope':'New12entity two-cell phase/redesigned electrode construction; truefourstates','physical_override':{**cfg,'main_layer_count':12,'not_certified':r['limits']+['127pilot is not dense certification']},'temperatures_C':[25,50],'main_layer_count':12,'physical_supports':3});(a.out/'results.json').write_text(json.dumps(j,indent=2));assert all(sha(ROOT/k)==v for k,v in frozen.items());(a.out/'postflight.json').write_text(json.dumps({'all_frozen_inputs_match':True}))
def main():
 p=argparse.ArgumentParser();p.add_argument('action',choices=['source','optics']);p.add_argument('--pattern',choices=['eight','binary'],required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--nx',type=int,default=32);p.add_argument('--nz',type=int,default=17);p.add_argument('--maxiter',type=int,default=1800);p.add_argument('--warm',type=Path);p.add_argument('--fields',type=Path);p.add_argument('--grid',type=Path);a=p.parse_args();a.out=a.out.resolve();a.out.mkdir(parents=True,exist_ok=False);(a.out/'source.py').write_bytes(Path(__file__).read_bytes());globals()[a.action](a)
if __name__=='__main__':main()
