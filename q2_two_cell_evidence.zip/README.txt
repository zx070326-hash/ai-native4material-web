Python3 + NumPy2.x: python -X utf8 verify.py
Saved-spectrum arithmetic only; no field/Maxwell solve. Full source/input identities and local run paths are in the research repository. Primary sources and transfer limits remain in the prior Q2 materials audit.
